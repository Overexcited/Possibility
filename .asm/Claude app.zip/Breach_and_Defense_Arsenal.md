# BREACH AND DEFENSE ARSENAL
## Richard Ian Kurek v. Independent State of Papua New Guinea
### National Court of Justice — Human Rights Track

---

## Purpose

This document serves two functions in one reference:

- **Part A — Breach Analysis:** 142 breaches counted, organized by agency, officer, and legislative instrument. Of these, roughly 27 are directly actionable, independently founding a head of damage; the remaining ~115 are real, fully documented findings of institutional misconduct that establish bad faith, defeat good-faith defences, and support exemplary damages and indemnity costs, without standing as independent causes of action on their own — see "Breach Categorisation" below for the full breakdown.
- **Part B — Defense Responses:** Every anticipated State defense pre-assessed with layers engaged, provisions, evidence, and ready-to-deliver counter-submissions — including the four-prong income loss framework (Defense 3F).

| Situation | Action |
|---|---|
| State advances a known anticipated argument | Go to Part B. Find the matching defense number. Deliver the three-layer response as written. |
| State advances an unanticipated argument | Run it against the Critical Notices for Counsel checklist below. Identify which layers are engaged. Construct response using the template. |
| Court asks about a specific breach count | Go to Part A. Find the count by agency, legislation, and officer. |
| Costs application after proceedings | Use Part A breach counts + Part B layer 2 findings to document the full scope of State misconduct for indemnity costs purposes. |

---

## The Five-Layer Framework

| Layer | Description | Governing Provisions |
|---|---|---|
| 1 | Facts selectively presented to distort the narrative (cherry-picking). | PCR 1989 General Duty; NCR Order 8; Constitution s.59 |
| 2 | False conclusion derived from true premises. | PCR 1989; NCR Order 8; ss.59, 62; Wednesbury (d)(e) |
| 3 | Material facts deliberately omitted. | PCR 1989; s.59; NCR Order 8; Discovery obligations |
| 4 | Oppressive or disproportionate conduct within proceedings. | Constitution ss.41, 25; NCR Order 22 |
| 5 | Constitutionally prohibited outcome pursued. | ss.57, 58; CBASA s.12; NCR Order 12 r.40; Premdas |

---

# PART A: BREACH ANALYSIS

## CASE 1 — PNGICSA: 81 Counts

---

### a. Constitution of Papua New Guinea (PNGICSA) — Counts a1–a16

| Count | Section | Breach | Officer | Period |
|---|---|---|---|---|
| a1 | s.37 | Ongoing denial of protection of the law — systematic 5-year failure to process validated refund + manufactured visa crisis | ICA institutionally | Apr 2021 – present |
| a2 | s.41, s.37 | False 50% refund claim made without policy basis | Sapaka | 11 Jun 2021 |
| a3 | s.41, s.37 | Endorsement of false 50% claim; intimidation threat of prosecution | Repo | 20 Sep 2021 |
| a4 | s.41 | Forfeiture declaration using ICA's own obstruction as justification | Jack | 5 Jun 2025 |
| a5 | s.41 | Refusal to offset visa fee against confirmed debt — manufacturing overstay crisis | ICA/Louma | Jun–Aug 2025 |
| a6 | s.41 | Compliance Team referral as retaliatory act | Louma | 15 Aug 2025 |
| a7 | s.53 | Ongoing unlawful withholding of K1,000 bond — no just terms, no legislative basis | ICA institutionally | 9 Mar 2020 – present |
| a8 | s.53 | Forfeiture declaration — attempted permanent extinguishment of validated property right | Jack | 5 Jun 2025 |
| a9 | s.37 (protection of the law), s.59 (definitional support only — Premdas) | 50% refund rate determination — no reasons, no notice, no appeal process | Sapaka/Repo | Jun–Sep 2021 |
| a10 | s.37, s.59 (definitional support) | Failure to process refund after formal validation — no adverse decision, no reasons | ICA/Sapaka | Apr 2021 – Oct 2023 |
| a11 | s.37, s.59 (definitional support) | Forfeiture declaration — no prior notice, no reasons citing any legislation, no hearing | Jack | 5 Jun 2025 |
| a12 | s.37, s.59 (definitional support) | Visa extension refusal pending fee payment — no formal decision letter, no appeal rights | ICA/Louma | Jun–Aug 2025 |
| a13 | s.37, s.59 (definitional support) | Compliance Team referral — no notice to Richard of basis | Louma | 15 Aug 2025 |
| a14 | s.41 | Manufactured visa crisis creates direct threat to unity of family of three PNG-citizen children — National Goal 1(5) (family unit as fundamental basis of society) is not raised as a standalone breach (non-justiciable, s.25(1)) but informs the severity of this s.41 breach via the interpretive mandate at s.25(2)–(3) | ICA institutionally | Ongoing |
| a15 | s.41 (harsh/oppressive conduct — direct, independent basis, see Prong 5: does not ask whether Richard had a movement right, only whether the State's conduct was disproportionate; also reinforced by consequential harm from the children's established s.52 breach, Prong 6) | Richard's administrative captivity — 10 years' de facto confinement, harsh and oppressive regardless of citizenship | ICA institutionally | 2024 – present |
| a16 | s.37 | PNGICSA repeatedly failed to provide: basis for 50% claim; basis for forfeiture; reasons for visa refusal — framed as s.37 (protection of the law), not s.51 (freedom of information): s.51 is citizen-restricted ("every citizen") and this information concerned Richard's own bond/visa matters, not a children's-document request, so s.51 would carry a standing gap s.37 does not | Multiple officers | 2021 – present |

---

### b. ICSA Act 2010 (as amended 2021) (PNGICSA) — Count b17

| Count | Section | Breach | Officer |
|---|---|---|---|
| b17 | s.36 | Ongoing unlawful retention of bond funds without Ministerial approval and without lawful purpose | ICA institutionally |
*PFMA 1995 s.61 does not exist in the certified consolidated text — any reliance on it should be dropped.*

*Count b17 — analogous authority: in Punga Limited v Madang District Development Authority (N10995, 2024), a government authority received funds earmarked for the plaintiff and refused to release them without justification; the National Court found this an enforceable breach and ordered specific performance of their release. The case was decided on contract and specific-performance grounds rather than a constitutional cause of action, but the result confirms PNG courts will order a government agency to release funds it has no lawful basis to continue withholding.*

---

### c. Migration Act (Chapter 16) / Consolidated 2023 (PNGICSA) — Count c18

| Count | Provision | Breach | Officer |
|---|---|---|---|
| c18 | s.16(1)(e) — **POTENTIAL CRIMINAL OFFENCE** | Deliberate misrepresentation to General Manager Kapus: falsely attributed Wewak Treasury direction to Sapaka; omitted both Port Moresby visits; omitted own November 2023 commitments; omitted CMO instruction from same email thread. **Counsel: assess criminal referral.** Kapus's own response, on receiving both Repo's account and Richard's immediate documented refutation, was to request a copy of the bond receipt — she never acknowledged the contradiction and never responded further (Affidavit para. 55). | Repo — 2 Oct 2024 |

---

### d. PSMA 1995 + General Order 15 (PNGICSA) — Counts d19–d54

#### Ezekiel Sapaka — 10 Counts

| Count | Offence | Provision | Evidence |
|---|---|---|---|
| d19 | Wilful disobedience of Acting CMO's signed written instruction from 24 November 2022. Richard was never informed of the subsequent officer transfer to Metro — he continued following up through Sapaka's chain of responsibility without response throughout the transition period, compounding the harm. | PSMA s.51(d); GO 15.19(c) | CMO instruction 24/11/22; no action taken |
| d20 | Negligence / total failure to execute refund process Apr 2021 – Oct 2023 | PSMA s.51(e)(f); GO 15.19(d)(e) | Email record |
| d21 | GO 15.58 — failure to respond: 5 May 2021 | GO 15.58 | Email record |
| d22 | GO 15.58 — failure to respond: 25 May 2021 | GO 15.58 | Email record |
| d23 | GO 15.58 — failure to respond: 21 July 2021 | GO 15.58 | Email record |
| d24 | GO 15.58 — failure to respond: 28 May 2022 | GO 15.58 | Email record |
| d25 | GO 15.58 — block non-response Nov 2022 – Oct 2023 | GO 15.58 | Email record |
| d26 | Misconduct — false 50% refund claim without documentary basis | PSMA s.51(i); GO 15.19(h) | Email 11/06/2021 |
| d27 | Failure to brief Gabriel Metro upon transfer | PSMA s.51(f) | Email/in-person evidence |
| d28 | Disrespectful conduct at ICA counter, second Port Moresby visit | PSMA s.51(i) | Richard's statement |

#### Patrick Repo — 7 Counts

| Count | Offence | Provision | Evidence |
|---|---|---|---|
| d29 | Misconduct — endorsing false 50% claim; fabricating fee category distinction with no legislative basis | PSMA s.51(i); GO 15.19(h) | Email 20/09/2021 |
| d30 | Conduct unbecoming — threatening Richard with prosecution to suppress legitimate complaint | PSMA s.51(i) | Email 20/09/2021 |
| d31 | Serious misconduct — deliberate misrepresentation of case history to General Manager Kapus | PSMA s.51(i); GO 15.19(h) | Email 02/10/2024 |
| d32 | Negligence — failure to supervise Sapaka's compliance with 26/04/2021 commitments | PSMA s.51(e) | Email record |
| d33 | Negligence — failure to ensure Sapaka "fast tracked" per Repo's Nov 2021 promise | PSMA s.51(e) | Email record |
| d34 | GO 15.58 — failure to respond: 28 May 2022 | GO 15.58 | Email record |
| d35 | GO 15.58 — multiple non-responses Nov 2023 – Sep 2024 | GO 15.58 | Email record |

#### Gabriel Metro — 7 Counts

| Count | Offence | Provision | Evidence |
|---|---|---|---|
| d36 | Misconduct — representing Treasury letter was written, signed, approved, and delivered when no such letter was ever produced | PSMA s.51(i); GO 15.19(h) | Email/in-person evidence |
| d37 | Negligence — failure to brief himself on case upon assuming responsibility from Sapaka | PSMA s.51(e) | In-person evidence |
| d38 | Negligence — failure to process refund after taking over Oct 2023 | PSMA s.51(e)(f) | Email record |
| d39 | GO 15.58 — failure to respond: 1 November 2023 | GO 15.58 | Email record |
| d40 | GO 15.58 — failure to respond: 15 November 2023 | GO 15.58 | Email record |
| d41 | GO 15.58 — failure to respond: 27 March 2024 | GO 15.58 | Email record |
| d42 | GO 15.58 — failure to respond: 18 July 2024 | GO 15.58 | Email record |

#### "Jack" — 2 Counts

| Count | Offence | Provision | Evidence |
|---|---|---|---|
| d43 | Serious misconduct — unlawful forfeiture declaration under fabricated 10-year rule, four years after formal validation | PSMA s.51(i); GO 15.19(h) | Email 05/06/2025 |
| d44 | Deliberate refusal of lawful fee offset while withholding client's own confirmed funds | PSMA s.51(i) (deliberate refusal fits "improper conduct" more precisely than "negligent/careless," which implies an unintentional failure) | Email 05/06/2025 |

#### Shirley Louma — 8 Counts

| Count | Offence | Provision | Evidence |
|---|---|---|---|
| d45 | GO 15.58 — failure to respond: 11 March 2025 (3 months) | GO 15.58 | Email record |
| d46 | GO 15.58 — failure to respond: 19 March 2025 | GO 15.58 | Gmail transcript |
| d47 | GO 15.58 — failure to respond: 5 June 2025 | GO 15.58 | Email record |
| d48 | GO 15.58 — failure to respond: 21 July 2025 | GO 15.58 | Gmail transcript |
| d49 | GO 15.58 — failure to respond: 29 July 2025 | GO 15.58 | Gmail transcript |
| d50 | GO 15.58 — failure to respond: 7 August 2025 | GO 15.58 | Gmail transcript |
| d51 | GO 15.58 — failure to respond: 13 August 2025 | GO 15.58 | Gmail transcript |
| d52 | Possible abuse of process — retaliatory Compliance Team referral | PSMA s.51(i) | Email 15/08/2025 |

#### Kessie Kapus — 2 Counts

| Count | Offence | Provision | Evidence |
|---|---|---|---|
| d53 | Negligence — supervisory failure 5+ years after the claim's validity was confirmed on her advice, April 2021 (April 2021 – present) | PSMA s.51(e) | Email record (continuous) |
| d54 | Failure to act on presented evidence — 2 Oct 2024, sole response was to re-request already-available document | PSMA s.51(f) | Email 02/10/2024 |

---

### e. Public Servants Oath (PNGICSA) — Counts e55–e64

| Count | Point | Act | Officer |
|---|---|---|---|
| e55 | Point 3 — avoid deception | 50% refund fabrication | Repo |
| e56 | Point 3 — avoid deception | Deliberate misrepresentation to Kapus, 2 October 2024 | Repo |
| e57 | Point 3 — avoid deception | Fabrication of "Treasury letter delivered" | Metro |
| e58 | Point 3 — avoid deception | Fabricated 10-year forfeiture rule | Jack |
| e59 | Point 4 — deal honestly with client | 50% refund fabrication | Repo |
| e60 | Point 4 — deal honestly with client | Treasury letter fabrication | Metro |
| e61 | Point 4 — deal honestly with client | Forfeiture declaration | Jack |
| e62 | Point 4 — deal honestly with client | False claim Richard should pursue Wewak Treasury independently | Repo/Sapaka |
| e63 | Point 1 — loyal service to the State | Defiance of Acting CMO's 2022 directive; Richard never notified of officer transfer to Metro (also independently covered by PSMA s.51(d)/GO 15.19(c), entry #32) | Sapaka |
| e64 | General Purpose (Code preamble — combat corruption; unethical behaviour includes "abuse of position and power... at the expense of the people and the Country") | Collective 5-year pattern of obstruction, deception, and manufactured extortion | All named officers |

---

### f. Wrongs (Misc. Provisions) Act (Ch.297) (PNGICSA) — Counts f65–f70

| Count | Provision | Basis |
|---|---|---|
| f65 | Misfeasance in Public Office (common law tort; State vicariously liable under Wrongs Act s.1(1)(a)) | Officers exercised public power with deliberate or reckless disregard for its unlawfulness and consequent injury. Established by: Sapaka's CMO defiance; Repo's Kapus misrepresentation; Jack's unauthorised forfeiture; sustained bad-faith obstruction of validated claim. |
| f66 | Negligence (common law tort; State vicariously liable under Wrongs Act s.1(1)(a)) | ICA owed duty of care from moment it undertook to process the claim. Breached repeatedly. Damages: two Port Moresby trips; legal costs; daily accumulating penalties; family distress. |
| f67 | Unjust Enrichment (equitable/restitutionary doctrine — general law; not a Wrongs Act s.1 tort claim) | State holds K1,000 to which it has no legal entitlement under its own policy and has purported to permanently retain through unlawful forfeiture. |
| f68 | s.1A — Sapaka personal liability | Defying Acting CMO's lawful written instruction placed Sapaka's actions categorically outside his lawful duties. Personally liable for harm caused during and after that period. |
| f69 | s.1A — Metro personal liability | Representing a Treasury letter had been written and personally delivered — if false as evidence strongly suggests — constitutes conduct outside his lawful duties. |
| f70 | s.1A — Jack personal liability | Declaring bond forfeit under a non-existent legal rule constitutes conduct plainly outside scope of authority and outside any lawful instruction. |

**Chain of responsibility, and its limit.** The record establishes a clear chain: Sapaka as the immediate processing officer (the false 50% claim, non-response, and defiance of the Acting CMO's written 24 November 2022 instruction to process the refund "as usual," itself unenforced); Repo as the supervising Manager over Sapaka and later Metro (endorsing the false claim, failing to supervise, then misrepresenting the history to Kapus); Metro as the officer who assumed the file (the Treasury-letter representation, never produced, and non-processing). Each is independently pleaded above. What the record does not establish, and what should not be asserted, is that anyone above Kapus or the Acting CMO ever received notice of this conduct. Kapus's own response to Repo's 2 October 2024 misrepresentation — set out at Count c18 — is the last point of contact reflected in the evidence.

---

### g. Lukautim Pikinini Act / Child Welfare (PNGICSA) — Counts g71–g73

| Count | Provision | Basis |
|---|---|---|
| g71 | s.4 — Best interests of child | Manufactured visa crisis creates direct and imminent threat to unity of family. Threatening to deport children's primary carer over a manufactured K255 debt when ICA owes Richard K1,000 — flagrant disregard for children's best interests. |
| g72 | s.6 — Right to live with parents | Three children have right to live with their father. Manufactured visa crisis directly threatens this right. |
| g73 | s.7 — Duty to maintain | By trapping Richard in undocumented status and withholding K1,000 from a non-working dependent household, ICA actively obstructs the family's ability to maintain and protect their children. |

---

### h. Other Instruments (PNGICSA) — Counts h74–h81

| Count | Instrument | Basis |
|---|---|---|
| h74 | Frauds & Limitations Act s.16 — misapplication | The FLA is a procedural bar only — it bars the right to sue after time; it does not forfeit property to the State. No forfeiture provision exists in the FLA or any applicable Act. Additionally: (1) The primary argument is that the formal validation of the claim by General Manager Kapus on 26 April 2021 constitutes a written acknowledgment of the debt, which under the Act's own s.7 ("Fresh accrual of action on acknowledgement or part-payment") deems the right of action to have accrued on the date of that acknowledgment, not before — making the current FLA deadline April 2027, well in the future. This is not a general-law fallback; it is the express mechanism the Act itself supplies for exactly this situation, applied on materially identical facts in *Hobert Gopmi v Robin Calistus* (2025) N11476 (Dowa J): a part payment acknowledging a debt was held to reset the FLA clock under s.7(1), the claim proceeding within six years of that later date rather than the original transaction. (2) FLA s.22 extends the limitation period for a person "under a disability" (defined at s.22 to include anyone under 21) until six years after the disability ends — irrelevant to Richard's own claim but decisive for James, Zach, and Brighton's, whose limitation clocks have not even started; (3) Even without the acknowledgment, the forfeiture declaration of 5 June 2025 was made before any limitation period could have run on the bond itself. The FLA creates no power of forfeiture; it is a procedural bar only. Jack's declaration does not invoke the FLA — it invokes a fabricated 10-year rule that exists nowhere in any legislation. |
| h75 | Organic Law — Ombudsman: Sapaka | Abuse of office and breach of duty — CMO instruction defiance. |
| h76 | Organic Law — Ombudsman: Repo | Abuse of office — deliberate misrepresentation to Kapus. |
| h77 | Organic Law — Ombudsman: Jack | Deliberate unfair treatment and breach of duty — forfeiture declaration. |
| h78 | Organic Law — Ombudsman: Systemic | Systemic failure to provide adequate reasons for 50% claim, forfeiture, and visa refusal. |
| h79 | Leadership Code: Kapus | Failure to exercise supervisory responsibility — failure of leadership obligations. |
| h80 | Leadership Code: Repo | Deliberate misrepresentation to superior; fabrication of policy — misuse of position and conduct bringing public office into disrepute. |
| h81 | Judicial Proceedings (Interest on Debts and Damages) Act 2015 (No. 15 of 2015), ss.2, 4, 6, 7 | Interest on the K1,000 bond runs from the maturity date of 9 March 2020 until payment. This Act repealed the predecessor Act (Chapter 52) (s.7) and applies to Court Orders made against the State on or after 1 January 2014 (s.2), covering this claim. Section 4(1) leaves the pre-judgment rate at the court's discretion between private parties, but s.4(2) caps it at 2% yearly wherever "proceedings... are taken against the State" — expressly including proceedings arising from breach of contract or mercantile usage. Section 4(3) confirms that 2% ceiling holds even where a contract or mercantile usage specifies a higher rate. Section 4(4) makes a judgment entered contrary to ss.4(2)–(3) a **nullity**, liable to be set aside on application by the State's lawyer, the court registrar, or any party — the 2% figure is jurisdictional, not a guideline to be argued around. Section 6 mirrors this structure for post-judgment interest: s.6(2) caps it at 2% yearly against the State, and s.6(5)(a) provides that no interest is payable on a judgment for damages against the State at all until a Certificate of Judgment is *served* on the State — the clock for post-judgment interest starts at service, not at the judgment date. This full statutory text, together with its application, is confirmed directly by *Jolpuk v Kabilo* (2023) N10309 (Tamade AJ, 15 May 2023), a slip-rule ruling that quotes ss.4 and 6 verbatim and recalculates a prior judgment's interest at 2% accordingly; the Supreme Court reached the same result independently in *Wereh v Wamuk* (2023) SC2487, holding an 8% award against the State erroneous for the same reason. A further National Court decision, *Hobert Gopmi v Robin Calistus* (2025) N11476 (Dowa J), confirms the practical reach of the cap beyond the National State in the narrowest sense: interest against a Local-Level-Government-descended statutory authority (Lae District Development Authority/Lae City Authority) was assessed at 2%, the Court treating that entity within the same interest regime as the State proper — directly relevant here, since PNGICSA and PNGCIR are themselves statutory authorities, not the State in the narrow sense. By contrast, *Yame Yame Ltd v Honunga Plant Hire* (2024) N11086 (Collier J) confirms the other side of the same line: between purely private parties, with no State or State-entity defendant at all, 8% remains the ordinary rate — "the general approach... is that a defendant will be ordered to pay interest at the rate of 8%." Read together, the four decisions confirm the 2% ceiling is specific to State and State-entity defendants, not a general feature of the Act. Counsel should press for the full 2% under s.4 for the pre-judgment period, plus post-judgment interest under s.6 running from service of the Certificate of Judgment, but should not plead for or expect anything above 2%. *Pinzger v Bougainville Copper Ltd* [1985] PNGLR 160 and *Sausau v PNG Harbours Board* N3255 support the general principle that interest is awardable on a withheld sum, but both predate the 2015 Act and its 2% State ceiling and are not authority for any rate above it. Counsel to calculate the exact figures — pre-judgment under s.4 and post-judgment under s.6 — as at the date of filing using the 2% rate throughout. |

---

## CASE 2 — PNGCIR: 61 Counts

---

### i. Constitution of Papua New Guinea (PNGCIR) — Counts i82–i101

| Count | Section | Breach | Period |
|---|---|---|---|
| i82 | s.36 — Freedom from inhuman treatment | PNGCIR's refusal trapped family in high-crime environment causing knife assault (Exhibit N). James witnessed assault, documented psychological trauma. Basic Rights Preamble cl.(a) ("security of the person") supports this reading as an interpretive aid only, not as an independent cause of action — Constitution s.24 confines Preamble material to use as "an aid to interpretation," and the enforcement mechanism at s.57(1) is expressly scoped to "a right or freedom referred to in this Division" (Division 3, ss.32–62). The Preamble sits outside Division 3, so it cannot itself ground a claim; s.36, the numbered provision that operationalises Preamble cl.(a)'s "security of the person" language, is the operative and only basis used. s.35 (Right to life) was considered and is not used: it requires deprivation of life, and s.35(1)(b) is a self-defence exception available to a person who kills, not a cause of action for a survived assault. | 2016 – present (ongoing) |
| i83 | s.36 — Freedom from inhuman treatment | Living conditions: unreliable electricity and running water, open fire cooking, contaminated bore water causing recurrent Staphylococcus aureus infections, inadequate medicine, and a home situated within 200 metres of at least six violent clan conflicts (two at the property's own front gate, with gunfire having entered the yard) — Affidavit para. 21. The same conditions produced further physical harm to the children specifically: untreated scabies infections over ~2.5 years causing permanent scarring to all three children (Exhibit O), Brighton's improperly-set broken arm causing permanent deformity (Exhibit P), and James's scarring from a fall on unlit stairs during a power outage (Exhibit Q). | 2016 – present (ongoing) |
| i84 | s.37 — Protection of the law | Denied protection by: impossible condition not authorised by law; cancellation without notice or reasons or appeal; false information about appeal rights; mandatory obligation treated as discretionary. | 2018–2026 |
| i85 | s.41 | Demanding work permit impossible for non-working visa holder | 2020+ |
| i86 | s.41 | Cancelling application B1914006387 "due to foreign case" without notice after 2 years | Aug 2020 |
| i87 | s.41, s.37 | Falsely telling Richard there is no right of appeal | Post-Aug 2020 |
| i88 | s.41, s.37 | Lying about the Wewak NID office closure | 2020/2021 |
| i89 | s.52 — James | Freedom of movement denied — no birth certificate for passport | Mar 2016 – present (~10 years, ONGOING) |
| i90 | s.52 — Zach | Freedom of movement denied — no birth certificate for passport; post-issuance passports unaffordable | Jun 2021 – present (~5 years, ONGOING) |
| i91 | s.52 — Brighton | Freedom of movement denied — no birth certificate for passport; post-issuance passports unaffordable | Jun 2021 – present (~5 years, ONGOING) |
| i92 | Consequential harm from Counts i89–i91 (children's s.52 breach) — not framed as an independent s.42 claim (see Arsenal Prong 6) | Richard's inability to leave with his family for a decade is a direct, provable consequence of the children's established s.52 breach — he could not and did not abandon dependent children who were themselves unable to leave. Feeds s.41 (severity/disproportionality) and s.58 (damages) directly; does not require its own constitutional gap-filler. | 2016–2026 (~10 years, ONGOING) |
| i93 | s.52 — Serah | Freedom of movement denied — unable to travel with children lacking passports | 2016–2026 (~10 years, ONGOING) |

*Counts i89–i91, i93 — s.52 is a discrete, independently compensable right, including on a continuing/per-occasion basis: in Wandi Dope v Constable Michael Malai (2012) N4574 (Cannings J), repeated infringements of a Div III.3 right, including s.52, were compensated separately per occasion rather than as one undifferentiated sum.*
| i94 | s.53; s.51 (further alternative, untested) | Three children deprived of birth certificate documents (property rights / legal identity) without just terms. s.51 also applies: citizenship is automatic by law at birth, so CRA s.25's "shall be registered" is a non-discretionary, ministerial duty to record an already-existing fact, not a discretionary act creating new status — the certificate is the legally-prescribed vehicle carrying that pre-existing information, which the children were unconditionally entitled to access. Withholding the document withheld the information itself, and it was that informational gap — not any independent decision — that made passport applications and departure impossible. The only PNG case directly construing s.51, *Mesulam v Joku* (SCA No 84 of 2022, Supreme Court, 29 Nov 2023 — the Court's own description, "first of its kind" to interpret s.51), operates entirely within an existing-document/exemption framework (a two-pronged test for whether an agency's refusal to disclose a document it holds is justified) — it does not address, and gives no support for, extending s.51 to a document that was never created. This is consistent with s.51's own structure: s.51(1) (the operative, self-executing right) is framed as access to documents subject to ten exemption categories that all presuppose an existing record; the broader, format-agnostic "official information" language sits in s.51(3), which is not itself a directly enforceable right — it directs Parliament to pass enabling legislation establishing access procedures, and no such legislation has ever been passed. The reading this argument needs is the dormant one, not the operative one. CRA s.25's mandatory registration duty is the cleaner, tested route to the same result and does not depend on this extension. Nothing compensable turns on s.51's fate here: — s.53 (the certificate as property), s.52 (the movement consequence, a right to a state of affairs rather than to a document, so it was never subject to this problem), and the Wrongs Act negligence claim at Count o134 (breach of the CRA-defined standard of care) independently cover this harm. s.51 was always the fourth and weakest of four routes to the same result, not the only one. | 2018–2026 |
| i95 | s.37, s.41 | Work permit required of foreign-national father only; mother excluded from witnessing her own children's registrations | 2018–2026 |

*Count i95 — framed under s.37 (protection of the law) and s.41 (harsh/oppressive conduct), not s.55 (Equality of citizens): s.55(1) protects citizens against unequal treatment among themselves on specifically enumerated grounds only — race, tribe, place of origin, political opinion, colour, creed, religion, sex. It is not a "every person" provision like ss.36/37/41/59/62, so Richard (non-citizen) cannot invoke it directly, and "married to a non-citizen" is not an enumerated ground on which Serah (a citizen) could invoke it either. The same conduct — excluding Serah from her own children's registration proceedings, demanding a work permit only of Richard — is fully captured by s.37 and s.41, both already used elsewhere for the same officer conduct.*
| i96 | s.37, s.59 (definitional support) | Cancellation of B1914006387 — no notice; 2 years of silence | Aug 2020 |
| i97 | s.37, s.59 (definitional support) | Work permit demand — no legislative authority cited; no opportunity to challenge | 2020+ |
| i98 | s.37, s.59 (definitional support), Civil Registration Act s.9 | Denial of appeal rights — contrary to Civil Registration Act s.9 | Post-Aug 2020 |
| i99 | s.37, s.59 (definitional support) | Refusal to provide Registrar-General's contact — denying avenue of redress | During complaint call |
| i100 | s.37, s.59 (definitional support) | Repeated non-responses to written complaints | 2020–2024 |
| i101 | s.37 (work permit basis — Richard's own matter); s.51 via the children's own right, Richard requesting as their representative (Registrar-General contact; appeal rights under CRA s.9 and Amendment Act s.37C(14) — these concern the children's registration, not Richard's) | Nancy Dilu refused: Registrar-General contact; legal basis for work permit demand; information about appeal rights under CRA s.9 and Amendment Act s.37C(14) | Multiple occasions |

*Counts i89–i91 and i93 do not cite s.42: s.52 alone is sufficient for the children and Serah as confirmed citizens.*

> **Ongoing violation note:** Birth certificates were issued **27 April 2026**, but the freedom of movement violation **remains active**: a decade of PNGCIR-imposed captivity, deepened by PNGICSA's bond withholding and manufactured visa crisis, has left passport applications unaffordable (est. 1-2 years to save). Richard's unlawful overstay status, combined with the active Compliance Team referral (15 August 2025), now creates a real risk of deportation — separating him from his children and leaving Serah unable to simultaneously work and solely care for them, the outcome his decade in captivity was endured to prevent. The late certificate issuance itself constitutes an implicit admission that all years of prior refusal had no lawful basis (see Defense 2B for the no-new-documentation argument).

> **Deportation as institutional self-contradiction:**
>
> Deportation would compel the very outcome the law forbids a parent from choosing — Lukautim Pikinini Act 2015 s.7 (child's right to live with parents), s.8 (Richard's duty to maintain them), Criminal Code Act s.284 (Duty of Head of Family — a person with charge of a child under 14 in his household must provide the necessaries of life) and s.283 (general Duty to Provide Necessaries) — through State machinery the same Act binds against producing it.
>
> **Distinguishing *Independent State of PNG v Uddin* [2022] PGSC 109; SC2312 directly, since the State will likely cite it:** Uddin is the closest reported PNG case on similar facts (non-citizen parent, PNG-citizen family, deportation risk) and it went against the applicant on appeal — but for a specific, stated reason that doesn't apply here. The Supreme Court found "absolutely nothing to show" the Minister's conduct departed from ordinary immigration policy, because Uddin was a genuine illegal entrant, convicted of unlawful entry, unappealed (¶42-44). That is precisely what this argument does not rest on: Richard's overstay, if it materialises, traces directly to PNGICSA's own established bad-faith refusal to offset a confirmed debt (Defense 1G), not to any unlawful conduct of his own. Uddin also confirms (Premdas, adopted by the Court at ¶61-65) that there is no right to be heard on a deportation decision as such — that specific complaint is not made here and should not be. The argument made here is narrower and does not depend on it: a deportation triggered by a State-manufactured predicament is the "no reasonable body" case Uddin itself says would succeed (¶38), not the ordinary-law-enforcement case it says would not.
>
> The Act expressly binds the State (s.3, "Act Binds the State", per the Act's Arrangement of Sections, Part I — Preliminary; commencement confirmed via a Lukautim Pikinini Regulation gazetted under the Act's authority, National Gazette G96-126, 2021).
>
> Deportation would place PNGICSA, acting for the State, in the position of producing the precise condition the same State is bound under the same Act to prevent. The harm is not speculative, and would not simply continue but measurably worsen: the documented conditions (poverty, unreliable electricity and running water, continuing exposure to endemic community violence, medical deprivation — Affidavit paras. 21, 64–67) are currently offset, at significant and sustained personal cost, by Richard's own labour — additional cleaning and hygiene work, supplementing the children's education, wound care in an environment poorly suited to it. Deportation would remove that mitigation along with him.
>
> This argument depends on the overstay itself being recognised as State-manufactured rather than Richard's own default — it is: see Defense 1G, which establishes on two independent grounds (Wednesbury bad faith and economic duress) that the overstay was engineered by PNGICSA's own refusal to offset a confirmed debt it owed him.

---

### j. Civil Registration Act 1963 (PNGCIR) — Counts j102–j106

| Count | Section | Breach |
|---|---|---|
| j102 | s.25 — Births required to be registered | PNGCIR treated mandatory statutory obligation ("shall be registered") as discretionary and refused registration for years. No cancellation power exists. |
| j103 | s.9 — Right of appeal | Nancy Dilu directly and falsely told Richard and Serah there was no right of appeal. Express statutory right denied. |
| j104 | s.16 — Registrar not required to verify | PNGCIR imposed additional verification (work permit) beyond prescribed particulars — no authority under this provision. |
| j105 | s.27 — Delayed registration | s.27 empowers the Registrar to direct an informant of a birth more than a year old to apply to a District Court Magistrate for consent to register — a specific, named mechanism built for exactly this situation. PNGCIR never invoked it, instead inventing an impossible work-permit condition and cancelling the application. |
| j106 | s.59(3)(a)(d), s.59(4)(a) — Offences and Penalties | Providing false information (s.59(3)(a)); concealing/denying information to prevent registration (s.59(3)(d)) — Nancy Dilu. s.59(4)(a) reaches Dilu's refusal to register James directly: "The Registrar or a Registration Officer who omits or refuses without reasonable cause to register... a birth... that, by this Act, he is required to register... is guilty of an offence." Penalty under either subsection: fine up to K500 or imprisonment up to six months. s.59(5) creates a statutory continuing-offence mechanism ("the offence shall be deemed... to continue so long as the person refuses or fails to comply... a further offence... each day"); its text ties it to a duty "to give any information within a particular period," mapping most directly onto the s.59(2)/(3) informant-duty offences, and is offered as reinforcement for the Habolo/Wialu continuing-duty argument (Defense 1G). |

---

### k. Civil Registration (Amendment) Act 2014 (PNGCIR) — Counts k107–k110

| Count | Section | Breach | Period |
|---|---|---|---|
| k107 | s.37C(3) | By imposing impossible condition on mandatory registration, PNGCIR caused Richard and Serah to potentially be in breach of s.37C(3), which makes failure to register a criminal offence. State exposed family to criminal liability through its own unlawful conduct. | 9 March 2016 – 27 April 2026 |
| k108 | s.37C(14) | Nancy Dilu explicitly told Richard and Serah there was no right of appeal. This section expressly provides for appeal when a registration application is rejected. Direct misrepresentation of statute. | 4 September 2020 (Affidavit paras 32–34) |
| k109 | s.3(6), as substituted by Civil Registration (Amendment) Act 2014 s.4 | The Registrar-General is mandated to establish an office in each province: "The Registrar-General shall facilitate the establishment of an Office of the Registrar-General in each province headed by a Provincial Registrar" — mandatory, not discretionary. No functioning office exists in East Sepik Province (Wewak). Statutory breach materially contributed to registration failures. Reinforced by s.37B(3) ("The Office of the Registrar-General shall be responsible for the administration and governance of the National Civil Register") and s.37D(2) ("The Office of the Registrar-General shall be responsible for the collection, maintenance and use of all information obtained during registration") — both independently mandatory, institutional-level duties on the Office itself, not on any individual counter officer. | 9 March 2016 – late 2017 (Affidavit paras 25–26) |
| k110 | Civil Reg. Amendment Act 2014 s.3(6) + s.37C(2) — Pre-Application Barrier and Systems Failure | PNGCIR's official website was non-functional for approximately 1–2 years during the period when Richard and Serah were attempting to lodge James's birth certificate application. No NID office existed in Wewak in breach of s.3(6). Without access to the required forms, document checklist, lodgement address, or procedural instructions, the application could not be lodged. This is not merely a s.3(6) office-location failure — it is independently a breach of s.37C(2): "The Registrar-General shall establish procedures and processes for collection, storage and maintenance of a person's information through a computer network system, supported by appropriate technology under the regulations." The non-functional website and absent lodgement procedure are precisely the "procedures and processes... supported by appropriate technology" this provision mandates. The State created the very barrier preventing timely exercise of the mandatory registration right it simultaneously claimed the parents had a duty to exercise under s.37C(1) ("A person shall be registered in accordance with this Act"). The obligation to register ran from birth (9 March 2016) — not from the date the State eventually made it possible to apply. | PNGCIR institutionally — pre-2018 |

**The "flows up the chain" principle — why Counts k107–k110 are not merely officer-level misconduct.** Responsibility here does not stop at the individual counter officer. Four distinct statutory levels are engaged: (1) the individual officer's immediate conduct; (2) the administrative system and procedures the officer was operating within; (3) the provincial registration infrastructure s.3(6) mandates; (4) the Registrar-General's own Office-level duties under ss.37B(3), 37C(2), and 37D(2) for the systems, technology, and institutional machinery beneath that infrastructure. The same underlying failure — no functioning way to lodge or process a birth registration in Wewak for 1–2 years — is simultaneously a breach at every one of these levels, because each level's duty was a precondition for the one below it functioning at all. This matters for causation specifically: the counterfactual is not speculative. Richard and Serah did not merely intend to register James — they possessed the required documents, attempted to lodge them, and were told the process could not proceed because the mandated provincial mechanism did not exist. Removing that one statutory failure from the sequence is not inventing a hypothetical; it is restoring the sequence the Act itself required. The resulting chain — mandatory statutory duty unperformed → registration infrastructure failure → registration contravention → absent birth certificate → passport documentation unmet → departure prevented → prolonged exposure to the conditions in the Affidavit → constitutional and economic harm — is supplied by the statute and the documentary record at every link, not by inference stacked on inference.

**Statutory basis flag — Count k107's date range crosses a disputed change in the governing Act, and the dispute itself may be useful.** The Civil Registration Act 1963 and its 2014 Amendment (the source of s.37C throughout B2–B3) were certified for repeal and replacement by the Civil and Identity Registration Act 2024 (No. 21 of 2024) on 23 December 2024. Two things are both true here and should not be collapsed into each other. First: the 2024 Act is treated and described as being in effect by practically everyone with a public voice on the subject — a Prime Ministerial launch event in mid-May 2025, national press coverage reporting it as in force, a new PNGCIR corporate plan and logo, and PNGCIR's own ongoing description of itself as operating under it since. Second: none of that is evidence that the Act was actually brought into legal force. Under the Interpretation Act's ordinary mechanism for an Act expressed to commence "in accordance with a notice in the National Gazette," the public launch and the legal commencement are separate events, and only the second one determines which statute actually governed PNGCIR's conduct on any given day. Despite repeated, differently-angled searches, no Gazette notice — number, date, or text — has been located for this Act, and nothing found addresses the Act's status in Gazette terms at all; every source located describes the rollout, not the legal trigger. That gap between near-universal practical treatment and unverifiable legal footing is itself worth building into the case: if the Act was never validly gazetted, the old Civil Registration Act (Chapter 304, as amended 2014) remains the governing statute for the entire period alleged, including the post-May-2025 portion, and s.37C(3) continues to apply throughout Count k107's full range without needing to locate any 2024-Act equivalent at all. Counsel should put PNGCIR to strict proof of the Gazette notice if it seeks to rely on the 2024 Act for any post-May-2025 conduct.

---

### l. Employment of Non-Citizens Act 2007 (PNGCIR) — Counts l111–l112

| Count | Section | Breach |
|---|---|---|
| l111 | s.6 — Work permit obligation | Richard is on non-working visa; cannot be employed; cannot hold a work permit. PNGCIR demanded the legally impossible. Ultra vires condition imposed without any legislative authority. |
| l112 | Employment of Non-Citizens Act 2007, s.6(1)–(2) — No employment relationship exists | s.6(1) makes it an offence for an *employer* to employ a non-citizen without a valid work permit (fine up to K20,000); s.6(2) separately makes it an offence for the *non-citizen employee* (fine up to K10,000). Both presuppose an actual employment relationship existing in the first place. Richard has none in a birth registration context — there is no employer for either subsection to attach to. PNGCIR's demand doesn't just target the wrong party; it invokes a statutory scheme not engaged by these facts at all. *Wolfgang Bandisch v National Capital District Botanical Enterprises Ltd* (2009) N3806 confirms it is the employer's responsibility to secure a work permit before the non-citizen commences employment (at [27]-[30], construing ss.6, 18 of this Act) — the obligation runs to an existing or intended employment relationship, which does not exist here. This is a distinct Act from the separate 1978 Public Employment (Non-Citizens) Act, which governs the State's own public-service hiring and is not the one engaged here. |

---

### m. Other Statutory Instruments (PNGCIR) — Counts m113–m117

| Count | Instrument | Section | Breach |
|---|---|---|---|
| m113 | Lukautim Pikinini Act 2015 | s.3 — Act Binds the State. Not s.6, which is the Convention on the Rights of the Child incorporation cited at Count m117. | State (PNGCIR) failed to be bound by child protection principles. |
| m114 | Lukautim Pikinini Act | s.7 — Right to live with parents | Threatened by PNGICSA's manufactured visa crisis against primary caregiver. No action by PNGCIR to expedite registration that would have resolved this. |
| m115 | Lukautim Pikinini Act | s.8 — Duty to maintain | State actions prevented family from exercising earning capacity, obstructing parental duty. |
| m116 | Passports Act 1982 | s.4(1)(c), s.4(2)(b) | Refusal to enable passport eligibility for three children over extended periods. s.4(1)(c) requires an application to "include any other matters or particulars as may be required by the Minister," and s.4(2)(b) requires it to "be accompanied by such matters as are prescribed" — these are the statutory hooks under which the birth-certificate requirement sits (specified at Regulation level, not in the Act itself, which is standard). s.6 governs parental consent for minors' applications, not documentary eligibility, and is not relied on here. |
| m117 | Convention on the Rights of the Child | Art.7 — Right to identity, registration, and nationality | Incorporated via Lukautim Pikinini Act s.6. All three children denied registration at birth and for years thereafter, directly violating their right to be registered immediately after birth and to acquire a name and nationality. State bound by Convention. |

---

### n. PSMA 1995 + General Order 15 — Officer Counts (PNGCIR) — Counts n118–n132

#### Nancy Dilu — 7 Counts

| Count | Offence | Provision |
|---|---|---|
| n118 | False statement — lied about Wewak NID office closure | PSMA s.51(i); Oath Point 3 |
| n119 | False statement — misrepresented cancellation reason | PSMA s.51(i) |
| n120 | False statement — denied existence of appeal rights contrary to CRA s.9 and Amendment Act s.37C(14) | PSMA s.51(i); GO 15.19(h) |
| n121 | Refused to provide Registrar-General's contact details | PSMA s.51(f) |
| n122 | Hung up on Richard during complaint call — disgraceful conduct | PSMA s.51(i) |
| n123 | Admitted PNGCIR fault but stated "will not take responsibility" — deliberate obstruction | PSMA s.51(i) |
| n124 | Admitted widespread training failures at Wewak NID were known to management | PSMA s.51(i) |

#### Benjamin Kepino — 3 Counts

| Count | Offence | Provision |
|---|---|---|
| n125 | GO 15.58 — complete non-response to formal complaint email | GO 15.58 |
| n126 | GO 15.58 — non-response to follow-up correspondence | GO 15.58 |
| n127 | Failure to investigate and act on formal complaint | PSMA s.51(e)(f) |

#### Unnamed Compliance Officer — 4 Counts

| Count | Offence | Provision |
|---|---|---|
| n128 | Requiring work permit — impossible and ultra vires demand | PSMA s.51(i) |
| n129 | Wrong information on visa classes — no knowledge of Special Exemption Visa | PSMA s.51(e) |
| n130 | Repeatedly failing to sign emails — obscuring identity during formal complaint | PSMA s.51(i) |
| n131 | 4-month response delay August 2024 | GO 15.58 |

#### Joanna Seiweni — 1 Count

| Count | Offence | Provision |
|---|---|---|
| n132 | Acknowledged fault December 2024 but took no corrective action | PSMA s.51(f) |

**Chain of responsibility, and its limit.** The record establishes a clear chain on this side too: Dilu as the Port Moresby officer (contradictory statements about documents on file, denial of an existing appeal right, the work-permit demand, refusal to provide Registrar-General contact details); Kepino as the Compliance Officer to whom the 15 September 2020 formal complaint was sent and never acknowledged; the unnamed Compliance Team officers who handled the later applications and maintained the same improper demands; and the Registrar-General as the statutory office-holder bearing the mandatory systems duties under CRA (Amendment) 2014 s.3(6) and s.37C(2) pleaded at Counts k109–k110 — duties on the Office itself, not on any individual counter officer. Formal complaints and escalations reached Dilu, Kepino, Seiweni, and the Compliance Team. What the record does not establish, and what should not be asserted, is that the Registrar-General personally received and failed to act on a formal notice of this specific, prolonged non-registration.

---

### o. Wrongs Act / Oath / Other (PNGCIR) — Counts o133–o142

*Count o133's "s.1A" citation, and the equivalent PNGICSA officer counts (f68–f70), rely on the Wrongs (Miscellaneous Provisions) Act (Consolidated: 11/9/2023) s.1A, added by amendment No. 12 of 2022, s.2, which provides personal liability for an agent or servant of the State whose acts or omissions are outside scope of duties, outside course of duty, or not in accordance with lawful instructions, subject to CBASA s.5A.*

| Count | Instrument | Breach |
|---|---|---|
| o133 | Wrongs Act s.1A — Nancy Dilu personal liability | Misfeasance: knowingly provided false information about appeal rights; lied about Wewak closure; admitted fault but refused to act. |
| o134 | Negligence (common law tort; State vicariously liable under Wrongs Act s.1(1)(a)), PNGCIR institutionally | Duty of care from acceptance of James's application Nov 2018. Breached by: 2 years without contact; cancellation without notice; impossible conditions; denial of appeal rights. |
| o135 | Wrongs Act s.1(4) — Vicarious liability | All PNGCIR officer acts performed in purported official capacities using official channels, application numbers, and colour of official authority. |
| o136 | Public Servants Oath Point 3 | Deception — false cancellation reason (Nancy Dilu) |
| o137 | Public Servants Oath Point 3 | Deception — false information on appeal rights (Nancy Dilu) |
| o138 | Public Servants Oath Point 3 | Deception — false information on Wewak office closure (Nancy Dilu) |
| o139 | Public Servants Oath Point 4 | Dishonesty with client — impossible work permit demand (unnamed compliance officer) |
| o140 | Public Servants Oath Point 2 | Failure to uphold laws, regulations and general orders — acknowledged fault but refused to act in accordance with statutory obligations (Joanna Seiweni) |
| o141 | Public Servants Oath Point 3 | Lack of openness and transparency — unnamed compliance officer concealed identity during formal complaint process, preventing the applicant from identifying or challenging the decision-maker; directly contrary to Point 3's obligation to "be open, transparent and loyal to the public interest in all my dealings" |
| o142 | General Purpose (Code preamble — combat corruption; unethical behaviour includes "abuse of position and power... at the expense of the people and the Country") | Collective failure to register three births for years — brings public service into disrepute |

*Note: The Civil Registration (Amendment) Act 2014 s.37C(3) criminal-exposure point — that PNGCIR's own impossible condition exposed the family to criminal liability for non-registration — is captured at Count k107 above. s.37C(3) is not a Constitutional provision and is not separately repeated here.*

---

---

## NOTE TO COUNSEL: ROLE OF THE OATH BREACHES AND BREACH CATEGORISATION

### A. Role of the Public Servants Oath Counts

The Public Servants Oath counts included in this analysis are **not independent causes of action**. The Oath is an internal instrument under the Public Services (Management) Act 2014. Breach of the Oath creates disciplinary liability within the public service framework — grounds for termination, referral to the Ombudsman Commission, or personal censure — but does not confer a private right of action in the National Court.

Their function in this case is **evidentiary and aggravating**:

1. They demonstrate that the conduct of each named officer was not merely administrative error — it constituted a personal breach of a solemn undertaking sworn to the State.
2. They support **bad faith findings** across the board, which are relevant to the misfeasance in public office count (Wrongs Act s.1) and the exemplary damages threshold under CBASA s.12.
3. They undermine any **good faith defence** available to individual officers under ICSA Act s.47 and its PNGCIR equivalent.
4. They support the **indemnity costs application** by demonstrating the severity and continuity of the institutional misconduct.
5. They strengthen the **narrative weight** of the case before the court — a judge reading that every officer involved breached the oath they personally swore will assess the institutional conduct in a different light than if the same facts were presented purely as statutory violations.

**Importantly**, Point 3 of the Oath — *"be open, transparent and loyal to the public interest in all my dealings"* — was violated by virtually every act and omission documented across both agencies: every non-response, every verbal-only communication to avoid a paper trail, every fabricated policy position, every concealment of identity, every misrepresentation, every ignored instruction, every manufactured procedural barrier. This is not limited to the specific counts cited — it is the underlying character of the institutional conduct throughout. Counsel may wish to address this as a **systemic institutional breach** in submissions, rather than limiting it to individual officer-level citations.

---

### B. Breach Categorisation — Actionable Heads of Damage vs. Weight of Misconduct

The 142 counted breaches serve two distinct functions. The table below separates them:

**Category 1 — Directly actionable: lead to heads of damage**
These breaches are the foundation of the damages claim. Each connects directly to a recognised head of damage under PNG law.

| Head of Damage | Primary Breach Counts | Legal Basis |
|---|---|---|
| Loss of income / earning capacity | counts f65, f66, i92, m115 | Constitution s.41 (confinement as harshness, Prong 5) and consequential harm via children's s.52 breach (Prong 6) as primary; LP Act s.8 (Prong 4); Wrongs Act negligence (Prong 2). Not s.48: Premdas directly contradicts a s.48 employment-freedom basis. |
| Loss of freedom of movement | counts a15, i89–i93, m116 | Constitution s.52; Passports Act s.4(1)(c), s.4(2)(b) |
| Bond debt / unjust enrichment | counts a7, a8, b17, f67 | Constitution s.53 (Richard — further alternative, see Defense 1H); ICSA Act ss.13, 35–36 (PFMA s.61 was considered and found not to exist — see Defense 1H — and is not relied upon) |
| Physical harm (violence, injury, illness) | counts i82, i83 | Constitution s.36 (inhuman treatment) — primary; Wrongs Act negligence as fallback. Basic Rights Preamble cl.(a) ("security of the person") supports this reading as interpretive aid only (Constitution s.24) — see Count a1's note |
| Psychological harm | counts i82, i83, f66 | Constitution s.36 — primary; Wrongs Act s.1 negligence as fallback |
| Educational deprivation (children) | *Pled via narrative and Affidavit only — no distinct numbered count* | LP Act ss.14–16 |
| Family separation / bereavement | counts i92, i93, a15 | Constitution s.52 — the movement breach that prevented travel to attend the funeral (Affidavit para 78), with Richard's own loss framed as consequential harm (Prong 6). Not s.35 (Right to Life requires a State-caused death; this was a natural death from cancer) or s.53 (no property in issue) |
| Out-of-pocket expenses (Port Moresby trips, phone costs, printing, transport, informal loans) | counts f65, f66, o133, o134 | Constitution s.58 (reasonable damages for resulting harm) — primary; Wrongs Act s.1 negligence as fallback |
| Visa overstay / manufactured enforcement crisis | counts a4–a6, a12, a13, d43, d44 | Constitution s.41 — via s.23(2)/s.155(4) for Counts a4–a6 (stand alone, no accompanying enumerated right); via s.52/Prong 6 for Counts a12–a13 (s.58 available through that route); ICSA Act |
| Exemplary / aggravated damages | All misfeasance and bad faith counts | CBASA s.12; sustained bad faith across 142 counts; **institutional indifference following written admission of fault** — Joanna Seiweni (PNGCIR Compliance Team) acknowledged fault in writing 5 December 2024, with no remedial action taken since; the gap between admission and inaction is itself aggravating conduct, independent of and additional to the underlying 142 counts |

**Category 2 — Weight and aggravation: strengthen the case without being independent heads of damage**
These breaches do not independently found a damages claim but they:
- Demonstrate sustained, deliberate, institutionalised bad faith
- Elevate the conduct from administrative negligence to misfeasance
- Support exemplary damages by establishing severity and continuity
- Undermine any good faith defence
- Support indemnity costs

This category includes:
- All Public Servants Oath counts (PNGICSA e55–e64; PNGCIR o136–o142)
- PSMA 1995 / General Order 15 individual officer conduct counts (PNGICSA d19–d54; PNGCIR n118–n132) — these overlap with actionable counts but their primary function is to map the institutional culture
- The s.37C(3) criminal-exposure point (Count k107, Civil Registration (Amendment) Act 2014 — not a Constitution provision, and not double-counted as a separate entry; see B7 note above) — demonstrates the perversity of the State's position: PNGCIR's own impossible requirements exposed the family to criminal liability for non-registration while simultaneously preventing registration
- The Ombudsman Commission's failure to progress the formal registered complaint (documented in emails) — not a count against the respondents but relevant to laches and the reasonableness of the delay in commencing proceedings
- The PSC complaint of 2 October 2024 (documented in emails) — PSC declined to proceed once informed Richard was not a PNGICSA employee. Not a count against the respondents, and not evidence PSC failed its own mandate (its jurisdiction runs to employees and the employing agency, not to affected third parties) — but relevant to the same laches/reasonableness-of-delay narrative, and to showing that no internal accountability channel was in fact open to someone in Richard's position
- Migration Act counts (PNGICSA c18) — Repo's misrepresentation and the potential s.16(1)(e) criminal-referral dimension demonstrate the pattern of deception rather than founding a separate damages head
- Organic Law / Ombudsman and Leadership Code counts (PNGICSA h75–h80) — institutional accountability failures across officers, supporting the systemic bad-faith characterization
- Constitution s.59 (natural justice) counts, used throughout both cases — the volume and consistency of natural justice failures across years and officers is what elevates the conduct from negligence to misfeasance, rather than each instance separately founding damages
- Constitution s.37 (protection of the law) counts, used throughout for information-denial conduct concerning Richard's own matters — support the same bad-faith characterization. s.51 (freedom of information) is used narrowly and only via the children's own right (Richard as their representative), since s.51 is citizen-restricted and does not reach Richard's own standing; Dilu's refusal of Registrar-General contact and appeal-rights information (Count i101) is the clearest fit, since that information concerned the children's own registration

---

### C. What the Email Evidence Confirms

The email archive (Exhibits J and F, and supporting materials) provides **self-authenticating documentary confirmation** of the following, each of which aligns precisely with the affidavit:

**PNGCSA — Confirmed by emails:**
- Sapaka's validation email of 26 April 2021 ("your claim is valid") — Exhibit J ✅
- Kessie Kapus copied on that validation — Exhibit J ✅
- Repo's 50% fabrication and prosecution threat — Exhibit J ✅
- Repo's November 2021 apology and fast-track commitment — Exhibit J ✅
- Metro's letter commitment of October 2023 — Exhibit J ✅
- Repo's October 2024 misrepresentation to Kapus — Exhibit J ✅
- PNGICSA's complete 11-month silence (September 2024 – August 2025 email chain) ✅
- Jack's forfeiture declaration of 5 June 2025 — Exhibit J ✅
- Louma referral to Compliance — Visa extension email chain ✅
- Richard's 11 March 2025 offset request — Visa extension email chain ✅
- PSC complaint of 2 October 2024 — PSC declined to proceed once informed Richard was not a PNGICSA employee ✅

**PNGCIR — Confirmed by emails:**
- Richard's 2 September 2020 email to Nancy Dilu — unanswered — Exhibit F ✅
- Kepino complaint of 15 September 2020 — never acknowledged — Exhibit F ✅
- PNGCIR Compliance's work permit demand of 23 May 2022 — on official letterhead — Exhibit F ✅
- PNGCIR Compliance's mother-as-witness restriction — same email — Exhibit F ✅
- Seiweni's 5 December 2024 acknowledgment of fault — Exhibit F ✅
- February 2026 Rocket Computer Services enquiry re printing delay (applications lodged August 2024, still unprinted February 2026) — Serah emails ✅

**Ombudsman — Confirmed by emails:**
- Grimbai contact of 7 September 2020 ✅
- Formal complaint submission of 15/27 September 2020 ✅
- Grimbai's January 2021 acknowledgment that he had read the complaint but "forgot" ✅
- April 2021 registration confirmation ✅
- October 2024 re-engagement — complaint form resent ✅
- August 2025 comprehensive submission to Ombudsman ✅
- No substantive response at any stage ✅

---

## Combined Totals

| # | Legislation / Instrument | PNGICSA | PNGCIR | Total |
|---|---|---|---|---|
| 1 | Constitution of PNG | 16 | 20 | 36 |
| 2 | ICSA Act 2010 (+2021 Amendment) | 1 | — | 1 |
| 3 | Migration Act (Ch.16) / 2023 | 1 | — | 1 |
| 4 | PSMA 1995 + General Order 15 | 36 | 15 | 51 |
| 5 | Public Servants Oath | 10 | 7 | 17 |
| 6 | Wrongs (Misc. Provisions) Act (Ch.297) | 6 | 3 | 9 |
| 7 | Civil Registration Act 1963 | — | 5 | 5 |
| 8 | Civil Reg. Amendment Act 2014 | — | 4 | 4 |
| 9 | Employment of Non-Citizens Act 2007 | — | 2 | 2 |
| 10 | Passports Act 1982 | — | 1 | 1 |
| 11 | Lukautim Pikinini Act 2015 | 3 | 3 | 6 |
| 12 | Convention on the Rights of the Child (via LP Act s.6) | — | 1 | 1 |
| 13 | Frauds and Limitations Act 1988 | 1 | — | 1 |
| 14 | Organic Laws (parallel forum, not National Court counts) | 6 | — | 6 |
| 15 | Judicial Proceedings (Interest on Debts and Damages) Act 2015 | 1 | — | 1 |
| | **GRAND TOTALS** | **81** | **61** | **142** |

---

# PART B: ANTICIPATED STATE DEFENSES AND COUNTER-SUBMISSIONS

## PNGICSA DEFENSES — Case 1

---

### DEFENSE 1A: "The State is not vicariously liable for the conduct of individual officers."

**Layers:** 2, 3, 5
**Provisions:** Constitution ss.57, 58; CBASA s.12; Premdas [1979] PNGLR 329; Wrongs Act ss.1(1)(a), 1(4) (alternative only)
**Evidence:** 5-year institutional pattern across 6 named officers. CMO signed instruction. All conduct via official government email accounts and positions.

**Counter-Submission:**
> This is a constitutional claim under ss.57 and 58 directly against the State — it does not depend on establishing vicarious liability at all. In the alternative, if the State raises a vicarious liability argument regardless, Wrongs Act s.1(4) covers torts committed "while performing or purporting to perform" State functions — unauthorized acts are covered. The sustained 5-year institutional pattern across 6 officers warrants exemplary damages under CBASA s.12(1) under either route. In Premdas v The State [1979] PNGLR 329 the National Court's remedial power under s.57 was described as unlimited. The outcome the State seeks — no accountability for proven sustained rights violations — is constitutionally foreclosed. Once misconduct by a named officer acting in an official capacity is shown, the onus shifts to the State to prove the officer's conduct was "totally removed from the domain of their authorised actions" — *Willie Gawi and Olga Kari v The State* (2012) N4814 (Cannings J).

**Pleading precision required (alternative route only):** if the Wrongs Act s.1(1)/(4) route is pleaded, s.1(1) and s.1(4) must be specifically identified in the statement of claim, together with an express allegation that each named officer acted "in the course of" or "while purporting to perform" their duties — generic references to State liability are not enough. *Kisa v Talok* [2017] PGSC 51; SC1650 dismissed an appeal on this exact defect, holding it incurable even at the Supreme Court. This is squarely why the primary route above (a direct s.57/58 constitutional claim against the State, not dependent on vicarious liability at all) is the safer lead pleading.

---

### DEFENSE 1B: "Officers acted outside their authority, therefore the State is not responsible."

**Layers:** 1, 2, 3, 5; Wednesbury (c)(e)
**Provisions:** Constitution ss.37, 41, 57, 58, 62; Sir Brown Bai v Tomscoll (2015) N6112; Wrongs Act ss.1(4), 1A (alternative only)
**Evidence:** All officer conduct performed using official email accounts, positions, and letterhead. Harm had legal effect exclusively as State acts for 5+ years.

**Counter-Submission:**
> The constitutional claim under ss.57 and 58 does not depend on this argument at all. In the alternative, if the State raises it regardless: Wrongs Act s.1(4) expressly covers acts done "while purporting to perform" State functions — unauthorized acts are the State's liability. Applying Wednesbury from Sir Brown Bai v Tomscoll (2015) N6112: the acts complained of fail test (c) — operated on the basis of bad faith — and test (e) — so absurd no reasonable person would act that way. The State is advancing a position that contradicts the legal effect its own acts produced for 5 years. That is itself an arbitrary and capricious position engaging Constitution s.62.

---

### DEFENSE 1C: "The bond was lawfully forfeited under the 10-year rule."

**Layers:** 1, 2, 3, 4, 5; Wednesbury (a)(c)(d)(e); Constitution s.62
**Provisions:** Frauds & Limitations Act s.16; ICSA Act ss.35, 36; Constitution ss.37, 41, 53, 59, 62; CBASA s.12; Sir Brown Bai v Tomscoll (2015) N6112
**Evidence:** Jack's forfeiture email 5 June 2025 (Exhibit J). No forfeiture provision in any applicable Act. CMO instruction validating claim (Exhibit K). PNGICSA's own published 100% refund policy (Exhibit I). East Sepik Treasury Receipt C27794 (Exhibit H).

**Counter-Submission:**
> No forfeiture provision exists in the ICSA Act, Migration Act, or any applicable legislation — confirmed for the Migration Act by direct review of its complete consolidated text (Chapter 16, consolidated 26/4/2023): the word "forfeit" does not appear anywhere in the Act. Applying Wednesbury from Sir Brown Bai v Tomscoll (2015) N6112, Jack's declaration fails all four applicable tests: (a) it disregards the relevant statutory framework entirely; (c) it was made in bad faith using a fabricated legal rule; (d) it fails to direct itself properly in law as no forfeiture provision exists anywhere; (e) declaring a validated debt forfeit under a non-existent rule is so absurd no reasonable person would act that way. Constitution s.62 is directly engaged. Jack's email cited no provision and gave no reasons for the forfeiture beyond the invented rule itself — a further, independent defect: the Supreme Court in *Mision Asiki v Manasupe Zurenuoc* (2005) SC797 holds that the duty to give reasons for an administrative decision is integral to natural justice, and where no adequate reasons are given, the court is to infer that none existed. The Frauds and Limitations Act creates no power of forfeiture and is inapplicable — Jack did not invoke it; he invented a fabricated 10-year rule that exists in no legislation. In any event, no limitation period was ever running against the underlying bond debt in the first place: PNGICSA's obligation to refund is a continuing duty it remains bound to discharge, and a continuing failure to perform a continuing duty has no accrual date until the duty is actually performed — the claim does not depend on any tolling analysis to survive. *Habolo Building & Maintenance Ltd v Hela Provincial Government* (2016) SC1549 confirms this is not merely argued from principle: for a continuing occurrence, the relevant date runs from day to day, not from when the conduct was first committed — followed and applied by a later Supreme Court panel in *Augus Wialu v John Andreas & The State* (2020) SC1970, which extended the same day-to-day accrual reasoning to a Frauds and Limitations Act s.16 limitation defence, not only to CBASA s.5 notice. Even treating the claim as subject to the Frauds and Limitations Act's general limitation period, that period was in any event reset by General Manager Kapus's formal written acknowledgment of the debt on 26 April 2021 — the Act's own s.7 deems the right of action to accrue afresh from the date of a written acknowledgment of the debt, making the current deadline April 2027. This institutional liability does not depend on any individual officer's personal exposure surviving a limitation analysis — the State's own continuing default in refunding a debt it has itself confirmed is a live, present breach regardless of which individual officer's specific acts are separately assessed. A limitation period bars a remedy; it does not retroactively convert unlawful conduct into lawful conduct — even if a personal claim against Jack for the forfeiture declaration itself were ever found to be time-barred, the declaration remains unlawful permanently, and the State's continuing failure to correct what it produced (the bond still withheld) is a fresh, live breach regardless. In the further alternative, even if a lawful forfeiture power existed (which is denied), its exercise here would remain voidable for economic duress: the declaration followed PNGICSA's own refusal to apply the confirmed debt against fees it simultaneously demanded, using its regulatory position to manufacture the very default the forfeiture then penalised (see Defense 1G).

---

### DEFENSE 1D: "Officers acted in good faith and are protected under ICSA Act s.47."

**Layers:** 2; Wednesbury (c); Constitution s.62
**Provisions:** ICSA Act s.47(1); PSMA s.51; Constitution s.62; Sir Brown Bai v Tomscoll (2015) N6112
**Evidence:** Sapaka: defied CMO signed instruction 12+ months. Repo: deliberately misrepresented case history to Kapus, omitting facts present on same email thread. Metro: fabricated Treasury letter. Jack: invoked legal rule that does not exist.

**Counter-Submission:**
> ICSA Act s.47(1) limits protection to acts done in good faith. Bad faith is established independently for each officer. Applying Wednesbury test (c) from Sir Brown Bai v Tomscoll (2015) N6112: each named act "operated on the basis of bad faith or dishonesty." Sapaka's 12-month defiance of a direct CMO written instruction is per se bad faith. Repo's deliberate misrepresentation to a superior while the contradicting CMO instruction was attached to the same email thread is per se bad faith. Metro's fabrication of a document never produced is per se dishonesty. Jack's invocation of a legal rule that does not exist is per se bad faith. Section 47 is expressly unavailable to each officer on the established facts. The Wednesbury framework itself does not rest on a single decision: the Supreme Court in *Jack Kariko v Tom Korua* [2020] PGSC 29; SC1939 expressly adopted and applied Associated Provincial Picture Houses v Wednesbury Corporation in quashing a public-service disciplinary dismissal, on facts with a real structural echo here — a whistleblowing subordinate was terminated while the officer actually responsible for the underlying misconduct kept his position, which the Court held unreasonable in the Wednesbury sense precisely because the decision-makers failed to appreciate evidence squarely before them. The same pattern recurs throughout this file: Sapaka, Repo, Metro, Jack and Dilu each escape any internal consequence while the claimant absorbs the cost of their conduct.

---

### DEFENSE 1E: "The claimant failed to follow proper procedure by not attending Wewak Treasury."

**Layers:** 1, 3; Discovery obligations
**Provisions:** Migration Act s.16(1)(e); PCR 1989 General Duty; Constitution s.59
**Evidence:** Repo email 2 October 2024 falsely attributing Wewak direction to Sapaka while CMO instruction disproving this was attached to same thread. Evidence of both Port Moresby visits omitted. CMO instruction directing processing. Repo's November 2021 commitments.

**Counter-Submission:**
> This argument is defeated on four independent grounds by the State's own email record. First: the direction to attend Wewak Treasury was Repo's own direction — Repo's email of 2 October 2024 falsely attributed it to Sapaka while the CMO instruction disproving this was attached to the same thread. Second: the claimant attended Port Moresby on two separate occasions — omitted entirely from this narrative. Third: the Acting CMO's instruction of 24 November 2022 directed processing without Treasury attendance. Fourth: the State's own November 2023 conduct disproves any procedural necessity for personal attendance by the claimant at all — Metro and Repo undertook to prepare a letter and have it delivered to Treasury directly, demonstrating that government-to-government communication between PNGICSA and Treasury was entirely achievable without the claimant's involvement; if PNGICSA could correspond with Treasury's Wewak branch by letter, there was no proper basis to ever require the claimant to personally attend, carry documents, or act as intermediary between two government offices, whether at Wewak or Port Moresby. In any event, Metro's promise to have Port Moresby Treasury process the refund directly was never achievable: by Repo's own admission, the funds sat in the Wewak Treasury RPM account, not the ICSA trust account, meaning Port Moresby held no funds to disburse regardless of any letter or attendance. This is a textbook misrepresentation by omission engaging PCR 1989 General Duty and Constitution s.59. Discovery orders should also be sought for all internal PNGICSA correspondence regarding the Wewak Treasury direction.
>
> **Pre-emptive rebuttal — if the State now produces a Treasury letter it previously claimed to have written and delivered:** this does not rescue the State's position; it creates a three-way trap. (1) If the letter is genuine and dated as claimed, the State has been withholding from the claimant, for over a year, a document authorising release of his own funds — a fresh breach of natural justice and Constitution s.59, and Discovery should be sought for its native file (not a scan) to check creation and last-modified metadata against the claimed date. (2) If forensic metadata shows the document was created after this dispute intensified, that is direct evidence of fabricated evidence in an active claim — a serious matter going to the credibility of every other State representation on this file. (3) If the letter is genuine but was, as Metro undertook, sent to Port Moresby Treasury rather than the Wewak Treasury RPM account where the funds actually sat, its production only confirms the State's own conduct was Wednesbury unreasonable — instructing a document to the one office incapable of acting on it, while telling the claimant to travel to the only office that could. Every branch of this trap independently supports the claimant's position; the State has no version of "producing the letter" that improves its case.

---

### DEFENSE 1F: "The 50% refund rate is established policy."

**Layers:** 1, 2; Wednesbury (a)(c)(d)(e); Constitution s.62
**Provisions:** PCR 1989; NCR Order 8; Constitution ss.59, 62; Sir Brown Bai v Tomscoll (2015) N6112; Barrick (Niugini) Ltd v Nekitel (2020) N8409
**Evidence:** PNGICSA's own published 100% refund policy. No 50% policy document produced by any officer in 5 years of correspondence.

**Counter-Submission:**
> A decision-maker's failure to produce the decision and its reasons itself supports an inference of bad faith and that no good reason exists — *Barrick (Niugini) Ltd v Nekitel* (2020) N8409 (Kandakasi DCJ). Five years of silence on the source of the 50% figure is not an evidentiary gap the State can now fill retrospectively; on Barrick, it is itself evidence against the State's position. This is not a National Court outlier: the Supreme Court's holding in *Mision Asiki v Manasupe Zurenuoc* (2005) SC797 — that the duty to give reasons is integral to natural justice, and that the absence of reasons is itself to be read as proof none existed — has been applied consistently for two decades, most recently in 2025. Barrick and Mision Asiki reinforce each other on the same point from different levels of the court system.
> No document, policy, regulation, or legislative provision establishing a 50% rate has been produced in five years of correspondence. PNGICSA's own published policy establishes 100% refund. The 50% claim was fabricated without documentary basis and endorsed using a fabricated fee category distinction with no legislative basis anywhere. Applying Wednesbury: fails test (a) — no relevant statutory basis; test (c) — bad faith fabrication contradicting own published policy; test (d) — not directed properly in law; test (e) — no reasonable person would determine a 50% rate contradicting their own published 100% policy without any documentary basis. Constitution s.62: arbitrary and capricious in its purest form.

---

### DEFENSE 1G: "The visa overstay situation is the claimant's own responsibility."

**Layers:** 2, 3, 5; Wednesbury (c)(e)
**Provisions:** Constitution ss.37, 41, 52, 57, 58; ICSA Act s.4; Sir Brown Bai v Tomscoll (2015) N6112
**Evidence:** Jack's email 5 June 2025 refusing offset. ICA's own written confirmation of K1,000 debt. Manufactured sequence documented in State's own emails: bond withheld → offset refused → overstay created → compliance referral made.

**Counter-Submission:**
> The overstay was manufactured by PNGICSA through deliberate sequential acts: withholding K1,000 it owes the claimant, refusing to offset that confirmed debt against K255 it claims is owed, then initiating compliance action for the overstay that refusal created. Applying Wednesbury test (c): this operated on the basis of bad faith. Test (e): it is so absurd that no reasonable person would withhold a confirmed K1,000 debt, refuse to apply it against a K255 charge, and then initiate deportation proceedings over the K255 shortfall. This argument asks the court to find the claimant responsible for a situation PNGICSA engineered and documented in its own correspondence.

> This is not an isolated incident of maladministration — it is the same structural pattern already established at Defense 3G: the State creating, through its own unlawful conduct, a binary choice between two things the claimant is independently entitled to, with no justification advanced for the restriction. Here, PNGICSA held Richard's confirmed K1,000 debt while requiring a K255 fee to preserve his lawful status, forcing an election between exercising his right to pay for his own visa application with his own funds and receiving funds it independently owed him — a choice created entirely by the State's own refusal to apply one against the other. The repetition of this pattern across two independent contexts (freedom of movement/parental duty at Defense 3G; funds owed/funds demanded here) is itself probative of a systemic institutional practice, relevant to the severity and continuity threshold for exemplary damages under CBASA s.12(1).

> In the alternative, and independent of the bad-faith finding above: any overstay penalty, forfeiture, or compliance action flowing from Richard's non-payment of the K255 fee is voidable for economic duress. PNGICSA held a confirmed, uncontested debt to Richard, refused to apply it against a smaller sum it simultaneously demanded from him, and then initiated compliance proceedings over the resulting shortfall — using its monopoly position as immigration authority to extract compliance through withheld funds rather than lawful means. A consequence extracted through economic duress cannot stand independently of whether the underlying forfeiture power exists at all (cf. Defense 1C).

---

### DEFENSE 1H: "Richard is not a citizen, so s.53 does not protect his bond from forfeiture."

**Layers:** 2, 5
**Provisions:** Constitution s.53(7); ICSA Act s.36; Constitution ss.37, 41, 58
**Evidence:** Constitution s.53(7) text; PNGICSA's own published 100% refund policy (Exhibit I); ICSA Act s.36 (Count b17)

**Counter-Submission:**
> Constitution s.53(7) does remove the K1,000 bond from s.53's direct constitutional protection, since Richard is not a citizen: "the power to compulsorily take possession of... the property of any such person shall be as provided for by an Act of the Parliament." That subsection does not leave the bond unprotected — it identifies where its protection comes from. That Act of the Parliament is the ICSA Act, s.36 specifically (Count b17: ongoing unlawful retention of bond funds without Ministerial approval or lawful purpose), already argued independently of s.53 (Brief, Part D3). Jack's forfeiture declaration and PNGICSA's ongoing withholding breach that statutory scheme regardless of s.53(7)'s effect on the constitutional route. In the further alternative, Constitution ss.37 (protection of the law, enforceable under s.57) and s.41 (proscribed acts, enforceable under s.155(4)/s.23(2) — Raz v Matane [1985] PNGLR 329) — both "every person," with no equivalent non-citizen carve-out — independently capture the same conduct: an agency disregarding its own published policy and inventing a forfeiture rule denies the protection of the law and is harsh, oppressive and disproportionate regardless of which specific property provision governs. This further alternative doesn't depend on s.36 at all, and is the stronger route if s.36 is contested. s.53(7) narrows the pathway; it does not narrow the outcome. s.53(7) has no application to the birth certificates (Count i94) since the children are citizens.

---

## PNGCIR DEFENSES — Case 2

---

### DEFENSE 2A: "The work permit requirement was a legitimate administrative condition."

**Layers:** 1, 2, 3, 5; Wednesbury (a)(c)(d)(e); Constitution s.62
**Provisions:** Employment of Non-Citizens Act 2007 s.6(1); Civil Registration Act 1963 ss.16, 17, 25; Constitution ss.37, 41, 59, 62; Sir Brown Bai v Tomscoll (2015) N6112
**Evidence:** Richard's Special Exemption Visa (non-working class). Employment of Non-Citizens Act 2007 s.6(1): obligation falls on employers not employees. No work permit requirement anywhere in the registration framework — ss.17 and 25 (the provisions actually governing who must give particulars and what must be registered for a standard compulsory-area birth) contain no such requirement.

**Counter-Submission:**
> Demolished on three independent grounds. First: Civil Registration Act s.16 — the Registrar is not required to verify prescribed particulars, so imposing additional verification beyond prescribed particulars is outside the Act entirely. Second: no work permit requirement appears anywhere in ss.17 or 25 — the provisions that actually govern who must give particulars and what must be registered — or in their prescribed particulars; the demand has no legislative basis. Third and decisively: Employment of Non-Citizens Act 2007 s.6(1) places the work permit obligation on EMPLOYERS. Richard is on a non-working visa. He cannot be employed. He cannot hold a work permit. There is no employer in a birth registration context. PNGCIR demanded what the law prohibits Richard from possessing, based on a fundamental misreading of legislation that does not apply to him. Applying Wednesbury: fails test (a) — irrelevant legislation applied; test (c) — bad faith imposition of impossible condition; test (d) — fundamentally wrong understanding of the law; test (e) — no reasonable person would demand a work permit from a non-working visa holder for birth registration. Constitution s.62: the definition of an arbitrary and capricious administrative condition. PNGCIR never once, across years of repeating the demand, cited a provision for it — a further defect on the Supreme Court's own terms in *Mision Asiki v Manasupe Zurenuoc* (2005) SC797: an unreasoned administrative demand is to be treated as one for which no good reason exists.

---

### DEFENSE 2B: "The applications were cancelled for legitimate administrative reasons."

**Layers:** 1, 2, 3; Wednesbury (a)(c)(d)(e)
**Provisions:** Civil Registration Act 1963 ss.9, 25, 27; Constitution ss.37, 41, 59; PCR 1989; Sir Brown Bai v Tomscoll (2015) N6112
**Evidence:** Application B1914006387 cancelled after 2 years without notice. Reason: "foreign case." No missing documents ever identified. No appeal information provided.

**Counter-Submission:**
> Civil Registration Act s.25: "shall be registered" — mandatory, no discretion, no cancellation power. "Foreign case" appears nowhere in the Act as a ground for cancellation. PNGCIR affirmatively confirmed completeness twice, in writing and in person, before ever citing a missing document as a reason for anything: at lodgement in November 2018, staff confirmed all required documentation had been provided (para. 27); in September 2019, Nancy Dilu confirmed again, when asked directly and twice, that all documents were in order and approval was imminent. Less than twelve months later, with no intervening correspondence of any kind, the same officer cited missing documents as the ground for cancellation. The specific content of that or any subsequent demand is immaterial: an agency that reverses its own affirmative confirmation of completeness without any new event or information has acted arbitrarily by definition, irrespective of what it later claims was missing — as the work permit demand's independent impossibility (Defense 2A) illustrates but does not depend on. Two years of processing without contact preceded silent cancellation. CRA s.27 delayed registration mechanism was not applied. Nancy Dilu then denied an appeal right that expressly exists under CRA s.9 and Amendment Act s.37C(14). The eventual issuance of all three certificates on 27 April 2026 was made on the same documentation already in PNGCIR's possession since each child's original application — no additional documentation beyond what had already been accepted as sufficient at lodgement was ever supplied, despite years of further demands the family could not meet. If the original documentation was sufficient to justify issuance in 2026, no legitimate documentary deficiency ever existed to justify cancellation or refusal in the years prior. Applying Wednesbury: fails test (a) — irrelevant categorization applied; test (c) — bad faith treatment of mandatory obligation as discretionary; test (d) — no cancellation power exists in law; test (e) — so absurd that no reasonable person would cancel a mandatory registration obligation after 2 years without notice, without specifying missing documents, and then deny the existence of an appeal right. Beyond its unlawfulness, the stated ground carries independent weight for severity: "foreign case" is not a defect in James's own application — he is a PNG citizen by descent, and the application concerned only his registration — it is PNGCIR's own record showing that prejudice attaching to Richard's non-citizen status was applied directly to his citizen son's file (Master Brief F4). "Foreign case" and, later, unspecified missing documents were never accompanied by any reasoned decision letter at any point across the whole cancellation — the same defect *Mision Asiki v Manasupe Zurenuoc* (2005) SC797 treats as independently fatal to natural justice, and as itself proof that no good reason existed.

---

### DEFENSE 2C: "Birth registration is a discretionary function."

**Layers:** 2 — direct misstatement of law; Wednesbury (d)
**Provisions:** Civil Registration Act 1963 s.25; Amendment Act 2014 s.37C(3); Constitution ss.37, 57; Sir Brown Bai v Tomscoll (2015) N6112
**Evidence:** CRA s.25(1): "A person referred to in Section 17 shall give to the Registrar, and subject to Sections 27 and 31 the Registrar shall register, the prescribed particulars of the birth of a child that is born in a compulsory registration area..." — mandatory "shall" on both the informant and the Registrar. Amendment Act s.37C(3): failure to register is a criminal offence.

**Counter-Submission:**
> Civil Registration Act s.25(1) uses mandatory language on both sides of the transaction: the parent "shall give," and the Registrar "shall register." There is no discretion. The Amendment Act reinforces this by making non-registration a criminal offence — a function cannot simultaneously be discretionary and criminal to omit. This argument fails Wednesbury test (d): it does not direct itself properly in law. No reasonable reading of "shall" produces "may." Accepting this argument would require the court to rewrite unambiguous legislation.

---

### DEFENSE 2D: "Nancy Dilu's statements were mistakes, not deliberate misconduct."

**Layers:** 2; Wednesbury (c); Constitution s.62
**Provisions:** PSMA s.51(i); Public Servants Oath Points 3, 4; Constitution s.62; Sir Brown Bai v Tomscoll (2015) N6112; Wrongs Act s.1A
**Evidence:** Five separate false statements. Admitted PNGCIR fault, stated "will not take responsibility." Hung up on Richard during formal complaint call. Refused Registrar-General contact details.

**Counter-Submission:**
> A single error might be a mistake. Five separate false statements — including denial of an express statutory appeal right under CRA s.9 and Amendment Act s.37C(14), fabricated Wewak office closure, admission of institutional fault combined with refusal to act, terminating a formal complaint call, and refusing to provide official contact details — establish a pattern inconsistent with innocent error. Applying Wednesbury test (c) from Sir Brown Bai v Tomscoll (2015) N6112: these acts operated on the basis of bad faith or dishonesty. The admission "there's nothing we can do" concedes the underlying error — PNGCIR does not dispute that a wrong occurred — while offering an excuse for not correcting it. That excuse was never borne out: no attempt was made afterward to remedy the admitted error, correct the record, or refer the matter through any of the mechanisms available to the agency for exactly this situation. The words alone do not establish bad faith; the conduct that followed them does — an admitted fault met with no corrective action at all is functionally a refusal to take responsibility, whatever language introduced it. Personal liability applies where acts are outside the scope of duties or contrary to lawful instructions — Wrongs Act s.1A, added by amendment No. 12 of 2022.

---

### DEFENSE 2E: "The delay in birth certificate issuance did not prevent freedom of movement."

**Layers:** 2, 5
**Provisions:** Constitution s.52; Passports Act 1982 ss.1, 6; Civil Registration Act s.25; Namah v Pato (2016) SC1497
**Evidence:** Passports Act s.4(1)(c)/s.4(2)(b): birth certificate required for passport issuance (see Count m116). Three children without certificates for up to 10 years. Border enforcement would have physically prevented departure.

**Counter-Submission:**
> The causal chain is mechanical and established by statute: birth certificate required for passport (Passports Act s.4(1)(c)/s.4(2)(b), see Count m116); passport required for international travel; border enforcement would have physically prevented departure. No alternative pathway exists. This is framed as a s.52 freedom-of-movement violation for the citizen children and Serah (Counts i89–i91, i93); Richard's own inability to leave is framed as consequential harm flowing from that established breach, not as an independent constitutional claim (see Prong 6). The Passports Act establishes the birth certificate/passport nexus as a matter of law, not inference. The freedom of movement violation is established mechanically. The State cannot argue the administrative barrier it created did not have the effect it demonstrably and mechanically produced for up to 10 years.

---

## CROSS-CASE DEFENSES

---

### DEFENSE 3A: "The harm claimed is not connected to State action."

**Layers:** 1, 2, 5
**Provisions:** Constitution ss.52, 57, 58; Lewis v The State (1980) PNGLR 219
**Evidence:** 10 years administrative captivity. Father's death — unable to visit or attend funeral. Knife assault documented by photographs (Exhibit N). James's psychological trauma. Living conditions documented. K1,000 withheld 6+ years with accruing interest.

**Counter-Submission:**
> Every element of harm is causally traceable to a specific State act or failure. Birth certificate refusal caused de facto denial of identity documentation; de facto denial of identity documentation caused passport ineligibility; passport ineligibility caused inability to travel; inability to travel caused isolation, father's death without visit, and prolonged exposure to violent crime resulting in knife assault. PNGICSA's manufactured visa crisis caused continued captivity. Under Lewis v The State (1980) PNGLR 219 economic loss is assessed at what the claimant would have earned. Richard as an Australian citizen with unrestricted right to work in Australia has economic loss calculated at Australian minimum wage rates across 10 years. James's documented psychological trauma from witnessing the knife assault is framed as a foreseeable consequence of the environment of administrative captivity — an aggravating factor supporting general and exemplary damages, not a standalone tort.

---

### DEFENSE 3B: "The claimant has not suffered compensable loss."

**Layers:** 2, 5
**Provisions:** Constitution s.58; CBASA s.12(1) (exemplary damages); Lewis v State; Judicial Proceedings (Interest on Debts and Damages) Act 2015, ss.4(1)–(4), 6(1)–(6) (2% ceiling against the State and State entities, both pre- and post-judgment — *Jolpuk v Kabilo* (2023) N10309; *Wereh v Wamuk* (2023) SC2487; *Hobert Gopmi v Robin Calistus* (2025) N11476)
**Evidence:** Australian earning capacity denied 10 years. Father's death. Documented knife assault. Documented living conditions. Three children denied legal identity up to 10 years (James) and up to ~5 years (Zach, Brighton). James's psychological trauma. K1,000 + 6+ years interest.

**Counter-Submission:**
> Compensable losses established across multiple categories: economic loss (Australian minimum wage rates × 10 years, Lewis v State methodology); general damages (10 years unlawful administrative captivity); special damages (Port Moresby trips, legal costs, accumulating visa penalties); non-economic damages (father's death and funeral, 10-year family separation, documented assault); children's damages (de facto denial of identity documentation, loss of identity, restriction of freedom of movement across multiple years); psychological harm (James — foreseeable consequence of administrative captivity, absorbed into general and exemplary damages). CBASA s.12(1): exemplary damages where breach "so severe or continuous as to warrant" — ten years of multi-rights violation across two agencies meets and exceeds this threshold. Exemplary damages must be specifically pleaded.

---

### DEFENSE 3C: "The claimant should have pursued administrative remedies before bringing proceedings."

**Layers:** 1, 3
**Provisions:** Constitution s.57; NCR Order 23; CBASA
**Evidence:** 58 State-authored emails from official government accounts spanning April 2021 to August 2025. Acting CMO signed instruction 24 November 2022. Two Port Moresby in-person attendances. Formal complaints to compliance officers. Escalation to General Manager level.

**Counter-Submission:**
> The claimant pursued every available administrative avenue for over five years before bringing proceedings. The evidence is the State's own email record — 58 emails across 4+ years from official government accounts, two in-person attendances, formal complaints, General Manager escalation, and a signed CMO instruction — all without resolution. Beyond the department itself, Richard escalated to the Ombudsman Commission (who promised forms and assistance, then repeatedly failed to deliver and eventually went silent), to the Australian Department of Foreign Affairs and Trade, and to the UN Human Rights Council — each of whom was unable to assist due to jurisdictional or diplomatic limitations beyond the claimant's control. Evidence of all escalation attempts is contained in the supporting affidavit. Furthermore, even the initial birth certificate application was delayed by State-created barriers (non-functional website, no Wewak NID office) — time which belongs to the State's infrastructure failure, not the claimant's inaction. The State cannot argue administrative remedies were not exhausted when the full escalation record — from front counter to UN Human Rights — is documented in the claimant's evidence.

---

### DEFENSE 3D: "Richard as an Australian national cannot claim constitutional protections."

**Layers:** All layers; compartmentalization strategy
**Provisions:** Constitution ss.36, 37, 41, 53, 59, 62 ("every person"); GO 15.58 ("members of public"); CRA s.25 ("every birth"); Lukautim Pikinini Act s.6 (Convention on Rights of the Child)
**Evidence:** GO 15.58: "members of the public" — no citizenship restriction. Constitution ss.36, 37, 41, 53, 59, 62 apply to "every person." Freedom of movement claims filed on behalf of PNG-citizen children and Serah.

**Counter-Submission:**
> The claims are compartmentalized and this argument does not apply to any of them. Richard's claims engage ss.36, 37, 41, 59, 62, and s.53 — all apply to "every person" or without citizenship restriction. His economic loss is framed via Wrongs Act negligence (Prong 2, no constitutional right needed) and consequential harm via the children's established s.52 breach (Prong 6), not s.48 — *Premdas v The State* [1979] PNGLR 329 precludes a constitutional employment-freedom basis, and not s.42 or ICCPR Art.12(4), neither of which is relied upon as an independent basis anywhere in this case (see Prong 3's note; ICCPR is confirmed by Constitution s.117(7) to have no direct domestic incorporation, and is used only as s.39(3) interpretive support within Prong 5). The freedom of movement claims under s.52 are filed on behalf of James, Zach, Brighton, and Serah — all PNG citizens. CRA s.25 applies to "every birth" regardless of nationality of father. GO 15.58 confirmed: "members of the public" — no citizenship restriction. The court is being asked to enforce duties the State owed regardless of who presented at the counter. The nationality of the person harmed does not extinguish the breach.

---

### DEFENSE 3E: "We have provided all relevant documents in discovery."

**Layers:** 3; Discovery obligations; PCR 1989; Constitution s.59
**Provisions:** National Court Bench Book citing Credit Corporation v Jee (1988-89) PNGLR 11; PCR 1989 General Duty; Constitution s.59
**Evidence:** 58 State-authored emails. Internal records establishing CMO instruction defied for 12+ months without any internal escalation or remedy. Internal records should include: departmental communications, supervisory records, file notes, policy documents, and all PNGCIR internal communications re registration applications.

**Counter-Submission:**
> The National Court Bench Book states: "A lawyer has a professional responsibility to ensure that his client gives complete discovery. Discovery is not a matter of bargaining or compromising. It is the obligation on a party to supply a list of all the documents which might have any bearing on the subject matter in dispute." The State must produce ALL internal records bearing on this matter — not a curated selection designed to support its narrative. Any selective disclosure is: (a) a breach of the State's discovery obligations; (b) a breach of PCR 1989 General Duty (prejudicial to administration of justice); (c) an objective violation of Constitution s.59 (right to have matter determined on accurate and complete factual basis). Discovery orders must be sought at the earliest opportunity. Where the specific issue is the State's claimed inability to identify the individual behind an official account or role, see Defense 3K.

---

### DEFENSE 3F: "Richard is not a citizen and has no right to freedom of movement in PNG, therefore the State is not liable for his economic loss." [FOUR-PRONG INCOME LOSS FRAMEWORK]

**Layers:** 1, 2, 3, 5; four of the original six prongs remain independent (Prong 1/s.48 withdrawn — Premdas; Prong 3/ICCPR withdrawn as a standalone basis — s.117(7), folded into Prong 5 as interpretive support — see below) — the State must defeat all four to escape liability for this head of damage
**Provisions:** Constitution s.41 (Prong 5, via s.155(4)/s.23(2) — Raz v Matane, not s.57 alone), s.52 (via children, Prong 6, s.57); ICCPR Art.12(4) (Prong 3 — no direct domestic incorporation, s.39(3) interpretive support only, see Prong 3 note); Wrongs Act ss.1, 1(4) (Prong 2); Lewis v The State (1980) PNGLR 219; Lukautim Pikinini Act s.8 (Prong 4); not s.42, not s.48 (withdrawn, see Prong 1 below)

**Structure of Argument:**
> "The claimant's economic loss is recoverable on any one of the following four independent grounds. The court need only find one. The State would need to defeat all four to escape liability for this head of damage."

---

**PRONG 1 — Section 48: Freedom of Employment — NOT RELIED UPON**

~~Constitution s.48 applies to "every person." It guarantees the right to seek and obtain employment.~~ **Withdrawn**: *Premdas v The State* [1979] PNGLR 329 — this Brief's own central non-citizen authority, near-identical facts (non-citizen unable to continue employment after entry-permit revocation) — holds directly that "there is no right to employment conferred by the Constitution" and that such a complaint is "irrelevant" to s.48. s.48 protects freedom of *choice* of calling, not a right to employment; relying on it here would hand the State a ready rebuttal using this Brief's own authority against it.

Causal chain (still live, now argued under Prongs 2 and 6 below): PNGCIR failed to issue birth certificates → children had no passports → Richard could not leave with or without them → Australian employment was inaccessible. PNGICSA's manufactured visa crisis compounded and extended the captivity. The underlying fact is not lost — only this constitutional label for it.

---

**PRONG 2 — Wrongs Act Negligence: No Constitutional Right Required**

This route bypasses constitutional rights arguments entirely. It is a pure tort claim.

PNGICSA owed Richard a duty of care from the moment it undertook to process his bond refund claim. PNGCIR owed Richard a duty of care from the moment it accepted James's birth registration application in November 2018. Both duties were breached. The foreseeable damage flowing from those breaches includes economic loss — specifically the loss of earning capacity in Australia.

Under Lewis v The State (1980) PNGLR 219, economic loss is assessed at what the claimant would have earned. Richard's Australian earning capacity is the correct baseline regardless of his actual PNG income of zero.

This prong requires no constitutional right to movement whatsoever. It only requires that the State owed a duty of care — which it did the moment it accepted and began processing the claims — and that the breach caused foreseeable loss.

Preempting the rebuttal: If the State argues Australian earning capacity is too remote, Lewis v State directly defeats that. The established measure is what the claimant would have earned. Richard's qualifications and his unrestricted Australian right to work establish that Australian minimum wage is the correct baseline.

---

**PRONG 3 — ICCPR Article 12(4) — NOT RELIED UPON AS AN INDEPENDENT BASIS**

~~ICCPR Article 12(4): "No one shall be arbitrarily deprived of the right to enter his own country." This provision uses "no one" — not "no citizen of that country." It refers to "his own country" — the country of which the person is a national. Australia is Richard's own country. PNG's administrative failures arbitrarily prevented him from exercising his right to return to Australia.~~ **Withdrawn, on primary-text confirmation, not just an unresolved citation.** Constitution s.117(7) is definitive: "no treaty forms part of the municipal law of Papua New Guinea unless, and then only to the extent that, it is given the status of municipal law by or under a Constitutional Law or an Act of the Parliament." The ICCPR has never been given that status by any Act — confirmed independently across multiple sources, consistent with the same, better-documented position for the CRC ("parties cannot claim relief directly under the CRC... instead, a party must seek relief under national law"). This isn't a citation problem to fix; there is no PNG domestic-law route by which ICCPR Art.12(4) grounds a freestanding cause of action, and no Act supplies one. Relying on it as an independent prong invites a clean, easy rebuttal.

**What the ICCPR is actually good for here, and it's real: Constitution s.39(3).** When a court determines whether a law or an act is "reasonably justifiable in a democratic society having a proper regard for the rights and dignity of mankind," s.39(3) directs it to have regard to — among other things — "any other international conventions, agreements or declarations concerning human rights and fundamental freedoms." The ICCPR qualifies squarely. This is genuine, PNG Supreme Court-endorsed practice, not a stretch: PNG's own courts have said instruments including the ICCPR "have influenced our Constitution and continue to guide the manner in which the provisions of the Constitution may be interpreted." That is an *interpretive* role, not a standalone right of action — but it is not nothing. Art.12(4)'s "no one... his own country" language is genuinely useful as interpretive reinforcement wherever this Brief already argues that PNGICSA's or PNGCIR's conduct was disproportionate, arbitrary, or not reasonably justifiable — principally Prong 5 (s.41) and the Wednesbury arguments throughout Part E — not as its own numbered ground.

This prong is accordingly not counted among the independent bases below. The economic-loss claim now rests on **four** independent prongs (2, 4, 5, 6), not five — restated throughout this section and Part F. Nothing factual is lost: Richard's inability to return to Australia is still fully captured, just through Prong 5 (s.41, harsh and oppressive) and Prong 6 (consequential harm), with the ICCPR argument folded in as reinforcement for those rather than carried as its own ground.

---

**PRONG 4 — Derivative Claim Through the Children's s.52 Rights**

The children have a direct s.52 claim, framed throughout as such (Counts i89–i91, i93). Part of their compensable loss is the economic deprivation caused by their father's inability to earn Australian income to support them — which itself flowed directly from the s.52 violation against them.

Structure: Children's s.52 violated → family unable to travel to Australia → Richard unable to earn → children deprived of economic support they had a right to receive under Lukautim Pikinini Act s.8.

Richard's income loss is part of the children's damages, not only his own. Compensation for this loss flows to the family as a unit regardless of whether the court characterises it as Richard's loss or the children's loss.

Preempting the rebuttal: The State cannot argue the children have no claim to their father's lost Australian income — their right to maintenance under the Lukautim Pikinini Act s.8 is exactly that claim. The State caused the loss of that maintenance through its own failures.

---

**PRONG 5 — Section 41: Ten Years' Confinement as Harsh and Oppressive Conduct (Economic Loss as Remedy, Not Basis)**

Even if Richard has no movement right under s.52, the State's conduct in effectively imprisoning him in PNG for 10 years is harsh and oppressive under s.41 regardless of his citizenship. The harm is the same. The conduct is the same. Section 41 does not ask whether the victim had a movement right — it asks whether the State's act was disproportionate and oppressive. It was.

Compensation for economic loss is a direct and appropriate remedy for the harm caused by that proscribed act. The court awards compensation for the consequences of the proscribed conduct, not only for the violation of a specific movement right.

**Enforcement vehicle:** s.41 is not itself a "right or freedom" enforceable under s.57(1). *SCR No 5 of 1985; Raz v Matane* [1985] PNGLR 329 (Kidu CJ, Kapi DCJ; Amet J dissenting) holds s.41 confers a right of action enforceable instead under s.155(4) and, in the further alternative, s.23(2) — both accepted even by the dissent, so this costs nothing to plead regardless of which view a given bench prefers. This was affirmed as current law by the Supreme Court in *Independent State of PNG v Uddin* [2022] PGSC 109; SC2312, which expressly overruled the National Court's long-standing "broad approach" treating s.41 as directly s.57-enforceable, and again in *Kaluwin v Haiveta* SC2384 (2023) and most recently *Madang Timbers Ltd v Matthew* SC2749 (4 July 2025) — four decades of unbroken Supreme Court authority on this specific point, with no contrary decision since 1985. *Madang Timbers* forecloses the obvious workaround too: it rejects the argument that s.58 survives even where s.57 does not, holding that s.58 is expressly "an addition to, and not in derogation of, s.57" and is equally predicated on a breach of a "right or freedom" — so a bare s.41 finding cannot ground s.58 compensation either. The Court draws the s.23 line precisely because s.23, unlike ss.57 and 58, is not limited to a "guaranteed right or freedom" at all — a distinct statutory footing, not a workaround of the same one. This Prong is argued under s.155(4) and s.23(2) accordingly; s.57 is not relied on for it alone.

This is not an improper stretching of s.155(4) into a freestanding cause of action, and the Supreme Court has been explicit about exactly where that line sits: s.155(4) "concerns remedies only and is not about a creation of and grant of any right to any person," its power is exercisable "only... provided the exercise of that power is only remedial in nature and is aimed at protecting and or enforcing the rights of parties granted by other law," and it "does not affect the primary rights of parties which are determined by the substantive law" — *Carlos D'Attanasio v The State* (2025) SC2735, drawing on *Powi v Southern Highlands Provincial Government* (2006) SC844, *Application by Ombudsman Commission; Re Aundak Kupil* [1994] PNGLR 469, and *SCR No 2 of 1981* [1982] PNGLR 150. This Prong does exactly what that doctrine permits and nothing more: it does not ask s.155(4) to create Richard's right, it uses s.155(4) to enforce the right s.41 itself already creates, exactly as Raz v Matane's own 1985 holding contemplated — the substantive right is s.41's; s.155(4) supplies only the door through which it is enforced.

**Additional pathway — s.32 (Right to Freedom):** Unlike s.41, s.32 carries none of the Raz v Matane enforcement limitation above — it is an ordinary Division III.3 right, directly enforceable under s.57 without needing the s.155(4)/s.23(2) route just described. Section 32(2) gives "every person" — not "every citizen" — "a legal right to do anything that... is not prohibited by law," and provides that "no person... may be prevented from doing anything that complies with" that paragraph. Richard's confinement — prevented from leaving PNG despite no legal prohibition on his departure — falls squarely within s.32(2)(d). The Supreme Court has already applied s.32 to non-citizens directly: in *Namah v Pato* [2016] PGSC 13; SC1497, the Court's own final orders held that the conditions of the Manus Island asylum seekers' detention violated, among other rights, "the right to freedom under s.32 of the Constitution" — a non-citizen population, decided on the merits, not a procedural dismissal. The National Court has since applied s.32(2) as a free-standing, directly infringed right on the same footing as s.37 and s.41 in *Re Fish Ban* (2020) N8221 (Cannings J) — all three held infringed together by the same unlawful conduct — and substantively in *Re Willingal* (1997) N1506, where a custom compelling forced marriage was held unconstitutional specifically for infringing s.32(2)'s "legal right to do anything not prohibited by law." *Sila v Independent State of PNG* (2024) N10976 confirms s.32 remains live and current, though that decision principally engages s.32(1)'s interpretive role rather than s.32(2)'s substantive right directly. This gives Richard's own captivity claim — otherwise routed entirely through s.41's more difficult path — a second, independently sufficient, directly s.57-enforceable basis, pleaded in the alternative. It does not replace the s.41 argument above, which remains valuable in its own right for the bad-faith and aggravation weight the Wednesbury analysis throughout this file already builds.

**Do not cite *David Simon v Koisen* or *Nowra* for direct s.58 damages.** Both were part of the National Court "broad approach" line just overruled above, and both are now expressly adverse authority, not persuasive support. *Madang Timbers Ltd v Matthew* SC2749 names *David Simon v Koisen* [2018] N7075 directly as one of the decisions it overturns for awarding s.58 compensation on a bare s.41 finding, and allowed the appeal on that exact ground (¶60-63) — the matter was remitted for damages to be reassessed on the correct basis. *Kaluwin v Haiveta* SC2384 separately names *Nowra No 8 Pty Ltd v Swokin* [1993] PNGLR 498 among the decisions that "do not correctly represent the law and should not be followed" (¶27). If the State's counsel raises either case, the answer is the enforcement-vehicle point already made above: this claim was never framed as a bare s.58 award for s.41 alone — it goes through s.155(4)/s.23(2), which both overruling decisions leave untouched.

**Supporting authority:** *Tomscoll v Mataio* (2016) N6200 confirms s.41 protection extends to non-citizens — against the same office (Chief Migration Officer / PNGICSA's CEO) as this claim — and itself grounds relief in s.155(4), not a bare s.57/s.41 route. *Toa v Ly Cuong-Long* [2008] N3471 (Cannings J) found a s.41 breach on facts directly on point for "harsh or oppressive" — summary termination without notice or a right to be heard, after prolonged good standing — the same structure as the forfeiture declaration and Compliance Team referral set out here; damages there were ordinary contract damages for wrongful dismissal, not s.58 compensation, so it is unaffected by the authorities above and is cited only for its characterisation of what "harsh or oppressive" means.

**Distinguishing Uddin.** The trial decision in *Uddin v Kantha* [2020] PGNC 83; N8267 was reversed on appeal on every ground, not only enforcement: *Independent State of PNG v Uddin* [2022] PGSC 109; SC2312 held the removal was "reasonable and therefore lawful," not harsh or oppressive (¶42-44), on facts that included a PNG-citizen wife and child, no investigation into fitness to remain, and no hearing given. Only the Supreme Court's reasoning is relied on here, and it supplies the distinguishing test: Uddin failed because "there is absolutely nothing to show" the Minister acted contrary to immigration policy — the respondent was a genuine illegal entrant, convicted and unappealed, and the removal was ordinary lawful process (¶42-44). Richard's position is different in exactly the respect the Supreme Court said mattered: his overstay is not his own unlawful conduct but the direct, independently-established product of PNGICSA's own bad-faith refusal to apply a debt it confirmed it owed him (Defense 1G — Wednesbury bad faith and economic duress, two independent grounds). Uddin supplies the test Richard's facts pass and Uddin's own facts failed. See Master Brief E1 for the full authority table and Arsenal A7 for the same distinction applied to the deportation argument directly.

**Distinguishing the likely State authority:** *Curran v The State* [1994] PNGLR 230 is the case most likely to be raised against this Prong — a non-citizen's s.41 claim over visa cancellation failed because "purely monetary considerations" were not, on their own, determinative. This Prong is distinguishable: the harshness finding here rests on the fact of confinement itself (above), with economic loss serving only as the remedy for that already-established harm — not, as in Curran, as the harm the harshness finding itself depends on. Curran does not disturb the enforcement-vehicle authority above — it expressly applies and follows both Premdas and the Supreme Court's *Raz v Matane* [1985] PNGLR 329; the only thing it declines to follow is a separate National Court gloss (*Raz v Matane* [1986] PNGLR 38) importing a Wednesbury-style test into s.41 review of a Minister's own discretionary visa-cancellation power specifically. That narrow point does not touch the Wednesbury analysis used throughout Part B of this file, which concerns ordinary administrative decisions by PNGICSA and PNGCIR officers, not a Ministerial exercise of the Migration Act's cancellation discretion.

---

**PRONG 6 — Consequential Harm to Richard from the Children's Established Section 52 Breach**

The Children's s.52 breach (Prongs/Counts i89–i91 above) is fully established: they are citizens, s.52 protects them directly, and no contested extension of any kind is required to reach that conclusion.

Richard's own inability to leave PNG for a decade is a direct, foreseeable, and provable *consequence* of that established breach, not a claim requiring its own independent constitutional footing. A parent does not, and as a matter of practical and psychological reality cannot, abandon dependent children who are themselves unable to leave the country. This is ordinary consequential causation — the same structure by which a family member routinely recovers for harm flowing from a wrong done to a primary victim, without needing to show the family member held an independent right of their own that was also breached. The fact occurred, the State's own proven conduct caused it, and it requires no separate constitutional label to be compensable: it is evidence of the severity and disproportionality of the Respondents' conduct for s.41 purposes, and a direct component of the loss recoverable under s.58 once the children's breach is established.

This footing is also independently reinforced: Constitution s.36 (inhuman treatment) and s.37 (protection of the law) already reach Richard directly as "every person" provisions regardless of citizenship (see the s.36/s.37 counts throughout sections a and i above), and Wrongs Act negligence is owed to him personally as a foreseeably affected family member, independent of any constitutional characterisation.

---

**Against the "No Law Against It" Argument:**

If the State argues "yes this happened but there is no law obligating compensation for it," the primary response is constitutional, not tortious — Constitution s.58 (Compensation) is drafted for exactly this scenario:

> Constitution s.58(2) provides that a person whose Basic Rights are infringed *is entitled* to reasonable damages — not may be entitled, not shall be entitled subject to the Court being satisfied, but is entitled: a present-tense declaration of an existing right, not a discretion the Court may decline to exercise. The provision's own internal contrast confirms this is deliberate: exemplary damages are expressly qualified "if the court thinks it proper," reasonable damages are not (see also Master Brief F3). This reading is confirmed by direct authority, not left to rest on the section's own text alone: *Constitutional Reference No. 1 of 1977* [1977] PNGLR 362; SC122 (Frost CJ, five-judge bench) describes s.58 as conferring "an additional and independent entitlement... to reasonable damages, and if the Court thinks proper exemplary damages" — precisely this mandatory/discretionary split; *Wilson v Kekeya* [2018] N7613 applies the same reading. 142 breaches are established on this record; s.58(2) does not require the claimant to locate some separate statute creating a compensation right — its premise is that the entitlement already exists.
>
> In the further alternative, s.23 (Sanctions) supplies a second, broader constitutional route: where any Constitutional Law provision prohibits or restricts an act or imposes a duty and no other law provides for its enforcement, the National Court may — in the absence of any other equally effective remedy — order compensation from the person in default, including a governmental body.
>
> This constitutional footing does not stand alone. The Wrongs Act independently imposes tortious liability on the State for negligence causing foreseeable loss — the foreseeable consequence of failing to process birth certificate applications for 10 years was that the family could not obtain passports, could not travel, and could not access earning capacity, a mechanical chain established by statute, not a speculative one. Equitable principles under the Underlying Law Act 2000 and the rule that a wrongdoer cannot profit from their own wrong independently defeat the State's argument as well. The court additionally has unlimited remedial power under s.57 (Premdas) and may make any orders necessary to do justice under s.155(4). Five independent routes — s.58(2) directly, s.23 as a broader backup, Wrongs Act tort, equitable/Underlying Law Act principles, and the court's own s.57/s.155(4) remedial power — converge on the same conclusion: an outcome where the State causes 10 years of proven rights violations and pays nothing for it is not a just outcome this court is obligated to reach."

---

**Summary: Prong Strength Assessment**

| Prong | Route | Citizenship Required? | Strength |
|---|---|---|---|
| 1 | s.48 Freedom of Employment | — | **Not relied upon** — contradicted by *Premdas v The State* [1979] PNGLR 329; do not plead |
| 2 | Wrongs Act negligence | No | Very strong — pure tort, no constitutional right needed |
| 3 | *(withdrawn — Constitution s.117(7) confirms no direct domestic incorporation; folded into Prong 5 as s.39(3) interpretive support only)* | — | — |
| 4 | Derivative via children's s.52 | No (via children) | Strong — maintenance right clearly engaged |
| 5 | s.41 Proscribed acts | No | Strong — supplementary, no movement right needed |
| 6 | Consequential harm to Richard via children's s.52 breach | No (via children) | Strong — ordinary consequential causation, no independent constitutional footing needed; s.42 deliberately not relied upon |

Four prongs remain (Prong 1 and Prong 3 withdrawn — see above; Premdas and Constitution s.117(7) respectively). The State must defeat all four to escape liability for the economic loss claim. Prong 2 alone is sufficient — pure tort, no constitutional right or citizenship required.

---

## MASTER REFERENCE TABLE

| Defense | Layers | Key Provisions / Cases | Wednesbury Tests Failed |
|---|---|---|---|
| 1A — No vicarious liability | 2,3,5 | ss.57,58; Wrongs ss.1(1)(a),1(4); CBASA s.12; Premdas | N/A — wrong legal framework applied |
| 1B — Officers outside authority | 1,2,3,5 | ss.37,41,57,58,62; Wrongs ss.1(4),1A; Sir Brown Bai v Tomscoll | (c) bad faith; (e) absurd position |
| 1C — Bond lawfully forfeited | 1,2,3,4,5 | ss.37,41,53,59,62; ICSA ss.35,36; FLA ss.7,16; Sir Brown Bai v Tomscoll; Mision Asiki v Manasupe Zurenuoc | (a)(c)(d)(e) — all four |
| 1D — Good faith / ICSA s.47 | 2 | ICSA s.47(1); PSMA s.51; s.62; Sir Brown Bai v Tomscoll; Kariko v Korua SC1939 | (c) bad faith — each officer individually |
| 1E — Claimant failed procedure | 1,3 | Migration Act s.16(1)(e); PCR 1989; s.59; Discovery | N/A — misrepresentation by omission |
| 1F — 50% rate is policy | 1,2 | PCR 1989; NCR Order 8; ss.59,62; Sir Brown Bai v Tomscoll; Barrick v Nekitel; Mision Asiki v Manasupe Zurenuoc | (a)(c)(d)(e) — all four |
| 1G — Visa overstay own fault | 2,3,5 | ss.37,41,52,57,58; ICSA s.4; Sir Brown Bai v Tomscoll | (c) bad faith; (e) absurd |
| 1H — Non-citizen, s.53 doesn't protect bond | 2,5 | s.53(7); ICSA ss.4,5,35,36; PFMA s.61; ss.37,41,58 | N/A — statutory route unaffected by s.53(7) |
| 2A — Work permit legitimate | 1,2,3,5 | ENC Act s.6; CRA ss.16,25,26; ss.37,41,59,62; Sir Brown Bai v Tomscoll; Mision Asiki v Manasupe Zurenuoc | (a)(c)(d)(e) — all four |
| 2B — Cancellation legitimate | 1,2,3 | CRA ss.9,25,27; ss.37,41,59; Sir Brown Bai v Tomscoll; Mision Asiki v Manasupe Zurenuoc | (a)(c)(d)(e) — all four |
| 2C — Registration discretionary | 2 | CRA s.25; Amendment s.37C(3); ss.37,57; Sir Brown Bai v Tomscoll | (d) — wrong in law |
| 2D — Mistakes not misconduct | 2 | PSMA s.51(i); Oath; Wrongs s.1A; s.62; Sir Brown Bai v Tomscoll | (c) bad faith or dishonesty |
| 2E — No freedom of movement breach | 2,5 | s.52; Passports Act; Namah v Pato | N/A — mechanical statutory chain |
| 3A — No connection to State action | 1,2,5 | ss.52,57,58; Wrongs s.1(4); Lewis v State | N/A — causal chain direct and documented |
| 3B — No compensable loss | 2,5 | s.58; CBASA s.12; Lewis v State | N/A — multiple heads established |
| 3C — Admin remedies not exhausted | 1,3 | s.57; NCR Order 23 | N/A — 5 years State-documented engagement |
| 3D — Nationality objection | All | ss.36,37,41,53,59,62; GO 15.58; CRA s.25; LP Act s.6 | N/A — compartmentalization; duties apply regardless |
| 3E — Discovery complete | 3 | Bench Book; PCR 1989; s.59; Credit Corp v Jee | N/A — disclosure obligation is absolute |
| 3F — No s.52 right, no economic loss | 1,2,3,5 | Consequential harm via children's s.52 breach (Prong 6); Wrongs Act; Lewis; LP Act s.8; s.41 (s.155(4)/s.23(2), Prong 5, ICCPR Art.12(4) as s.39(3) interpretive support only); s.32 (direct s.57, alternative to Prong 5); s.52 (via children, s.57) | (c)(d)(e) — Wednesbury + 4 independent prongs |
| 3G — Richard's presence was voluntary | 1,2,3 | LP Act ss.6,7; PNG Criminal Code ss.283,284; Family Law Act 1975 (Cth) ss.61C,60CC; CRC Art.9,18 | N/A — departure was unlawful, not merely inadvisable |
| 3H — Should have mitigated via remote work | 1,2,3 | Migration Act (Ch.16) visa conditions; Kopen v Independent State of PNG; Constitution s.36 | N/A — legally and factually foreclosed, not merely undesirable |
| 3I — Fear of retaliation not explicit, doesn't excuse delay | 2,5 | ss.57,58; CBASA s.5 | N/A — reasonable apprehension need not be an explicit threat |
| 3J — Act bars execution/payment deadline | 2,5 | ss.10,11,57(3),155(4); Premdas; Human Rights Rules 2010 | N/A — construction and supremacy, not a reasonableness test |

---

### DEFENSE 3G: "Richard chose to remain in Papua New Guinea voluntarily."

**Layers:** 1, 2, 3
**Provisions:** Constitution ss.38, 39, 52; Lukautim Pikinini Act 2015 ss.7, 8; PNG Criminal Code Act ss.283, 284; Family Law Act 1975 (Cth) ss.61C, 60CC; Convention on the Rights of the Child Arts.9, 18; Australian Criminal Code Act 1995 (Cth) s.270.7B; ICCPR — no direct incorporation (Constitution s.117(7)), s.39(3) interpretive use only, see Prong 3 note
**Evidence:** Three children born in PNG. Birth certificates withheld by PNGCIR. No passports obtainable. Children could not lawfully depart without identity documents.

**Counter-Submission:**
> **The State's voluntariness argument fails at a threshold, principled level, before any question of Richard's or Serah's individual reasons or circumstances arises at all.**
>
> Serah held two constitutionally and statutorily guaranteed rights, independently and unconditionally: the right to freedom of movement (Constitution s.52), and the right — jointly a duty — to remain with and care for her children (Lukautim Pikinini Act 2015 ss.7, 8; Convention on the Rights of the Child Art.9). Neither right is conditioned on the other. Both were guaranteed to her in full, concurrently, before the State's conduct intervened.
>
> The combined effect of PNGCIR's refusal to register the children's births, and the resulting absence of any lawful means for the children to leave Papua New Guinea, was to convert those two independently guaranteed rights into a forced election: Serah could exercise her right to leave, or her right and duty to remain with her children, but not both. No justification for that restriction has ever been offered, nor could one be — the effect was an unintended byproduct of unlawful administrative conduct, not a deliberate policy answerable to the s.38/39 test of a restriction "reasonably justifiable in a democratic society." It fails that test more completely than a deliberate restriction would, because nothing is advanced to justify it at all.
>
> This is not a case of two people's rights competing, nor an incidental effect of a valid restriction. It is the State creating, through its own unlawful conduct, a binary choice between two of one person's own already-guaranteed entitlements — the same structure already argued for Richard under the de facto detention analysis (Const. s.41, Prong 5, above): no formal denial of either right, but no lawful way to exercise both. A right that can only be exercised by forfeiting another independently guaranteed right is not being honoured in substance, whatever its formal status remains on paper. On this ground alone — independent of the child-abandonment and visa-collapse analysis that follows — the voluntariness defence fails: Serah was never in a position to exercise her freedom of movement without extinguishing rights and obligations the State was equally bound to let her keep.
>
> The same principle applies to Richard independently — and on his own facts, more starkly still, because his is not a hypothetical. Richard held, unconditionally and concurrently, the factual capacity to leave (as an Australian citizen holding a valid passport, with an unrestricted right of residence in Australia — Affidavit para. 2; this is a factual predicate, not a PNG constitutional claim — s.52 is citizen-only and has never applied to him) and his own duty to remain with and care for his children (Lukautim Pikinini Act 2015 s.8; Criminal Code Act s.284, Duty of Head of Family, and s.283, Duty to Provide Necessaries). Exercising the first meant abandoning his children to the conditions described throughout this document. Richard did not merely risk that trade — he lived the alternative, for over a decade, having lawfully chosen the second. He addresses this directly in his own sworn evidence: *"I strongly reject any characterisation that my continued presence in Papua New Guinea was in any way voluntary. The choice I faced was between remaining with my children or abandoning them. That is not a genuine choice"* (Affidavit para. 23). Unlike a hypothetical forced election, the record does not need to speculate what a person in that position would suffer — it documents what Richard actually suffered because he could not do otherwise: ten years of poverty, violence, medical deprivation, and psychological harm (Affidavit Parts C, E), all consequent on his refusal to exercise a right that could only be exercised by forfeiting a duty the State was equally bound to let him keep.
>
> The State's voluntariness argument fundamentally mischaracterises the legal position. Richard's continued presence in PNG was not a choice — it was his only lawful option. Departing without his children was unlawful under multiple frameworks across two jurisdictions and international law:
>
> **PNG law:** LP Act s.7 enshrines the child's right to live with their parents. LP Act s.8 imposes a positive duty to maintain children. Criminal Code Act s.284 (Duty of Head of Family) makes it an offence for a person with charge of a child under 14 in his household to fail to provide the necessaries of life. Criminal Code Act s.283 (general Duty to Provide Necessaries) covers the same failure more broadly. Departing and leaving three children aged under 5, under 3, and under 3 (twins) in dangerous conditions without their primary caregiver would have directly engaged all four provisions.
>
> **Australian law:** Family Law Act 1975 (Cth) s.61C provides that both parents share parental responsibility — unilaterally abandoning children in a foreign country would constitute a serious breach. Family Law Act s.60CC makes the best interests of the child paramount — departure to leave three children in documented poverty and dangerous conditions would have exposed Richard to severe adverse findings in any subsequent Australian family court proceedings and potential orders for removal of parental responsibility. Australian Criminal Code Act 1995 (Cth) s.270.7B (exploitation provisions) may additionally have been engaged depending on the conditions in which children were left.
>
> **International law:** CRC Art.9 provides that children shall not be separated from their parents against their will. CRC Art.18 imposes common parental responsibility for the upbringing and development of the child. Departure would have unilaterally forced that separation and extinguished Richard's ability to fulfil his Art.18 obligations — the CRC route is incorporated domestically via LP Act s.6, confirmed; the ICCPR has no direct domestic incorporation route at all (Constitution s.117(7), see Prong 3 note) and is not relied on here beyond the CRC/LP Act basis, which stands on its own.
>
> Remaining in PNG was therefore not the most admirable choice among available options — it was Richard's **only lawful option**. The choice the State implicitly invites the court to consider — departing alone and leaving three children without their primary caregiver in documented dangerous conditions — was not a legally available choice at all. It was a criminal act under both PNG and Australian law, and a breach of international obligations. The voluntariness argument collapses entirely on this analysis. The start date for all harm is the date State conduct prevented departure — not the date of Richard's original voluntary arrival.
>
> This is the second independent application in this case of the same underlying principle: a binary choice between two of a person's own independently guaranteed rights, imposed by the State's unlawful conduct rather than by any valid restriction, is not a genuine choice and does not discharge the State's obligations toward either right. The same structure recurs, in a different context, at Defense 3J — the payment/departure forced election — where full payment before departure is sought for exactly the reason no lawful departure existed here without abandoning the children.

---

### DEFENSE 3H: "Richard should have mitigated his loss by working remotely while in Papua New Guinea."

**Layers:** 1, 2, 3
**Provisions:** Migration Act (Chapter 16) — Special Exemption Visa (Dependent of Citizen, non-working class) conditions; Kopen v Independent State of Papua New Guinea [1988-89] PNGLR 659 (duty to mitigate); Constitution s.36
**Evidence:** Visa conditions expressly prohibiting employment (Exhibit A); Affidavit paras 7, 11 (visa restriction; full-time caregiving of three children including twins); Count i83 above (s.36 — absence of reliable electricity among the living conditions described).

**Counter-Submission:**
> This argument takes a true premise — that Richard is a qualified IT specialist — to a false conclusion: that he should therefore have generated income remotely during the relevant period. It fails on at least three independent grounds, any one of which disposes of it on its own.
>
> **First, it is legally foreclosed.** Richard's visa (Special Exemption Visa — Dependent of Citizen, non-working class) prohibits him from seeking employment while in Papua New Guinea. That prohibition is not confined to work for a PNG employer or work paid in Kina: employment physically performed while present in Papua New Guinea is employment in Papua New Guinea for visa purposes, regardless of where the client, the payment, or the output of that work is located. Remote contract work for an overseas client, performed from Richard's home in PNG, falls within the same prohibition as any other form of local employment.
>
> **Second, it is factually foreclosed independent of the visa question.** Richard has been the family's full-time, primary caregiver for three young children, including twins, throughout the relevant period (Affidavit para 11) — itself a full-time role, assumed specifically because Serah could not perform it while running the household's sole income-generating enterprise. That caregiving took place in conditions this document already sets out elsewhere as a breach in their own right (Count i83 — s.36 Freedom from Inhuman Treatment, citing the absence of reliable electricity among other conditions). A household environment already relied upon in this document as inadequate for basic living conditions is equally inadequate to sustain dependent, connectivity-reliant remote contract work.
>
> **Third, even if either obstacle were somehow overcome, the duty to mitigate does not require the impossible.** PNG law recognises a duty to take reasonable steps to minimise loss, including in the employment context (Kopen v Independent State of Papua New Guinea [1988-89] PNGLR 659). A claimant cannot be faulted for failing to do what he was legally barred from doing and, separately, factually unable to do. The mitigation argument does not reduce the claim — it does not arise at all.

---

### DEFENSE 3I: "The claimant's fear of retaliation was never an explicit threat, so it does not excuse his delay in bringing proceedings."

**Layers:** 2, 5
**Provisions:** Constitution ss.57, 58 — mandatory enforcement of guaranteed rights; CBASA s.5 — notice/limitation framework; Willie Gawi and Olga Kari v The State (2012) N4814 — estoppel by conduct
**Evidence:** Affidavit para. 87; Richard's Special Exemption Visa declaration (signed condition requiring him to remain "of good character"); the pattern of conduct documented throughout this document, including the veiled prosecution threat over Richard's characterisation of an officer's conduct and the subsequent manufactured forfeiture and visa crisis.

**Counter-Submission:**
> For much of the relevant period, Richard held a genuine and reasonable concern that formally commencing legal proceedings against PNGICSA could provoke retaliatory administrative action against his visa status. This concern was not free-floating; it was anchored in a specific, signed condition of his visa. Richard's Special Exemption Visa carries only two explicit declared conditions: that he remain "of good character," and that he not seek employment. He held a rational fear that a lawsuit against the host State could be arbitrarily characterised by PNGICSA as a "demonstration of bad character," supplying a ready-made administrative pretext to cancel the visa and separate him from his children — a fear compounded by the pattern of conduct already documented in this document, including the veiled prosecution threat over his characterisation of an officer's conduct and the subsequent manufactured forfeiture and visa crisis. He does not allege, and the record does not establish, that PNGICSA ever explicitly threatened retaliation for pursuing litigation specifically — the fear does not need to be explicit to be reasonable, and a vague or general apprehension of an unspecified adverse consequence can be just as rational, and just as paralysing, as a targeted one. As Richard states in his own sworn evidence: *"Whilst I cannot establish that such action would have been taken, the pattern of conduct I had observed from PNGICSA officers... made this a concern I considered reasonable and which I did not take lightly"* (Affidavit para. 87). That the apprehension rests on reasonable inference rather than a proven, targeted threat does not diminish its force as an explanation for delay — a court is not entitled to expect a litigant to disregard a reasonably formed fear merely because the feared consequence was never tested. The same underlying conduct is independently addressed further at F4 (Exemplary Damages).
>
> Independently of the excuse above: if the State raises any defect in CBASA s.5 notice at all, and does not apply promptly to have the proceedings dismissed on that basis, allowing the matter to progress toward trial instead, it is by its own conduct estopped from later relying on that defect — *Willie Gawi and Olga Kari v The State* (2012) N4814 (Cannings J), applying this principle where the State allowed proceedings to progress 14 years after filing despite an available notice objection. This is a separate, self-standing answer to any CBASA timing objection, independent of whether Richard's own delay is otherwise excused.

---

### DEFENSE 3J: "The Court cannot order a payment deadline or enforce swift payment — the Act makes payment discretionary and bars execution against the State."

**Layers:** 2, 5
**Provisions:** Constitution ss.10, 11, s.57(3), s.155(4); Premdas v The State [1979] PNGLR 329; Claims By and Against the State Act 1996 ss.2(2), 13, 14; Human Rights Rules 2010 (made under Constitution s.184 and National Court Act s.8)
**Evidence:** Claims By and Against the State Act 1996, ss.13–14 — the primary source: no execution, attachment, or process in the nature of execution or attachment against the property or revenue of the State; a judgment against the State must be satisfied "within a reasonable time" out of "monies legally available," by instalments if the Departmental Head for Finance so elects, provided the judgment is thereby satisfied within a reasonable time. Commission of Inquiry into the Department of Finance, Final Report — corroborates that payment of State judgment debts follows this same discretionary, often heavily delayed pattern in practice.

**Counter-Submission:**
> The State will likely resist any request for a specific payment deadline by pointing to the Claims By and Against the State Act 1996, s.13's bar on execution against the State, and to s.14(3)'s "reasonable time" standard for satisfying a judgment. Neither defeats the relief sought at Master Brief F6.1. The Act does apply to this claim — s.2(2) expressly extends its provisions to enforcement proceedings under Constitution s.57 and to compensation claims under s.58 — so no argument that the Act simply does not reach a constitutional claim is available here. But s.13(1) bars only "execution... or process in the nature of execution or attachment... against the property or revenue of the State": seizure, garnishee, or similar coercive process against State assets. It does not bar the Court from making an order in the first place, or from giving specific content to the "reasonable time" s.14(3) already requires but does not itself define. Courts have repeatedly done exactly that: in *Pacific Helicopters Ltd v Kambanei* (2007) N3242, the National Court declared that the Secretary for Finance's prolonged failure to satisfy judgment debts (running over a decade in that case) breached his s.14(3) duty, granted mandamus, and ordered him examined on oath as to funds available for payment. In *Atlas Corporation Ltd v Ngangan* (2020) SC1995, the Supreme Court confirmed the same framework on appeal, holding that mandamus is available against the Departmental Head for finance matters for breach of the s.14(3) duty, subject only to the sequencing requirement that oral examination first ascertain that monies are legally available to satisfy the judgment before mandamus actually issues. Section 14(5) confirms this directly: mandamus lies against the Secretary for Finance specifically "for failure to observe the requirements of Subsection... (3) or (4)" — an unreasonable delay in payment is not an event the Act insulates him from being compelled over; it is the one circumstance the Act expressly contemplates mandamus for. The relief already sought at F6.1 — a specific deadline, with liberty to apply for mandamus (preceded by oral examination as to available funds, consistent with Atlas Corporation) if it passes unmet — tracks this statutory mechanism precisely rather than inventing one: it requires no fresh action, no attachment of State property, and no order outside this Court's power. As a procedural matter, mandamus under s.14(5) presupposes a Certificate of Judgment issued under s.13(2) and endorsed by the Solicitor-General under s.14(2); that sequence should be completed promptly once judgment is entered, so the liberty-to-apply mechanism is available without delay if needed. In the further alternative, if any broader reading of s.13 were adopted that reached the making of the order itself rather than only its execution, that reading would to that extent be inconsistent with the Constitution's supreme law status and "invalid and ineffective" under s.11(1) — an ordinary Act cannot cut down the unlimited remedial power s.57(3) confers (Premdas) or s.155(4)'s inherent jurisdiction in a constitutional human rights matter. This is reinforced by the procedural framework the claim proceeds under: the Human Rights Rules 2010 exist specifically "to facilitate a quick and just resolution" of human rights matters, waiving fees and permitting the Court to act on its own motion — an institutional commitment to speed that an open-ended, undated payment obligation — of the kind Pacific Helicopters and Atlas Corporation both show can commonly extend a decade or more in practice — sits in direct tension with.
>
> If the State proposes payment by instalments — expressly permitted by s.14(4), provided the judgment is thereby satisfied "within a reasonable time" — that does not satisfy the relief sought at Master Brief F6.1, and full payment by a single deadline, before departure, remains the only order that avoids recreating the forced election already established at Defense 3G in a second context. This is not a scheduling problem that a front-loaded early instalment could solve. The forced election is triggered by the combination of (a) sufficient funds becoming available to relocate and (b) the practical degradation of the applicants' ability to enforce a PNG judgment, order, or contempt application once they have left the country — and that combination recreates itself at whatever point in any instalment schedule sufficient funds first accumulate, whether that is the first instalment or the last. Front-loading changes only when the trap is triggered, not whether it exists. Nor does the source of the funds matter to this structural point: the same combination would arise regardless of who provided the relocation-sufficient sum, which is precisely why the responsibility falls on the Court rather than on any third party — a gift from a family member is not something the Court has power over or responsibility for, but an instalment structure the Court itself orders is. Nor is a secured or escrowed structure an answer the applicants seek or would accept as a substitute: any such arrangement would itself require ongoing administration, oversight, or release conditions extending beyond judgment — precisely the continued entanglement with State machinery that has already produced the harm this case seeks to remedy, and precisely what the relief at F6.1 is meant to end, not relocate into a different form. Full payment before departure is the only relief that resolves the matter completely and does not itself produce a further, Court-caused violation of the same rights this case concerns.

---

### DEFENSE 3K: "We cannot identify the individual officer(s) who used this account/role, because access was shared or not individually logged."

**Layers:** 2, 3; Discovery obligations; PCR 1989; Public Servants Oath Point 3
**Provisions:** Wrongs (Miscellaneous Provisions) Act s.1(1)(a) (mandatory naming of servants/agents — confirmed to apply to tort claims only, not constitutional human rights claims: *Patrick Liri v David Manning* (2024) N11068, following *Pokarup v The State* (2024) N11028); PSMA 1995 s.51; Public Servants Oath Point 3 (National Gazette G100, 20 June 2002): "avoid deception, fraud, theft and all other forms of corrupt behaviour, and be open, transparent and loyal to the public interest in all my dealings"; general equitable principle that a party may not rely on a deficiency of its own making to avoid a duty (already applied at Part G, Ground 2, to the State's inability to rely on delay it engineered); *Philip Nare v The State* [2017] 1 PNGLR 366; SC1584 (five-member bench — State's vicarious liability does not require the individual tortfeasor to be named, identified, or joined)
**Evidence:** "Jack" corresponded from clientservice@immigration.gov.pg (Exhibit J); the PNGCIR Compliance Team officer corresponded on official letterhead without signing a name (Exhibit F, Affidavit para 30).

**Counter-Submission:**
> Wrongs Act s.1(1)(a)'s naming requirement does not even reach most of what is pleaded against these two officers, before any of the following arguments are needed. The requirement applies to claims founded in tort; it does not apply to constitutional human rights claims, which are conceptually and legally distinct — *Patrick Liri v David Manning* (2024) N11068 (Cannings J), following *Pokarup v The State* (2024) N11028. There, 87 plaintiffs sued the State over conduct by police officers never named or identified in the proceedings; the State argued s.1(1)(a) barred the claim; the Court held the section had no application once the claim rested on breach of constitutional rights rather than tort, and went on to find the State vicariously liable for breaches of ss.36, 37, 44, 49 and 53 committed by those unidentified officers. The primary claims here are of the same character — s.36, s.37, s.41, s.52, s.53, s.58 — not tort, so s.1(1)(a) is not engaged for them at all.
>
> If the State asserts it cannot identify the specific individual who authored correspondence from an official departmental account, that response fails in any of three ways, and the State does not get to choose which. If the underlying access, roster, or account-assignment records exist and are simply not produced, that is a discovery breach and supports the adverse inference that the withheld information is unfavourable to the State's position. If no such records were ever kept — if PNGICSA and/or PNGCIR structured a client-facing account used to make representations with legal consequences (a forfeiture declaration; a work permit demand) without any means of later attributing who used it — that is not a valid excuse for non-identification; it is a further and independent institutional failure, inconsistent with the Public Servants Oath's commitment to open and transparent dealing and with ordinary standards of accountable public administration, and a party cannot rely on a deficiency of its own creation to defeat an obligation that deficiency itself prevents it from discharging — the same principle already applied to reject the State's reliance on delays of its own making (Part G, Ground 2). Either way, the primary claim against the State does not depend on this identification at all, and that is now settled by binding authority, not merely principle: the five-member Supreme Court bench in *Philip Nare v The State* [2017] 1 PNGLR 366; SC1584 held that "unlawful conduct... renders the State vicariously liable for damages," that "the 'independent discretion' rule has been abolished," and that "it is not part of the cause of action that the offending officers be identified or be parties to the cause pleaded against the State." That holding has been applied without exception in every reported case since, including on facts where the specific officer was never identified anywhere in the proceedings and the claim was, as here, one for breach of human rights rather than tort — *Patrick Liri v David Manning* (2024) N11068, above, is the closest factual match available; see also *Ikian Lyanga v The State* (2017) SC1635; *Bruno Yara v Kami Yanjuan* (2018) N7118; *Thomas Yalbees v Tom Amaiu* (2018) N7393. The same result has been reached against a private employer, not only the State: in *Guard Dog Security Services Ltd v Richard Mathews* (2019) SC1861, the Supreme Court upheld a finding of vicarious liability for an employee who was never identified at trial, on circumstantial evidence of the role alone. This affects only the alternative personal-liability claims against these two officers under Wrongs Act s.1A (Master Brief B3/B4, D2) — the primary claim proceeds against the State directly for the acts of the apparatus it structured and staffed (Master Brief B2), and *Nare* and *Patrick Liri* together confirm, as a matter of binding authority applied on nearly identical facts, that it does not depend on any individual officer's identity. Two unidentified officers out of ten does not disturb a case built on a documented, corroborated, multi-agency pattern spanning a decade.

---

## CRITICAL NOTICES FOR COUNSEL

---

### 1. Judicial Review: Considered and Not Pursued

> Judicial review under Order 16 was considered and is not being pursued — see Brief, Step 2 for the full reasoning. In short: it offers nothing this claim needs, its 4-month time limit has already expired for several relevant acts, and everything it could provide (declarations, protective orders, damages) is already available under the direct s.57 claim per *Premdas v The State* [1979] PNGLR 329. Deportation risk is addressed directly at F1 regardless of which specific administrative step produced it.

### 2. Section 5 Notice / Continuous Breach

> ⚠️ CBASA applies to the direct s.57/s.58 claim by its own terms — see Brief, Step 3 for the continuous breach argument (each day of bond withholding, visa non-renewal, and the still-active freedom of movement violation under s.52 is a fresh cause of action — the third is the most durable, since it doesn't depend on the PNGICSA dispute remaining unresolved) and CBASA s.9(c) timing. Counsel to advise on fresh notice immediately.

---

### 3. Exemplary Damages — Must Be Specifically Pleaded

> ⚠️ CBASA s.12(1): threshold is met. **Must be specifically pleaded in the originating process. Failure to plead may preclude the award entirely.** There is no rule of law barring an exemplary damages award against the State for its servants' or agents' conduct — confirmed on appeal as recently as 2024: *Independent State of PNG v Thomas Kei* (2024) SC2550 upheld an exemplary damages award against the State on facts involving deliberate police violence, applying the same "severe or continuous" CBASA s.12(1) threshold this file already relies on, and citing *Abel Tomba v The State* [1997] SC518, *Koimo v The State* [1995] PNGLR 535, *Kakipa v Nikilli* (2002) N5689, *Wiwa v State* (2012) N5271, and *Namba v Naru* (2011) N4396 as the settled line of supporting authority.

---

### 4. Personal Defendants — Mandatory

If personal liability is pursued against any officer individually (status: undecided, see Brief Part D2), a binding order requires them to be a party — this would apply to Sapaka, Metro, Jack, and Dilu (Wrongs Act s.1A).

---

### 5. Four-Prong Income Loss Framework — Defense 3F

The economic loss claim is secured through four independent legal routes (see Defense 3F above; Prong 1/s.48 and Prong 3/ICCPR both withdrawn as standalone bases — Premdas and Constitution s.117(7) respectively). **The State must defeat all four to escape liability for this head of damage.** Prong 2 (Wrongs Act negligence) is sufficient alone and requires no citizenship or constitutional right. Ensure all four remaining prongs are argued in opening submissions.

---

### 6. James's Psychological Harm — Framing

James's documented psychological trauma from witnessing the knife assault on his father is framed as a foreseeable consequence of the environment of administrative captivity — an aggravating factor supporting general and exemplary damages. It is **not** framed as a standalone nervous shock tort under Wrongs Act s.36. This avoids any limitation period vulnerability while preserving the full evidentiary and quantum weight of the harm within the constitutional breach claim.

---

### 7. Discovery Orders — Apply at Earliest Opportunity

Discovery obligation is comprehensive and non-negotiable — apply at the earliest opportunity, not deferred. See Brief, Step 4 for the specific document-production targets and case citation (Credit Corporation v Jee).

---

### 8. Unlimited Remedial Power — Premdas

Premdas v The State [1979] PNGLR 329: National Court has UNLIMITED power to remedy s.57 breaches. Court may act on its own initiative (Re Human Rights of Prisoners Sentenced to Death (2014) N6939). All orders sought are within scope.

---

### 9. Mandamus and Emergency Injunction — File Simultaneously

> ⚠️ Visa overstay penalties accumulating daily. Compliance Team referral 15 August 2025 creates active deportation risk. Mandamus and emergency injunction must be filed without delay. These do not wait for the main claim.

---

### 10. Migration Act s.16(1)(e) — Criminal Referral

Repo's deliberate misrepresentation to General Manager Kapus on 2 October 2024 may constitute a criminal offence. Counsel to assess whether referral for prosecution is warranted in addition to the civil claim.

---

### 11. ICSA Act s.39 — Ministerial Committee of Inquiry

Grounds for Ministerial appointment of a Committee of Inquiry are met under s.39(1)(c) ("persistent and deliberate frustration of, or failure to comply with, lawful directions") and s.39(1)(d) ("persistently exceeded its powers or disobeyed applicable laws"). Available as an escalation mechanism independent of court proceedings.

---

### 12. Lewis v State Economic Loss Calculation

Under Lewis v The State (1980) PNGLR 219 loss of earning capacity assessed at what claimant would have earned. Australian minimum wage rates × approximately 10 years. Counsel to formally calculate this sum. Where quantum rests on a historical rate or valuation fixed years before judgment, courts have applied an inflation uplift to bring it into current terms rather than leaving it frozen at the historical date — *Ben Kavu Urame v Sixth Estate Limited* (2025) N11430 applied a 30% uplift to a 10-year-old valuation on exactly that reasoning, following the same approach in *Lapune Aine & 21 Others v The State* [2011] PNGC 116; N4389; the purpose of a damages award is to restore the claimant to the position he would have been in, which a stale, unadjusted figure cannot do. The income-loss calculation above spans a comparable stretch of time and should be checked for the same adjustment when finalised. Interest on the K1,000 bond accrues from 9 March 2020 under the Judicial Proceedings (Interest on Debts and Damages) Act 2015, ss.4, 6; against the State both pre- and post-judgment interest are capped at 2% yearly (s.4(2), s.6(2)), not discretionary — confirmed by direct application in *Jolpuk v Kabilo* (2023) N10309 (Tamade AJ), which quotes ss.4 and 6 verbatim and recalculates a prior award to 2%, and independently in *Wereh v Wamuk* (2023) SC2487 (see Count h81). Note also s.6(5)(a): post-judgment interest against the State does not begin accruing until a Certificate of Judgment is served. Counsel to calculate the exact figures as at date of filing using the 2% rate throughout.

---

### 13. Convention on the Rights of the Child

Lukautim Pikinini Act 2015 s.6: children have rights under "domestic laws and the Convention on the Rights of the Child." Convention incorporated directly into PNG law. Available in addition to domestic constitutional provisions.

---

### 14. Mitigation-by-Remote-Work Argument — Defense 3H

The State may argue Richard should have generated income remotely given his IT background. This is pre-empted at Defense 3H on three independent grounds: the visa's employment prohibition extends to remote work physically performed in PNG regardless of client location; full-time caregiving of three young children in conditions already documented as a breach in their own right (Count i83) independently forecloses it; and the duty to mitigate does not require what is legally prohibited or factually impossible. Ensure all three grounds are argued together, not just the strongest one — the State need only defeat one to leave the argument alive if the others are omitted.

---

### 15. Institutional Design as a Contributing Cause — Evidentiary, Not a Structural Relief Claim

> The administrative structures through which this harm occurred were not accidental, external, or imposed on the State — they were designed, established, and staffed by the State itself, voluntarily, under its own constitutional mandate and Acts of Parliament (PSMA 1995, ICSA Act, Civil Registration Act, GO 15). Had those structures included adequate checks, escalation pathways, and supervisory accountability — the very kind their own enabling legislation contemplates — the harm documented throughout this claim was foreseeably preventable or capable of significant mitigation. This is not pled as an independent claim for structural or injunctive relief. Its function is evidentiary: it supports the foreseeability element of the Wrongs Act negligence claims (Defense 3F, PRONG 2) — the harm was not the remote consequence of isolated officer error, but the predictable output of a system the State itself built and left uncorrected for a decade, across two agencies and multiple named officers — and it reinforces the severity/continuity threshold for exemplary damages under CBASA s.12(1).

---

### 16. K1,000 Bond Validity — Four Independent Grounds

> The validity of the K1,000 bond refund does not depend on any officer's say-so, and counsel should not let the State draw the argument onto that ground. It is established, independently, on four fronts, any one of which is sufficient on its own:
>
> 1. **Objective legal fact.** The bond was paid (Receipt C27794, 9 March 2015) and PNGICSA's own published policy makes it refundable after five years. The claim became valid by operation of that policy and the passage of time on 9 March 2020 — no officer's approval was ever required to bring the debt into existence.
> 2. **Express written acknowledgment.** PNGICSA nonetheless confirmed the claim's validity in writing, repeatedly: Sapaka's email of 26 April 2021, expressly on Kapus's advice and copied to her; Sapaka's reaffirmation of 11 June 2021; and Repo's 50% recommendation of 20 September 2021, which necessarily concedes the underlying claim is valid — a party cannot propose a percentage of a debt it disputes exists.
> 3. **Course of conduct / estoppel.** Every subsequent dealing with the file — Repo's "fast track" promise, Metro's undertaking to draft a Treasury letter, the CMO's written instruction to process it — proceeded on the same premise. The State cannot now adopt a litigation position that contradicts five years of its own conduct.
> 4. **Uncontested fact.** Across 58 official emails spanning more than four years, no PNGICSA officer at any point disputed that the claim was valid. What was contested, when anything was, was only the quantum (the fabricated 50% figure) — never the entitlement itself.
>
> This matters less for proving the debt is owed — grounds 1 and 2 alone settle that — than for what it does to the State's remaining defences. Because the claim's validity was never in question, every act of delay, evasion, and eventual forfeiture *after* that point cannot be characterised as an honest dispute about entitlement. It can only be characterised as obstruction of a claim the State knew was good. That reframing is what elevates the conduct from maladministration to misfeasance and secures the exemplary damages threshold under CBASA s.12(1).

---

### 17. Constructive Refusal Through Bad-Faith Evasion — Framing for Laches and Misfeasance

> PNGICSA never once said "no" to the K1,000 refund. That is not a point in its favour — it is the mechanism of the harm, and counsel should present it that way rather than as an absence of wrongdoing. From April 2021 until Jack's forfeiture declaration of 5 June 2025, the pattern was consistently one of deflection rather than denial: a confirmed claim, a promised "fast track" that never arrived, a Treasury letter that was never produced, a file quietly transferred without notice, months of silence, and the same evidence resupplied by the claimant on repeated occasions to different officers who each treated it as new. Only in June 2025 — four years after validation — did the State ever put an actual refusal in writing, and even then it did so under a fabricated legal rule.
>
> This distinction carries real weight on two fronts:
>
> - **Answers the laches/delay argument (see Brief, Part G) from a different angle than Grounds 1–8 there.** A claimant who is told "yes, it's valid, just wait" cannot be faulted for waiting — he was not sleeping on a known grievance; he was being strung along by representations the State never withdrew until the forfeiture. The delay was induced, not neglected.
> - **Elevates the conduct from negligence to misfeasance.** Failing to act is negligence. Repeatedly promising action, naming specific next steps, and never delivering any of them — while the claimant complies with every instruction given — is a deliberate pattern, not an oversight, and supports the bad-faith findings needed for exemplary damages and for defeating the good-faith defence under ICSA Act s.47.
>
> **Pre-emptive rebuttal if the State produces a Treasury letter it previously claimed to have written but never produced (see Defense 1E):** production does not exculpate the State — if genuine, it proves PNGICSA held a document authorising the release of Richard's own funds and still refused to give him a copy of it; if recently created, native-file metadata will show it. Either way, it is evidence for the claimant, not the State. See Defense 1E for the full three-part rebuttal.

---

## EVIDENCE SELF-AUTHENTICATION NOTES

The following categories of evidence are self-authenticating and cannot be meaningfully contested by the State. They form the uncontestable factual foundation of the case.

---

### Category 1: State-Authored Email Correspondence

All 58 PNGICSA emails (Exhibit J) and PNGCIR correspondence (Exhibit F) were sent from official government email accounts (@immigration.gov.pg; official PNGCIR addresses). They are State-authored documents. The State cannot challenge their authenticity without challenging the integrity of its own official communications infrastructure. They are admissions against interest wherever they acknowledge the claim, commit to action, or contradict the State's defense position.

**Specific uncontestable facts established by State-authored emails:**
- The K1,000 bond debt was confirmed valid on 26 April 2021 by Ezekiel Sapaka, expressly on the advice of Acting General Manager Kessie Kapus, who was copied on the email.
- Repo committed to "fast track" the refund in November 2021.
- The CMO instruction of 24 November 2022 directed Sapaka to process the refund.
- Repo's email of 2 October 2024 contains the misrepresentations — with the CMO instruction attached to the same thread.
- That same email thread began on 18 September 2024 with six attachments the claimant supplied, including the CMO's signed instruction and the full prior correspondence record — all of which remained accessible to Kapus once she was looped in on 2 October 2024. Kapus was not new to the case: she was the officer whose advice Sapaka had cited in validating the claim in April 2021. Her sole response asked for a document already among those attachments, and after the claimant identified Repo's misrepresentation and pointed directly to the attached evidence, she did not respond again.
- Jack's forfeiture declaration of 5 June 2025 is in writing from an official account.
- Louma's compliance referral of 15 August 2025 is in writing from an official account.

The State cannot produce evidence of forgery for the non-existence of something. The non-issuance of the bond refund is proven by the absence of a payment — an absence established by the State's own records.

---

### Category 2: Documentary Records

**East Sepik Treasury Receipt C27794 (Exhibit H):** Original receipt proving K1,000 payment on 9 March 2015. The State cannot prove this payment was not made without producing counter-evidence of equivalent weight, which does not exist.

**PNGICSA published 100% refund policy (Exhibit I):** The State's own published policy. Cannot be denied. Directly defeats any 50% rate argument.

**Birth certificates issued (Exhibit G):** The State's eventual compliance proves the years of prior refusal had no basis. The State is estopped from arguing the refusal was lawful when it subsequently performed the very act it had been unlawfully refusing to perform.

---

### Category 3: Evidence the State Cannot Produce

The State **cannot** produce:
- A document establishing a 50% refund policy — it does not exist.
- A document establishing a 10-year forfeiture rule — it does not exist.
- A document establishing a work permit requirement for birth registration — it does not exist in the CRA.
- Evidence that the Treasury letter Metro claimed to have personally delivered was ever written — it was not.
- Evidence that the bond was refunded — it was not.

The absence of documents the State would be expected to produce if its position were true is itself evidence that its position is false. The court may draw adverse inferences from the State's inability to produce documents that would exist if its assertions were accurate. This is not a novel inference invented for this case: it is the settled rule from *Mision Asiki v Manasupe Zurenuoc* (2005) SC797 — an administrative decision-maker's failure to give reasons is treated as proof that none existed — applied without interruption by the Supreme and National Courts from 2005 through 2025. Every entry in this category is an instance of that same rule operating against the State.

---

### Using This Document During Proceedings

| When | Action |
|---|---|
| State makes any submission | Run it against the Critical Notices for Counsel checklist above. If any item is triggered, note the defense number from Part B and the layer engaged. Pass to counsel. |
| State makes a submission matching a known defense | Go directly to Part B, find the defense number, pass the counter-submission to counsel. |
| State claims it has provided full discovery | Raise Defense 3E. Request specific categories of documents listed in the Brief, Part H, Step 4. |
| State challenges Richard's economic loss claim | Raise Defense 3F — four prongs (Prong 1/s.48 and Prong 3/ICCPR both withdrawn as standalone bases). Prong 2 (Wrongs Act negligence) alone is sufficient. |
| State argues Richard should have mitigated by working remotely | Raise Defense 3H — all three grounds together (visa bar extends to remote work performed in PNG; caregiving; documented living conditions). |
| Costs application | Present the Part A breach counts (142 total, named officers, specific provisions) and all Part B Layer 2 findings to document the scope of State misconduct. |

---
