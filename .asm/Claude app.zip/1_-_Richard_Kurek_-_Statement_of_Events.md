# STATEMENT OF EVENTS
## Richard Ian Kurek -- Prepared for the Public Solicitor's Office

---

**Applicants:** Richard Ian Kurek, Serah Sharon Akut, and their three sons James Alexander Kurek, Zach Liam Kurek, and Brighton Reece Kurek

**Address:** Section 69, Lot 1, Old Airstrip, Waliawi, Wewak, East Sepik Province

**Prepared by:** Richard Ian Kurek

---

## Introduction

My name is Richard Kurek. I am an Australian citizen, date of birth 10 April 1982, and a qualified IT specialist by profession. My de facto partner is Serah Sharon Akut, a Papua New Guinea citizen, bearing National Identification Number 1460894169 -- and the mother of our three sons. We first met while Serah was visiting Australia and entered into a committed relationship. About eighteen months into our relationship, Serah's Australian visa expired and she had to return home to PNG. We did not want to be separated for the length of time it would have taken to arrange a new Australian visa while living apart, so we agreed that the best option was for me to come to PNG temporarily while we sorted out her visa and made arrangements to relocate to Australia together.

Our intention was always to return to Australia together. That was not a vague hope -- it was a specific plan, discussed and agreed with both our families before I left Australia. We estimated I would need to be here for roughly nine to twelve months. Serah was going to establish a small IT business while I was here, to sustain us and save for our move. My family in Australia was prepared to help fund the transition if needed. In preparation, and knowing my own visa would prohibit me from working in PNG, I spent the more than six months I waited in Australia for my PNG visa to be approved giving Serah substantial, expert-level IT training so the business would be capable of standing on its own from the outset.

Even before I left Australia, our plans were already being tested. My visa application was lodged through the PNG High Commission in Canberra, where I was told to expect processing within three to six weeks. It actually took approximately nine months, and despite my daily follow-up calls, nobody -- including the High Commission officer I dealt with directly -- could ever tell me why. She repeatedly said she simply did not know, which suggested the hold-up was occurring somewhere else, presumably with the PNG authorities in Port Moresby. That unexplained delay cost us heavily: I had to renew my Australian housing lease and absorb other costs while we waited, my flight costs more than doubled due to seasonal pricing changes by the time I was finally able to travel, and -- critically -- the affordable K1,000-per-month office space Serah had already identified for her business was gone by the time I arrived, along with every other comparably priced option she had found. I don't attribute that specific delay to any agency named in these proceedings, but I record it because it set the tone for everything that followed -- it was my first experience of PNG officialdom, and it was a preview of the same pattern of silence and unexplained delay that would go on to define our next decade.

I came to Papua New Guinea on or about 27 May 2015 on a Special Exemption Visa (Dependent of Citizen, non-working class), Permit Number 99902182335, subsequently renewed as Permit Number 99902878248. That visa class expressly prohibits me from seeking any form of employment in PNG, which I have complied with throughout my time here.

A few months after I arrived, we found out Serah was pregnant. We had wanted our son to be born in Australia, but rushing an international relocation mid-pregnancy did not feel responsible, and risked bringing him into a difficult and unforeseeable transitional situation. We decided the safer course was for James to be born here, and then we would move as soon as we practically could afterwards.

Our first son, James Alexander Kurek, was born on 9 March 2016 at Boram General Hospital, Wewak. We also have twin sons -- Zach Liam Kurek and Brighton Reece Kurek -- born 12 June 2021. The twins were an unexpected pregnancy; Serah had a Nexplanon contraceptive implant in place at the time. It is contrary to our core beliefs to terminate a pregnancy, so we did not. All three boys are PNG citizens by descent through their mother.

The point at which our plans began to unravel was not when the twins arrived, and it was not anything we did wrong. It was the very first step we tried to take after James was born -- getting his birth certificate. That turned out to be the beginning of a saga that is now a decade long.

---

## The Business That Never Had a Chance

Serah's business plan was not an afterthought -- it was carefully prepared, deliberately resourced, and central to how we intended to fund our return to Australia. It was undermined from the outset by structural conditions that were entirely unforeseeable to us at the time.

The registration process alone should have taken two to three weeks, according to the advice we were given. It took approximately two years. We lodged the application through what was presented to us as the official regional business registration office in Wewak. We later learned this was not a real government office at all -- it was a third-party IPA agent operating as a private business while posing as an official registration point. I understand this entity was eventually investigated and had its IPA agent authority revoked, and that we were among a large number of applicants affected by its conduct.

The compounding effect of these two delays -- the nine-month visa delay and the two-year registration saga -- was severe. The affordable office space Serah had originally found was already gone because of the visa delay. By the time the business was finally, lawfully able to operate two years later, even the next price tier of office space had been taken. We were left with only the most expensive options -- the K3,000 to K5,000 per month range that is common in our area, which makes sustainable small business operation effectively impossible. By that point we had already descended into poverty, and the financial foundation the business needed to succeed had been eroded before it had even opened its doors.

Once finally operating, the business faced a chronic, government-caused electricity crisis. PNG Power Limited, the state-owned monopoly electricity provider, has failed to maintain reliable power throughout our entire time here, affecting homes, businesses, schools, and medical facilities across the province alike.

In 2022, Serah finally saved enough to lease a small office. Before she could establish a stable customer base -- made enormously difficult by the near-daily power outages -- the landlord abruptly and unlawfully evicted all tenants, claiming renovations, and unlawfully withheld all of Serah's business equipment for almost a year.

I encouraged Serah to pursue this legally. She applied for Legal Aid through the Public Solicitor's Office, who reviewed the evidence, agreed the landlord's conduct was unlawful, and began preparing a case. About two weeks later the landlord suddenly released the equipment, and the Public Solicitor closed the file as the immediate matter had been resolved. I urged Serah to pursue a separate claim for the income lost during the nearly year-long period her equipment had been withheld. She chose not to. The landlord faced no consequence for what she did. That equipment -- a genuine financial investment meant to generate income for our family -- has continued to deteriorate in storage ever since, and between the unlawful withholding, the loss of affordable premises, and the equipment's ongoing decay, that investment has effectively been destroyed through no fault of our own.

As a result, for most of our time here, Serah's income has come from informal, irregular work through personal contacts and her church community -- typing, printing, binding, laminating. It is wildly inconsistent and, by my estimate, somewhere between ten and twenty times below what our family would need for a minimum adequate standard of living. This is not borderline poverty. This is extreme and sustained hardship, caused not by anything we did, but by the conduct of the agencies and circumstances described throughout this statement.

---

## 2016--2018: We Could Not Even Get a Form

After James was born, we tried to find out how to apply for his birth certificate. This should have been straightforward. It was not.

For roughly eighteen months -- from early 2016 through late 2017 -- the PNGCIR website was non-functional or only partially accessible, as part of a broader problem at the time where multiple PNG government department websites were being updated while still live, leaving broken and incomplete pages visible to the public throughout. There was no NID office in Wewak at the time, despite the Civil Registration (Amendment) Act 2014 requiring one to exist in every province. Every phone call to Port Moresby went unanswered. We could not get an application form, a document checklist, or any information whatsoever about how the process worked. We could not lodge an application because the agency responsible would not answer their phones and did not have a functioning website.

In approximately late 2017, we heard through word of mouth that a new NID office had opened in Wewak. When Serah went to check, it had already closed again, and there was no way to find out if or when it would reopen. It stayed closed for at least another six months. When it finally reopened, Serah began making repeated visits. Many of those visits meant queuing all day only to be turned away without being seen. Staff gave contradictory information on different visits about what documents were needed. It took many trips before she was finally able to get the application lodged.

---

## November 2018: Application Lodged -- Finally

On approximately 19 November 2018, after everything Serah had been through just to reach this point, James's birth certificate application was formally accepted at the Wewak NID office. Staff confirmed that all required documents had been provided. We were not given an official printed receipt -- the office printer had no ink -- but staff wrote the application reference number B1914006387 on a piece of paper and told us to expect contact from Port Moresby within two weeks.

We waited five weeks and heard nothing. Serah returned to the Wewak NID office, where staff confirmed the reference number again and admitted they themselves had also been unable to make contact with Port Moresby.

---

## 2018--2020: Nearly Two Years of Nothing

Months passed. Then a year. Then almost two years. After approximately nine months of total silence, Serah contacted the Wewak NID office directly. They told her they had received nothing from Port Moresby either. She asked them to try contacting Port Moresby on our behalf. They agreed -- and six weeks later, when she followed up, they told her they too had been unable to get through. PNGCIR's own provincial office could not reach its own head office. That alone says something about the state of the agency during this period.

In approximately September 2019, Serah finally managed to reach Nancy Dilu at Port Moresby directly. Ms. Dilu told her there had been a delay because some documents had been accidentally mixed up, but assured Serah the issue had been sorted out and that all documents were now in order -- reconfirming this a second time when Serah asked directly. She promised approval within two weeks. When Serah called back two weeks later, she received a vague excuse and a promise of a callback that never came.

This matters. In September 2019, the same officer who would later cite missing documents as the reason for cancellation explicitly confirmed -- twice when asked directly -- that all documents were in order. Those two positions cannot both be true. Either the documents were always sufficient, and the stated reason for cancellation was false; or PNGCIR had confirmed they were sufficient when they were not. Either way, somebody lied.

---

## August 2020: "Cancelled Due to Foreign Case"

In approximately August 2020, through word of mouth, Serah obtained a WhatsApp number for the Wewak NID office. On approximately 12 August 2020, the office told her the application was "Pending Approval" and to follow up in two weeks. She did. On approximately 24 August 2020 -- just twelve days after being told it was pending approval -- the reply came back: *"Cancelled due to foreign case."*

No explanation. Serah immediately sent three further messages asking which documents had supposedly been missing and demanding a reason. None of them were answered.

Serah called Port Moresby immediately. After considerable difficulty getting through, she was told by Ms. Dilu that there was nothing PNGCIR could do and that we would simply have to lodge a new application from scratch. When pressed, Ms. Dilu said the reason was that documents had not been attached to the application -- directly contradicting what she had confirmed in September 2019.

---

## September 2020: My Calls to PNGCIR

I was not prepared to accept that response. I had obtained Ms. Dilu's direct email address from Serah's earlier correspondence with PNGCIR, and on 2 September 2020 I emailed her requesting a full explanation for the cancellation. No reply was received. I then began attempting to reach PNGCIR Port Moresby by phone myself over the following days. My calls went unanswered repeatedly. I installed an automatic redial application on my phone and let it run until someone finally answered on 4 September 2020. Phone records from that date confirm a subset of the number of attempts required.

The person who answered was Nancy Dilu.

During that call -- and I wrote down everything immediately afterwards while it was fresh in my memory -- Ms. Dilu made a series of significant admissions on behalf of PNGCIR: that the Wewak NID office had been providing incorrect information to applicants and lacked proper training and document checklists; that PNGCIR Port Moresby had failed to contact us about any alleged deficiency at any point during the nearly two years of processing; that the same had happened to other Wewak applicants; and that Port Moresby was in fact aware the Wewak NID office had closed -- directly contradicting her earlier apparent ignorance. She also insisted I was required to provide a work permit. I explained that my visa class legally prohibits me from seeking employment, making it literally impossible for me to obtain one. She said it was still a requirement and that no exemption process existed.

Ms. Dilu then said there was nothing PNGCIR could do and that we had to start again from scratch. When I asked how to appeal, she denied any appeal process existed -- which is false, as the right to appeal is expressly provided by the Civil Registration Act 1963 and the Civil Registration (Amendment) Act 2014. When I asked for the Registrar-General's contact details, she directed me to the PNGCIR website. Based on my own prior experience trying to navigate that site, I genuinely believed at the time that she knew full well those details weren't there and was just trying to get me off the phone. I checked anyway. The details were not there. I called back to confront her about this. She became evasive and ended the call. I called back again and demanded to speak to a supervisor. After being placed on hold for an extended period, a different officer answered. She did not identify herself. She listened to my full complaint and directed me to contact Compliance Officer Benjamin Kepino at compliance@pngcir.gov.pg.

I sent a detailed formal written complaint to Mr. Kepino on 15 September 2020. That email was never acknowledged or responded to.

---

## 2021--2024: Fresh Applications, More Obstruction

On 23 and 26 November 2021, with nothing else working, I tried PNGCIR again via WhatsApp, hoping a different point of contact might get a more useful response. The officer who replied simply referred me back to the same main phone number that had never worked for us in the first place.

With no other option available, we submitted fresh applications for all three children -- James, Zach, and Brighton -- assigned application numbers B2414001162, B2414001163, and B2414001164. What followed over the next several years was a continuing series of contradictory demands and in some cases legally impossible requirements from PNGCIR's Compliance Team. The compliance officer handling these applications did not identify themselves by name in correspondence.

We were told that Serah -- a PNG citizen and the mother of the children -- was not permitted to act as a witness on her own children's birth registrations. We were also told repeatedly that I was required to produce a work permit -- despite Serah having immediately and explicitly advised PNGCIR that my visa class prohibits employment, and despite a copy of my visa documentation being attached to the very email thread making the demand, clearly showing my visa class. Serah even resubmitted it with the relevant visa class circled in red for emphasis. The demand was never withdrawn with any reasoned explanation.

Throughout the entire duration of this matter, PNGCIR strongly preferred to communicate verbally -- by phone or in person -- and consistently avoided putting anything in writing. This made it very difficult to document what had been said or to hold anyone accountable when requirements changed.

Those applications were ready for collection by approximately August 2024. Nobody notified us. They sat approved but unactioned for approximately four months. In December 2024, Serah sent a formal complaint to PNGCIR's Compliance Team. A compliance officer named Joanna Seiweni responded on 5 December 2024, acknowledged fault in writing, and advised that the applications had been verified and would proceed.

Birth certificates for all three children were finally issued on **27 April 2026** -- approximately ten years and seven weeks after James was born, and approximately four years and ten months after the twins.

The certificates were issued on the basis of the same documentation already in PNGCIR's possession. No new documents were submitted before they were finally issued. That fact alone confirms that every refusal and every additional requirement imposed along the way was not objectively justified.

Even with the certificates finally in hand, this has not freed us. As explained below, the PNGICSA situation has left us financially unable to even apply for passports, let alone afford the airfares, Serah's Australian visa costs, and resettlement expenses we would need to actually leave.

---

## Meanwhile -- The Bond Refund Saga (PNGICSA)

While all of the above was happening with PNGCIR, we were simultaneously caught in a completely separate but equally frustrating situation with the PNG Immigration and Citizenship Service Authority.

**March 2015:** As a condition of my visa, a Cash Landing Bond of K1,000 was paid to the East Sepik Provincial Treasury Office in Wewak by Serah on my behalf, as required by the PNG High Commission. The total payment was K1,100, comprising the bond and a K100 visa application fee. Treasury Receipt Number C27794 was issued. Before I departed Australia, I was told explicitly by the PNG High Commission in Canberra that the bond would be refunded in full after five years. PNGICSA's own published policy at the time stated: *"Cash Landing Bond requires a deposit of K1,000 and can be reimbursed after 5 years."* No information was ever published anywhere about how the refund process actually worked, who to contact, or what was required to initiate it. The bond has been accruing statutory interest since its maturity date in March 2020.

**March 2020:** The bond became eligible for reimbursement. I began trying to contact PNGICSA to initiate the refund. Phone calls went unanswered. It took months just to find out who to write to.

**December 2020:** I submitted a formal written refund request.

**April 2021:** Revenue Officer Ezekiel Sapaka confirmed in writing: *"As per advice from our Acting General Manager Visa Management who is also copied in this email, your claim is valid."* Acting General Manager Kessie Kapus was copied. I received no payment.

**June 2021:** Mr. Sapaka suddenly claimed that only 50% of the bond was refundable, inventing a distinction between "landing fees" and "bond maintenance fees." This distinction appears nowhere in PNGICSA's published policy, in any legislation, or in any document that he or any other officer has ever produced when I formally requested it.

**September 2021:** Manager of Finance Patrick Repo got involved -- not to correct Mr. Sapaka, but to back him up, inventing the same baseless distinction. In the same email, Mr. Repo seized on a single word of frustration I had used in an earlier message -- "asshole," describing Mr. Sapaka -- and suggested it could lead to prosecution. That word came after months of being ignored despite patient, professional follow-up. I believe it was an accurate description of how Mr. Sapaka had treated me, and I believe the prosecution remark was a deliberate scare tactic meant to discourage me from pursuing what I was legitimately owed.

**November 2021:** I formally escalated to Mr. Repo with the complete correspondence history. He apologised and promised to fast-track the matter. Nothing happened.

**November 2022:** With no resolution in sight, Serah travelled from Wewak to Port Moresby by public transport at our own expense -- a four to five day undertaking given the relevant offices were on opposite sides of the city. She met with the Acting Chief Migration Officer, who personally wrote and signed an instruction directing Mr. Sapaka to process the refund "as usual" -- the CMO's own words confirming this was meant to be a routine, standard process. Serah delivered that instruction to Mr. Sapaka in person. Nothing happened. We were never told his responsibilities had been quietly transferred to someone else.

**October 2023:** I travelled to Port Moresby myself. I was initially refused entry to the PNGICSA building because of the dress code -- I had to buy suit pants and shoes on the spot before they would let me in to make enquiries about money they already owed me. Inside, Mr. Sapaka told me for the first time that he had been transferred off my case months earlier and never told us. He sent me to Senior Finance Officer Gabriel Metro, who had no idea who I was or what my case involved. I had to explain the entire history from scratch, again.

Mr. Metro later confirmed by email that a referral letter to the Wewak Treasury (Department of Finance) had been prepared and approved. Rather than handing it to me to take back to Wewak myself -- which was the entire reason I had travelled to Port Moresby -- Mr. Metro and Mr. Repo told me he would personally deliver it as a courtesy. Neither would give me a copy. I was sceptical from the start, because the offer conveniently removed any way for me to verify the letter even existed. Mr. Repo also told me the volume of paperwork in my case was unusually excessive and would cause delays -- a claim I do not believe, given my entire file consists of straightforward correspondence any officer could review in an afternoon. I believe that was simply another excuse to buy time and discourage me from following up. Eleven months of emails later, the letter was never produced. I do not believe it was ever created.

**October 2024:** After eleven months of total silence, I emailed the Acting CMO directly with the full documented history attached, copying every PNGICSA contact I had. Mr. Repo then sent an internal email to General Manager Kapus that completely misrepresented the entire history -- leaving out both Port Moresby trips, both meetings, the CMO's written instruction, and his own promises -- and falsely implying Mr. Sapaka had simply pointed me to Wewak Treasury from the start. He said all this in the same email thread where the contradicting evidence was sitting in plain view. I refuted it immediately and in full. Ms. Kapus's only reply was to ask for a copy of the bond receipt. She never once acknowledged the contradiction, and never responded to my refutation.

**September 2024 -- March 2025:** I applied to renew my Australian passport in September 2024, ahead of my visa's expiry on 21 October 2024. Preparing that application was itself made harder by our financial situation and the constant blackouts, which made simply accessing a computer a genuine obstacle. Processing and postal delays meant the new passport did not reach me in Wewak until the first week of March 2025 -- entirely outside my control. The same financial and infrastructure problems also delayed how quickly I could lodge my visa extension application after finally receiving the passport.

**March 2025:** I contacted PNGICSA about my visa extension and formally requested that the K255 extension fee be offset against the K1,000 bond they had already confirmed I was owed since April 2021. I made this request because I have no income of my own and our broader financial situation, caused by both agencies, had left me without the means to pay the fee outright. I offered to let them keep the entire K1,000 against the K255 fee -- effectively giving up over K700 that was lawfully mine -- just to sort out my visa. They refused.

**June 2025:** I submitted my completed visa extension application on 4 June 2025. The next day, a Client Service officer who only identified himself as "Jack" told me the original K1,000 payment from 2015 had been "forfeited to the state" and demanded the fee be paid before anything would be processed. No law was cited. Nobody had ever told me beforehand that any such forfeiture condition existed.

**August 2025:** Manager Shirley Louma referred my matter to the Compliance Team -- an active threat of deportation -- after ignoring seven emails I had sent between March and August 2025.

I am currently in overstay status as a direct result of PNGICSA's own conduct.

---

## The Environment Matters, Not Just the Restriction

Before describing what has happened to my family during this period, I want to address something I expect may be raised.

I did come to Papua New Guinea by my own choice. But I made that decision under one specific condition: that it was temporary, and that I was free to leave when we were ready. I accepted what I was accepting because it was going to end. What changed was not my tolerance for this place. What changed was my ability to leave it.

The choice to come here, and the removal of my ability to leave, are two entirely separate things. I only ever chose the first. The second was imposed on me against my will by the conduct of two government agencies. And the environment I briefly accepted in 2015 is not the environment I have been confined to since -- things got progressively worse: the power situation, the financial poverty, the structural deterioration of the house, our inability to access services. What I agreed to endure for a few months became orders of magnitude beyond anything I could have foreseen or consented to.

Being prevented from leaving a place is not the same regardless of where that place is. Confinement to a safe, comfortable, well-resourced environment is not the same as confinement to a high-crime area with no reliable infrastructure, no adequate medical access, and extreme poverty. The harm is in the environment you are trapped in, not just in the fact of being trapped. I do not assert that these conditions are universal to Papua New Guinea. I assert that they are the conditions of our specific situation -- this property, this area, this level of poverty -- and that it is the State's conduct that has kept us here.

When you confine people to an environment with a known high rate of violent crime, violent assault becomes a foreseeable outcome. When you confine people to poverty without adequate medical access, preventable illness and injury become foreseeable outcomes. When you confine children to inadequate food and education, developmental harm becomes a foreseeable outcome. These are not random misfortunes that happened to coincide with our time here. They are the predictable consequences of being forced to remain in this specific environment for over a decade, against our will.

---

## What This Has Cost Us

### Living Conditions

We live in a house in Waliawi, Wewak, that is structurally compromised by significant termite damage. We are on the second floor. Multiple supporting structural beams have been weakened. Sections of the floor have collapsed and been patched with plywood. We regularly get cuts to our feet from broken tiles. I have a genuine and ongoing fear that part of the roof, floor, or balcony may collapse without warning -- which would be likely to cause severe injury or death to anyone present. The property is also infested with rats, cockroaches, bedbugs, ants, and spiders, which falls to me to manage as the one home all day.

There is a defective septic tank a few metres from our bedroom window that leaks raw sewage. There is no rubbish collection service of any kind; household refuse -- including from a large adjacent informal settlement of several hundred dwellings -- is burned in open piles at all hours, and the smoke, including from burning rubber and toxic materials, enters our home through our open steel-grated windows daily.

Electricity has for an extended period been available only from roughly 10pm to 3 or 4am -- meaning no power at all during daylight or early evening hours. From around 7pm every evening, all cooking, cleaning, and childcare has to happen by torchlight, including hauling water, food, and cooking equipment up and down the stairs to and from an outdoor open fire, often while managing young children at the same time. Our cheap solar torches don't last the whole evening, which regularly runs until 10 or 11pm once everything is done. No refrigeration, no reliable lighting, and unreliable power even for our phones -- which have been our main, and often only, way of communicating with both government departments and the outside world this entire time. PNG Power Limited, the state-owned sole electricity provider, has been failing this province throughout our time here.

Water access has been similarly unreliable. For approximately three years the supply was disconnected entirely due to an unpaid account we could not afford to settle. Since reconnection, the typical pattern has been water late at night, usually after 9pm, and gone again by morning -- a cycle that can run for weeks or months at a stretch -- on top of complete outages of three or more days happening several times a year. We supplement with rainwater collected from roof runoff -- unreliable, and not even usable until the roof has been thoroughly flushed by sustained rain, and even once filtered it goes bad within weeks -- and with a bore on the property whose water causes skin conditions like boils and rashes. Food is prepared primarily over an open fire.

Our yard -- the only outdoor space available to my children -- routinely contains razor blades, broken glass, old rusted vehicles, and other hazardous debris that I am required to monitor and clear to prevent injury. At least six violent clan conflicts have occurred within approximately 200 metres of our home during my time here, two of which reached our front gate, involving hundreds of participants armed with bush knives and improvised weapons, and resulting in fatalities. Homemade gun and slingshot projectiles have landed in our yard during some of these conflicts. On one occasion, a police officer discharged a firearm at a fleeing suspect and the round passed through our yard at body height before lodging in a vehicle on the adjacent property.

### Violence and Personal Safety

During my time here I have been the victim of multiple violent incidents including knife attacks and attempted assaults. In the most serious, I sustained a deep laceration to my hand. My son James was present and witnessed his father being attacked. I reported these incidents to police; the responses were inadequate in each case and no formal investigation or record was produced. I developed severe anxiety, depression, and hypervigilance following these incidents, including an extended period during which I was afraid to leave our home. James himself showed a visible, lasting change in behaviour after witnessing the knife attack, which I believe caused him real and ongoing psychological harm. These are ongoing consequences of being confined to an environment I had not chosen and could not leave.

### Medical Access and Physical Harm

The nearest clinic was, for the great majority of our time here, approximately twenty minutes' walk away and involved queuing for four to six hours on an outdoor surface with no shade. A newer clinic facility was built nearby in late 2024, though we have only needed to use it once -- it does nothing to undo what came before it. The nearest hospital is approximately fifteen kilometres away, a bus fare we frequently cannot afford. We have gone through extended periods without the means to afford bandages, antiseptic, antibiotics, or paracetamol. Even basic hygiene items -- soap, toothpaste, toilet paper -- have been beyond our means for days or weeks at a time.

The tropical environment carries a high prevalence of bacterial infection, with even minor cuts carrying significant risk of Staphylococcus aureus infection -- a risk acutely elevated by the absence of basic hygiene supplies and reliable clean water.

In late 2022, all three children and I contracted severe scabies infections. Zach and Brighton were particularly badly affected, with hundreds of infected open sores across their bodies. The cycle of scratching, bleeding, partial healing, and reinfection continued for approximately two and a half years due to our inability to access or afford the necessary medication, and was only resolved after we eventually obtained ivermectin in mid-2025. Zach and Brighton have permanent scarring as a result.

Two of my children -- James and Brighton -- each broke an arm during our time here, each at approximately four years of age. I attribute these injuries partly to the unsafe conditions of the property, and I am concerned that sustained nutritional deficiency may have been a contributing factor to bone fragility. In Brighton's case, the treating hospital failed to properly reduce the fracture before casting. When the cast was removed, his arm remained visibly and significantly deformed. X-rays confirmed angulation beyond the accepted threshold for self-correction in a growing child. A subsequent surgical manipulation produced no improvement. Brighton has been left with a permanently deformed right arm.

James fell on a set of stairs during a blackout -- a regular occurrence -- with only dim torchlight available. He sustained a deep laceration to his lip. Inadequate hospital treatment resulted in the wound reopening during healing, leaving him with a permanent facial scar. The injury was a direct consequence of having no reliable electricity. The scarring was preventable and was a direct consequence of the standard of care available to us.

### Nutrition

I have lived on one meal a day for most of the past ten years -- typically a bowl of rice with a tablespoon of tinned tuna or a slice of processed meat, with occasional vegetables. I have skipped breakfast and lunch throughout in order to ensure the children eat more adequately. I note that sustained daily consumption of tinned tuna over many years carries a well-documented risk of mercury accumulation in the body -- the accumulation itself is essentially inevitable at that level of long-term consumption, even though the resulting health effects vary between individuals. My children's diet has been similarly restricted, with insufficient consistent access to protein variety, vegetables, calcium, and other nutrients essential to healthy development. The harm that sustained nutritional deprivation causes to growing children is established medical knowledge, and some of the effects -- including on bone density, cognitive development, and growth -- may be permanent.

### Education

James is currently enrolled in primary school in Grade 2. Zach and Brighton are not yet of school age. All three children missed the early childhood education -- kindergarten and pre-school -- they would have had access to in Australia. The standard of education available in this area is materially below what they would have received in Australia. James demonstrates clear academic potential -- I have invested considerable time in supplementary education across a wide range of subjects -- but he also displays characteristics consistent with mild dyslexia affecting his reading and writing development. In Australia there is a well-developed infrastructure of specialist assessment and support for this condition. We have had no access to any such resources. The time my children have lost cannot be recovered -- and the disadvantage of permanently starting behind where they should have been, along with whatever neurological effects come from sustained early deprivation, is not something that simply resets once circumstances improve.

### Family

My father passed away on 10 April 2022 -- my fortieth birthday. Due to my inability to leave Papua New Guinea, I could not visit him during his final illness and could not attend his funeral. My family in Australia has been largely beyond meaningful reach for over a decade. Occasional voice and video calls are a poor substitute for physical presence, particularly for the purpose of building relationships between my sons and their paternal family. My sons have never met any member of their paternal family in Australia in person, with the sole exception of my mother, who visited Wewak for approximately two weeks. She contracted a serious illness almost immediately on arrival and spent the majority of that visit bedridden, making the visit of very limited value. My sons have had no opportunity to develop the family relationships and support networks that would ordinarily form a natural part of their upbringing. That is an irreversible loss.

### Financial Loss

I am a qualified IT specialist with an unrestricted right to work in Australia. A specific employment opportunity arranged by my brother was lost as a direct consequence of my inability to leave. Over the approximately ten years of our confinement, I have lost the entirety of the income I would have earned in Australian employment. Formally calculating that loss is a matter for counsel, but the baseline is the Australian National Minimum Wage for the full relevant period, consistent with Lewis v The State (1980) PNGLR 219. That loss is not abstract -- it represents the savings we would have had, the security our family would have had, the future that was taken from us.

Beyond lost earnings, I have been put directly out of pocket by the conduct of both agencies: two trips from Wewak to Port Moresby, each made necessary exclusively by PNGICSA's failures; years of phone credit, mobile data, and printing costs accumulated in attempting to correspond with two departments that routinely did not respond; transport costs; and interest on the numerous informal high-interest community loans Serah was compelled to take out during periods of acute financial crisis.

I am now 44 years old with a decade-long gap in my Australian employment history in a field where currency of skills and experience is particularly valued. My prospects of re-entering the Australian workforce at the level I would have attained are permanently reduced. This is a foreseeable and ongoing consequence of the years the State's conduct has cost me.

The K1,000 Cash Landing Bond also remains outstanding, together with interest accruing from its maturity date of March 2020 at the applicable statutory rate.

---

## The Compounding Effect

What I have described did not remain static. It worsened, progressively, in a way that compounded with every year that passed.

At the start, we had savings. I had solid employment prospects and a family support network in Australia. I still had my youth and my health. Each of those has been stripped away, one by one, as time passed and we remained unable to leave. The savings ran out. My father died, taking with him the financial support he had offered. My mother has since retired and her capacity to help has significantly diminished. My employment prospects have deteriorated with every year out of the Australian workforce. My health has suffered under the conditions of our confinement. The ability of my family and friends in Australia to meaningfully support our transition back has weakened with every year of separation.

There is also a category of cost still ahead of us that I want to flag, even though I cannot put a precise figure on it yet: years of unaddressed medical and dental neglect do not simply disappear once circumstances improve -- they have to be fixed, and fixing them is expensive. Serah and I both now require significant dental work as a direct consequence of years without adequate care. There will be other costs like this we have not even identified yet. Prevention is always cheaper than the cure, and we have been denied the former for a decade.

By the time any remedy becomes available, the position we would have been in had we been permitted to leave as planned is no longer recoverable. The support network that existed in 2015 is not the one that exists in 2026. The person I was at 33 with a career ahead of him is not the same person I am at 44 with a decade-long gap and declining prospects. The harm compounds. It does not wait. And it does not reset when the legal barriers are finally removed.

---

## Where Things Stand Now

Birth certificates for all three children were finally issued on 27 April 2026. However, birth certificates are only the legal prerequisite for passport applications -- and passport applications require money we do not have. Even with passports, we currently lack the financial means to fund five international airfares, Serah's Australian visa and associated costs, or initial resettlement in Australia. The practical restriction on our freedom of movement -- mine, Serah's, and our children's -- persists and is ongoing.

My visa is in overstay. PNGICSA has referred the matter to its Compliance Team. I am at genuine risk of deportation, which would immediately separate me from my three children and leave Serah unable to simultaneously work and provide primary care for three young children without their primary caregiver -- causing immediate and severe harm to their health, safety, and wellbeing.

The harm the State has caused is not in the past. It is present. It is ongoing. And in some of its dimensions -- my father's death, the scars on my children's bodies, Brighton's permanently deformed arm, the years of education my children have not had, the career I have not had, the decade of life we have not lived -- it is permanent.

I also want to be honest about the toll all of this has taken on me personally. There is a particular kind of shame that comes from being unable to feed your own children -- from hearing one of them say "Daddy, I'm hungry" and having nothing to offer but "I'm sorry, we have to wait until Mummy comes home," knowing she might come home with nothing too. This has not just deprived my family. It has been dehumanising. It has stripped us, in the most basic sense, of our dignity -- of our ability to simply live safely, healthily, and freely as a family, with some kind of future ahead of us.

---

## Escalation -- Everything Tried Before Coming Here

I have not come to the Public Solicitor's Office as a first resort. I have spent years trying to resolve this through every available channel.

I escalated repeatedly within both agencies -- from front-line officers to managers, general managers, and the Acting Chief Migration Officer -- over periods of more than seven years with PNGCIR and more than four and a half years with PNGICSA, without achieving resolution.

I first contacted the PNG Ombudsman Commission by telephone on 7 September 2020, speaking with an officer in the Screening Unit. I submitted a formal written complaint by email on 24 and 27 September 2020. After months of silence, I followed up in January 2021. In April 2021 I escalated to the Commission's general enquiries address, and received written confirmation on 21 April 2021 that my complaint had been formally registered and put through for assessment. No further substantive response was ever received. I made further contact in October 2024 and submitted additional documentation in August 2025. Still nothing.

I contacted the Australian Department of Foreign Affairs and Trade seeking consular assistance. I received an automated acknowledgement only. No officer ever contacted me, and no assistance was offered.

I contacted the United Nations Human Rights Council seeking humanitarian assistance -- specifically, whether expedited Australian citizenship by descent for my children might be available. No response of any kind was received.

I also want to be honest about something else: for much of this period, I was genuinely afraid that initiating formal legal proceedings might result in adverse action against my visa. That was not an unreasonable concern given what I had already witnessed from PNGICSA -- including a veiled prosecution threat for using a single word of frustration in an email, and the manufactured forfeiture and visa crisis that followed. That fear was a real factor in my continued attempts to resolve things through administrative channels, and it is something I want to record in full transparency.

Legal proceedings are not where I wanted to end up. They are simply the only option remaining.

I need to put an end to my family's suffering. We demand justice and significant financial compensation for our decade of harm, suffering, and deprivation -- for the violation of our constitutional rights, for my substantial loss of income and future earning capacity, and for the permanent and ongoing harm that has been caused to every member of my family. We also seek compensation for the broader and cumulative deprivation of the basic services, infrastructure, and standard of living we would have had as a matter of course in Australia -- reliable electricity and water, adequate healthcare, food security, safety, and education. This deprivation was not an inevitable feature of being unable to leave Papua New Guinea in the abstract; it was the direct and foreseeable result of being confined specifically to this environment, with its particular poverty, infrastructure failures, and lack of services, for over a decade.

---

*Prepared by Richard Ian Kurek*
*Date: [DATE TO BE INSERTED]*
