# LEGAL BRIEF
## Richard Ian Kurek v. Independent State of Papua New Guinea
### National Court of Justice — Human Rights Track

---
### Consolidated Civil Claim: PNGICSA + PNGCIR — Constitution ss.57, 58

---


# PART A: EXECUTIVE SUMMARY

## A1. The Primary Claimant and Family

| Person | Status | Details |
|---|---|---|
| Richard Ian Kurek | Australian citizen — Primary Claimant | Born 10 April 1982. Passport RA77919028 (renewal applied Sept 2024, received March 2025; formerly PA1014705). Held Special Exemption Visa (Dependant of Citizen) — non-working class. |
| Serah Sharon Akut | PNG citizen — De facto partner | NID 1460894169. |
| James Alexander Kurek | PNG citizen — Child | Born 9 March 2016, Boram General Hospital, Wewak. |
| Zach Kurek (twin) | PNG citizen — Child | Born 12 June 2021, Boram General Hospital, Wewak. |
| Brighton Reece Kurek (twin) | PNG citizen — Child | Born 12 June 2021, Boram General Hospital, Wewak. |

---

## A2. Claim 1 — PNGICSA: Cash Landing Bond, Visa Crisis, Officer Misconduct

On 9 March 2015, a K1,000.00 Cash Landing Bond was paid to the East Sepik Provincial Treasury (Receipt C27794) as a condition of Richard's visa application approval. PNGICSA's own published policy states this bond is refundable after 5 years. Richard became eligible to claim the bond refund when that 5 year period elapsed on 9 March 2020.

At no point has PNGICSA ever contested the validity of the claim. To the contrary, the claim was first confirmed as valid on 26 April 2021 by Ezekiel Sapaka, expressly on the advice of Acting General Manager Kessie Kapus, who was copied on that email, and was reaffirmed by Sapaka again on 11 June 2021 (Exhibit J). Manager Finance Patrick Repo likewise engaged directly with the claim's validity when recommending a 50% refund figure — disputing only the quantum owed, not the claim's validity (Exhibit J). Senior Finance Officer Gabriel Metro was separately provided the complete documentation and correspondence history, including these prior confirmations, before purporting to draft a letter authorising release of the funds. No officer involved — including the Acting Chief Migration Officer, who signed a written instruction directing the refund be processed as usual (Exhibit K) — could have taken any of these actions on the basis of an invalid claim; a department cannot process, refer, verify, or instruct action on a claim it does not accept as valid. These confirmations — whether express or necessarily implied by PNGICSA's own sustained conduct — did not constitute an "approval" of the refund—the right already existed—but are formal administrative admissions of the State's debt, made by PNGICSA itself.

Despite this uncontested legal fact, PNGICSA subjected the claimant to years of bad-faith obstruction, repeatedly demanding the resubmission of the exact same evidentiary documents across several years of correspondence and two expensive in-person visits to Port Moresby, yet to this day the bond refund remains unpaid.

Throughout that period, PNGICSA officers committed the following documented acts:

- Fabricated a non-existent 50% refund policy with no documentary or legislative basis (Sapaka, 11 June 2021; endorsed by Repo, 20 September 2021) (Arsenal, Counts 2–3).
- Defied the CMO's own written instruction for over 12 months (Sapaka, from November 2022) (Arsenal, Counts 26, 32).
- Purported to draft a Treasury letter that was never produced; the promise to personally deliver it to Port Moresby Treasury directly contradicted PNGICSA's own established position — that the funds sat in the Wewak Treasury RPM account, not the ICSA trust account, meaning Port Moresby held no funds to disburse and could not have processed the refund regardless of any letter (Metro/Repo, 2023–2024) (Arsenal, Defense 1E).
- Delivered deliberate misrepresentations to General Manager Kapus, omitting material facts already attached to the same email thread (Repo, 2 October 2024) (Arsenal, Count 31).
- Failed to engage with evidence already in her possession despite being the officer whose advice underpinned the claim's validation in 2021 (Kapus, 2 October 2024) (Arsenal, Count 67).
- Declared the bond "forfeited to the state" on 5 June 2025 under a non-existent legal rule ("Jack", Client Service Officer) (Exhibit J).
- Refused to offset the K255 visa extension fee against the confirmed K1,000 debt, manufacturing an artificial overstay crisis (PNGICSA/Louma, June–August 2025).
- Referred Richard to the Compliance Team in what is reasonably perceived as a retaliatory act (Louma, 15 August 2025).

Richard's visa expired in October 2024. He has been in overstay status, accumulating daily penalties because PNGICSA refused to process his visa extension application unless he first paid a fee - a fee he reasonably requested to be offset against the debt PNGICSA owes him — the offset being necessary because PNGCIR's conduct in Claim 2 had left him without separate funds to pay it.

---

## A3. Claim 2 — PNGCIR: Birth Certificate Refusal, Denial of Identity Documentation, Officer Misconduct

### Pre-Application Barriers — State-Created Delay and Start of State Liability

Prior to the November 2018 lodgement of James's birth certificate application, Richard and Serah faced insurmountable, State-created barriers to accessing the information required to lodge the application. PNGCIR's official website was non-functional for approximately two years during this period, and no NID office existed in Wewak (East Sepik Province) at the time — a direct breach of the Civil Registration (Amendment) Act 2014 s.3(6), which mandates the establishment of a provincial registration office in each province. 

Without a functioning website or a local office, and because all their telephone calls went unanswered, Richard and Serah had no access to the required forms, document checklists, lodgement addresses, or procedural instructions. The claimants did not merely possess a passive willingness to register the birth; they provably made a significant number of active attempts through multiple channels over a two-year period to do so. Every one of these attempts was frustrated by the State's own infrastructure failures and statutory breaches.

Consequently, the commencement date of the State's liability for violating the family's freedom of movement does not begin on the formal application date of November 2018; it must be calculated constructively from early 2016, the date Richard and Serah first attempted to obtain the required information, plus a reasonable allowance of time to gather documents and for standard administrative processing to occur. It is a fundamental maxim of law that a wrongdoer cannot profit from its own wrong: the State is barred from arguing that its liability—or any limitation period—commences only from the November 2018 lodgement date, since the violation began when the State first frustrated the parents' active attempts to apply, not on the date it eventually permitted the application. To rule otherwise would unlawfully reward the State for its own obstruction.

James's birth certificate application (B1914006387) was lodged in November 2018. It was cancelled in August 2020 — after two years of silence — with the reason "cancelled due to foreign case." The cancellation was never communicated during the two-year processing period.

The stated reason for cancellation included the absence of a work permit for Richard. Richard held a Special Exemption Visa (non-working). As a condition of his visa type, he is explicitly prohibited from seeking employment, and therefore cannot obtain a work permit card. The demand was legally impossible. It was an ultra vires condition with no basis in the Civil Registration Act or any other applicable legislation.

PNGCIR officers additionally:

- Provided false information about the reasons for cancellation.
- Falsely denied the existence of appeal rights — contrary to Civil Registration Act s.9 and Amendment Act s.37C(14).
- Lied about the Wewak NID office closure.
- Refused to provide the Registrar-General's contact details.

Birth certificates for all three children were issued 27 April 2026 — after approximately 10 years of unlawful non-issuance for James and 5 years for the twins. The issuance on **27 April 2026** constitutes an implicit administrative admission that the years of prior non-issuance had no lawful basis: no additional documentation beyond what had already been submitted — and accepted as sufficient — at each child's initial lodgement was ever supplied, despite years of further demands the family could not meet (see Arsenal, Defense 2B). The State did in April 2026 exactly what it always could and should have done in the years prior. The harm caused during those years remains fully compensable.

---

## A4. The Causal Connection

The two claims are causally connected, and neither is fully intelligible without the other. PNGCIR's years of unlawful non-issuance of the children's birth certificates made passports unobtainable, which made it impossible to leave Papua New Guinea. That confinement — not yet fully ended, since the family still cannot afford passports even now that certificates have issued — is the root of nearly every head of damage claimed in this case: it foreclosed the one route (Richard earning at Australian rates) that would have prevented the poverty documented in full at A5 (violence exposure, medical deprivation, restricted nutrition, lost education, psychological harm), it prevented Richard from fulfilling his Lukautim Pikinini Act 2015 s.8 duty to maintain his children — making the economic loss at F3 simultaneously his own loss and the quantified measure of the children's loss of maintenance (see Arsenal, Defense 3F, Prong 4) — and it is what exposed the family to PNGICSA's manufactured visa crisis in the first place: a decade's enforced presence is what turned a routine visa extension into a crisis PNGICSA then manufactured through its own conduct.

That second agency's wrongdoing is independent in its origin — PNGICSA owes Richard the K1,000 bond debt in its own right, regardless of the confinement — but it is now being used to extend the very harm PNGCIR caused. PNGICSA's refusal to offset that confirmed debt against the K255 visa extension fee, combined with the active Compliance Team referral of 15 August 2025, has left Richard in active overstay with a real risk of deportation that could materialise at any time. Deportation would not merely add a new harm to an already difficult situation — it would compound the existing one, removing the parent whose presence has been the only thing mitigating the poverty already documented, and forcing the same election between his guaranteed right to leave and his legal duty to remain with his children that he refused to make voluntarily for a decade (see Arsenal, Defense 3G, addressing the same doctrine as it applies independently to Serah).

Deportation would go further than mirroring that forced election — it would compel the very outcome the Lukautim Pikinini Act 2015 forbids a parent from choosing, through the very State machinery that Act binds against producing it (ss.3, 7, 8; full statutory basis at Arsenal, Case 1, A7 — "Deportation as institutional self-contradiction"). This is not a speculative harm: the conditions described above are already documented on this record (see Affidavit paras. 21, 64–67). This is precisely the harm s.57's emergency and protective jurisdiction exists to prevent before it happens, not only to remedy afterward — the relief sought at F1 asks the Court to exercise that power now, while prevention is still possible, rather than leave the family to a damages claim after the fact.

---

## A5. Human Consequences

**Why this specific location, not just PNG generally:** Confinement to PNG explains why the family could not leave the country; it does not by itself explain why they remained in this specific high-risk, under-resourced location within it. The answer is the same root cause: the poverty produced by Richard's inability to earn at Australian rates (A4 above) foreclosed relocation within PNG as much as it foreclosed departure from it — moving requires money the confinement itself removed. The exposure below is accordingly a further, foreseeable consequence of the same unlawful conduct already pleaded, not an independent or speculative harm.

**Violence and Personal Safety:** The family's home sits in an area of sustained, endemic violent crime, not an isolated incident: at least six violent clan conflicts have occurred within approximately 200 metres of the property during the family's residence, two of which erupted at the family's own front gate, involving hundreds of participants and resulting in fatalities, with gunfire and other projectiles repeatedly entering the yard the children play in (Affidavit para. 21). Richard has separately been the victim of multiple violent incidents in this same environment, including physical threats, attempted assaults, and a knife attack causing a deep hand laceration (Exhibit N). James witnessed the knife attack and suffered documented psychological trauma; Richard developed severe anxiety, depression, and hypervigilance as a direct consequence.

**Medical Deprivation and Injury:** No reliable electricity or running water, and recurrent Staphylococcus aureus infections from bore-water laundry. All three children suffered severe scabies infections left untreated for approximately 2.5 years, causing permanent scarring (Exhibit O). James and Brighton each broke an arm; Brighton's was improperly set and left him permanently deformed (Exhibit P). James was permanently scarred falling on unlit stairs during a power outage (Exhibit Q).

**Nutrition and Development:** For approximately a decade Richard has eaten a single daily meal so his children could eat; the children's diet has been severely restricted in variety and nutritional quality, with documented risk to bone density, cognitive development, and growth.

**Education:** All three children missed the early childhood education they would have had in Australia. James shows signs of dyslexia with no access to the specialist assessment or support that would be available there — a permanent, foreseeable academic disadvantage.

**Bereavement and Family Separation:** Richard's father died of cancer during this period; Richard could not visit him in his final months or attend his funeral. His three children have never met their grandfather, and Richard has had no physical contact with his Australian family for approximately 10 years. The harm here is not only the missed goodbye. The Respondents' conduct did not cause the death, but it caused the situation that made the death far more devastating than it would otherwise have been: Richard's captivity in PNG made the family reliant on his father's support during the very years that support was needed and available; the same captivity made that support impossible to receive in person; and his father's death then removed that support entirely, at a time Richard remained trapped in the same conditions that had made it necessary. A natural death is not compensable in itself — but the compounded loss of accessible support, produced by conduct already pleaded as unlawful, is a direct and foreseeable consequence of that conduct, not a separate or speculative harm.

**Financial Devastation:** Richard is a qualified IT specialist who would have earned at minimum the Australian National Minimum Wage had he been free to leave — approximately AUD $494,608 in past economic loss alone, before interest or any future-loss component (full methodology in the companion Quantum of Damages document), consistent with Lewis v The State (1980) PNGLR 219.

**Projected and Foreseeable Future Harm:** The harm is not only historical: the family's practical capacity to ever exercise their denied freedoms is progressively diminishing, a backlog of untreated dental and health needs continues to grow, and Richard's decade-long employment gap has permanently diminished his re-entry prospects at age 44.

**Cumulative Psychological Harm:** The cumulative effect of poverty, violence, medical deprivation, and isolation has caused Richard profound, persistent — not episodic — anxiety and depression, and the documented shame of being unable to provide his children with adequate food, safety, or medical care. All five family members have suffered ongoing psychological harm from this environment; James's trauma is separately accounted for in the damages pleading (see Step 3). *This is pleaded under s.36 (inhuman treatment) directly, not only as general damages colour: s.36's "cruel or otherwise inhuman" standard is not limited to discrete physical incidents (the knife assault, the scabies infections — C1 above) — a decade of sustained degradation to basic dignity is itself within the section's ordinary meaning. The affidavit's own language for this paragraph uses this exact register — "dehumanising," "stripped us of our dignity" (¶84) — confirmed against the primary text; that wording should be kept verbatim rather than paraphrased, it is doing legal work, not just describing the experience. One distinction worth drawing proactively: Application by Ireeuw & Ors [1985] PNGLR 430; PGNC 7 held that mere administrative confinement conditions — restricted movement, visitors, and food regulation "occasioned by the need for proper administration" of a border camp — do not amount to cruel or inhuman treatment under s.36. That case is distinguishable, not analogous: it concerned the ordinary, reasonably necessary incidents of an orderly camp, not — as here — years of bureaucratic dysfunction producing actual, documented physical harm (untreated infections, improperly-set fractures, a knife assault) and sustained psychological degradation. The distinction is drawn here so the State doesn't get to raise Ireeuw first.*

---


# PART B: PARTIES

## B1. Claimants

| # | Name | Capacity | Claims |
|---|---|---|---|
| 1 | Richard Ian Kurek | Australian citizen; Special Exemption Visa (non-working); primary carer | ss.36, 37, 41, 53, 59, 62 (not s.48 — Premdas v The State [1979] PNGLR 329; not s.42 or s.32 — not relied upon; not ICCPR Art.12(4) as an independent basis — Constitution s.117(7), used only as s.39(3) interpretive support — see Additional Arguments); Wrongs Act negligence available as an alternative route to the same economic loss figure, not a separate claim — status: undecided, see Part D2; K1,000 bond + interest; economic loss (~10 years Australian earning capacity); general and exemplary damages |
| 2 | Serah Sharon Akut | PNG citizen; de facto partner; NID 1460894169 | ss.52, 55, 59; freedom of movement; natural justice |
| 3 | James Alexander Kurek | PNG citizen; child; DOB 9 March 2016 | ss.36, 52, 53, 55, 59; freedom of movement (~10 years (ongoing)); denied proof of identity and citizenship |
| 4 | Zach Kurek | PNG citizen; child; DOB 12 June 2021 (twin) | ss.36, 52, 53, 55, 59; freedom of movement (~5 years (ongoing)); denied proof of identity and citizenship |
| 5 | Brighton Reece Kurek | PNG citizen; child; DOB 12 June 2021 (twin) | ss.36, 52, 53, 55, 59; freedom of movement (~5 years (ongoing)); denied proof of identity and citizenship |

---

## B2. Primary Defendant

**Independent State of Papua New Guinea** — Direct constitutional liability under ss.57, 58 for breach of constitutional rights through exercise of State power, encompassing the conduct of both PNGICSA and PNGCIR. This is the primary basis and does not depend on tort law. In the alternative only (status: undecided, see Part D2), vicarious liability under Wrongs Act s.1(1)(a) — the State is subject to tort liability for its servants' and agents' torts — and s.1(4), for the named officers of both agencies.

---

## B3. PNGICSA Named Officers

*(This table maps the personal-liability case against each PNGICSA officer in full, for counsel's use if a tort claim is pursued in addition to the constitutional claim (see Part D2 for the status of that decision). Naming an officer here does not assert that a vicarious liability or personal liability claim will be pleaded against them — both remain open questions pending counsel's analysis of which limitation regime applies to which specific act. If a tort claim is pursued: PNG authority holds that identifying the individual tortfeasor is close to a pleading necessity for a vicarious liability claim against the State (Pagasa Pembaro v Garry Baki (2015) N6224, confirmed against primary text: failure to name creates "no nexus... no cause of action against the nominal defendant"). The full test the case sets out, if the tort route is taken: (1) the named officer must be identified as the State's employee; (2) the tort must have occurred within the scope of that employment; (3) the officer must have been performing or purporting to perform functions conferred by statute or the underlying law. Naming one officer per incident is sufficient — the case does not require naming every officer involved (its own example: naming the commanding officer of a multi-officer raid suffices). Pursuing personal liability against an officer individually is a further, separate question, and for Repo specifically raises Migration Act s.16(1)(e)'s potential criminal-referral dimension.)*

| Officer | Role / Email | Basis of Personal Liability |
|---|---|---|
| Ezekiel Sapaka | a/Revenue Officer, Finance Branch — esapaka@immigration.gov.pg | Wrongs Act s.1A: defied Acting CMO's lawful written instruction from 24 November 2022; Richard never notified of officer transfer to Metro. PSMA s.51(c)(d)(e)(f)(i). GO 15.58 ×5. |
| Patrick Repo | Manager Finance — prepo@immigration.gov.pg | Wrongs Act s.1A: deliberate misrepresentation to General Manager Kapus (2 Oct 2024). PSMA s.51(i). Migration Act s.16(1)(e) — potential criminal offence. |
| Gabriel Metro | Senior Finance Officer (Revenue) — gmetro@immigration.gov.pg | Wrongs Act s.1A: fabricated existence of Treasury letter claimed personally delivered. PSMA s.51(e)(f)(i). GO 15.58 ×4. |
| "Jack" | Client Service Officer — clientservice@immigration.gov.pg | Wrongs Act s.1A: forfeiture under non-existent legal rule (5 June 2025). PSMA s.51(i). Constitution s.62 — arbitrary act. |
| Shirley Louma | Manager, Extensions Branch — slouma@immigration.gov.pg | PSMA s.51(i): retaliatory compliance referral (15 Aug 2025). GO 15.58 ×7. |
| Kessie Kapus | General Manager, Visa and Passport Division — kkapus@immigration.gov.pg | PSMA s.51(e)(f): supervisory failure 5+ years since being copied on written confirmation of the claim's validity (26 April 2021); failure to act on evidence (2 Oct 2024). |

---

## B4. PNGCIR Named Officers

*(Same distinction as the B3 note above applies here.)*

| Officer | Role | Basis of Personal Liability |
|---|---|---|
| Nancy Dilu | PNGCIR Port Moresby | Wrongs Act s.1A: misfeasance — 5 false statements including denial of express statutory appeal right; admitted fault but refused to act. PSMA s.51(i). |
| Benjamin Kepino | Compliance Officer | PSMA s.51(e)(f): complete non-response to formal complaint; failure to investigate. GO 15.58 ×2. |
| Unnamed Compliance Officer | Compliance Team | PSMA s.51(e)(i): impossible work permit demand; wrong visa information; unsigned emails; 4-month delay. |
| Joanna Seiweni | Paralegal/Compliance | PSMA s.51(f): acknowledged fault December 2024; took no corrective action. |

---


# PART C: CONSTITUTIONAL FRAMEWORK

## C1. Constitution of Papua New Guinea

| Section | Provision | Application | Whose Claim |
|---|---|---|---|
| s.22 | Enforcement of the Constitution — rights provisions are not left without effect for lack of supporting machinery or procedural law; any gap is to be supplied by the National Court "in the light of the National Goals and Directive Principles, and by way of analogy from other laws, general principles of justice and generally-accepted doctrine." | Interpretive backbone generally for reading the Constitution's justiciable provisions consistently with the National Goals; not now needed for a s.42 gap-filling role, since s.42 is not relied upon anywhere in this case (see Additional Arguments) — Richard's captivity is instead pleaded as consequential harm flowing from the children's established s.52 breach (Arsenal Prong 6). | Richard primarily; underpins claims generally |
| s.23 | Sanctions — where a Constitutional Law provision imposes a duty and no Constitutional Law or Act of Parliament provides for its enforcement, the National Court may, in the absence of any other equally effective remedy, order compensation from the person in default, including a governmental body. | A broader constitutional backstop alongside s.58(2): the further alternative for the bond forfeiture (Arsenal Defense 1H) and for the payment-enforcement relief at F6.1 (Arsenal Defense 3J), where it is construed under s.10 to avoid conflicting with s.57(3)/s.155(4) rather than to limit them. | Richard (bond); all claimants (general compensation backstop) |
| s.25 | National Goals and Directive Principles — non-justiciable in themselves (s.25(1)), but under s.25(3) any law or power is to be read, applied, and enforced consistently with them wherever reasonably possible. Goal 1: freedom from domination/oppression; Goal 1(5): the family unit as the fundamental basis of society. | Not pleaded as an independent breach. Informs, via s.25(3) and s.22 above, how the Court should read the justiciable provisions actually engaged elsewhere in this Brief — CRA s.25's mandatory registration duty and the children's s.52 movement claim both fall to be construed consistently with Goal 1(5)'s recognition of the family unit. This cautious framing is confirmed correct, not merely safe, by *Medaing v Ramu Nico Management (MCC) Ltd* [2011] PGSC 40; SC1144 — the Supreme Court there held s.25(3) does not let a court declare a law or power unlawful for conflicting with a National Goal; it only requires the law or power to be interpreted consistently with the Goals where reasonably possible. That is exactly the role given to it here, and no further-reaching use of s.25 would currently be safe to plead. | All claimants (interpretive only) |
| s.32 | Right to Freedom — "every person." **Interpretive provision only**: *Application by Tom Ireeuw & Ors* [1985] PNGLR 430 holds s.32(1) has no independent content — it takes meaning only from a specific freedom-granting section read alongside it. | Not relied upon for Richard's liberty claim — s.42 is not pleaded anywhere in this case (see Additional Arguments), and s.32 has no independent content without it. Richard's captivity is instead pleaded as consequential harm flowing from the children's established s.52 breach (Arsenal Prong 6). | Not relied upon |
| s.36 | Freedom from inhuman treatment — "no person shall be submitted to... treatment or punishment that is cruel or otherwise inhuman." | Covers two factually distinct harms flowing from the administrative captivity, kept distinct in the Quantum of Damages causation framework rather than treated as one: the knife assault (Case 2, Count 1 — an intervening third-party act) and the children's untreated scabies infections causing permanent scarring (Affidavit para. 72; Exhibit O — a single-step environmental harm, poverty preventing access to medication). Basic Rights Preamble cl.(a) ("security of the person") is consistent with this reading but is not relied on as an independent basis, for the same reason noted at Arsenal Count 1. | All claimants, particularly the three children |
| s.37 | Protection of the law — "every person." | Both agencies denied the protection of the law by imposing unlawful conditions, ignoring validated claims, and refusing legal obligations. State's litigation conduct must also comply. | All claimants |
| s.41 | Proscribed acts — harsh, oppressive, disproportionate acts prohibited. Applies to all State conduct including within proceedings. | Manufactured visa crisis, forfeiture declaration, impossible work permit demand, and 10-year administrative captivity are individually and cumulatively proscribed. | All claimants |
| s.48 | Freedom of employment — freedom of *choice* of calling, not a right to employment. **Not relied upon**: *Premdas v The State* [1979] PNGLR 329 — this Brief's own central non-citizen authority — holds directly, on near-identical facts (non-citizen unable to continue employment after entry-permit revocation), that "there is no right to employment conferred by the Constitution" and that such a complaint is "irrelevant" to s.48. | The economic loss claim rests instead on s.41 (harsh and oppressive confinement, Arsenal Prong 5), s.58 (reasonable damages entitlement), and the statutory heads already pleaded (Wrongs Act s.1A, Lukautim Pikinini Act). No constitutional gap here — the loss is compensable through those routes without needing s.48. | — |
| s.51 | Right to freedom of information — "every citizen has the right of reasonable access to official documents," subject to ten enumerated exemption categories. A further, format-agnostic right to "official information" exists at s.51(3), but is not self-executing — it directs Parliament to pass enabling legislation establishing access procedures, and none has been passed. | Pleaded narrowly as a further alternative for the children's own registration-information request (Arsenal Count 16/27): Richard has no direct standing (citizen-restricted), but the children do, with Richard acting as their representative. Genuinely untested for whether it extends to a document that never existed — see Arsenal Count 16's full treatment, including *Mesulam v Joku* (SC, 29 Nov 2023), which does not reach this question. | James, Zach, Brighton (via Richard as representative) — further alternative only |
| s.52 | Freedom of movement — "every citizen." Right to move freely and to enter and leave PNG. | Mechanically breached by PNGCIR's birth certificate refusal: no certificate → no passport (Passports Act s.6) → unable to leave — a statutory chain that needs no case authority to establish, though SCR No 1 of 1986; Re Vagrancy Act (Ch.268) [1988] PNGLR 1 confirms administrative restrictions on movement directly engage s.52, and Namah v Pato (2016) SC1497 confirms the same for restrictions on liberty generally, not just criminal custody. This is Serah's and the children's direct, primary claim — Richard's standing to bring it on their behalf does not require him to hold the right himself: s.57(1) extends to "any person who has an interest in [a right's] protection and enforcement," and separately permits application on behalf of a person "unable fully and freely to exercise his rights" — exactly the parent/next-friend role Richard already holds for the Third to Fifth Applicants. | Serah, James, Zach, Brighton |
| s.53 | Protection from unjust deprivation of property. **Note:** s.53(7) removes s.53's protection for the property of a person who is not a citizen, redirecting it to "an Act of the Parliament" instead — see Arsenal Defense 1H for the full rebuttal. Applies without qualification to the children (citizens). | K1,000 bond withheld since 9 March 2020 without just terms. Forfeiture declaration 5 June 2025 — no legislative authority. For Richard, s.53(7) means the primary basis is the ICSA Act s.36 statutory scheme that s.53(7) itself points to (already pleaded, D3; Arsenal Count 28 — the PFMA s.61 route was considered and removed this session as unverified, see Additional Arguments), with s.53 pleaded only in the further alternative; ss.37, 41, 58 ("every person," no equivalent carve-out) remain fully available regardless. Birth certificates are documents of legal status constituting property rights — s.53 applies to the children without qualification. | Richard (bond — statutory route primary, s.53 further alternative); all children (certificates — full s.53 protection) |
| s.55 | Equality of citizens — every citizen shall have equal treatment under the law. | PNGCIR imposed the work permit condition exclusively on Richard as a foreign-national father while imposing no equivalent condition on PNG-citizen fathers. The PNG-citizen mother (Serah) was additionally denied the right to act as witness for her own children's birth registrations. This discriminatory procedure disadvantaged the PNG-citizen children and their PNG-citizen mother on the basis of the father's nationality — a constitutionally impermissible basis for differential treatment under s.55. No case found squarely on this fact pattern (differential treatment of citizens based on a non-citizen relative's status) despite a targeted search; *Application of Wagi Non* [1991] PNGLR 84 is the closest available and is offered as general supporting texture, not a precise analogue — it confirms PNG courts apply s.55 with real force in a family context (a wife's discriminatory criminal treatment relative to her husband found unlawful, court acting on its own volition), not that this specific fact pattern has been tested. | Serah; James; Zach; Brighton |
| s.57 | Enforcement of guaranteed rights — SHALL enforce (mandatory). Premdas v The State [1979] PNGLR 329: UNLIMITED remedial power. Court may act on own initiative: Re Human Rights of Prisoners Sentenced to Death (2014) N6939; Re Alleged Brutal Treatment of Suspects (2014) N5512. | Primary enforcement mechanism. State argument producing outcome where proven rights violations go without remedy conflicts with mandatory provision. | All claimants |
| s.58 | Compensation — direct against State, independent of vicarious liability. CBASA s.12(1): exemplary damages where breach "so severe or continuous as to warrant." | Compensation claimed directly. Threshold for exemplary damages met on facts — 10 years, multiple rights, two agencies, ongoing. | All claimants |
| s.59 | Natural justice — objective standard. Right to accurate and complete factual basis for determination. | Breached by both agencies: decisions without notice, reasons, or appeal. Also engaged by any misleading State submissions in proceedings. This is genuine standalone content, not merely definitional support for s.37 — confirmed against primary text this round: *Richard Koki v Sam Inguba* (2009) N3785 holds s.59 "sets the minimum requirement of the principles of natural justice... the duty to act fairly and, in principle, to be seen to act fairly." *Michael Anis Winmarang v Ericho* (2006) N3040 confirms a duty to give reasons for an administrative decision is integral to this, citing *Mision Asiki v Zurenuoc* (2005) SC797 — where no reasons are given, a court may infer none good existed. Most directly useful: *Stewart Yareng v Kiong* (2019) N8152 is close to a factual match — students disciplined by an administrative body succeeded jointly on s.37, s.41, *and* s.59 together, the same three-provision combination already pleaded throughout this case's B1 counts, with the court confirming s.57(1) enforcement (not Order 16 judicial review) as the correct vehicle. | All claimants |
| s.62 | Deliberate judgement — no arbitrary or capricious exercises of discretionary power. | Jack's forfeiture (non-existent rule), Repo's 50% rate (no basis), PNGCIR's work permit demand (impossible and ultra vires) are all arbitrary acts. Sir Brown Bai v Tomscoll (2015) N6112 confirms these fail the Wednesbury tests (Kekedo v Burns Philp [1988-89] PNGLR 122 separately establishes Wednesbury unreasonableness as a ground of review generally — see E1). | All claimants |
| s.155(4) | Inherent power — National Court may make any orders necessary to do justice. | Enforcement mechanism authorising all orders sought. | All claimants |

---

## C2. Non-Citizen Compartmentalization

The State may argue Richard cannot claim constitutional protections as an Australian national. This argument fails because:

**Richard's claims do not rely on citizenship-restricted provisions.** Sections 36, 37, 41, 59, and 62 apply to "every person" or "no person" without qualification (not s.48 — *Premdas* precludes an employment-freedom basis; not s.42 — not relied upon anywhere in this case, see Additional Arguments). Section 53 is the one partial exception, and is addressed rather than omitted: s.53(7) redirects protection for a non-citizen's property to "an Act of the Parliament" instead of the constitutional provision directly. For Richard's bond, that Act is the ICSA Act and PFMA s.61, both already pleaded (Part D3; Arsenal Count 29) — the substance of the protection is unaffected by s.53(7), only its constitutional-versus-statutory pathway, and s.53 is retained as a further alternative (full rebuttal at Arsenal Defense 1H). s.53(7) has no application to the children's certificates, since they are citizens. GO 15.58 applies to "members of the public" — confirmed from legislation, no citizenship restriction. His economic loss claim is further secured through Wrongs Act negligence, which requires no citizenship (ICCPR Art.12(4) reinforces this interpretively under s.39(3) but is not itself a domestic cause of action — Constitution s.117(7), see Arsenal Prong 3). His liberty claim is pleaded as consequential harm flowing from the children's established s.52 breach (Arsenal Prong 6) — he need not win any independent liberty right of his own.

**Freedom of movement claims are filed on behalf of PNG citizens.** The s.52 claims are filed on behalf of Serah, James, Zach, and Brighton — all PNG citizens.

**State duties apply regardless of nationality.** Civil Registration Act s.25 mandates registration of "every birth." The court is being asked to enforce duties the State owed regardless of who presented at the counter. The nationality of the person harmed does not extinguish the breach.

---

# PART D: LEGISLATIVE FRAMEWORK

## D1. Claims By and Against the State Act 1996

| Section | Provision | Application |
|---|---|---|
| s.2 | Right to sue State in contract or tort. | Procedural basis for tort and contract elements. |
| s.5 | Notice within 6 months of cause of action. | CBASA applies to direct s.57/s.58 constitutional claims by its own terms — this is not a JR-style bypass situation. Continuous breach argument is what does the necessary work: each day of bond withholding, visa non-renewal, and the still-unresolved freedom of movement deprivation (s.52) is a fresh cause of action, keeping notice current. |
| s.9(c) | State has 90 days from service of s.57 application to file defence. | Governs State's response timeline. |
| s.11 | Rights of parties equal as nearly as possible. Costs as between private persons. | State has no special procedural immunity. |
| s.12(1) | Exemplary damages where breach "so severe or continuous as to warrant." Verified from legislation. | Threshold met. **Must be specifically pleaded in originating process.** |

---

## D2. Wrongs (Miscellaneous Provisions) Act (Chapter 297) — Consolidated 2023

**Status: a secondary avenue, not yet a decided part of the strategy.** The claim throughout this brief is primarily brought as a direct constitutional claim under ss.57/58 (see Part C, Part G) — it does not depend on tort law, and for the continuing institutional wrongs it avoids the limitation exposure below entirely (Part G, Ground 1). The Wrongs Act provisions below — both vicarious liability against the State and personal liability against individual officers — are mapped out in full as a supplementary avenue, and will likely be approached cautiously given the added complexity: different acts may fall under different limitation regimes, and it is not yet established which regime applies to which specific act. Whether to plead a tort claim in addition to the constitutional claim, and against which parties, is for counsel to assess against the full mapping in Part B and this section.

| Section | Provision (Verified from Legislation) | Application |
|---|---|---|
| s.1(1)(a) | State liable in tort for torts committed by its servants and agents. | Establishes the vicarious-liability route against the State itself; officers are separately joined as parties where personal liability is sought against them individually (see s.1A row below). |
| s.1(4) | State liable where officer commits tort "while performing or purporting to perform" State functions. "Purporting to perform" covers unauthorized acts. | Defeats any argument that unauthorized officer conduct removes State liability. |
| s.1A | "Subject to Section 5A of the Claims By and Against the State Act 1996, where the court establishes that the acts or omissions of an agent or servant of the State is (a) outside of the agent or servant's scope of duties; or (b) outside of the agent or servant's course of duty; or (c) not in accordance with lawful instructions, the agent or servant shall be held personally liable." Added by amendment No. 12 of 2022, s.2; confirmed against the certified consolidated Act text (Consolidated: 11/9/2023). | Applies to Sapaka (CMO defiance), Metro (fabricated letter), Jack (forfeiture without authority), Dilu (five false statements). Personal liability in addition to State liability. |


---

## D3. Other Key Legislative Instruments

| Instrument | Key Provisions | Application |
|---|---|---|
| ICSA Act 2010 (+2021 Amendment) | ss.4, 5, 23, 35, 36, 47 | PNGICSA's authority, functions, CMO powers, Trust Account, good faith defence (unavailable to named officers) |
| Public Finances (Management) Act 1995 | s.61 | Prohibition on unlawful retention or disposition of public money. The K1,000 bond is public money collected on behalf of the State (ICSA Act s.5, s.35). Jack's forfeiture declaration and the ongoing retention of the bond without Ministerial authority or legislative basis constitute unauthorized dealings with public money under this provision. Reinforces ICSA Act ss.35–36 breach counts. |
| Migration Act (Ch.16) / 2023 | General admin + s.16(1)(e) | Bond administration obligations; Repo — potential criminal offence |
| PSMA 2014 + General Order 15 | s.51(c)(d)(e)(f)(i); GO 15.19; GO 15.58 (verified: "members of public" — no citizenship restriction) | Disciplinary liability all named officers |
| Public Servants Oath | Points 2, 3, 4, 6, 8 | Legally binding — breached by multiple officers |
| Civil Registration Act 1963 + Amendment Act 2014 | ss.9, 16, 25, 27, 60; ss.3(6), 37C(3), 37C(14) | Mandatory registration obligation; appeal rights; criminal exposure; provincial office duty |
| Employment of Non-Citizens Act 2007 | s.6(1) | Work permit obligation falls on EMPLOYERS, not employees — confirmed against the consolidated Act text (s.6(1)-(2) creates separate employer/employee offences) and *Wolfgang Bandisch v NCD Botanical Enterprises Ltd* (2009) N3806. No employer in birth registration context. Richard legally prohibited from employment. Demand was legally impossible and ultra vires. |
| Lukautim Pikinini Act 2015 | ss.5, 6, 7, 8 | Best interests paramount; Convention on Rights of the Child incorporated via s.6; right to live with parents; duty to maintain |
| Passports Act 1982 | ss.1, 6 | Statutory nexus: birth certificate required for passport; establishes freedom of movement causal chain |
| Frauds and Limitations Act 1988 | s.16 (misapplied); s.22 (extension for disability) | No State forfeiture power exists. s.22 confirmed against primary text: extends the limitation period for anyone "under a disability" (defined to include under-21s) until six years after the disability ends — directly protects James, Zach, and Brighton's own claims regardless of any other limitation argument. |
| Underlying Law Act 2000 | — | *Withdrawn as a citation for this purpose.* Neither s.7(4) (a gap-filling provision for updating outdated underlying-law rules) nor s.9 (same) says what this row previously claimed — confirmed against primary text. Tolling is instead pleaded via Frauds and Limitations Act s.22 (Ground 9); ICCPR incorporation does not exist in PNG domestic law at all (Constitution s.117(7)) and is used only as s.39(3) interpretive support (see Arsenal Prong 3). |
| Judicial Proceedings (Interest on Debts and Damages) Act 2015 (No. 15 of 2015, certified 26 Oct 2015) | ss.4(1)–(2), 6(1)–(2) | **Confirmed against the certified Act text.** Repeals and replaces the 1962 Act (Chapter 52) (s.7); applies retrospectively to all Court Orders against the State made on or after 1 January 2014 (s.2). Both pre-judgment (s.4(2)) and post-judgment (s.6(2)) interest against the State are capped at **2% yearly** — a reduction from the repealed Act's 8% cap. A judgment exceeding 2% against the State is a nullity, liable to be set aside (ss.4(4), 6(6)) — the cap is not merely a ceiling to argue toward but a hard limit on the pleading itself. Full worked methodology and figures at standalone Quantum of Damages document. |
| ICCPR Article 12(4) — no direct domestic incorporation (confirmed) | "No one shall be arbitrarily deprived of the right to enter his own country." | Not pleaded as an independent basis. Constitution s.117(7) is definitive: a treaty forms no part of PNG municipal law unless an Act of Parliament gives it that status, and none has for the ICCPR. Used instead as s.39(3) interpretive support — a court assessing whether conduct was "reasonably justifiable in a democratic society" may have regard to international human rights instruments, and PNG's own courts have said the ICCPR specifically has "influenced" and continues to "guide" constitutional interpretation. Reinforces Prong 5 (s.41) and the Wednesbury arguments; carries no independent weight of its own. |
| Organic Law — Ombudsman Commission | Wrong conduct provisions | Parallel escalation mechanism — grounds established for Sapaka, Repo, Jack, and PNGCIR institutional conduct |
| ICSA Act s.39 | Ministerial Committee of Inquiry — grounds met under s.39(1)(c) and (d) | Available escalation mechanism. "Persistent and deliberate frustration of, or failure to comply with, lawful directions" and "persistently exceeded its powers or disobeyed applicable laws" are both established. Flag for counsel to consider. |

---


# PART E: KEY CASE LAW

## E1. Primary PNG Authorities

| Case | Court / Year | Principle | Application |
|---|---|---|---|
| Premdas v The State | [1979] PNGLR 329 | National Court has **UNLIMITED** power to remedy constitutional rights breaches under s.57. Remedy includes declaratory orders, protective orders, damages, and interim restraining orders. | All orders sought are within scope. Court may act on own initiative. Defeats any State argument limiting available remedies. |
| SCR No 5 of 1985; Raz v Matane | [1985] PNGLR 329 | Kidu CJ and Kapi DCJ (Amet J dissenting): s.41 (proscribed acts) does not confer a "right or freedom" within the meaning of s.57(1) — it is enforceable instead under s.155(4) and, in the further alternative, s.23(2). Both routes are accepted by every judge on the panel, including the dissent. | Controls how every s.41-based count in this case must be enforced — s.155(4)/s.23(2), not s.57. Affirmed by the Supreme Court in 2022 (below); a real, live distinction, not a technicality safely ignored. |
| Independent State of PNG v Uddin | [2022] SC2312 | Supreme Court (Salika CJ, Murray J, Anis J), full text obtained and read this session — corrects the earlier secondary-source characterisation below. Reversed the National Court on **every** ground, not only enforcement: (1) confirms Raz v Matane's majority controls, s.41 not s.57-enforceable; (2) reversed the harsh/oppressive finding on the merits — held Uddin's removal was "reasonable and therefore lawful," not harsh or oppressive; (3) held the National Court had no power under s.155(4) either to order a specific entry permit issued, since Migration Act s.19 ousts review of entry-permit and removal decisions "on any ground," and s.155(4) doesn't override a clear statutory bar (State v Tamate [2021] SC2132); (4) confirmed Premdas: no natural-justice hearing right on deportation for non-citizens; (5) the "forcible transfer"/prior-detention finding was irrelevant to the case actually before the court. | The enforcement-vehicle point (1) is what this Brief already relies on. Points (2)-(5) are not favourable and must be actively distinguished, not cited as support — see the corrected note below and Arsenal A7. |
| Uddin v Kantha (National Court, reversed in full on appeal — see above) | [2020] PGNC 83; N8267 | Cannings J's trial decision, now confirmed overturned on every point, not only the enforcement question. Uddin's actual facts, per the Supreme Court's own recitation: an asylum seeker whose refugee claim was rejected, deported once already in 2018, then **illegally re-entered PNG by boat with no permit at all** in 2019, and was **criminally convicted** of unlawful entry (K2,000 fine). | **Not a favourable analogue — actively distinguish it.** Richard has never been convicted of any immigration offence, was never validly deported, and holds a currently-valid Special Exemption Visa throughout; his overstay is the direct, admitted product of PNGICSA's own refusal to apply a debt it confirmed it owed him, not unlawful conduct of his own. That is the entire distinction the Supreme Court's ruling turned on (¶42-44: "absolutely nothing to show" the removal was anything other than ordinary lawful process for a genuine illegal entrant). Richard's facts, unlike Uddin's, supply exactly what the Supreme Court found missing. |
| Re Human Rights of Prisoners Sentenced to Death | (2014) N6939 | Court may exercise s.57 jurisdiction on its own initiative — Cannings J conducted a judge-led human rights inquiry under s.57 without a party application. | If State conduct during proceedings is sufficiently egregious, court may act independently. (Note: the previously-cited *State v Kusap Kei Kuya* [1983] PNGLR 263 was checked this session and found to be an unrelated criminal confession-admissibility case — removed and replaced.) |
| Kekedo v Burns Philp (PNG) Ltd | [1988-89] PNGLR 122 | Leading PNG authority establishing Wednesbury unreasonableness as a ground of judicial review generally — a decision "which no reasonable tribunal could have reached," alongside ultra vires, error of law, and breach of natural justice as the recognised grounds. Confirmed against primary text this round: this case does *not* contain the specific five-part test below — that was previously misattributed here. | General authority that Wednesbury unreasonableness is a recognised, available ground — the umbrella under which the specific test (next row) operates. |
| Sir Brown Bai & Patrick Reu v Hon. Assik Tommy Tomscoll & Ors | (2015) N6112 | Confirmed against primary text as the actual source of the specific five-part test used throughout this Brief and the Arsenal: a valid exercise of discretion (1) must be real, (2) must have regard to matters the statute refers it to, (3) must ignore irrelevant considerations, (4) must not operate on bad faith or dishonesty, (5) must direct itself properly in law, and (6) must not be so absurd that no reasonable person would act that way — the court's own words: "it is the sixth principle which is often referred to as the one that succinctly summarizes the Wednesbury principles." | Jack's forfeiture declaration fails (3)(4)(5)(6). PNGCIR work permit demand fails (3)(4)(5)(6). Repo's 50% fabrication fails (3)(4)(5)(6). Numbering above follows N6112's own six points; prior references to "(a)-(e)" throughout this Brief and the Arsenal map onto points (3)-(6) — retained as lettered shorthand elsewhere for continuity, now correctly sourced. |
| SCR No 1 of 1986; Re Vagrancy Act | (Ch.268) [1988] PNGLR 1 | The Vagrancy Act was declared unconstitutional for breaching ss.38, 42 and 52 — administrative restrictions on movement engage s.52 directly and must satisfy s.38's "reasonably justifiable" test. | Direct authority for Serah's and the children's s.52 claims: administrative barriers to movement (birth certificate refusal → no passport) are the same category of constitutional breach. |
| Lewis v The State | (1980) PNGLR 219 | Loss of earning capacity assessed at what plaintiff **WOULD** have earned, not actual earnings at trial. | Richard's economic loss calculated at Australian minimum wage rates for duration of administrative captivity — not PNG income of zero. |
| David Toll v Kibi Kara | [1990] PNGLR 71 | Dishonesty **NOT** required for finding of improper conduct under PCR 1989. Conduct merely prejudicial to administration of justice is sufficient. | State lawyers advancing objectively misleading arguments engage PCR 1989 without needing to prove subjective dishonesty. |
| Marape v O'Neill | [2016] PGSC 16; SC1492 | PCR 1989 Rule 15 engaged where lawyers' conduct amounts to collusion to pervert the course of justice. | Available argument where State lawyers advance arguments they know to be false or misleading. |
| Credit Corporation v Jee | (1988-89) PNGLR 11 (cited in Bench Book) | "Discovery is not a matter of bargaining or compromising. It is the obligation on a party to supply a list of all the documents which might have any bearing on the subject matter in dispute." | Supports early discovery orders requiring full production of all internal departmental records. |

---

## E2. The Wednesbury Five Tests
*(Sir Brown Bai v Tomscoll (2015) N6112 — the specific test; Kekedo v Burns Philp (PNG) Ltd [1988-89] PNGLR 122 — Supreme Court authority for Wednesbury review generally)*

| Test | Requirement | Breached By |
|---|---|---|
| (a) | Consider only matters relevant to the statute conferring the power. | Jack: forfeiture — no statutory basis. Repo: 50% rate — no statutory basis. PNGCIR: work permit — irrelevant legislation applied. |
| (b) | Ignore irrelevant considerations. | Repo: personal motivation to suppress complaint. PNGCIR: father's nationality irrelevant to mandatory registration. |
| (c) | Must NOT operate on basis of bad faith or dishonesty. | Sapaka: CMO defiance. Repo: Kapus misrepresentation. Metro: Treasury letter fabrication. Jack: non-existent rule. Nancy Dilu: 5 false statements. |
| (d) | Direct itself properly in law. | Jack: no forfeiture provision in any Act. Work permit demand: wrong party under ENC Act s.6. Discretionary argument: "shall" means "shall." |
| (e) | Not so absurd that no reasonable person would act that way. | Withholding K1,000 → refusing K255 offset → initiating deportation for K255. Demanding work permit from person legally prohibited from employment for birth registration. |

---


# PART F: RELIEF SOUGHT

*Under Premdas v The State [1979] PNGLR 329 the National Court has unlimited power to remedy s.57 breaches. All relief below is within scope. Two qualifications, confirmed this session against primary text: first, s.41 (proscribed acts) is not itself a "right or freedom" enforceable under s.57 — SCR No 5 of 1985; Raz v Matane [1985] PNGLR 329 (Kidu CJ, Kapi DCJ; Amet J dissenting), affirmed on appeal in Independent State of PNG v Uddin [2022] SC2312. s.41 relief is instead sought under s.155(4) and, in the further alternative, s.23(2) — both confirmed available for s.41 by every judge in Raz v Matane, including the dissent. Second, and separately: Uddin also confirms s.155(4) does not override a clear statutory bar on review — relevant specifically to Order 3 below, addressed there directly. Every s.41-based item below is cited accordingly; s.57 is retained alongside where a genuine Div III.3 right is also engaged (s.36, s.37, s.52), since those rights are unaffected by either point.*

---

## F1. Emergency / Urgent Relief — File Immediately

**Note to Solicitor on Strategy:** This relief neutralizes the immediate threat of deportation and forces regularisation of the claimant's visa via the K1,000 offset. A finalised visa makes deportation legally impossible, but the injunctions (Orders 1 and 2) must still be sought concurrently with the Mandamus (Order 3): positive orders (mandamus) take time to execute, whereas negative orders (injunctions) provide immediate, day-one protection against rogue Compliance action in the interim. Total abolishment of all overstay penalties is not sought here as interim relief — it is the automatic legal consequence of the final Declaratory Relief (F2) establishing the overstay as state-manufactured, and follows from that finding without needing to be separately ordered now.

| Relief | Basis | Priority |
|---|---|---|
| 1. **Emergency Injunction (Protection of Family Unit)** — restraining the State from executing any deportation, compliance, or enforcement action against Richard pending final resolution of these proceedings. | ss.57, 155(4); Premdas; Lukautim Pikinini Act 2015 ss.7-8 (right to live with parents; duty to maintain), s.3 (Act Binds the State) | **IMMEDIATE** |
| 2. **Emergency Injunction (Status Protection)** — restraining PNGICSA from classifying Richard as a "prohibited immigrant" and suspending the accumulation and enforcement of all overstay penalties pending resolution. | s.37 (s.57); s.41 (s.155(4), s.23(2) — not s.57, Raz v Matane) | **IMMEDIATE** |
| 3. **Mandamus (Visa Regularisation via Offset)** — compelling PNGICSA to immediately process the pending visa extension application by applying the verified K1,000 debt owed to the claimant as full satisfaction of the standard visa fee, without requiring secondary payment. | s.53; ICSA Act s.5; CBASA s.11. *Distinguished from Independent State v Uddin [2022] SC2312's bar on courts directing entry-permit issuance: that bar addresses a court substituting its own discretionary judgment for the Minister's on whether someone should be permitted to remain — a decision Migration Act s.19 commits to the Minister alone. This order asks nothing of that kind. It doesn't ask PNGICSA to grant, extend, or exercise any discretion over Richard's status at all — it asks that a debt PNGICSA itself already confirmed be applied as payment, a ministerial/accounting act with no discretionary immigration content. If the State argues otherwise, the fallback is to seek a declaration that the refusal to offset was unlawful (F2) and leave the mechanics of compliance to PNGICSA, rather than press the mandamus as originally framed.* | **IMMEDIATE** |

---

## F2. Declaratory Relief

- That PNGICSA's failure to refund the K1,000 bond since 9 March 2020 constitutes a continuous breach of Constitution ss.37, 41, 53, 59, 62 and ICSA Act ss.4, 5, 35, 36.
- That Jack's forfeiture declaration of 5 June 2025 is null and void — made without legislative authority, arbitrarily and capriciously, in breach of Constitution s.62 and Wednesbury principles.
- That PNGICSA's refusal to offset the K255 fee against the confirmed K1,000 debt is unlawful under Constitution s.41.
- That PNGICSA is estopped from enforcing any overstay penalty, visa refusal, forfeiture, or deportation action against Richard arising from non-payment of the K255 visa extension fee, where that non-payment was itself a direct and foreseeable consequence of PNGICSA's own unlawful withholding of the K1,000 debt it owes him — consistent with the estoppel principle already applied to PNGCIR's conduct above (a party cannot rely on a default it engineered).
- That PNGCIR's work permit condition was ultra vires, without legislative authority, and void ab initio.
- That PNGCIR's cancellation of application B1914006387 and all subsequent refusals were unlawful breaches of Civil Registration Act s.25 and Constitution ss.37, 41, 59, 62.
- That the combined effect of PNGICSA and PNGCIR's conduct constituted unlawful administrative captivity of the family from approximately 2016 – present (ongoing), breaching Constitution s.41 (enforceable via s.155(4)/s.23(2)) and s.52 (enforceable via s.57, s.58).

---

## F3. Compensatory Damages

Constitution s.58(2) is mandatory for reasonable damages once a breach is established, not discretionary. The provision states that a person whose rights are infringed *"is entitled"* to reasonable damages — a present-tense declaration of an existing right, not a power the Court may choose to exercise — and the contrast within the same subsection is deliberate: exemplary damages are expressly qualified *"if the court thinks it proper,"* reasonable damages are not (text confirmed against the certified Constitution). This textual reading is confirmed by direct authority: *Constitutional Reference No. 1 of 1977* [1977] PNGLR 362; SC122 (Frost CJ, five-judge bench) describes s.58 as conferring "an additional and independent entitlement... to reasonable damages, and if the Court thinks proper exemplary damages" — precisely the mandatory/discretionary split argued above. *Wilson v Kekeya* [2018] N7613 applies the same reading: "an entitlement arises under Section 58(2)." For a continuing breach, the entitlement is not confined to the present: it accrues from the first day of the breach and covers its full duration, since the Court's finding operates on a breach that has been continuing throughout, not one starting on the date of judgment. The entitlement is not limited to economic loss — reasonable damages under s.58(2) extend to any actual or foreseeable harm the breach caused, including physical and psychological harm, loss of liberty, family separation, and the children's own developmental and educational harm, alongside the economic loss quantified below. *One precision point, confirmed against Raz v Matane [1985] PNGLR 329 (Kidu CJ): s.58(2) damages flow from an infringement of an actual Div III.3 right or freedom. A pure s.41 finding — unlawful, but not also a breach of an enumerated right — grounds compensation under s.23(2) instead, not s.58 directly. This does not weaken the claim: every s.41-based harm in this case is independently anchored to an enumerated right as well (s.36, s.37, or s.52, directly or via Prong 6's consequential-harm route for Richard), so s.58 remains available throughout — s.41 is pleaded as the severity/disproportionality characterisation, not as the sole gateway to damages. Where s.41 genuinely stands alone (the visa/overstay-crisis counts, Arsenal A1 Counts 2-6), s.23(2) is pleaded as the operative damages basis, not s.58.*

*Full worked methodology, per-applicant breakdown, causation analysis, and figures are set out in the standalone companion document: **Quantum of Damages — Full Per-Applicant Analysis**. Summary only below.*

### F3.1. Summary of Heads of Damage

| Head of Damage | Claimant(s) | Basis |
|---|---|---|
| K1,000.00 Cash Landing Bond, principal + interest — pleaded in the alternative to the Mandamus at F1; see Quantum doc §3.3 | Richard | s.53; ICSA Act s.5; JPIDDA 2015 ss.4(1)–(2), 6(1)–(2) |
| Economic loss — Australian earning capacity, past + continuing + future | Richard | Lewis v The State; six-prong liability framework — see Breach and Defense Arsenal, Defense 3F; calculation methodology — Quantum doc Part 3.2; interest — F3.2 below; future loss — F3.4 below |
| General/non-economic damages — administrative captivity, injury, bereavement, isolation, dignity | All five applicants | ss.36,41,52 — see Quantum doc Parts 3–7. Bereavement (father's death; unable to attend the funeral — Affidavit para 78) is pleaded as a consequence of the s.52 movement breach, with Richard's own share pleaded as consequential harm (Arsenal Prong 6), not a s.35 claim (no State-caused death) or s.53 claim (no property in issue) |
| Special damages — travel, communications, business loss, overstay penalties | Richard, Serah | Wrongs Act s.1 negligence — primary, no constitutional enforcement-vehicle question; Constitution s.41 via s.23(2) — independent alternative (not s.58 directly, s.41 standing alone here — Raz v Matane) — see Quantum doc Parts 3.4, 4.3–4.4 |
| Exemplary damages | All applicants | CBASA s.12(1); Premdas — see Quantum doc Part 8 |

**Indicative family total (excl. exemplary, excl. final actuarial interest run): K1,982,124–K2,391,124, using the Bank of Papua New Guinea's official rate as at 2 July 2026 (K485,126–K894,126 Kina-denominated components, all applicants, plus Richard's AUD $494,608+ economic loss converted at K1,496,998, at a 50/52-week realistic-attendance rate — see Quantum doc §3.2.1 point 6).** This is a dated snapshot, not a final figure — see the Quantum of Damages document (3.2.4) for the full conversion methodology and the reasoning for using the PNG Government's own reference rate. It also excludes weekly-tranche interest (illustrative ≈ K140,050 — F3.2 below) and any future-loss sum the Court may elect to award (F3.4 below).

### F3.2. Interest on Economic Loss — Weekly-Tranche Methodology

The K1,000 bond attracts interest from a single date — the date of the underlying debt. Richard's economic loss is different in kind: it comprises ten separate annual amounts (Quantum doc §3.2.3), each of which accrued progressively across its own financial year as wages, not as a lump sum on one date. Running interest on a full year's figure from a single fixed date would either overstate the claim (from the year's start) or understate it (from the year's end).

The weekly-tranche method instead treats each year's total as accruing evenly across it, consistent with how wages are actually paid. For interest purposes this is closely approximated — without needing to run separate weekly calculations — by treating each year's full amount as accruing from that year's midpoint (1 January), a standard simplification for evenly-accruing periodic sums.

Applying JPIDDA 2015 ss.4/6 at the certified **2% per annum** rate (see D above), simple interest, from each year's midpoint to 2 July 2026 totals approximately **AUD $46,273**, bringing the principal-plus-interest figure to approximately **AUD $540,881 (≈ K1,637,048)**. Full year-by-year figures are set out in the Quantum of Damages document at §3.2.5. This is a worked calculation to confirm methodology and order of magnitude — counsel or an instructed actuary should confirm whether the Act's text prescribes simple or compound interest and recompute to the actual date of filing or judgment; if compound interest applies, the figure would be modestly higher. **Do not plead a higher rate against the State — ss.4(4)/6(6) make an excessive judgment a nullity.**

### F3.4. Future Loss of Earning Capacity

The past-loss component (§3.2.3) is fixed, because the relevant years have already elapsed. The future-loss head rests on the following facts and argument.

Richard's date of birth (10 April 1982) is corroborated by identity documents already in evidence and establishes that he is currently 44 years of age. The ten-year absence from the Australian labour market is established at Quantum doc §3.2.1–3.2.3.

But for the Respondents' conduct, Richard would have remained continuously employed in Australia across that decade — with one employer throughout, or across a small number of employers, either way building an unbroken, recent work history. Age is not a barrier to someone already in continuous employment, because no hiring decision is being made; the disadvantage that attaches to being 44 arises specifically at the point of entry into the labour market, not from continuing within it. Richard's actual position is the reverse of that counterfactual: a cold-start job search at 44 with a ten-year gap on the record — the combination that measurably narrows prospects relative to a candidate with continuous, recent experience. This is not a physical limitation: Richard has no injury or health condition of any kind and remains as capable of the same work as at any younger age. The disadvantage is evidentiary rather than physical — an age and an employment gap that, combined, are difficult to overcome on paper, and that do not diminish with further time. This is a matter of ordinary common knowledge rather than a proposition requiring expert quantification — though PNG's Supreme Court requires real evidence of a substantial risk to future earning capacity before making an award on this head (Coady v Motor Vehicles Insurance (PNG) Trust [1987] PNGLR 55); the facts above are put forward as satisfying that requirement.

Papua New Guinea authority applies a discount rate when converting a future loss stream to its present value: Koko Kopele v Motor Vehicles Insurance (PNG) Trust [1983] PNGLR 223 gives five per cent; the later Pinzger v Bougainville Copper Ltd [1985] PNGLR 160 gives three per cent. Counsel should confirm which reflects current practice.

The relief sought at F6.1 changes what this head actually needs to cover. If the Court orders prompt payment and it is made, the total deprivation of Richard's Australian earning capacity ends on that date — there is no future loss to speculate about beyond it, because his ability to seek employment is restored. What remains is narrower and falls into two distinct components, not one:

1. **Delay-period continuation, if payment is late.** Any period between judgment and actual payment is not a future loss requiring separate justification — it is the same, already-proven past loss (§3.2.1–3.2.3 methodology, same rate) continuing for a known and specific reason. This avoids the ordinary objection to future-loss claims (that they are speculative) entirely, since nothing is being projected; the same proven loss simply has not yet stopped.
2. **Permanent diminished capacity after payment**, if pressed — the residual, genuinely prospective component addressed by the "cold-start at 44" analysis above. This is smaller and separate from (1), and remains a matter for counsel's judgment on quantum, as below.

**Counsel should consider whether to press a specific future-loss claim on this basis and, if so, on what quantum.** No figure or multiplier is proposed by the claimant.

Beyond the calculable heads above, the lost decade carries further financial consequences that resist precise quantification — foregone superannuation accrual, investment and savings opportunities, and the general compounding effect of lost time on long-term financial security. These are not separately claimed or quantified; they illustrate that the true scope of harm exceeds what the wage-and-interest figures alone capture.

---

## F4. Exemplary Damages

CBASA s.12(1) verified from legislation: available where breach "so severe or continuous as to warrant." Threshold is met:

- 10 years sustained constitutional rights violations
- Two separate government agencies operating simultaneously
- 10 officers implicated by name or identified role (9 named individually, plus one PNGCIR Compliance Officer identified by role only) — each committed to documented misconduct
- Deliberate fabrication of facts, legal rules, and correspondence
- Defiance of direct CMO written instruction for 12+ months
- Active manufactured crisis threatening deportation of three children's primary carer
- Documented physical assault caused by administrative captivity
- Entire family including three young children permanently harmed
- Conduct severe and erratic enough to reasonably deter the primary applicant from formally asserting his family's rights for years (Affidavit para. 87; see Arsenal, Defense 3I) — a chilling effect on access to justice, not merely a delay to be excused
- Not isolated errors but a habitual operating norm: across both agencies and effectively every officer dealt with over the relevant period, indifference to legal obligations was the pattern rather than the exception — destroying any presumption of good faith or honest mistake (see generally Affidavit Parts B–C)
- PNGCIR's own contemporaneous record shows citizenship-based prejudice affecting the children's own applications, not just matters that were Richard's own: James's birth certificate application — his own document, not Richard's — was cancelled with the stated reason "Cancelled due to foreign case" (Affidavit para. 30; Exhibit D), notwithstanding that James is a PNG citizen by descent and the application concerned only his own registration

> ⚠️ **Exemplary damages MUST be specifically pleaded in the originating process. Failure to plead them may preclude their award entirely.**

---

## F5. Costs

Costs on an indemnity basis sought given the nature of the State's conduct. NCR Order 22 applies. CBASA s.11 confirms costs may be awarded against the State as between private persons.

---

## F6. Further Relief

Pursuant to Constitution s.155(4) and Premdas, any further orders necessary to do justice, including referral of named officers to the Lawyers Statutory Committee, referral to the Ombudsman Commission, and systemic orders requiring PNGICSA and PNGCIR to remedy their administrative processes.

### F6.1. A Payment Timeframe, Not Just a Judgment Sum

An award of damages does not, by itself, remedy this claim's central harm. The freedom of movement violation is no longer purely administrative — it is now also financial: even a favourable judgment leaves the family unable to leave PNG until the money is actually received. A remedy that stops at the judgment sum, on the ordinary "reasonable time" timeline, would leave the Court fully aware that the underlying rights violation may continue for years — a Commission of Inquiry into the Department of Finance itself confirms that payment of State judgment debts is at the Secretary for Finance's discretion, made in "reasonable time" from "moneys legally available" (i.e. budgeted funds), often by instalments, and that the enabling Act specifically excludes the courts from ordering execution against the State. On the Human Rights Track, awarding damages while leaving payment timing to that ordinary, undated process does not end the s.52 violation — it prolongs it with judicial awareness, and does so within a procedural framework whose own stated purpose cuts the other way: the Human Rights Rules 2010 (made under Constitution s.184 and National Court Act s.8) exist specifically "to facilitate a quick and just resolution" of human rights matters. An open-ended payment timeline is not merely unhelpful to that purpose — it sits in tension with it.

The apparent statutory bar on execution does not defeat a specific payment timeframe ordered under this Court's own constitutional remedial power, for two independent reasons:

1. **Construction first (s.10):** the bar is properly read as directed at ordinary civil judgment debts (the commercial and negligence claims a Commission of Inquiry into Finance would ordinarily address), not at orders made under s.57(3)'s "unlimited" remedial power (Premdas) or s.155(4)'s inherent jurisdiction in a constitutional rights case. Section 10 requires every Act other than the Constitution to be construed, wherever the words fairly allow, so as not to conflict with it — and this narrower reading avoids any conflict entirely.
2. **Supremacy as the backstop (s.11):** if the bar could only be read as also reaching constitutional remedial orders, then to that extent it is inconsistent with the Constitution's supreme law status and is "invalid and ineffective" under s.11(1) — an ordinary Act cannot cut down a remedial power the Constitution itself confers.

The Court is asked to set a specific, reasonable payment deadline as part of the judgment itself (rather than leaving timing to the ordinary post-judgment process), with liberty to apply if it is not met. A deadline with liberty to apply is not execution against the State in the sense the Act addresses; it is the Court exercising its own remedial jurisdiction to ensure the rights violation this case is about actually ends, consistent with the Human Rights Track's purpose.

Full payment before departure, in one sum, is the relief sought — not merely preferred over instalments, but the only structure that resolves the matter completely and avoids recreating the forced election addressed at Defense 3G in a second context. An instalment schedule, even one front-loaded so the first payment is itself relocation-sufficient, does not avoid this: the trap is the combination of sufficient funds becoming available and the practical degradation of the applicants' ability to enforce a PNG order once they have left the country, and that combination recreates itself at whatever point in any schedule sufficient funds first accumulate — front-loading changes only when it is triggered, not whether it exists. Nor is a secured or escrowed arrangement an answer the applicants seek: any such structure would require its own ongoing administration and release conditions, extending the applicants' entanglement with the same machinery this relief is meant to end rather than ending it (see Arsenal Defense 3J for the full treatment, and Defense 3G for the same forced-election structure in its first application in this case).

If the deadline passes without payment, liberty to apply means the applicants may return within the same proceedings — without commencing a fresh action — to seek an order of mandamus compelling the Secretary for Finance to perform the specific, already-ordered duty. This is the ordinary administrative-law consequence of a public official's failure to comply with a court order directed at them personally, not a novel remedy: it converts a missed deadline into an immediate, concrete next step rather than a further period of unenforced waiting.

---


# PART G: PRE-EMPTING THE LACHES / DELAY ARGUMENT

## G1. The State May Argue Delay — This Fails on Ten Grounds

The State may attempt to argue that proceedings were not brought promptly and that the claimant has slept on his rights (laches/delay). This argument fails comprehensively on eight independent grounds. The National Court's Human Rights Track operates on a purposive interpretation of justice designed specifically for individuals operating without resources; it does not expect a person in the claimant's position to move at the speed of a Port Moresby law firm. Evidence supporting these grounds is detailed in the supporting affidavit.

**Ground 1 — Continuing Failure to Discharge a Duty:** The core wrongs pleaded here are not completed acts that happened and finished on a particular date — they are the State's continuing failure to discharge duties it remains legally bound to perform: refund the confirmed bond debt, process the visa extension, and — even now that the registration duty itself (CRA s.25's mandatory "shall be registered") was finally discharged on 27 April 2026 — restore the family's practical freedom of movement (s.52), which certificates alone did not achieve, since passports remain unaffordable (Arsenal, Case 2 B1, Ongoing violation note). A continuing failure to perform a continuing duty has no single accrual date, because the duty remains undischarged; the breach is not something that happened, it is something still happening, and will not be complete until the State actually does what it is required to do. To calculate a limitation period from when the State first failed to act would produce an absurd result: the State would acquire, through the mere passage of time, a growing immunity to continue violating the claimant's rights indefinitely — the wrong becoming more insulated from remedy the longer it persists. No limitation doctrine can be read to reward prolonged unlawful conduct with increasing protection from it. In the alternative, even characterised as a series of acts rather than one continuing default, each day of bond withholding, visa non-processing, and accumulating penalty constitutes a fresh cause of action in its own right — so no limitation issue arises for the most recent instances regardless. This is not merely argued from principle: *Habolo Building & Maintenance Ltd v Hela Provincial Government* (2016) SC1549 holds that for a continuing occurrence, the date of occurrence for CBASA s.5 notice purposes runs from day to day, not from when the conduct was first committed — the Supreme Court there found the primary judge had erred by disregarding the continuing occurrences. A later Supreme Court decision expressly follows and applies this exact holding on near-identical reasoning: *Augus Wialu v John Andreas & The State* (2020) SC1970 confirms that "the occurrence" for s.5 purposes, and the date of accrual for FLA s.16 purposes, can each be a continuing series rather than a single event — the primary judge's error there, corrected on appeal, was precisely the mistake of treating a continuing course of conduct as one fixed historic date, which is the same error any State argument along those lines would be making here. This institutional liability is independent of any individual officer's personal exposure for a specific historic act: even where a particular officer's conduct on a particular date might separately face a limitation analysis (see Arsenal, Defense 1C), the State's own continuing default is a live, present breach unaffected by that analysis. A limitation period bars a remedy; it does not retroactively convert unlawful conduct into lawful conduct. Even if a personal claim against a specific officer — Jack's forfeiture declaration, Louma's compliance referral, or any other individual act — were ever found to be time-barred, the act itself remains unlawful permanently. The State's continuing failure to correct the state of affairs that unlawful act produced — the bond still withheld, the visa still unprocessed, the overstay status still imposed — is a fresh, live breach in its own right, regardless of whether the originating act can still be individually litigated.

**Ground 2 — State-Created Pre-Application Delay:** Even the initial birth certificate application was delayed by State-created barriers. PNGCIR's website was non-functional for approximately two years, and no NID office existed in Wewak, directly breaching Civil Registration (Amendment) Act 2014 s.3(6). The State cannot rely on a delay it engineered.

**Ground 3 — Active Exhaustion of Administrative Remedies:** Richard exhausted every available avenue before initiating proceedings: departmental officers → Acting CMO → General Manager → Ombudsman Commission → Australian DFAT → UN Human Rights Council. The time spent pursuing these avenues in good faith belongs to the State's systemic failure, not to the claimant's neglect.

**Ground 4 — Severe Logistical and Technological Deprivation:** The claimant does not possess a computer. Every piece of legal research, correspondence, and drafting for these proceedings has been conducted manually on a mobile phone. This extreme technological bottleneck was compounded by the local power crisis and prolonged periods of internet poverty where data could not be purchased. Furthermore, without access to essential domestic appliances (refrigerator, stove, washing machine, vacuum, reliable indoor/outdoor lighting), basic family survival requires immense daily manual labour. Case preparation could only occur in the marginal time and energy remaining after these manual survival requirements were met.

**Ground 5 — Health, Trauma, and Compounding Interruptions:** The timeline was repeatedly shattered by severe crises, including a violent knife assault requiring medical intervention, the death of the claimant's father, and upwards of 18 severe illnesses (colds/flus/infections) contracted by the claimant while living in a severely compromised physical environment. These events do not merely add isolated delays; they multiply and compound stress, severely degrading the cognitive energy required to process complex legal situations and draft detailed legal arguments on a mobile phone.

**Ground 6 — Access to Justice and Concealed Legal Aid:** The claimant is a non-citizen. He possessed no knowledge that the Office of the Public Solicitor would assist a foreign national, nor was he aware that a Wewak branch of the Public Solicitor even existed until his partner (Serah) required assistance for a separate unlawful eviction matter. Had the State made legal aid accessibility known, proceedings could have commenced years earlier.

**Ground 7 — Reasonable Apprehension of Retaliatory Action:** Richard's Special Exemption Visa contains a specific, signed declaration requiring him to remain "of good character." For years, the claimant held a highly rational fear that initiating a lawsuit against the host State would be arbitrarily interpreted by PNGICSA as a demonstration of "bad character," providing a manufactured excuse to instantly cancel his visa and deport him away from his children. In a system characterized by arbitrary officer conduct (as proven by the facts of this case), this fear was a paralyzing, justifiable deterrent to litigation. See Arsenal, Defense 3I.

**Ground 8 — The Catalyst for Action (Change of Circumstance):** The delay ended when the circumstances fundamentally shifted. In April 2026, the State finally issued the birth certificates, providing concrete proof of their years of prior unlawful refusal. Simultaneously, PNGICSA forced the claimant into an active overstay status. This combination broke the paralyzing fear described in Ground 7: the injustice became absolute, the threat of deportation became active rather than theoretical, and the sheer necessity of survival triggered a renewed passion for justice that finally outweighed the fear of State retaliation.

**Ground 9 — James, Zach, and Brighton's own claims have no limitation exposure at all, independent of every argument above.** Confirmed against the primary text of the Frauds and Limitations Act 1988: s.22 extends the limitation period for any person "under a disability" — expressly defined to include anyone under the age of 21 — until six years after the disability ends. None of the eight grounds above are actually needed to protect the three children's own claims; their limitation clocks have not started running and will not start until each turns 21. This is the cleanest, most legally certain answer available for the primary claim's core (the birth-registration failures) and should be led with, not left as a fallback beneath eight grounds that mostly address the adults' delay instead. This protection is independent of the CBASA s.5 notice question addressed below: notice on the children's behalf is given by Richard as next friend (s.57(1) — see C1), so there is no scenario in which their own disability creates a separate notice-timing exposure that the CBASA extension mechanism, immediately below, doesn't already cover regardless.

**Ground 10 — the ongoing harm flowing from the s.52 breach (poverty, medical deprivation, psychological harm, the financial devastation pleaded throughout Part F) does not need its own continuing-violation theory, and none is pleaded for it.** It would be tempting to characterise the family's continuing inability to afford departure, even now that certificates exist, as itself an ongoing s.52 violation — a mechanism that "transferred" from the original documentary cause to a poverty-based one. That theory was considered and deliberately not pursued: nothing is currently *legally* restricting departure, only economically, and s.52 protects against the former, not the latter (see *Jalla v Shell* [2023] UKSC 16 for the general common-law principle that a continuing state of affairs is not a continuing wrong merely because it keeps producing harm — persuasive only, not PNG authority, but the reasoning is sound and worth anticipating if the State reaches for it). None of this is needed. The ordinary, uncontroversial route already carries the full weight: damages for an established, completed breach include all of its foreseeable consequential harm, continuing and future, as part of that one cause of action — that is what Prong 6's consequential-harm architecture already pleads, and it requires no fiction that the breach itself is still occurring. The distinction matters only so the two routes aren't confused with each other in argument: Ground 1 (continuing occurrence) is about the *breach* still happening; this ground is about the *damage* from an already-established breach still accruing — different doctrines, both available, neither dependent on the other.

**In the alternative — formal application for extension of time under CBASA s.5:** Grounds 1-8 above are pleaded primarily to establish that notice is not late at all, because the breach is continuing (Ground 1) and Habolo v Hela confirms notice runs day-to-day for such a breach — and Ground 9 removes the question entirely for the children's own claims, which is the strongest position of all where it applies. But CBASA s.5 itself provides a direct, independent fallback if any court declines to characterise a specific historic count as continuing: s.5 permits the Departmental Head responsible for Justice matters (Solicitor-General) or the court to grant an extension of time on "sufficient cause" shown. The standard is not free-floating — *Rawson Construction Ltd v Department of Works* (2005) SC777, applied by the full court in *Anis Kore v The State* (2011) SC1136, sets out the precise three-part test: (1) a reasonable explanation for not giving notice in time, and for any delay in applying for the extension itself; (2) a reasonable cause of action on the merits; (3) evidence that the delay hasn't and won't prejudice the State (chiefly, that its witnesses and evidence are still available). Grounds 4-7 above (technological and logistical deprivation; health, trauma, and compounding crisis; concealed legal aid; reasonable apprehension of retaliation) go directly to limb (1); the sheer number and specificity of breach counts pleaded across both documents, each independently evidenced, goes to limb (2); and the fact that PNGCIR's own officer (Joanna Seiweni) confirmed fault in writing as recently as December 2024 goes to limb (3) — the State's own record shows its evidence and institutional memory of these events are still current, not stale. This should be pleaded explicitly, in the alternative, not left implicit — a court that accepts the continuing-breach theory for the ongoing counts but hesitates on an older, more clearly discrete one (the 2016-2018 pre-application barriers, for instance) should not be left without a second basis to reach the same result. *Trnka v The State* [2000] PNGLR 294 is worth being aware of, not avoided: an extension was refused there because the plaintiff's "notice" consisted of complaints to the Police Commissioner, Police Minister, and Prime Minister — recipients with no connection to the CBASA notice function at all. That is a materially different record from this one: Richard's exhaustion efforts, while not formal CBASA notice, were directed at the actual respondent agencies and the Ombudsman Commission (the body constitutionally tasked with investigating exactly this kind of administrative failure), not at politically arbitrary third parties. The distinction is worth drawing expressly if the State cites Trnka, rather than leaving the court to draw it unprompted.

---

# PART H: PROCEDURAL SEQUENCE

Steps are listed in priority order. Steps 1–3 are urgent and should be initiated simultaneously or in immediate sequence.

---

## Step 1 — Emergency Injunctive Relief and Mandamus ⚠️ FILE IMMEDIATELY

Compliance Team referral dated 15 August 2025 creates active deportation risk. Every day of delay increases overstay penalties.

File urgent interlocutory application seeking the three items of emergency/urgent relief listed at F1, filed simultaneously with commencement of the main proceedings — not deferred pending resolution of the substantive claim.

**Basis:** Constitution ss.57, 41, 155(4); Premdas v The State [1979] PNGLR 329.

---

## Step 2 — Judicial Review: Considered and Not Pursued

Judicial review under Order 16 was considered and is not being pursued as part of this claim. It offers nothing this case needs and carries real cost: a strict 4-month time limit (O.16 r.4) that has already expired for several of the relevant acts, a separate leave requirement, and a second parallel proceeding layered on an already extensive case.

Everything judicial review could provide is already available through the direct claim. *Premdas v The State* [1979] PNGLR 329 confirms the National Court's remedial power under s.57 is unlimited — declaratory orders, protective orders, and damages are all available, and the Court may act on its own initiative. Deportation risk does not depend on characterising any single administrative step as a formally reviewable "decision": PNGICSA holds a confirmed debt and has not renewed the visa, and that is addressed directly by the emergency injunctions sought at F1, regardless of which internal step (a compliance referral, a forfeiture declaration, or simple non-processing) produced the risk.

The CBASA s.5 notice concern that judicial review would otherwise sidestep is instead met directly rather than bypassed: CBASA applies to s.57/s.58 constitutional claims by its own terms (unlike judicial review, which sits outside CBASA entirely). It is the continuous breach argument at Step 3 — daily bond withholding, ongoing visa non-renewal, and the still-unresolved freedom of movement deprivation (s.52), each as fresh causes of action — that keeps notice current, not an assumed exemption. The third ground is the most durable: unlike the bond and visa disputes, which the relief sought at F1 could resolve during these proceedings, the family's inability to exercise freedom of movement is independently expected to remain live for a further 1-2 years regardless of how the PNGICSA dispute resolves (Arsenal, Case 2 B1, Ongoing violation note).

---

## Step 3 — Section 5 Notice / Originating Process

- **Continuous breach argument:** Three independent, still-live breaches each constitute a fresh cause of action, so notice remains current even if any one of them is resolved before trial: (1) daily bond withholding; (2) the ongoing visa crisis; and (3) the still-active freedom of movement deprivation under s.52. Birth certificate non-issuance itself ended 27 April 2026 and runs its own 6-month notice clock from that date (currently open, closing late October 2026 — counsel to confirm precise mechanics) as a now-discrete, completed claim; but the deprivation it caused has not ended, since passports remain unaffordable (est. 1-2 years — Arsenal, Case 2 B1, Ongoing violation note), so ground (3) survives independently of the non-issuance claim's own closing clock and of whichever agency's dispute resolves first. Ground (3) also carries Richard's continuing economic loss: he remains unable to travel and therefore unable to access Australian employment today, so the loss — pleaded via Wrongs Act negligence (Arsenal Prong 2) and consequential harm via the children's s.52 breach (Arsenal Prong 6), not s.48 (Premdas precludes a constitutional employment-freedom basis) — resets daily on the same footing, not as a free-standing loss claim but as the consequence of a right still being actively denied. Section 5 Notice served now is within 6 months of the most recent discrete acts on all three grounds.
- **Non-accrual argument (in the alternative to tolling):** Where the claimant is required to exhaust internal administrative escalation before proceedings can be brought, the cause of action does not accrue — and the limitation clock does not begin — until the State issues a final administrative response or the escalation process otherwise concludes. This avoids reliance on equitable tolling entirely: there is no period to toll if the limitation period has not yet started running.
- **CBASA s.9(c):** Once s.57 application served, State has 90 days to file a defence.
- File originating summons on the Human Rights Track under Order 23 NCR / Human Rights Rules 2010.
- **If a tort claim is pursued alongside the constitutional claim** (status: undecided, see Part D2): name the State and the officer(s) needed to properly plead vicarious liability per Pagasa Pembaro v Garry Baki; whether to additionally pursue personal liability against any officer individually is a further, separate question — see Part B and Part D2.
- **Exemplary damages must be specifically pleaded** in the originating process (CBASA s.12(1)).
- James's psychological trauma is pleaded as a foreseeable consequence of administrative captivity — absorbed into general and exemplary damages, not as a standalone s.36 claim (see Arsenal, Notice 6, for the limitation-avoidance reasoning).

---

## Step 4 — Discovery Orders

Apply at the earliest opportunity requiring the State to produce ALL internal records. National Court Bench Book (citing *Credit Corporation v Jee* [1988-89] PNGLR 11): discovery is not a matter of bargaining — the State must produce all documents having any bearing on the subject matter.

**Note to Solicitor:** While a general discovery order for "all relevant documents" should be sought, it is critical to explicitly list the specific categories below as concurrent requirements to prevent the agencies from exploiting ambiguity to withhold damaging internal files.

Specifically seek production of:

- **PNGICSA:** All internal correspondence, emails, file notes, and supervisory records regarding the K1,000 bond (Receipt C27794) from 9 March 2020 to present.
- **PNGICSA:** The complete internal file relating to the Acting CMO's written instruction of 24 November 2022, including all compliance, non-compliance, and officer transfer communications.
- **PNGICSA:** All internal communications or policy documents relating to the alleged "50% refund policy" — or a formal admission confirming no such policy exists.
- **PNGICSA:** All internal records, file notes, or statutory references relied upon by Client Service Officer "Jack" to justify the forfeiture declaration of 5 June 2025.
- **PNGCIR:** All internal processing records, internal emails, and file notes regarding birth registration application B1914006387 and all subsequent applications for the three children.
- **PNGCIR:** All internal policy documents or directives relied upon to demand a work permit from a non-working visa holder — or a formal admission confirming no such policy exists.
- **PNGICSA & PNGCIR:** Staff records confirming the full legal name of "Jack" (PNGICSA Client Service Officer, clientservice@immigration.gov.pg) and of the PNGCIR Compliance Team officer who corresponded without signing a name — required given Wrongs Act s.1(1)(a)'s mandatory naming requirement for officer defendants. If the State asserts it cannot identify either individual, production of the underlying access logs, rosters, or account-assignment records showing why identification is not possible — an inability of this kind is not, without more, an acceptable excuse for non-identification (see Arsenal, Defense 3K).

Selective disclosure by the State is itself a breach of discovery obligations and the PCR 1989 General Duty.

---

## Step 5 — Evidence

| Exhibit | Description | Key Use |
|---|---|---|
| J | PNGICSA Gmail correspondence (58 emails, Apr 2021 – Aug 2025) | Primary PNGICSA evidence. Self-authenticating — official government accounts. Proves: bond non-payment, 50% fabrication, CMO defiance, Kapus misrepresentation. |
| F | PNGCIR Gmail correspondence | Primary PNGCIR evidence. Self-authenticating. Proves: work permit demand, cancellation, denial of appeal rights. |
| D | PNGCIR reply on James's application, 24 August 2020 — "Cancelled due to foreign case" | Proves citizenship-based prejudice attached directly to a child's own application, not just to Richard's matters (see Master Brief F4). |
| K | Acting CMO signed instruction, 24 November 2022 | Proves CMO directed processing. Sapaka's 12+ months non-compliance is then incontrovertible. |
| H | East Sepik Treasury Receipt C27794, 9 March 2015 | Proves K1,000 payment. Original document. |
| I | PNGICSA published 100% refund policy | Proves own published policy. Directly defeats 50% claim. |
| M | Richard's visa extension application and supporting documentation, submitted 4 June 2025 | Establishes the application Jack's forfeiture response (Exhibit J, 5 June 2025) purported to answer — proves the application was complete and properly lodged when the forfeiture claim was raised against it. |
| A | Richard's visa documentation | Proves non-working visa class. Defeats work permit demand as legally impossible. |
| G | Birth certificates issued (all three children) | Proves years of prior refusal had no basis — State's own eventual compliance. |
| N | Knife assault wound photographs | High-resolution. Proves physical injury and environment harm. |
| O | Photographs/medical records of all three children's scabies infections and resulting scarring | Proves untreated medical harm from bore-water/poverty conditions over ~2.5 years. |
| P | Photographs/medical records of Brighton's broken arm and resulting permanent deformity | Proves improperly-set fracture and lasting physical harm. |
| Q | Photographs of James's scarring from a fall on unlit stairs during a power outage | Proves environmental/infrastructure harm directly caused by living conditions. |
| B | Photographs of the residence's structural decay, termite damage, and collapsed flooring | Proves the substandard, physically dangerous living conditions underlying the general damages claim (Affidavit para 16). |
| C | Screenshot of a PNG government website's degraded/non-functional state, 2016–2017 | Corroborates the absence of any functioning channel to register or obtain information during the earliest registration period — supports reasonable-diligence and continuing-duty/no-accrual arguments (Affidavit para 25). |
| E | Screenshots of Richard's phone call log, 4 September 2020 | Corroborates the pattern of repeated unanswered calls to PNGCIR before contact was finally made with Nancy Dilu (Affidavit para 32). |
| L | Biographical data pages of Richard's Australian passports (PA1014705, RA77919028) | Establishes the passport renewal timeline explaining the gap between visa expiry (21 October 2024) and the extension application (4 June 2025) (Affidavit para 56). |
| R | Records of Richard's contact with the PNG Ombudsman Commission, September 2020 – August 2025 | Proves sustained, reasonable diligence in escalating the complaint through proper channels — supports continuing-breach and no-accrual arguments and rebuts any laches/delay defense (Affidavit para 88(c)). |
| — | Staphylococcus aureus infections | Sworn directly at Affidavit para 71 — personal-knowledge testimony, no separate exhibit required. |
| — | Father's death and inability to attend the funeral | Sworn directly at Affidavit para 78 — personal-knowledge testimony, no separate exhibit required. |
| — | James's psychological harm | Sworn directly at Affidavit para 66 (Richard's own observation) — personal-knowledge testimony, no separate exhibit required. |

---

## Step 6 — Hearing Preparation

Counsel should prepare:

- Opening submissions citing all constitutional provisions, key case law (Premdas, Sir Brown Bai v Tomscoll, Kekedo v Burns Philp, Asiki, Lewis v State), and the causal chain.
- Pre-emptive submissions on the citizen/non-citizen compartmentalization to address any nationality objection.
- Pre-emptive submissions on the six-prong income loss framework (Arsenal, Defense 3F) to secure the economic loss claim against all anticipated rebuttals.
- Pre-emptive submissions identifying anticipated State defenses and why they fail — using the Arsenal as the reference.

---

## Step 7 — Right of Appeal

Whether to appeal is Richard's decision alone, to be made only if the outcome of the case is not acceptable to him — nothing here presumes an appeal will be pursued. What follows is the mechanics, set out in advance so that decision can be made quickly within the appeal window if it becomes necessary. Appeals from National Court to Supreme Court of PNG. Notice of appeal within 40 days of judgment. Grounds must be specified. Review written judgment for:

- **Error of law** — wrong legal test applied (e.g. vicarious liability applied to constitutional claim).
- **Error of fact** — finding not supported by evidence.
- **Failure to consider** — material submission or evidence ignored.
- **Unreasonableness** — conclusion not open to a reasonable judge on the evidence.
- **Breach of natural justice** — proper consideration not given to claimant's case.

Request certified copy of full written judgment immediately upon delivery.

---


# PART I: LITIGATION CONDUCT FRAMEWORK

*Apply to every State submission before counsel responds. See the Arsenal for pre-written counter-submissions to all anticipated arguments.*

---

## I1. The Three-Layer Response

| Layer | Content | Effect |
|---|---|---|
| **Layer 1 — Merits Rebuttal** | "The State's argument fails on the merits because [factual/legal rebuttal]. The conclusion the State asks this court to draw does not follow from the facts presented." | Defeats the argument on its merits. |
| **Layer 2 — Unlawfulness of the Argument** | "The act of advancing this argument is itself unlawful. The State has [selectively presented facts / omitted material facts / derived a false conclusion / advanced an arbitrary and capricious position] in violation of [provisions]. Applying Wednesbury test (a/b/c/d/e) from Sir Brown Bai v Tomscoll (2015) N6112: this argument fails because [specific test]." | Puts State's conduct on the record. Creates basis for costs and referral. |
| **Layer 3 — Constitutionally Prohibited Outcome** | "The outcome the State seeks is one this court cannot lawfully deliver. Section 57 mandates enforcement. Premdas v The State [1979] PNGLR 329: this court's remedial power is unlimited. The severity and continuity of the breaches warrants exemplary damages under CBASA s.12(1). An outcome where proven rights violations go without remedy is constitutionally foreclosed." | Invokes mandatory enforcement obligation and unlimited remedial power. |

---

## I2. Assessment Checklist

*Apply to each State submission. Any "yes" independently supports a Layer 2 or Layer 3 response.*

| # | Question | Provision / Authority |
|---|---|---|
| 1 | Does this argument, if accepted, deny the claimant the protection of the law? | Constitution s.37 |
| 2 | Does this argument produce an outcome where proven rights violations go without remedy? | ss.57, 58; CBASA s.12; Premdas |
| 3 | Is this argument harsh, oppressive, or disproportionate? | Constitution ss.41, 25 |
| 4 | Is this argument arbitrary or capricious, or does it defend an arbitrary/capricious act? | s.62; Wednesbury (e) — Sir Brown Bai v Tomscoll |
| 5 | Does this argument operate in bad faith or dishonesty? | Wednesbury (c) — Sir Brown Bai v Tomscoll; PCR 1989 |
| 6 | Does this argument misapply the law or fail to direct itself properly in law? | Wednesbury (d) — Sir Brown Bai v Tomscoll; s.62 |
| 7 | Does this argument introduce false or misleading information into the record? | Constitution s.59; PCR 1989 General Duty |
| 8 | Does this argument selectively present true facts while omitting material facts? | PCR 1989; NCR Order 8; s.59; Discovery obligations |
| 9 | Does this argument derive a conclusion that does not follow from the facts? | PCR 1989; NCR Order 8; ss.59, 62 |
| 10 | Does this argument apply vicarious liability to defeat a constitutional claim under ss.57–58? | ss.57, 58; Wrongs Act s.1(4) — covers purported performance |
| 11 | Is this argument frivolous, vexatious, or an abuse of process? | NCR Orders 8 r.27, 9 r.15, 12 r.40 |
| 12 | Is this argument objectively unreasonable in the circumstances? | NCR Order 22; Wednesbury (e) |
| 13 | Does a sworn affidavit supporting this argument contain false or misleading statements? | Oaths Act Ch.317; PCR 1989 |
| 14 | Does the argument attempt to deny constitutional protections on nationality grounds? | ss.37, 41, 59, 62; GO 15.58; CRA s.25 |
| 15 | Does the argument rely on selective document disclosure while withholding relevant records? | Discovery obligations; PCR 1989; s.59 |

---


# PART J: BREACH COUNT SUMMARY

*Full breach analysis with all counts organized by agency, officer, and legislative instrument is in the Breach and Defense Arsenal.*

---

## J1. Combined Totals

*19 counts and Constitution s.42 removed for insufficient legal weight this session (13 PNGICSA, 6 PNGCIR) — full text and reasoning preserved in Additional Arguments. Table below reflects what currently stands pleaded; original totals were 94/69/163.*

| # | Legislation / Instrument | Provisions Engaged | PNGICSA | PNGCIR | Total |
|---|---|---|---|---|---|
| 1 | Constitution of PNG | ss.22,23,25,32,36,37,41,51,52,53,55,57,58,59,62,155(4) (not s.42, not s.48 — see Additional Arguments) | 16 | 21 | 37 |
| 2 | ICSA Act 2010 (+2021 Amendment) | s.36 (s.39 available as escalation mechanism, not a breach count) | 1 | — | 1 |
| 3 | Migration Act (Ch.16) / 2023 | s.16(1)(e) | 1 | — | 1 |
| 4 | PSMA 2014 + General Order 15 | s.51(c)(d)(e)(f)(i); GO 15.19; GO 15.58 | 36 | 15 | 51 |
| 5 | Public Servants Oath | Points 2,3,4,6,8 | 10 | 7 | 17 |
| 6 | Wrongs (Misc. Provisions) Act (Ch.297) | ss.1,1(4),1A | 6 | 3 | 9 |
| 7 | Civil Registration Act 1963 | ss.9,16,25,27,60 | — | 5 | 5 |
| 8 | Civil Reg. Amendment Act 2014 | ss.3(6),37C(3),37C(14) | — | 4 | 4 |
| 9 | Employment of Non-Citizens Act 2007 | s.6(1) | — | 2 | 2 |
| 10 | Passports Act 1982 | s.6 | — | 1 | 1 |
| 11 | Lukautim Pikinini Act 2015 | ss.3,7,8 | 3 | 4 | 7 |
| 12 | Convention on the Rights of the Child (via LP Act s.6) | s.6 | — | 1 | 1 |
| 13 | Frauds and Limitations Act 1988 | s.16 (misapplied) | 1 | — | 1 |
| 14 | Organic Laws | Ombudsman + Leadership Code (parallel forum, not National Court counts — see Additional Arguments) | 6 | — | 6 |
| 15 | Judicial Proceedings (Interest on Debts and Damages) Act 2015 | ss.4(1)–(2), 6(1)–(2) (rate confirmed at 2% — see Arsenal Count 94) | 1 | — | 1 |
| | **GRAND TOTALS** | **15 legislative instruments; 25+ provisions** | **81** | **63** | **144** |

---

## J2. Breach Counts by Officer

| Officer | Agency | Counts | Primary Conduct |
|---|---|---|---|
| Ezekiel Sapaka | PNGICSA | 10 | CMO instruction defiance; Richard never notified of officer transfer; GO 15.58 ×5; 50% fabrication; misconduct |
| Patrick Repo | PNGICSA | 7 | Kapus misrepresentation; 50% endorsement; prosecution threat; supervision failures ×2; GO 15.58 ×2; Migration Act s.16(1)(e) potential criminal |
| Gabriel Metro | PNGICSA | 7 | Treasury letter fabrication; negligence ×2; GO 15.58 ×4 |
| "Jack" | PNGICSA | 2 | Forfeiture under non-existent rule; unlawful offset refusal; s.62 arbitrary |
| Shirley Louma | PNGICSA | 8 | GO 15.58 ×7; retaliatory compliance referral |
| Kessie Kapus | PNGICSA | 2 | Supervisory failure 5+ years (April 2021 – present); failure to act on evidence |
| Nancy Dilu | PNGCIR | 7 | 5 false statements; admitted fault + refused to act; hung up on claimant; refused RG contact |
| Benjamin Kepino | PNGCIR | 3 | GO 15.58 ×2; failure to investigate complaint |
| Unnamed Compliance Officer | PNGCIR | 4 | Impossible work permit demand; wrong visa information; unsigned emails; 4-month delay |
| Joanna Seiweni | PNGCIR | 1 | Acknowledged fault Dec 2024; no corrective action |

*Named officers above account for 51 of the 144 currently-pleaded counts (36 PNGICSA + 15 PNGCIR). The remaining 93 counts are institutional/agency-level breaches not attributed to a specific named officer — see the Case 1 / Case 2 breakdown in the Breach and Defense Arsenal for the full instrument-by-instrument listing.*
