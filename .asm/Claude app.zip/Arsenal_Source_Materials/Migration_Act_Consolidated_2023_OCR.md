# Migration Act (Chapter 16) — Consolidated 26/4/2023

## High-accuracy transcription

This Markdown file contains the full text extracted from the supplied 19-page PDF. The source PDF is digitally generated and contains embedded text, so the embedded text was used rather than introducing additional OCR recognition errors through image-based OCR.

---

## Page 1

```text
Migration Act (Chapter 16).
 Consolidated 26/4/2023
```

---

## Page 2

```text
                              Migration Act (Chapter 16).

                                        _______

                          ARRANGEMENT OF SECTIONS.

1.   Compliance with Constitutional requirements.
2.   Interpretation -
      “Administrator”
      “authorised officer”
      “authorised person”
      “Chief Migration Officer”
      “child”
      “conveyance”
      “dependant”
      “entry”
      “entry permit”
      “holder”
      “Immigration and Citizenship Service Authority”
      “immigration detention”
      “member of the crew”
      “officer”
      “passenger”
      “passport”
      “person in charge”
      “place of immigration detention”
      “precincts of the port”
      “proclaimed port”
      “refugee”
      “relocation centre”
      “repealed Act”
      “removal order”
      “rub-down search”
      “this Act”
      “vessel”
3.   Prohibition on entry without entry permit.
4.   Issue of entry permit.
5.   Conditions of entry.
6.   Cancellation of entry permit and Committee of Review.
7.   Unlawful presence in country.
8.   Power to refuse entry.
```

---

## Page 3

```text
  9.   Duties of persons arriving in country.
 10.   Prevention of unlawful presence.
 11.   Power to interrogate.
 12.   Removal orders.
 13.   Power to detain and remove persons from country.
 14.   Liability for expenses.
 15.   Duties of persons in charge of conveyances.
15A.   Minister may determine non-citizen to be refugee.
15B.   Relocation centres and places of immigration detention.
15C.   Direction to reside in relocation centre.
15D.   Control and management of relocation centres and places of immigration detention.
15E.   Powers of search in immigration detention and in relocation centre.
15F.   Reasonable use of force and protection of officers.
 16.   Offences.
 17.   Evidence.
 18.   Burden of proof.
 19.   No appeal against decision of Minister, etc.
 20.   Exemptions.
 21.   Repatriation.
 22.   Minister to report to the Parliament.
 23.   Regulations.
 24.   Transitional Provisions.




                                             - ii -
```

---

## Page 4

```text
                                                Migration Act (Chapter 16),


Being an Act to repeal and re-enact the law relating to entry into the country.

1.     COMPLIANCE WITH CONSTITUTIONAL REQUIREMENTS.
       (1) This Act, to the extent that it regulates or restricts a right or freedom referred to in
Subdivision III.3.C (qualified rights) of the Constitution, namely -
             (a) the freedom from arbitrary search and entry conferred by Section 44 of the
                   Constitution; and
             (b) the right to privacy conferred by Section 49 of the Constitution; and
             (c) the right to liberty of the person conferred by Section 42 of the Constitution;
                   and1
             (d) protection from unjust deprivation of property conferred by Section 53(1) of the
                   Constitution,2
is a law that is made for the purpose of giving effect to the public interest in public order and
public welfare.3

      (2) For the purposes of Section 29 of the Organic Law on Provincial Government4, it is
declared that this law relates to a matter of national interest.

2.      INTERPRETATION.
        In this Act, unless the contrary intention appears -
           “Administrator” means the Administrator of a relocation centre or place of immigration
              detention appointed under Section 15D;5
           “authorised officer” when used in a provision of this Act, means the Chief Migration
              Officer or an officer authorised in writing by the Minister for the purposes of that
              provision;6
           “authorised person” when used in a provision of this Act, means a person, who is not an
              officer, who is authorised by the Minister or the Chief Migration Officer in writing for
              the purposes of that provision;7




1 Paragraph (c) repealed and replaced by No. 10 of 1989, s.2, further amended by No.18 of 2015, s.1.
2 Paragraph (d) added by No. 18 of 2015, s.1.
3 Refer to Footnote 1.
4 This Organic Law has been repealed by Organic Law on Provincial Governments and Local-level Governments. Semble,

        similar provision in current Organic Law to Section 29 of the repealed law is Section 41.
5 The definition “Administrator” added by No. 10 of 1989, s.3(a) and amended by No. 18 of 2015, s.2(a).
6 The definition of “authorised officer” added by No. 18 of 2015, s.2(c).
7 The definition of “authorised person” repealed and replaced by No. 18 of 2015, s.2(b).



                                                                                    Prepared for inclusion as at 26/4/2023
```

---

## Page 5

```text
     Ch. No. 16                                                        Migration


             “Chief Migration Officer” is as defined by Section 2 of the Immigration and Citizenship
                Service Act 2010;8
             “child” includes a step child and lawfully adopted child;
             “conveyance” means a vessel, aircraft and any other conveyance capable of being used to
               convey persons;
             “dependant” means, in relation to a person, the spouse of that person, not living apart
               from that person under a decree of court or a deed of separation, and an unmarried
               child of that person under the age of 16 years;
             “entry” means -
                  (a) in the case of a person arriving in the country by sea or air at a proclaimed port
                       - leaving the precincts of that port; and
                  (b) in the case of any other arrival in the country - entry into the country by land,
                       sea or air,
               but does not include an entry -
                  (c) made for the purposes of complying with this Act; or
                  (d) expressly or impliedly sanctioned by an officer for the purposes of an enquiry or
                       detention under this Act;
             “entry permit” means an entry permit issued under Section 4 -
                  (a) which has not expired, been cancelled or become invalid; and
                  (b) which was not obtained or issued in consequence of fraud or misrepresentation
                       or the concealment or non-disclosure, whether intentional or inadvertent, of a
                       material fact or circumstance;
             “holder” means, in relation to an entry permit, a person permitted by that entry permit to
               enter the country;
             “Immigration and Citizenship Service Authority” means the Authority established by
                Section 3 of the Immigration and Citizenship Service Authority Act 2010;9
             “immigration detention” means the administrative detention of a foreign national who is
                reasonably suspected of being in the country unlawfully but it is not arrested as
                defined in the Arrest Act (Chapter 339);10
             “member of the crew” means a person employed in the working of a conveyance;
             “officer” means -
                  (a) Chief Migration Officer; or11
                  (b) an employee of the Immigration and Citizenship Service Authority; or12
                  (c) an officer for the purposes of the Customs Act; or
                  (d) a District Officer; or
                  (e) a commissioned officer of the Police Force; or



8 The definition of “Chief Migration Officer” added by No. 18 of 2015, s.2(d).
9 The definition “Immigration and Citizenship Service Authority” added by No. 18 of 2015, s.2(e).
10 Ibid.
11
     Paragraph (a) repealed and replaced by No. 18 of 2015, s.2(f).
12 Ibid.



                                                                 -2-
                                                                                  Prepared for inclusion as at 26/4/2023
```

---

## Page 6

```text
                                             Migration                                                   Ch. No. 16


                 (f) a person authorised by the Minister to perform consular duties on behalf of the
                     State outside the country;
           “passenger” means a person carried in a conveyance, other than a member of the crew;
           “passport” includes a document of identity issued from official sources, whether inside or
              outside the country, and having the characteristics of a passport;
           “person in charge” means -
                 (a) in relation to a vessel - the master or person (except a pilot) having for the time
                     being control or charge; and
                 (b) in relation to an aircraft - the pilot; and
                 (c) in the case of any other conveyance - the person having for the time being
                     control or charge;
           “place of immigration detention” means any established correctional facility or police
               lockup, or any other place designated as such by the Minister or an authorised
               officer;13
           “precincts of the port” means that part of the port at which customs and immigration
              formalities are conducted;
           “proclaimed port” means -
                 (a) an aerodrome or a port within the meaning of the Customs Act; or
                 (b) any place proclaimed by the Minister by notice in the National Gazette to be a
                     proclaimed port;
           “refugee” means a non-citizen -
                 (a) permitted to remain in Papua New Guinea pending his settlement elsewhere; or
                 (b) determined by the Minister to be a refugee;14
           “relocation centre” means a place declared to be a relocation centre under Section 15B;15
           “repealed Act” means the Act specified in Schedule 1;
           “removal order” means an order made under Section 12(1);
           “rub-down search” means a search of a person conducted by quickly running the hands
               over the person’s outer garments, and includes requiring the person to remove his or
               her overcoat, coat or jacket and any gloves, shoes and hat and surrendering these
               items as well as any items carried by or carried in the pockets of the person for the
               purposes of search;16
           “this Act” includes the regulations;
           “vessel” includes a ship or boat or other description of craft used in navigation.




13 The definition “place of immigration detention” added by No. 18 of 2015, s.2(g).
14 The definition of “refugee” added by No. 10 of 1989, s.3(b).
15 The definition of “relocation centre” added by No. 10 of 1989, s.3(b).
16 The definition of “rub-down search” added by No. 18 of 2015, s.2(h).




                                                               -3-
                                                                                      Prepared for inclusion as at 26/4/2023
```

---

## Page 7

```text
  Ch. No. 16                                                       Migration



3.     PROHIBITION ON ENTRY WITHOUT ENTRY PERMIT.17
       No person, other than a citizen, shall enter the country unless -
            (a) he is the holder of an entry permit; or
            (b) he is a person, or a member of a class or description of persons, exempted by
                  the Minister under Section 20 from the requirement to hold an entry permit.

4.     ISSUE OF ENTRY PERMIT.
       (1) A person seeking an entry permit shall apply for it in the prescribed manner.

      (2) An officer or authorised person, on receipt of an application made under Subsection
(1), may issue an entry permit.

      (3) An entry permit may be issued to a person before he has entered the country or after
he has entered the country.

5.     CONDITIONS OF ENTRY.
       An officer or authorised person may -
            (a) issue an entry permit subject to conditions; and
            (b) during the currency of an entry permit -
                       (i) make it subject to conditions; and
                      (ii) vary or cancel conditions to which it is subject.

6.    CANCELLATION OF ENTRY PERMIT AND COMMITTEE OF REVIEW.
      (1) The Minister may cancel an entry permit by written notice under his hand served on
the holder of the permit personally or by registered post.

      (2) Subject to Subsection (8), where a notice served under Subsection (1) relates to an
entry permit issued for a period of more than six months, the person on whom the notice was
served may, within seven days of the receipt of the notice, by written application to the Minister,
request that the cancellation of the entry permit be reviewed by a Committee of Review.

      (3) On the receipt of an application made under Subsection (2), the Minister shall inform
the Prime Minister of the application and the Prime Minister shall, as soon as practicable, appoint
a Committee of Review, consisting of three Ministers, to consider the application.

       (4) On the appointment of a Committee of Review under Subsection (3), the Minister
shall submit to the Committee the application and all information relevant to the applicant, his
entry and stay in the country, and the reasons for the cancellation of his entry permit.



17 Section 3 repealed and replaced by No. 15 of 1996, s.1.



                                                             -4-
                                                                          Prepared for inclusion as at 26/4/2023
```

---

## Page 8

```text
                                  Migration                                        Ch. No. 16


       (5) After considering the application and information submitted to it under Subsection
(4), and after making any inquiries or investigations it considers necessary, the Committee of
Review shall confirm the cancellation of the entry permit or recommend that its cancellation be
revoked.

      (6) A Committee of Review may recommend that the revocation of a cancellation of an
entry permit be subject to conditions.

      (7) A Committee of Review shall report its recommendations to the Minister who shall
take all such action as may be necessary to implement those recommendations.

      (8) Where the Minister, in a notice served under Subsection (1), states that the
cancellation of the entry permit is for a breach of a condition imposed following a
recommendation made in accordance with Subsection (6), the person on whom the notice is
served shall have no right to apply to have the cancellation reviewed under Subsection (2).

7.   UNLAWFUL PRESENCE IN COUNTRY.
     (1) Subject to Subsection (2), the presence of a person, other than a citizen, in the
country, is unlawful if -
             (a) he is not the holder of an entry permit; or
             (b) he evaded an officer for the purposes of entering the country.

     (2) The presence of a person in the country is not unlawful if he is leaving the country in
accordance with Section 9(3).

8.    POWER TO REFUSE ENTRY.
      (1) Notwithstanding the possession of an entry permit, a person other than a citizen may,
on arrival at the country or on reporting to an officer in accordance with Section 9(1), be refused
entry if -
             (a) he is unable to satisfy an officer that he has the means to support himself, and
                   any accompanying dependant during his proposed stay in the country; or
             (b) he is, in the opinion of an officer, suffering -
                      (i) from a mental illness; or
                     (ii) from a disease which would make his presence in the country a danger
                          to the community; or
             (c) he refuses to submit to a medical examination after being required to do so
                   under Subsection (2); or
             (d) he is not in possession of a valid passport.

      (2) An officer may, for the purposes of forming an opinion under Subsection (1)(b),
require a person seeking to enter the country to submit himself to a medical examination by a
medical practitioner, or detain him for that purpose.



                                               -5-
```

---

## Page 9

```text
  Ch. No. 16                                                        Migration



9.   DUTIES OF PERSONS ARRIVING IN COUNTRY.
     (1) A person arriving at a proclaimed port from another country and seeking to enter the
country shall appear before an officer.

      (2) A person appearing before an officer in accordance with Subsection (1) shall give to
that officer any information the officer may require.

     (3) A person refused permission to enter the country after appearing before an officer in
accordance with Subsection (1) -
           (a) if he arrived by vessel and is still aboard the vessel - shall not disembark; or
           (b) if he arrived by vessel and disembarked for the purpose of appearing before the
                 officer -
                     (i) shall return to the vessel; or
                    (ii) if the vessel has sailed -
                         (A) shall not depart from the precincts of the port except to a place
                               approved by an officer; and
                         (B) shall leave the country by the first available means in accordance
                               with any instructions given by an officer.

     (4) A person refused permission to enter the country after appearing before an officer in
accordance with Subsection (1) -
           (a) if he arrived by aircraft - shall return to the aircraft; or
           (b) if he arrived by aircraft and the aircraft has departed or there is not room on it
                 for him -
                     (i) shall not depart from the precincts of the port except to a place approved
                         by an officer; and
                    (ii) shall leave the country by the first available means in accordance with
                         any instructions given by an officer.

10.   PREVENTION OF UNLAWFUL PRESENCE.
      (1) An officer shall prevent a person from entering or remaining in the country in
contravention of this Act.

      (2) Where an authorised officer reasonably suspects that a person is a non-citizen who is
in the country unlawfully, the authorised officer may detain or direct an officer or authorised
person to detain the person for such time as is necessary in order to effect their removal or
departure from the country.18




18 Subsection (2) repealed and replaced by No. 18 of 2015, s.3.



                                                              -6-
                                                                           Prepared for inclusion as at 26/4/2023
```

---

## Page 10

```text
                                               Migration                               Ch. No. 16


     (3) A person detained under Subsection (2) must be released from detention if an
authorised officer has reasonable cause to believe that the person is -
            (a) a Papua New Guinea Citizen; or
            (b) a person granted an entry permit; or
            (c) a person ordered to be released, subject to any conditions by the Minister or an
                  authorised officer; or
            (d) a person granted a relevant exemption by the Minister pursuant to Section 20. 19

      (4) Where a person has entered or remained in the country in contravention of this Act,
an officer may -
            (a) return that person to the conveyance in which he arrived in the country and keep
                 him there until his departure from the country; or
            (b) obtain a removal order in respect of that person; or
            (c) arrest that person and keep him in custody pending his prosecution under this
                 Act. 20

11.   POWER TO INTERROGATE.
      (1) An officer may interrogate a person whose presence in the country he reasonably
believes to be unlawful.

           (2)    A person interrogated by an officer acting in accordance with Subsection (1) shall -
                  (a) fully and truthfully answer all questions put to him which tend, directly or
                       indirectly, to establish his identity, nationality or occupation; and
                  (b) disclose and produce to the officer all documents in his possession or under his
                       control relating to those matters.

      (3) All answers given or documents produced in accordance with Subsection (2) shall be
admissible in evidence in proceedings under this Act against the person making or producing
them.

12.        REMOVAL ORDERS.
           (1) The Minister may order the removal from the country of -
               (a) a person whose presence in the country is unlawful; and
               (b) at the further discretion of the Minister - any dependants of such a person.

           (2)    A removal order shall -
                  (a) be served on the person to be removed; and
                  (b) state a period from the date of service within which the person or dependants to
                       be removed shall be removed or shall remove himself or themselves from the
                       country.

19
     Subsection (3) added by No. 18 of 2015, s.3.
20 Ibid.



                                                           -7-
                                                                    Prepared for inclusion as at 26/4/2023
```

---

## Page 11

```text
     Ch. No. 16                                                      Migration



          (3)    The Minister may vary or revoke a removal order.

13.   POWER TO DETAIN AND REMOVE PERSONS FROM COUNTRY.
      (1) The Minister or an authorised officer may order that a person against whom a removal
order has been made be detained until arrangements can be made for his removal from the
country.21

          (2)
            A person against whom a removal order has been made may -
            (a) if he has not removed himself from the country within the period stated in the
                 order; or
            (b) if he is being detained in accordance with an order made under Subsection (1),
be placed on board a suitable conveyance by an officer or authorised person, and may be detained
in that conveyance until it leaves the country.22

     (3) A person against whom a removal order has been made may be removed to any
country which is under an obligation to receive him or to any country to which he consents to be
removed if the government of that country agrees to receive him.

      (4) A person in charge of a conveyance going to a country to which a person is to be
removed shall receive that person on board and on proper payment being made convey him to
that country and give him accommodation and maintenance during the passage.

      (5) Subject to Section 14, the cost of the passage, accommodation and maintenance
provided in accordance with Subsection (4) shall be paid by the person removed and the Minister
or an authorised officer may apply money or property of the person removed in payment of the
whole or part of that cost, or if the Minister or an authorised officer thinks fit, the whole or part of
the cost shall be borne by the State.23

14.   LIABILITY FOR EXPENSES.
      (1) Where a person -
            (a) enters the country in contravention of this Act; or
            (b) is refused entry to the country under the provisions of this Act,
the person in charge, the owner, and his agent, of the conveyance in which that person came to
the country shall be jointly and severally liable to pay to the State the expenses incurred by the
State in connexion with the care, maintenance and accommodation of that person and his passage
from the country.

     (2) The Minister may direct that the whole or a part of the expenses referred to in
Subsection (1) shall be borne by the State.

21 Subsection (1) repealed and replaced by No. 18 of 2015, s.4(a).
22
     Subsection (2) amended by No. 18 of 2015, s.4(b).
23 Subsection (5) repealed and replaced by No. 18 of 2015, s.4(c).



                                                              -8-
                                                                            Prepared for inclusion as at 26/4/2023
```

---

## Page 12

```text
                                                 Migration                                            Ch. No. 16


15.       DUTIES OF PERSONS IN CHARGE OF CONVEYANCES.
          A person in charge of a conveyance arriving in the country from another country shall -
               (a) in the case of a ship or aircraft arriving at a proclaimed port - prevent
                     disembarkation from the conveyance until disembarkation has been authorised
                     by an officer; and
               (b) inform an officer if he knows or has reasonable cause to believe, that in respect
                     of a person on board, that person’s presence in the country would be unlawful,
                     and prevent that person from disembarking unless permitted by an officer; and
               (c) prevent, with such reasonable force as may be necessary, the disembarkation
                     of -
                         (i) a person who has been given into his custody under Section 13(4); or
                        (ii) a person in respect of whom a removal order is in force; or
                       (iii) a person whose presence in the country would to his knowledge be
                             unlawful.

15A. MINISTER MAY DETERMINE NON-CITIZEN TO BE REFUGEE.24
     The Minister may determine a non-citizen to be a refugee for the purposes of this Act.

15B.        RELOCATION CENTRES AND PLACES OF IMMIGRATION DETENTION.25
            (1) The Minister may, by notice in the National Gazette, declare a place to be -
                (a) a relocation centre for the accommodation of a refugee or a non-citizen who
                     claims to be a refugee; or
                (b) a permanent place of immigration detention.

      (2) The Minister or an authorised officer may, by instrument, declare a place to be a
temporary place of immigration detention.

15C. DIRECTION TO RESIDE IN RELOCATION CENTRE.26
       (1) The Minister may, by instrument in writing, direct a refugee or class of refugees or
non-citizen claiming to be a refugee to reside in a relocation centre.

        (2) A direction under Subsection (1) is sufficient authority for an officer, police officer
or authorised person to detain and take into custody the refugee or class of refugees or non-citizen
claiming to be a refugee specified in the order for the purpose of taking that refugee or class of
refugees or non-citizen claiming to be a refugee to a relocation centre and keeping that refugee or
class of refugees or non-citizen claiming to be a refugee in that relocation centre.27




24 Section 15A added by No. 10 of 1989, s.4.
25 Section 15B added by No. 10 of 1989, s.5 and repealed and replaced by No. 18 of 2015, s.5.
26
     Section 15C added by No. 10 of 1989, s.6.
27 Subsection (2) amended by No. 18 of 2015, s.6(a).



                                                             -9-
                                                                                   Prepared for inclusion as at 26/4/2023
```

---

## Page 13

```text
     Ch. No. 16                                                         Migration



        (3) An officer, police officer or authorised person acting under a direction under
Subsection (1) may use such force as is reasonably necessary for the purpose of taking a person to
a relocation centre.28

15D. CONTROL AND MANAGEMENT OF RELOCATION CENTRES AND PLACES
       OF IMMIGRATION DETENTION.29
       (1) The Minister may appoint an officer to be the Administrator of a relocation centre or
place of immigration detention.

            (2)     The Administrator shall have -
                    (a) the control and management of a relocation centre or place of immigration
                         detention; and
                    (b) the services of officers for the purpose of managing a relocation centre or
                         place of immigration detention.

       (3) For the purposes of safety and good order, an Administrator, authorised officer or
authorised person may give lawful directions to persons at a relocation centre under a direction
under Section 15C(1) or to persons at a place of immigration detention.

       (4) A person who has been given such directions under Subsection (3) has an obligation
under this Act to comply with those directions.

15E.    POWERS OF SEARCH IN IMMIGRATION DETENTION AND IN
        RELOCATION CENTRE.30
        (1) An Administrator or authorised officer may at any time direct an officer, police
officer or authorised person -
              (a) to search any part of a relocation centre or place of immigration detention; or
              (b) to perform a rub-down search of -
                        (i) a detainee or person relocated under Section 15C; or
                       (ii) a visitor to the relocation centre or place of immigration detention
                            (except a Judge of the Supreme Court or the National Court or a
                            Magistrate); or
                     (iii) an officer; or
                     (iv) any other person in or entering the relocation centre or place of
                            immigration detention; or
              (c) to search and examine anything in the relocation centre or place of
                    immigration detention.



28 Subsection (3) amended by No. 18 of 2015, s.6(b).
29
     Section 15D added by No. 10 of 1989, s.7 and repealed and replaced by No. 18 of 2015, s.7.
30 Section 15E added by No. 18 of 2015, s.8.



                                                               - 10 -
                                                                                    Prepared for inclusion as at 26/4/2023
```

---

## Page 14

```text
                                   Migration                                         Ch. No. 16


        (2) Where an Administrator or an authorised officer believes on reasonable grounds that
the security or good order of the relocation centre or place of immigration detention or a detainee
is threatened, they may direct an officer or authorised person -
              (a) to search and examine anything outside but within 200 metres of the
                    relocation centre or place of immigration detention; and
              (b) require a person outside of but within 200 metres of the relocation centre or
                    place of immigration detention to submit to a rub-down search.

        (3) An officer, police officer or authorised person, in conducting a rub-down search
under this section, shall ensure that the search is conducted as expeditiously as possible and with
regard to the decency and self-respect of the person searched.

        (4) A rub-down search under this section shall be carried out only by an officer, police
officer or authorised person of the same gender as the person being searched.

       (5) Where a search takes place under this section, an officer, police officer or authorised
person shall complete such records of the search as the Chief Migration Officer determines.

        (6) Where a person, other than a detainee or person relocated under Section 15C,
refuses to submit to be searched under this section while inside the relocation centre or place of
immigration detention, the Administrator or authorised officer may order the person to leave the
relocation centre or place of immigration detention immediately.

      (7) An Administrator or authorised officer may require that a person taken into
immigration detention or directed to a relocation centre is subject to a rub-down search -
            (a) if detained, when they are detained; and
            (b) if directed to a relocation centre, when they are so directed; and
            (c) on admission to a place of immigration detention or relocation centre; and
            (d) prior to departure or transfer from a place of immigration detention or
                  relocation centre.

        (8) In carrying out a search, an officer, police officer or authorised person may seize
anything found in the relocation centre or place of immigration detention, whether in a person’s
possession or not, where the officer, police officer or authorised person believes on reasonable
grounds that possession of that thing is illegal, or would jeopardise or is likely to jeopardise the
security or good order of the relocation centre or place of immigration detention or the safety of
persons in the relocation centre or place of immigration detention.

       (9) An officer, police officer or authorised person who seizes any item of personal
property under this section shall give, the person from whom the item was taken, a receipt and
immediately inform the Administrator or authorised officer.

      (10)   The item seized under Subsection (9) shall be secured on official property.

                                                - 11 -
                                                                  Prepared for inclusion as at 26/4/2023
```

---

## Page 15

```text
  Ch. No. 16                                                 Migration


         (11) An item -
              (a) which has been seized under this section; and
              (b) where possession of the item would not otherwise be unlawful,
 may be returned by an officer or authorised person to the person from whom it was taken once
they leave the relocation centre or place of immigration detention.

         (12) Where the item -
              (a) cannot be returned; or
              (b) possession would otherwise be unlawful; or
              (c) is unclaimed after a period of 12 months from the date the officer or
                    authorised person attempts to return it,
it shall become the property of the State and may be disposed of by means of auction or
destruction or other means.

         (13)    Where the property is disposed of by auction, the proceeds shall be retained by the
State.

       (14) An Administrator or authorised officer may provide written standing orders
permitting the continued use of powers under this section by officers or authorised persons where
the ongoing security and good order of a relocation centre or place of immigration detention
justifies regular search at control points, or spot searches within these locations.

15F.   REASONABLE USE OF FORCE AND PROTECTION OF OFFICERS.31
       (1) An officer or authorised person may use reasonable force to exercise powers under
this Act pertaining to arrest, detention, removal, search, seizure, and relocation, or to compel a
person to comply, enter and search places or items, open containers or access equipment, seize
items or otherwise give effect to these powers.

       (2)       An officer or authorised person may use reasonable force to temporarily restrain a
person -
                 (a)     who has been arrested; or
                 (b)     who is in immigration detention; or
                 (c)     who is being removed; or
                 (d)     who has been directed to reside in a relocation centre; or
                 (e)     where the safety of the person, the safety of other persons or the good order of
                         the relocation centre or place of immigration detention is believed to be at
                         risk.

       (3) The officer or authorised person is not liable for injury or damage caused in
reasonably performing such functions authorised under the Act.


31 Section 15F added by No. 18 of 2015, s.8.



                                                    - 12 -
                                                                      Prepared for inclusion as at 26/4/2023
```

---

## Page 16

```text
                                               Migration                                Ch. No. 16


16.    OFFENCES.
       (1) A person who -
             (a) enters or remains in the country in contravention of this Act; or
             (b) aids or abets or incites a person to enter or remain in the country in
                   contravention of this Act; or
             (c) harbours a person whom he knows or has reasonable grounds for believing is
                   acting or has acted in contravention of this Act; or
             (d) disobeys or disregards an obligation imposed on him under or by virtue of this
                   Act; or
             (e) makes or causes to be made a false return, false statement, false representation,
                   or wilfully withholds any relevant fact or information in connexion with an
                   obligation imposed on him under or by virtue of this Act; or
             (f) resists or obstructs, actively or passively, an authorized person, officer or other
                   person exercising a duty under this Act; or
             (g) wilfully and without lawful excuse hinders or obstructs the removal of a person
                   from the country in accordance with this Act; or
             (h) gives, sells or lends a passport, or entry permit to another person in order that it
                   may be used in contravention of this or any other Act; or
             (i) uses for any purpose a passport or entry permit issued to another person; or
             (j) makes or causes to be made a false declaration for the purpose of obtaining an
                   entry permit for himself or any other person; or
             (k) without lawful authority has in his possession or uses a forged, unlawfully
                   altered, or irregular passport or entry permit or a passport or entry permit in
                   which an endorsement has been forged or unlawfully altered; or
             (l) hinders or obstructs a police officer acting in pursuance of a direction under
                   Section 15C (1),32
is guilty of an offence.

          Penalty:        A fine not exceeding K5,000.00 or imprisonment for a term not exceeding six
                          months.33

      (2) An officer may order a person in charge of a conveyance who is charged with an
offence under this Act not to remove his conveyance from the country until the charge has been
heard or determined and the fine (if any) has been paid.

17.  EVIDENCE.
     A copy of a removal order purporting to be signed by the Minister shall be prima facie
evidence of its contents.




32
     Paragraph (l) added by No. 10 of 1989, s.8.
33 The Penalty Clause is amended by No. 15 of 1996, s.2.



                                                           - 13 -
                                                                     Prepared for inclusion as at 26/4/2023
```

---

## Page 17

```text
 Ch. No. 16                                              Migration



18.   BURDEN OF PROOF.
      In proceedings under this Act, the burden of proof shall lie, where the question in issue is -
            (a) whether a person is or is not a citizen - on the person contending that the person
                 is a citizen; and
            (b) whether there is or is not an entry permit in force in respect of a person - on the
                 person contending the existence of the entry permit; and
            (c) whether or not an exemption from a provision of this Act is applicable - on the
                 person contending the applicability of the exemption; and
            (d) whether a person is or is not in possession of a passport - on the person
                 contending the possession.

19.   NO APPEAL AGAINST DECISION OF MINISTER, ETC.
      (1) Without limiting the generality of Subsection (2), the expression “review or
challenge” in that subsection includes -
            (a) a writ of certiorari, prohibition or mandamus or other form of prerogative writ,
                  or other writ, order or process in the nature of such a writ; or
            (b) proceedings by way of appeal or for a writ, order or process referred to in
                  Paragraph (a) (including proceedings for an order nisi or to show cause why
                  relief should not be granted).

      (2) An act, proposed act or decision of the Minister relating to the grant or cancellation of
an entry permit or to the removal of a person from the country, or any decision of a Committee of
Review under Section 6, is not open to review or challenge in any court on any ground.

20.   EXEMPTIONS.
      The Minister may, by instrument under his hand, exempt -
            (a) a person or a class or description of persons; or
            (b) a conveyance or class or description of conveyance,
either absolutely or conditionally, from all or any of the provisions of this Act.

21.   REPATRIATION.
      If the Minister is satisfied that a person, other than a citizen -
             (a) is destitute, infirm or mentally incapable; and
             (b) is unable to pay the cost of his passage and of the passage of any dependant to
                  the country of his birth or citizenship or to a country, the government of which
                  is prepared to receive him and any dependant; and
             (c) is willing to be repatriated,
he may authorise the repatriation of the person and any dependant at the expense of the State,
subject to any conditions he thinks fit to impose.




                                                - 14 -
```

---

## Page 18

```text
                                              Migration                               Ch. No. 16


22.   MINISTER TO REPORT TO THE PARLIAMENT.
      The Minister shall, at least once in every period of six months, give to the Parliament a
report stating -
             (a) the number of entry permits cancelled by him during the period to which the
                 report relates and brief details of the reasons for the cancellation; and
             (b) the number of persons removed from the country during the period to which the
                 report relates and brief details of the reasons for the removals; and
             (c) the number of persons repatriated by him during the period to which the report
                 relates and brief details of the reasons for the repatriations.

23.   REGULATIONS.
      The Head of State, acting on advice, may make regulations not inconsistent with this Act,
prescribing all matters that by this Act are required or permitted to be prescribed or that are
necessary or convenient to be prescribed for carrying out or giving effect to this Act and in
particular for the purposes of prescribing -
             (a) the forms to be used for the purposes of this Act; and
             (b) the deposit or security to be made or given in respect of a person seeking to
                   enter or remain in the country; and
             (c) the returns which the person in charge, the owner or his agent, of a conveyance
                   entering or leaving the country from or for another country shall give in respect
                   of the members of the crew and passengers on board that conveyance; and
           (ca) fees for services performed under this Act by authorised persons, whether those
                   services are performed within or outside Papua New Guinea, and making
                   provision for exemption from the payment of such fees; and34
             (d) penalties of fines not exceeding K5,000.00 or imprisonment for a term not
                   exceeding six months for offences against the regulations; and35
             (e) rules and procedures for the proper management and operation of relocation
                   centres; 36
             (f) authority to an Administrator to issue written instructions concerning
                   procedures in a relocation centre.37

24.  TRANSITIONAL PROVISIONS.
     (1) An entry permit issued under the repealed Act and in force immediately before 1 June
1980 shall continue in force and shall have effect as if it were an entry permit issued under this
Act.

      (2) An order for deportation made under the repealed Act and in force immediately
before 1 June 1980 shall continue in force and shall have effect as if it were a removal order made
under this Act.

34 Paragraph (ca) added by No. 15 of 1982.
35 Paragraph (d) amended by No. 15 of 1996, s.3.
36
     Paragraph (e) added by No. 10 of 1989, s.9
37 Ibid.



                                                          - 15 -
                                                                   Prepared for inclusion as at 26/4/2023
```

---

## Page 19

```text
 Ch. No. 16                                            Migration



       (3) A sum deposited, a bond, guarantee or security given or a surety bound under or for
the purposes of the repealed Act shall, with such alterations as may be necessary to make them
applicable to this Act, be deemed to have been deposited, given or bound under or for the purpose
of this Act.

      (4) A person held in detention by virtue of an order or provision of the repealed Act
immediately before 1 June 1980 shall be deemed to be held in detention by virtue of an analogous
order or provision of this Act.

      (5) A person appointed to a post, office, or position or given powers, duties or functions
under the repealed Act shall be deemed to have been appointed or given those powers, duties or
functions under this Act with such variations as may be necessary to be applicable under this Act.




                                           _________




Office of the Commissioner-Revised Laws, PNG




                                              - 16 -
```

---
