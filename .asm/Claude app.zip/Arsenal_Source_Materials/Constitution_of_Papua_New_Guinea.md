# Constitution of the Independent State of Papua New Guinea

## Full text transcription

Converted from the supplied PDF using its embedded machine-readable text.

## Page 1

```text
1
INDEPENDENT STATE OF PAPUA NEW GUINEA. 
CONSTITUTION 
of 
THE INDEPENDENT STATE OF PAPUA NEW GUINEA. 
PREAMBLE. 
Adoption of Constitution. 
WE, THE PEOPLE OF PAPUA NEW GUINEA— 
• 
united in one nation 
• 
pay homage to the memory of our ancestors—the source of our strength and origin of 
our combined heritage 
• 
acknowledge the worthy customs and traditional wisdoms of our people—which 
have come down to us from generation to generation 
• 
pledge ourselves to guard and pass on to those who come after us our noble traditions 
and the Christian principles that are ours now. 
By authority of our inherent right as ancient, free and independent peoples 
WE, THE PEOPLE, do now establish this sovereign nation and declare ourselves, under the 
guiding hand of God, to be the Independent State of Papua New Guinea. 
AND WE ASSERT, by virtue of that authority 
• 
that all power belongs to the people—acting through their duly elected 
representatives 
• 
that respect for the dignity of the individual and community interdependence are 
basic principles of our society 
• 
that we guard with our lives our national identity, integrity and self respect 
• 
that we reject violence and seek consensus as a means of solving our common 
problems 
• 
that our national wealth, won by honest, hard work be equitably shared by all 
WE DO NOW THEREFORE DECLARE 
that we, having resolved to enact a Constitution for the Independent State of Papua New 
Guinea 
AND ACTING through our Constituent Assembly on 15 August 1975 
HEREBY ESTABLISH, ADOPT and GIVE TO OURSELVES this Constitution to come into 
effect on Independence Day, that is 16 September 1975. 
IN SO DOING WE, THE PEOPLE OF PAPUA NEW GUINEA, SET BEFORE OURSELVES 
THESE NATIONAL GOALS AND DIRECTIVE PRINCIPLES THAT UNDERLIE OUR 
CONSTITUTION:— 
National Goals and Directive Principles.
```

---

## Page 2

```text
2
WE HEREBY PROCLAIM the following aims as our National Goals, and direct all persons and 
bodies, corporate and unincorporate, to be guided by these our declared Directives in pursuing 
and achieving our aims:— 
1. 
Integral human development. 
We declare our first goal to be for every person to be dynamically involved in the process of 
freeing himself or herself from every form of domination or oppression so that each man or 
woman will have the opportunity to develop as a whole person in relationship with others. 
WE ACCORDINGLY CALL FOR— 
(1) everyone to be involved in our endeavours to achieve integral human development of 
the whole person for every person and to seek fulfilment through his or her contribution 
to the common good; and 
(2) education to be based on mutual respect and dialogue, and to promote awareness of 
our human potential and motivation to achieve our National Goals through self-reliant 
effort; and 
(3) all forms of beneficial creativity, including sciences and cultures, to be actively 
encouraged; and 
(4) improvement in the level of nutrition and the standard of public health to enable our 
people to attain self fulfilment; and 
(5) the family unit to be recognized as the fundamental basis of our society, and for 
every step to be taken to promote the moral, cultural, economic and social standing of 
the Melanesian family; and 
(6) development to take place primarily through the use of Papua New Guinean forms of 
social and political organization. 
2. 
Equality and participation. 
We declare our second goal to be for all citizens to have an equal opportunity to participate in, 
and benefit from, the development of our country. 
WE ACCORDINGLY CALL FOR— 
(1) an equal opportunity for every citizen to take part in the political, economic, social, 
religious and cultural life of the country; and 
(2) the creation of political structures that will enable effective, meaningful participation 
by our people in that life, and in view of the rich cultural and ethnic diversity of our 
people for those structures to provide for substantial decentralization of all forms of 
government activity; and 
(3) every effort to be made to achieve an equitable distribution of incomes and other 
benefits of development among individuals and throughout the various parts of the 
country; and 
(4) equalization of services in all parts of the country, and for every citizen to have equal 
access to legal processes and all services, governmental and otherwise, that are required 
for the fulfilment of his or her real needs and aspirations; and 
(5) equal participation by women citizens in all political, economic, social and religious 
activities; and 
(6) the maximization of the number of citizens participating in every aspect of
```

---

## Page 3

```text
3
development; and 
(7) active steps to be taken to facilitate the organization and legal recognition of all 
groups engaging in development activities; and 
(8) means to be provided to ensure that any citizen can exercise his personal creativity 
and enterprise in pursuit of fulfilment that is consistent with the common good, and for 
no citizen to be deprived of this opportunity because of the predominant position of 
another; and 
(9) every citizen to be able to participate, either directly or through a representative, in 
the consideration of any matter affecting his interests or the interests of his community; 
and 
(10) all persons and governmental bodies of Papua New Guinea to ensure that, as far 
as possible, political and official bodies are so composed as to be broadly representative 
of citizens from the various areas of the country; and 
(11) all persons and governmental bodies to endeavour to achieve universal literacy in 
Pisin, Hiri Motu or English, and in “tok ples” or “ita eda tano gado”; and 
(12) recognition of the principles that a complete relationship in marriage rests on 
equality of rights and duties of the partners, and that responsible parenthood is based on 
that equality. 
3. 
National sovereignty and self-reliance. 
We declare our third goal to be for Papua New Guinea to be politically and economically 
independent, and our economy basically self-reliant. 
WE ACCORDINGLY CALL FOR— 
(1) our leaders to be committed to these National Goals and Directive Principles, to 
ensure that their freedom to make decisions is not restricted by obligations to or 
relationshipwith others, and to make all of their decisions in the national interest; and 
(2) all governmental bodies to base their planning for political, economic and social 
development on these Goals and Principles; and 
(3) internal interdependence and solidarity among citizens, and between provinces, to be 
actively promoted; and 
(4) citizens and governmental bodies to have control of the bulk of economic enterprise 
and production; and 
(5) strict control of foreign investment capital and wise assessment of foreign ideas and 
values so that these will be subordinate to the goal of national sovereignty and self-
reliance, and in particular for the entry of foreign capital to be geared to internal social 
and economic policies and to the integrity of the Nation and the People; and 
(6) the State to take effective measures to control and actively participate in the national 
economy, and in particular to control major enterprises engaged in the exploitation of 
natural resources; and 
(7) economic development to take place primarily by the use of skills and resources 
available in the country either from citizens or the State and not in dependence on 
imported skills and resources; and 
(8) the constant recognition of our sovereignty, which must not be undermined by 
dependence on foreign assistance of any sort, and in particular for no investment, 
military or foreign-aid agreement or understanding to be entered into that imperils our
```

---

## Page 4

```text
4
self-reliance and self-respect, or our commitment to these National Goals and Directive 
Principles, or that may lead to substantial dependence upon or influence by any country, 
investor, lender or donor. 
4. 
Natural resources and environment. 
We declare our fourth goal to be for Papua New Guinea‘s natural resources and environment 
to be conserved and used for the collective benefit of us all, and be replenished for the benefit 
of future generations. 
WE ACCORDINGLY CALL FOR— 
(1) wise use to be made of our natural resources and the environment in and on the land 
or seabed, in the sea, under the land, and in the air, in the interests of our development 
and in trust for future generations; and 
(2) the conservation and replenishment, for the benefit of ourselves and posterity, of the 
environment and its sacred, scenic, and historical qualities; and 
(3) all necessary steps to be taken to give adequate protection to our valued birds, 
animals, fish, insects, plants and trees. 
5. 
Papua New Guinean ways. 
We declare our fifth goal to be to achieve development primarily through the use of Papua 
New Guinean forms of social, political and economic organization. 
WE ACCORDINGLY CALL FOR— 
(1) a fundamental re-orientation of our attitudes and the institutions of government, 
commerce, education and religion towards Papua New Guinean forms of participation, 
consultation, and consensus, and a continuous renewal of the responsiveness of the 
institutions to the needs and attitudes of the People; and 
(2) particular emphasis in our economic development to be placed on small-scale artisan, 
service and business activity; and 
(3) recognition that the cultural, commercial and ethnic diversity of our people is a 
positive strength, and for the fostering of a respect for, and appreciation of, traditional 
ways of life and culture, including language, in all their richness and variety, as well as 
for a willingness to apply these ways dynamically and creatively for the tasks of 
development; and 
(4) traditional villages and communities to remain as viable units of Papua New Guinean 
society, and for active steps to be taken to improve their cultural, social, economic and 
ethical quality. 
 
Basic Rights. 
WE HEREBY ACKNOWLEDGE that, subject to any restrictions imposed by law on non-
citizens, all persons in our country are entitled to the fundamental rights and freedoms of the 
individual, that is to say, the right, whatever their race, tribe, places of origin, political opinion, 
colour, creed or sex, but subject to respect for the rights and freedoms of others and for the 
legitimate public interest, to each of the following:— 
(a) life, liberty, security of the person and the protection of the law; and
```

---

## Page 5

```text
5
(b) the right to take part in political activities; and 
(c) freedom from inhuman treatment and forced labour; and 
(d) freedom of conscience, of expression, of information and of assembly and 
association; and 
(e) freedom of employment and freedom of movement; and 
(f) protection for the privacy of their homes and other property and from unjust 
deprivation of property, 
and have accordingly included in this Constitution provisions designed to afford protection to 
those rights and freedoms, subject to such limitations on that protection as are contained in those 
provisions, being limitations primarily designed to ensure that the enjoyment of the 
acknowledged rights and freedoms by an individual does not prejudice the rights and freedoms 
of others or the legitimate public interest. 
Basic Social Obligations. 
WE HEREBY DECLARE that all persons in our country have the following basic obligations to 
themselves and their descendants, to each other, and to the Nation:— 
(a) to respect, and to act in the spirit of, this Constitution; and 
(b) to recognize that they can fully develop their capabilities and advance their true 
interests only by active participation in the development of the national community as a 
whole; and 
(c) to exercise the rights guaranteed or conferred by this Constitution, and to use the 
opportunities made available to them under it to participate fully in the government of 
the Nation; and 
(d) to protect Papua New Guinea and to safeguard the national wealth, resources and 
environment in the interests not only of the present generation but also of future 
generations; and 
(e) to work according to their talents in socially useful employment, and if necessary to 
create for themselves legitimate opportunities for such employment; and 
(f) to respect the rights and freedoms of others, and to co-operate fully with others in the 
interests of interdependence and solidarity; and 
(g) to contribute, as required by law, according to their means to the revenues required 
for the advancement of the Nation and the purposes of Papua New Guinea; and 
(h) in the case of parents, to support, assist and educate their children (whether born in or 
out of wedlock), and in particular to give them a true understanding of their basic rights 
and obligations and of the National Goals and Directive Principles; and 
(i) in the case of the children, to respect their parents. 
 
IN ADDITION, WE HEREBY DECLARE that all citizens have an obligation to themselves and 
their descendants, to each other and to the Nation to use profits from economic activities in the 
advancement of our country and our people, and that the law may impose a similar obligation on 
non-citizens carrying on economic activities in or from our country. 
 
PART I.—INTRODUCTORY.
```

---

## Page 6

```text
6
Division 1.—The Nation. 
1. 
The Independent State of Papua New Guinea. 
(1) 
Papua New Guinea is a sovereign, independent State by the name of the Independent 
State of Papua New Guinea. 
(2) 
The name of the Independent State of Papua New Guinea and its variants shall be 
protected by an Act of the Parliament. 
(See: National Identity Act (Chapter 9)). 
2. 
The area of Papua New Guinea. 
(1) 
The area of Papua New Guinea consists of the area that, immediately before 
Independence Day, constituted what was then known as Papua New Guinea, together with all 
internal waters and the territorial sea and underlying lands, and, subject to disclaimer by 
resolution of the Parliament at or before the end of its next meeting, includes such neighbouring 
waters and such lands underlying any such waters, and such additional lands and waters, as are 
declared by the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council, to be part of that area. 
 
(See: National Seas Act (Chapter 361)) 
 
(2) 
The sovereignty of Papua New Guinea over its territory, and over the natural resources 
of its territory, is and shall remain absolute, subject only to such obligations at international law 
as are freely accepted by Papua New Guinea in accordance with this Constitution. 
3. 
National symbols. 
(1) 
Acts of the Parliament may make provision for and in respect of— 
(a) a National Flag; and 
(b) a National Emblem; and 
(c) a National Motto; and 
(d) a National Seal; and 
(e) a National Anthem. 
(2) 
Until such time as other provision is made in accordance with Subsection (1), the 
National Flag, National Emblem and National Seal are those that were in use immediately before 
Independence Day. 
 (See National Identity Act (Chapter 9)) 
4. 
National Capital District. 
(1) 
There shall be a National Capital District. 
(2) 
The Seat of Government shall be in the National Capital District. 
(3) 
The boundaries of the National Capital District shall be as defined by an Organic Law.
```

---

## Page 7

```text
7
 
(See: Organic Law on Boundaries of the National Capital District) 
 
(4) 
An Organic Law or an Act of the Parliament shall make provision in respect of the 
government of the National Capital District. (See: NCDC Act 2001) 
(5) 
In calculating the number of provincial electorates in accordance with Section 125 
(electorates), the National Capital District shall be taken into account as if it were a province. 
5. 
Provinces. 
(1) 
An Organic Law may declare, or make provision in respect of the declaration of, part of 
the country as provinces. 
(2) 
An Organic Law may provide for, or make provision in respect of, the creation of new 
provinces by the amalgamation or division of existing provinces or for the variation of the 
boundaries of a province. (See: Organic Law on Provincial Boundaries) 
6. 
Declaration of Loyalty. 
Where a law requires a Declaration of Loyalty to be made, it shall be made in the following 
form:— 
“I,…, realizing fully the responsibilities to which I am committing myself and the consequences 
of not living up to this Declaration and those responsibilities, freely and willingly declare my 
loyalty to the Independent State of Papua New Guinea and its People and to the Constitution of 
Papua New Guinea adopted by the Constituent Assembly on 15 August 1975, as altered from 
time to time in accordance with its provisions, and promise that I will uphold the Constitution 
and the laws of Papua New Guinea.”. 
7. 
Oath of Allegiance. 
Where a law requires an Oath of Allegiance or Affirmation of Allegiance to be made, it shall be 
made in the following form:— 
“Oath of Allegiance. 
I,…, do swear that I will well and truly serve and bear true allegiance to Her Majesty Queen 
Elizabeth II, her heirs and successors according to law. 
SO HELP ME GOD. 
Affirmation of Allegiance. 
I,…, do promise and affirm that I will well and truly serve Her Majesty Queen Elizabeth II, her 
heirs and successors according to law.”. 
 
Division 2.—Interpretation. 
8. 
Principles of interpretation.
```

---

## Page 8

```text
8
For the purpose of the interpretation of this Constitution and the Organic Laws, the provisions of 
Schedule 1 (Rules for Shortening and Interpretation of the Constitutional Laws) applies and, 
subject to that Schedule, the underlying law applies. 
 
PART II.—THE NATIONAL LEGAL SYSTEM. 
Division 1.—The Laws of Papua New Guinea. 
9. 
The laws. 
The laws of Papua New Guinea consist of— 
(a) this Constitution; and 
(b) the Organic Laws; and 
(c) the Acts of the Parliament; and 
(d) Emergency Regulations; and 
(da) 
the provincial laws; and 
(e) laws made under or adopted by or under this Constitution or any of those laws, 
including subordinate legislative enactments made under this Constitution or any of 
those laws; and 
(f) the underlying law, and none other. 
(Paragraph (da) inserted by Constitutional Amendment No.1) 
10. Construction of written laws. 
All written laws (other than this Constitution) shall be read and construed subject to— 
(a) in any case—this Constitution; and 
(b) in the case of Acts of the Parliament—any relevant Organic Laws; and 
(c) in the case of adopted laws or subordinate legislative enactments—the Organic Laws 
and the laws by or under which they were enacted or made, 
and so as not to exceed the authority to make them properly given, to the intent that where any 
such law would, but for this section, have been in excess of the authority so given it shall 
nevertheless be a valid law to the extent to which it is not in excess of that authority. 
 
 
 
 
Division 2.—Constitutional Laws. 
Subdivision A.—Supreme Law. 
11. Constitution, etc., as Supreme Law. 
(1) 
This Constitution and the Organic Laws are the Supreme Law of Papua New Guinea, 
and, subject to Section 10 (construction of written laws) all acts (whether legislative, executive 
or judicial) that are inconsistent with them are, to the extent of the inconsistency, invalid and
```

---

## Page 9

```text
9
ineffective. 
(2) 
The provisions of this Constitution and of the Organic Laws are self-executing to the 
fullest extent that their respective natures and subject-matters permit. 
12. Organic Laws. 
(1) 
Subject to Subsection (4), for the purposes of this Constitution, an Organic Law is a law 
made by the Parliament that is— 
(a) for or in respect of a matter provision for which by way of an Organic Law is 
authorized by this Constitution; and 
(b) not inconsistent with this Constitution; and 
(c) expressed to be an Organic Law. 
(2) 
An Organic Law may be altered only by another Organic Law, or by an alteration to this 
Constitution. 
(3) 
Nothing in this section prevents an Organic Law from— 
(a) making any provision that might be made by an Act of the Parliament; or 
(b) requiring any provision to be made by an Act of the Parliament that might otherwise 
be so made, 
but any such provision may be altered by the same majority that is required for any other Act of 
the Parliament. 
(4) 
Where this Constitution authorizes an Organic Law to make provision for any matter, 
the Organic Law may— 
(a) make full provision for all aspects of that matter notwithstanding that all such aspects 
have not been expressly referred to in the provision authorizing the Organic Law except 
where this Constitution expressly limits the aspects of that matter for which provision 
may be made in an Organic Law; and 
(b) may impose conditions, restrictions or modifications in respect of that matter or any 
aspect of it, except where this Constitution expressly states that conditions, restrictions 
or modifications shall not be imposed in respect of that matter. 
Subdivision B.—Constitutional Alteration and Organic Laws. 
13. Alterations of the Constitution. 
This Constitution may be altered only by law made by the Parliament that— 
(a) is expressed to be a law to alter this Constitution; and 
(b) is made and certified in accordance with Section 14 (making of alterations to the 
Constitution and Organic Laws). 
14. Making of alterations to the Constitution and Organic Laws. 
(1) 
Subject to Sections 12(3) (Organic Laws) and 15 (urgent alterations), a proposed law to 
alter this Constitution, or a proposed Organic Law, must be supported on a division in 
accordance with the Standing Orders of the Parliament by the prescribed majority of votes 
determined in accordance with Section 17 (“prescribed majority of votes”) expressed on at least 
two occasions after opportunity for debate on the merits.
```

---

## Page 10

```text
10
(2) 
Subject to Section 15 (urgent alterations), the opportunities for debate referred to in 
Subsection (1) must have been— 
(a) during different meetings of the Parliament; and 
(b) separated in time by at least two months, 
and the proposed law must be published by the Speaker in full in the National Gazette, and 
circulated, in accordance with the Standing Orders of the Parliament, to all members of the 
Parliament not less than one month before it is formally introduced into the Parliament. 
(3) 
Amendments to a proposed law to amend this Constitution or a proposed Organic Law 
shall not be moved unless they have been circulated to members of the Parliament before the end 
of the meeting of the Parliament at which the first opportunity for debate referred to in 
Subsection (1) occurs. 
(4) 
Subject to Subsection (6), in his certificate given under Section 110 (certification as to 
making of laws), the Speaker must certify that the requirements of Subsections (1), (2) and (3) or 
Section 15 (urgent alterations), as the case may be, have been complied with. 
(5) 
The certificate referred to in Subsection (4) shall state— 
(a) the date on which each vote was taken; and 
(b) in relation to each vote— 
(i) 
the number of seats in the Parliament at the time; and 
(ii) 
the respective numbers of members of the Parliament voting for and against the 
proposal, and where the requirements of Subsection (2) were waived under Section 
15 (urgent alterations) for and against the motion for the waiver, 
and is, in the absence of proof to the contrary, conclusive evidence of the matter so stated. 
(6) 
Unless the Parliament decides otherwise in any particular case, Subsection (1) does not 
apply where the Speaker, after consultation with the Chief Justice or a Judge nominated by the 
Chief Justice for the purpose, certifies that the for the definition of “proposed law” for the 
purposes of that section. 
proposed law— 
(a) does not affect the substance of any provision to be altered by it; or 
(b) is designed to correct a self-evident error or omission; or 
(c) is merely incidental to or consequential on some other alteration of this Constitution 
or of any other law, 
and such a law may be made in the same way as Acts of the Parliament. 
(7) 
The Supreme Court may, on the application of any person made within four weeks after 
the date of a certificate under Subsection (6) or such further time as a Judge, on application made 
within that period, considers reasonable in the particular circumstances, disallow the certificate, 
but otherwise the certificate is conclusive. 
15. Urgent alterations. 
(1) 
The provisions of this section cease to have effect at the first moment of the fourth 
anniversary of Independence Day.
```

---

## Page 11

```text
11
(2) 
Subject to Subsection (5), the requirements of Section 14(2) (making of alterations to 
the Constitution and Organic Laws) may be waived, on the ground of urgency, by the Parliament 
by a division in accordance with the Standing Orders of the Parliament by a two-thirds absolute 
majority vote. 
(3) 
The requirements of Section 14(2) (making of alterations to the Constitution and 
Organic Laws) shall not be waived under Subsection (2) unless— 
(a) at least four days’ notice of the intention in accordance with the Standing Orders of 
the Parliament to invoke Subsection (2) has been given; and 
(b) the proposed law has been circulated, in accordance with the Standing Orders of the 
Parliament, to all members of the Parliament and published in full by the Speaker in the 
National Gazette at least four days before the motion to invoke Subsection (2) is moved; 
and 
(c) the opportunities for debate referred to in Section 14(1) (making of alterations to the 
Constitution and Organic Laws) have been separated in time by at least two weeks, but 
not necessarily during different meetings of the Parliament. 
(4) 
Amendments to a proposed law to amend this Constitution or a proposed Organic Law 
to which this section applies shall not be moved unless they have been circulated to members of 
the Parliament before the end of the first debate on the matter. 
(5) 
This section does not apply to proposed laws to alter the following provisions of this 
Constitution, or Organic Laws made for the purposes of any such provision:— 
(a) this section; 
(b) the Preamble; 
(c) Division II.2. (Constitutional Laws); 
(d) Division III.1. (National Goals and Directive Principles); 
(e) Division III.2. (leadership code); 
(f) Division III.3. (basic rights); 
(g) Division III.5. (basic social obligations); 
(h) Part IV. (citizenship); 
(i) Division VI.2. (the National Parliament); 
(j) Division VI.3. (special instances of the legislative powers); 
(k) Division VI.5. (the administration of justice); 
(ka) 
Part VIA. (provincial government and local level government); 
(l) Division VII.2. (the Public Services Commission); 
(m) 
Division VII.4. (special provisions in relation to the Police Force); 
(n) Division VII.5. (special provisions in relation to the Defence Force); 
(o) Part VIII. (supervision and control); 
(p) Part IX. (constitutional office-holders and constitutional institutions); 
(q) Part X. (emergency powers). 
 
(Paragraph (ka) inserted by Constitutional Amendment No.3) 
 
16. Indirect alterations.
```

---

## Page 12

```text
12
(1) 
No Constitutional Law takes effect so as to affect the operation of any provision of such 
a law in force immediately before the commencement of the first-mentioned law unless it was 
made in the manner and form required for the alteration of that provision. 
(2) 
For the avoidance of doubt, it is hereby declared that Subsection (1) extends to Schedule 
1 (Rules for Shortening and Interpretation of the Constitutional Laws) in its application to any 
provision of this Constitution. 
17. “Prescribed majority of votes”. 
(1) 
Subject to this section, in relation to a proposed law to alter any provision of this 
Constitution the prescribed majority of votes for the purposes of Section 14 (making of 
alterations to the Constitution and Organic Laws) is the majority of votes prescribed by this 
Constitution in relation to that provision, or if no majority is prescribed a two-thirds absolute 
majority vote. 
(2) 
For the purposes of Subsection (1) the prescribed majority of votes for this subsection, 
Sections 3, 6, 8, 20, 21, 23, 24, 26 to 31 (inclusive), 63, 68, 69, 73, 77 to 98 (inclusive), 101, 103, 
104, 110, 117, 138, 139, 150, 156, 165, 167, 171, 184 to 187 (inclusive), 206, 248 to 252 
(inclusive), 264 to 268 (inclusive), Sch.1.21, Sch.2.1 to Sch.2.14 (inclusive), Schedules 3, 4 and 
5 is an absolute majority. 
(3) 
For the purposes of Subsection (1) the prescribed majority of votes for this subsection, 
Sections 35, 36, 50, 57, 105, 106, 109, 113, 125, 126, 155, 157, 160, 163, 217, 235, 239, 243, 
244, 245 and 269 is a three-quarters absolute majority. 
(4) 
Subject to this section, for the purpose of a proposed law to add a new provision to this 
Constitution the prescribed majority of votes is the same as the prescribed majority of votes that 
would be required to alter that provision if it was already enacted. 
(5) 
Subject to Section 12(3) (Organic Laws), in relation to a proposed Organic Law the 
prescribed majority of votes is— 
(a) in the case of a proposed Organic Law to alter a provision of an Organic Law—the 
same as the majority that would be required for the making of the provision proposed to 
be altered; and 
(b) in any other case— 
(i) 
the majority of votes (not being less than an absolute majority) prescribed by 
this Constitution for the making of the Organic Law; and 
(ii) 
if no majority is prescribed, a two-thirds absolute majority. 
(6) 
Where, by virtue of the operation of the preceding provisions of this section, there are 
different prescribed majorities in relation to different provisions a proposed law, the prescribed 
majority of votes in relation to the law as a whole is the greatest of those majorities. 
(7) 
Nothing in this section prevents different majorities being prescribed in respect of            
different aspects or subject-matters of a provision. 
(8) 
No Organic Law may require a majority of votes for the alteration of a provision of an 
Organic Law greater than that by which the first-mentioned law was made. 
(9) 
Notwithstanding anything in this section, until 16 September 1980—
```

---

## Page 13

```text
13
(a) for the purpose  of a proposed law to add a new provision to this Constitution, the 
prescribed majority of votes is an absolute majority; and 
(b) for the purpose of making an Organic Law for which there was provision in this 
Constitution when adopted the prescribed majority of votes is an absolute majority. 
 
Subdivision C.—Constitutional Interpretation. 
18. Original interpretative jurisdiction of the Supreme Court. 
(1) 
Subject to this Constitution, the Supreme Court has original jurisdiction, to the exclusion 
of other courts, as to any question relating to the interpretation or application of any provision of 
a Constitutional Law. 
(2) 
Subject to this Constitution, where any question relating to the interpretation or 
application of any provision of a Constitutional Law arises in any court or tribunal, other than the 
Supreme Court, the court or tribunal shall, unless the question is trivial, vexatious or irrelevant, 
refer the matter to the Supreme Court, and take whatever other action (including the adjournment 
of proceedings) is appropriate. 
19. Special references to the Supreme Court. 
(1) 
Subject to Subsection (4), the Supreme Court shall, on application by an authority 
referred to in Subsection (3), give its opinion on any question relating to the interpretation or 
application of any provision of a Constitutional Law, including (but without limiting the 
generality of that expression) any question as to the validity of a law or proposed law. 
(2) 
An opinion given under Subsection (1) has the same binding effect as any other decision 
of the Supreme Court. 
(3) 
The following authorities only are entitled to make application under Subsection (1):— 
(a) the Parliament; and 
(b) the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council; and 
(c) the Law Officers of Papua New Guinea; and 
(d) the Law Reform Commission; and 
(e) the Ombudsman Commission; and 
(ea) 
a Provincial Assembly or a Local-level Government; and 
(eb) 
a provincial executive; and 
(ec) 
a body established by a Constitutional Law or an Act of the Parliament 
specifically for the settlement of disputes between the National Government and 
Provincial Governments or Local-level Governments, or between Provincial 
Governments, or between Provincial Governments and Local-level Governments, or 
Local-level Governments; and 
(f) the Speaker, in accordance with Section 137(3) (Acts of Indemnity). 
 
(Paragraph (ea), (eb) and (ec) inserted by Constitutional Amendment No.3) 
 
(4) 
Subject to any Act of the Parliament, the Rules of Court of the Supreme Court may
```

---

## Page 14

```text
14
make provision in respect of matters relating to the jurisdiction of the Supreme Court under this 
section, and in particular as to— 
(a) the form and contents of questions to be decided by the Court; and 
(b) the provision of counsel adequate to enable full argument before the Court of any 
question; and 
(c) cases and circumstances in which the Court may decline to give an opinion. 
(5) 
In this section, “proposed law” means a law that has been formally placed before the 
relevant law-making body. 
Division 3.—Adoption, Reception and Development of Certain Laws. 
20. Underlying law and pre-Independence statutes. 
(1) 
An Act of Parliament shall— 
(a) declare the underlying law of Papua New Guinea; and 
(b) provide for the development of the underlying law of Papua New Guinea. 
 
(See: The Underlying Act 2000)  
 
(2) 
Until such time as an Act of Parliament provides otherwise— 
(a) the underlying law of Papua New Guinea shall be as prescribed in Schedule 2 
(adoption, etc., of certain laws); and 
(b) the manner of development of the underlying law shall be as prescribed by Schedule 
2 (adoption, etc., of certain laws). 
(3) 
Certain pre-Independence statutes are adopted and shall be adopted as Acts of Parliament 
and subordinate enactments of Papua New Guinea, as prescribed by Schedule 2 
(adoption, etc., of certain laws). 
21. Purpose of Schedule 2. 
(1) 
The purpose of Schedule 2 (adoption, etc., of certain laws) and of the Act of the 
Parliament referred to in Section 20 (underlying law and pre-Independence statutes) is to assist 
in the development of our indigenous jurisprudence, adapted to the changing circumstances of 
Papua New Guinea. 
(2) 
For the purpose set out in Subsection (1), a Law Reform Commission shall be 
established in accordance with Schedule 2 (adoption, etc., of certain laws), and certain special 
responsibilities are imposed by that Schedule on the National Judicial System (and in particular 
on the Supreme Court and the National Court) and on the Law Reform Commission. 
(See: Constitution and Law Reform Commission Act 2004)  
Division 4.—General. 
22. Enforcement of the Constitution. 
The provisions of this Constitution that recognize rights of individuals (including corporations 
and associations) as well as those that confer powers or impose duties on public authorities, shall
```

---

## Page 15

```text
15
not be left without effect because of the lack of supporting, machinery or procedural laws, but 
the lack shall, as far as practicable, be supplied by the National Court in the light of the National 
Goals and Directive Principles, and by way of analogy from other laws, general principles of 
justice and generally-accepted doctrine. 
23. Sanctions. 
(1) 
Where any provision of a Constitutional Law prohibits or restricts an act, or imposes a 
duty, then unless a Constitutional Law or an Act of the Parliament provides for the enforcement 
of that provision the National Court may— 
(a) impose a sentence of imprisonment for a period not exceeding 10 years or a fine not 
exceeding K10 000.00; or 
(b) in the absence of any other equally effective remedy under the laws of Papua New 
Guinea, order the making of compensation by a person (including a governmental body) 
who is in default, 
or both, for a breach of the prohibition, restriction or duty, and may make such further order in 
the circumstances as it thinks proper. 
(2) 
Where a provision of a Constitutional Law prohibits or restricts an act or imposes a 
duty, the National Court may, if it thinks it proper to do so, make any order that it thinks proper 
for preventing or remedying a breach of the prohibition, restriction or duty, and Subsection (1) 
applies to a failure to comply with the order as if it were a breach of a provision of this 
Constitution. 
(3) 
Where the National Court considers it proper to do so, it may include in an order under 
Subsection (2) an anticipatory order under Subsection (1). 
24. Use of certain materials as aids to interpretation. 
(1) 
The official records of debates and of votes and proceedings— 
(a) in the pre-Independence House of Assembly on the report of the Constitutional 
Planning Committee; and 
(b) in the Constituent Assembly on the draft of this Constitution, 
together with that report and any other documents or papers tabled for the purposes of or in 
connexion with those debates, may be used, so far as they are relevant, as aids to interpretation 
where any question relating to the interpretation or application of any provision of a 
Constitutional Law arises. 
(2) 
An Act of the Parliament may make provision for the manner of proof of the records 
and documents referred to in Subsection (1). 
(See: Constitutional Documents (Manner of Proof) Act (Chapter 5)) 
(3) 
In Subsection (1), “the report of the Constitutional Planning Committee” means the 
Final Report of the pre-Independence Constitutional Planning Committee dated 13 August 1974 
and presented to the pre-Independence House of Assembly on 16 August 1974. 
 
PART III.—BASIC PRINCIPLES OF GOVERNMENT.
```

---

## Page 16

```text
16
Division 1.—National Goals and Directive Principles. 
25. Implementation of the National Goals and Directive Principles. 
(1) 
Except to the extent provided in Subsections (3) and (4), the National Goals and 
Directive Principles are non-justiciable. 
(2) 
Nevertheless, it is the duty of all governmental bodies to apply and give effect to them 
as far as lies within their respective powers. 
(3) 
Where any law, or any power conferred by any law (whether the power be of a 
legislative, judicial, executive, administrative or other kind), can reasonably be understood, 
applied, exercised or enforced, without failing to give effect to the intention of the Parliament or 
to this Constitution, in such a way as to give effect to the National Goals and Directive 
Principles, or at least not to derogate them, it is to be understood, applied or exercised, and shall 
be enforced, in that way. 
(4) 
Subsection (1) does not apply to the jurisdiction of the Ombudsman Commission or of 
any other body prescribed for the purposes of Division III.2 (leadership code), which shall take 
the National Goals and Directive Principles fully into account in all cases as appropriate. 
 
Division 2.—Leadership Code. 
26. Application of Division 2. 
(1) 
The provisions of this Division apply to and in relation to— 
(a) the Prime Minister, the Deputy Prime Minister and the other Ministers; and 
(b) the Leader and Deputy Leader of the Opposition; and 
(c) all other members of the Parliament; and 
(d) members of Provincial Assemblies and Local-level Governments; and 
(e) all constitutional office-holders within the meaning of Section 221 (definitions); and 
(f) all heads of Departments of the National Public Service; and 
(g) all heads of or members of the boards or other controlling bodies of statutory 
authorities; and 
(h) the Commissioner of Police; and 
(i) the Commander of the Defence Force; and 
(j) all ambassadors and other senior diplomatic and consular officials prescribed by an 
Organic Law or an Act of the Parliament; and 
(k) the public trustee; and 
(l) the personal staff of the Governor-General, the Ministers and the Leader and Deputy 
Leader of the Opposition; and 
(m) 
executive officers of registered political parties as defined by Section 128 
(“registered political party”); and 
(n) persons holding such public offices as are declared under Subsection (3) to be offices 
to and in relation to which this Division applies. 
 
(Paragraph (d) repealed and replaced by Constitutional Amendment No. 3
```

---

## Page 17

```text
17
and again by Constitutional Amendment No.12) 
 
(2) 
This Division applies to and in relation to a person referred to in Subsection (1) not only 
in the office referred to in that subsection but also in any other office or position that he holds 
under any law by virtue of that office. 
(3) 
An Organic Law or an Act of the Parliament may declare any public office (including 
an office in a provincial government or a local-level government body) to be an office to and in 
relation to which this Division applies. (Subsection 3 amended by Constitutional 
Amendment No.3) 
(4) 
In the event of doubt as to whether a person is a person to whom this Division applies, 
the decision of the Ombudsman Commission is final. 
27. Responsibilities of office. 
(1) 
A person to whom this Division applies has a duty to conduct himself in such a way, 
both in his public or official life and his private life, and in his associations with other persons, as 
not— 
(a) to place himself in a position in which he has or could have a conflict of interests or 
might be compromised when discharging his public or official duties; or 
(b) to demean his office or position; or 
(c) to allow his public or official integrity, or his personal integrity, to be called into 
question; or 
(d) to endanger or diminish respect for and confidence in the integrity of government in 
Papua New Guinea. 
(2) 
In particular, a person to whom this Division applies shall not use his office for personal 
gain or enter into any transaction or engage in any enterprise or activity that might be expected to 
give rise to doubt in the public mind as to whether he is carrying out or has carried out the duty 
imposed by Subsection (1). 
(3) 
It is the further duty of a person to whom this Division applies— 
(a) to ensure, as far as is within his lawful power, that his spouse and children and any 
other persons for whom he is responsible (whether morally, legally or by usage), 
including nominees, trustees and agents, do not conduct themselves in a way that might 
be expected to give rise to doubt in the public mind as to his complying with his duties 
under this section; and 
(b) if necessary, to publicly disassociate himself from any activity or enterprise of any of 
his associates, or of a person referred to in paragraph (a), that might be expected to give 
rise to such a doubt. 
(4) 
The Ombudsman Commission or other authority prescribed for the purpose under 
Section 28 (further provisions) may, subject to this Division and to any Organic Law made for 
the purposes of this Division, give directions, either generally or in a particular case, to ensure 
the attainment of the objects of this section. 
(5) 
A person to whom this Division applies who— 
(a) is convicted of an offence in respect of his office or position or in relation to the
```

---

## Page 18

```text
18
performance of his functions or duties; or 
(b) fails to comply with a direction under Subsection (4) or otherwise fails to carry out 
the obligations imposed by Subsections (1), (2) and (3), 
is guilty of misconduct in office. 
28. Further provisions. 
(1) 
For the purposes of this Division, an Organic Law— 
(a) may give to the Ombudsman Commission or some other authority any powers that 
are necessary or convenient for attaining the objects of this Division and of the Organic 
Law; and 
(b) shall make provision for the disclosure to the Ombudsman Commission or some 
other authority of the personal and business incomes and financial affairs of persons to 
whom this Division applies, and of their families and associates, and in particular of 
interests in contracts with governmental bodies and of directorships and similar offices 
held by them (including powers to nominate directors, trustees or agents, or similar 
officers); and 
(c) shall empower the Ombudsman Commission or some other authority to require a 
person to whom this Division applies to dispose of, or place under the control of the 
public trustee, any assets or income where this seems to be desirable for attaining the 
objects of this Division; and 
(d) may prescribe specific acts that constitute misconduct in office; and 
(e) may create offences (including offences by persons to whom this Division applies 
and offences by other persons); and 
(f) shall provide for the investigation by the Ombudsman Commission or some other 
authority of cases of alleged or suspected misconduct in office, and confer on the 
Commission or authority any powers that are necessary or convenient for that purpose; 
and 
(g) shall establish independent tribunals that— 
(i) 
shall investigate and determine any cases of alleged or suspected misconduct in 
office referred to them in accordance with the Organic Law; and 
(ii) 
are required subject to Subsection (1A), to recommend to the appropriate 
authority that a person found guilty of misconduct in office be dismissed from office 
or position; and 
(h) 
may make any other provision that is necessary or convenient for attaining the 
objects of this Division. 
(paragraph g(ii) repealed by Constitutional Amendment No.4) 
(See: Organic Law on Duties and Responsibilities of Leadership ; Organic 
Law on the Ombudsman Commission) 
 (1A) 
An Organic Law may provide that where the independent tribunal referred to in 
Subsection (1)(g) finds that— 
(a) there was no serious culpability on the part of a person found guilty of misconduct in 
office; and 
(b) public policy and the public good do not require dismissal,
```

---

## Page 19

```text
19
it may recommend to the appropriate authority that some other penalty provided for by law be 
imposed. 
(Subsection (1A) inserted by Constitutional Amendment No.4) 
(See: Organic Law on the Duties and Responsibilities of Leadership; 
Leadership Code(Alternative Penalties) Act (Chapter 1A)) 
 
(2) 
Where an independent tribunal referred to in Subsection (1)(g) makes a 
recommendation to the appropriate authority in accordance with that paragraph or with 
Subsection (1A), the appropriate authority shall act in accordance with the recommendation. 
 
(Subsection 2 repealed and replaced by Constitutional Amendment No.4) 
 
(3) 
For the purposes of Subsections (1)(g), (1A) and (2), “the appropriate authority”— 
(a) in relation to— 
(i) 
a person holding an office referred to in Section 26(1)(a), (b), (c) or (d) 
(application of Division 2); or 
(ii) 
a person holding an elective office that is declared under Section 26(3) to be an 
office to and in relation to which this Division applies, 
means the Head of State; and 
(b) in relation to a person holding any other office to which this Division applies—
means the appropriate appointing authority. 
(c)  
(Subsection (3) repealed and replaced by Constitutional Amendment No.4) 
 
(4) 
An Organic Law may provide for the suspension from office of a person to whom this 
Division applies pending the investigation of any case of alleged or suspected misconduct in 
office by him. 
(See: Organic Law on the Duties and Responsibilities of Leadership) 
(5) 
Proceedings under Subsection (1)(g) are not judicial proceedings but are subject to the 
principles of natural justice, and— 
(a) no such proceedings are a bar to any other proceedings provided for by law; and 
(b) no other proceedings provided for by law are a bar to proceedings under that 
paragraph. 
29. Prosecution of misconduct in office. 
(1) 
Where the Ombudsman Commission or other authority referred to in Section 28(1)(f) 
(further provisions) is satisfied that there is a prima facie case that a person has been guilty of 
misconduct in office, it shall refer the matter to the Public Prosecutor for prosecution before a 
tribunal established under Section 28(1)(g) (further provisions). 
(2) 
If the Public Prosecutor fails to prosecute the matter within a reasonable period, the 
Commission may prosecute it in his stead.
```

---

## Page 20

```text
20
30. Other authority. 
Where another authority is prescribed under Section 28 (further provisions) that authority— 
(a) shall be composed of a person or persons who are declared under Section 221(1) 
(definitions) to be a constitutional office-holder; and 
(b) is not subject to direction or control by any person or authority. 
31. Disqualifications on dismissal. 
(1) 
A person who has been dismissed from office under this Division for misconduct in 
office is not eligible— 
(a) to election to any elective public office; or 
(b) for appointment as Head of State or as a nominated member of the Parliament; or 
(c) for appointment to a provincial legislature or provincial executive (including the 
office of head of a provincial executive), or to a local-level government body, 
for a period of three years after the date of his dismissal. 
(Amended by Constitutional Amendment No.3) 
(2) 
In the event of doubt as to whether an office or position is an office or position to which 
Subsection (1) (a), (b) or (c) applies, the decision of the Ombudsman Commission is final. 
 
Division 3.—Basic Rights. 
Subdivision A.—Introductory. 
32. Right to freedom. 
(1) 
Freedom based on law consists in the least amount of restriction on the activities of 
individuals that is consistent with the maintenance and development of Papua New Guinea and 
of society in accordance with this Constitution and, in particular, with the National Goals and 
Directive Principles and the Basic Social Obligations. 
(2) 
Every person has the right to freedom based on law, and accordingly has a legal right to 
do anything that— 
(a) does not injure or interfere with the rights and freedoms of others; and 
(b) is not prohibited by law, 
and no person— 
(c) is obliged to do anything that is not required by law; and 
(d) may be prevented from doing anything that complies with the provisions of 
paragraphs (a) and (b). 
(3) 
This section is not intended to reflect on the extra-legal existence, nature or effect of 
social, civic, family or religious obligations, or other obligations of an extra-legal nature, or to 
prevent such obligations being given effect to by law. 
33. Other rights and freedoms, etc. 
Nothing in this Division derogates the rights and freedoms of the individual under any other law
```

---

## Page 21

```text
21
and, in particular, an Organic Law or an Act of the Parliament may provide further guarantees of 
rights and freedoms and may further restrict the limitations that may be placed on, or on the 
exercise of, any right to freedom (including the limitations that may be imposed under Section 38 
(general qualifications on qualified rights)). 
34. Application of Division 3. 
Subject to this Constitution, each provision of this Division applies, as far as may be— 
(a) as between individuals as well as between governmental bodies and individuals; and 
(b) to and in relation to corporations and associations (other than governmental bodies) 
in the same way as it applies to and in relation to individuals, 
except where, or to the extent that, the contrary intention appears in this Constitution. 
Subdivision B.—Fundamental Rights. 
35. Right to life. 
(1) 
No person shall be deprived of his life intentionally except— 
(a) in execution of a sentence of a court following his conviction of an offence for which 
the penalty of death is prescribed by law; or 
(b) as the result of the use of force to such an extent as is reasonable in the circumstances 
of the case and is permitted by any other law— 
(i) 
for the defence of any person from violence; or 
(ii) 
in order to effect a lawful arrest or to prevent the escape of a person lawfully 
detained; or 
(iii) for the purpose of suppressing a riot, an insurrection or a mutiny; or 
(iv) in order to prevent him from committing an offence; or 
(v) 
for the purpose of suppressing piracy or terrorism or similar acts; or 
(c) as the result of a lawful act of war. 
(2) 
Nothing in Subsection (1)(b) relieves any person from any liability at law in respect of 
the killing of another. 
36. Freedom from inhuman treatment. 
(1) 
No person shall be submitted to torture (whether physical or mental), or to treatment or 
punishment that is cruel or otherwise inhuman, or is inconsistent with respect for the inherent 
dignity of the human person. 
(2) 
The killing of a person in circumstances in which Section 35(1)(a) (right to life) does 
not, of itself, contravene Subsection (1), although the manner or the circumstances of the killing 
may contravene it. 
37. Protection of the law. 
(1) 
Every person has the right to the full protection of the law, and the succeeding 
provisions of this section are intended to ensure that that right is fully available, especially to 
persons in custody or charged with offences.
```

---

## Page 22

```text
22
(2) 
Except, subject to any Act of the Parliament to the contrary, in the case of the offence 
commonly known as contempt of court, nobody may be convicted of an offence that is not 
defined by, and the penalty for which is not prescribed by, a written law. 
(3) 
A person charged with an offence shall, unless the charge is withdrawn, be afforded a 
fair hearing within a reasonable time, by an independent and impartial court. 
(4) 
A person charged with an offence— 
(a) shall be presumed innocent until proved guilty according to law, but a law may place 
upon a person charged with an offence the burden of proving particular facts which are, 
or would be, peculiarly within his knowledge; and 
(b) shall be informed promptly in a language which he understands, and in detail, of the 
nature of the offence with which he is charged; and 
(c) shall be given adequate time and facilities for the preparation of his defence; and 
(d) shall be permitted to have without payment the assistance of an interpreter if he 
cannot understand or speak the language used at the trial of the charge; and 
(e) shall be permitted to defend himself before the court in person or, at his own 
expense, by a legal representative of his own choice, or if he is a person entitled to legal 
aid, by the Public Solicitor or another legal representative assigned to him in accordance 
with law; and 
(f) shall be afforded facilities to examine in person or by his legal representative the 
witnesses called before the court by the prosecution, and to obtain the attendance and 
carry out the examination of witnesses and to testify before the court on his own behalf, 
on the same conditions as those applying to witnesses called by the prosecution. 
 
(Paragraph (a) amended by Constitutional Amendment No.13) 
 
(5) 
Except with his own consent, the trial shall not take place in his absence unless he so 
conducts himself as to render the continuance of the proceedings in his presence impracticable 
and the court orders him to be removed and the trial to proceed in his absence, but provision may 
be made by law for a charge that a person has committed an offence the maximum penalty for 
which does not include imprisonment, (except in default of payment of a fine), to be heard 
summarily in his absence if it is established that he has been duly served with a summons in 
respect of the alleged offence. 
(6) 
Nothing in Subsection (4)(f) invalidates a law which imposes reasonable conditions that 
must be satisfied if witnesses called to testify on behalf of a person charged with an offence are 
to be paid their expenses out of public funds. 
(7) 
No person shall be convicted of an offence on account of any act that did not, at the 
time when it took place, constitute an offence, and no penalty shall be imposed for an offence 
that is more severe in degree or description than the maximum penalty that might have been 
imposed for the offence at the time when it was committed. 
(8) 
No person who shows that he has been tried by a competent court for an offence and has 
been convicted or acquitted shall again be tried for that offence or for any other offence of which 
he could have been convicted at the trial for that offence, except upon the order of a superior 
court made in the course of appeal or review proceedings relating to the conviction or acquittal.
```

---

## Page 23

```text
23
(9) 
No person shall be tried for an offence for which he has been pardoned. 
(10) 
No person shall be compelled in the trial of an offence to be a witness against himself. 
(11) 
A determination of the existence or extent of a civil right or obligation shall not be made 
except by an independent and impartial court or other authority prescribed by law or agreed upon 
by the parties, and proceedings for such a determination shall be fairly heard within a reasonable 
time. 
(12) 
Except with the agreement of the parties, or by order of the court in the interests of 
national security, proceedings in any jurisdiction of a court and proceedings for the 
determination of the existence or extent of any civil right or obligation before any other 
authority, including the announcement of the decision of the court or other authority, shall be 
held in public. 
(13) 
Nothing in Subsection (12) prevents a court or other authority from excluding from the 
hearing of the proceedings before it persons, other than the parties and their legal representatives, 
to such an extent as the court or other authority— 
(a) is by law empowered to do and considers necessary or expedient in the interests of 
public welfare or in circumstances where publicity would prejudice the interests of 
justice, the welfare of persons under voting age or the protection of the private lives of 
persons concerned in the proceedings; or 
(b) is by law empowered or required to do in the interests of defence, public safety or 
public order. 
(14) 
In the event that the trial of a person is not commenced within four months of the date 
on which he was committed for trial, a detailed report concerning the case shall be made by the 
Chief Justice to the Minister responsible for the National Legal Administration.  
(15) 
Every person convicted of an offence is entitled to have his conviction and sentence 
reviewed by a higher court or tribunal according to law. 
(16) 
No person shall be deprived by law of a right of appeal against his conviction or 
sentence by any court that existed at the time of the conviction or sentence, as the case may be. 
(17) 
All persons deprived of their liberty shall be treated with humanity and with respect for 
the inherent dignity of the human person. 
(18) 
Accused persons shall be segregated from convicted persons and shall be subject to 
separate treatment appropriate to their status as unconvicted persons. 
(19) 
Persons under voting age who are in custody in connexion with an offence or alleged 
offence shall be separated from other persons in custody and be accorded treatment appropriate 
to their age. 
(20) 
An offender shall not be transferred to an area away from that in which his relatives 
reside except for reasons of security or other good cause and, if such a transfer is made, the 
reason for so doing shall be endorsed on the file of the offender. 
(21) 
Nothing in this section— 
(a) derogates Division III.4 (principles of natural justice); or 
(b) affects the powers and procedures of village courts. 
(22) 
Notwithstanding Subsection 21(b) the powers and procedures of village courts shall be
```

---

## Page 24

```text
24
exercised in accordance with the principles of natural justice. 
 
Subdivision C.—Qualified Rights. 
General. 
38. General qualifications on qualified rights. 
(1) 
For the purposes of this Subdivision, a law that complies with the requirements of this 
section is a law that is made and certified in accordance with Subsection (2), and that— 
(a) regulates or restricts the exercise of a right or freedom referred to in this Subdivision 
to the extent that the regulation or restriction is necessary— 
(i) 
taking account of the National Goals and Directive Principles and the Basic 
Social Obligations, for the purpose of giving effect to the public interest in— 
(A) defence; or 
(B) public safety; or 
(C) public order; or 
(D) public welfare; or 
(E) 
public health (including animal and plant health); or 
(F) 
the protection of children and persons under disability (whether legal or 
practical); or 
(G) the development of under-privileged or less advanced groups or areas; or 
(ii) 
in order to protect the exercise of the rights and freedoms of others; or 
(b) makes reasonable provision for cases where the exercise of one such right may 
conflict with the exercise of another, 
to the extent that the law is reasonably justifiable in a democratic society having a proper respect 
for the rights and dignity of mankind. 
(2) 
For the purposes of Subsection (1), a law must— 
(a) be expressed to be a law that is made for that purpose; and 
(b) specify the right or freedom that it regulates or restricts; and 
(c) be made, and certified by the Speaker in his certificate under Section 110 
(certification as to making of laws) to have been made, by an absolute majority. 
(3) 
The burden of showing that a law is a law that complies with the requirements of 
Subsection (1) is on the party relying on its validity. 
 
 
39. “Reasonably justifiable in a democratic society”, etc. 
(1) 
The question, whether a law or act is reasonably justifiable in a democratic society 
having a proper regard for the rights and dignity of mankind, is to be determined in the light of 
the circumstances obtaining at the time when the decision on the question is made.
```

---

## Page 25

```text
25
(2) 
A law shall not be declared not to be reasonably justifiable in a society having a proper 
regard for the rights and dignity of mankind except by the Supreme Court or the National Court, 
or any other court prescribed for the purpose by or under an Act of the Parliament, and unless the 
court is satisfied that the law was never so justifiable such a declaration operates as a repeal of 
the law as at the date of the declaration. 
(3) 
For the purposes of determining whether or not any law, matter or thing is reasonably 
justified in a democratic society that has a proper regard for the rights and dignity of mankind, a 
court may have regard to— 
(a) the provisions of this Constitution generally, and especially the National Goals and 
Directive Principles and the Basic Social Obligations; and 
(b) the Charter of the United Nations; and 
(c) the Universal Declaration of Human Rights and any other declaration, 
recommendation or decision of the General Assembly of the United Nations concerning 
human rights and fundamental freedoms; and 
(d) the European Convention for the Protection of Human Rights and Fundamental 
Freedoms and the Protocols thereto, and any other international conventions, agreements 
or declarations concerning human rights and fundamental freedoms; and 
(e) judgements, reports and opinions of the International Court of Justice, the European 
Commission of Human Rights, the European Court of Human Rights and other 
international courts and tribunals dealing with human rights and fundamental freedoms; 
and 
(f) previous laws, practices and judicial decisions and opinions in the country; and 
(g) laws, practices and judicial decisions and opinions in other countries; and 
(h) the Final Report of the pre-Independence Constitutional Planning Committee dated 
13 August 1974 and presented to the pre-Independence House of Assembly on 16 
August 1974, as affected by decisions of that House on the report and by decisions of the 
Constituent Assembly on the draft of this Constitution; and 
(i) declarations by the International Commission of Jurists and other similar 
organizations; and 
(j) any other material that the court considers relevant. 
40. Validity of emergency laws. 
Nothing in this Part invalidates an emergency law as defined in Part X (emergency powers), but 
nevertheless so far as is consistent with their purposes and terms all such laws shall be 
interpreted and applied so as not to affect or derogate a right or freedom referred to in this 
Division to an extent that is more than is reasonably necessary to deal with the emergency 
concerned and matters arising out of it, but only so far as is reasonably justifiable in a democratic 
society having a proper regard for the rights and dignity of mankind. 
 
 
41. Proscribed acts. 
(1) 
Notwithstanding anything to the contrary in any other provision of any law, any act that
```

---

## Page 26

```text
26
is done under a valid law but in the particular case— 
(a) is harsh or oppressive; or 
(b) is not warranted by, or is disproportionate to, the requirements of the particular 
circumstances or of the particular case; or 
(c) is otherwise not, in the particular circumstances, reasonably justifiable in a 
democratic society having a proper regard for the rights and dignity of mankind, 
is an unlawful act. 
(2) 
The burden of showing that Subsection (1)(a), (b) or (c) applies in respect of an act is on 
the party alleging it, and may be discharged on the balance of probabilities. 
(3) 
Nothing in this section affects the operation of any other law under which an act may be 
held to be unlawful or invalid. 
Rights of All Persons. 
42. Liberty of the person. 
(1) 
No person shall be deprived of his personal liberty except— 
(a) in consequence of his unfitness to plead to a criminal charge; or 
(b) in the execution of the sentence or order of a court in respect of an offence of which 
he has been found guilty, or in the execution of the order of a court of record punishing 
him for contempt of itself or another court or tribunal; or 
(c) by reason of his failure to comply with the order of a court made to secure the 
fulfilment of an obligation (other than a contractual obligation) imposed upon him by 
law; or 
(d) upon reasonable suspicion of his having committed, or being about to commit, an 
offence; or 
(e) for the purpose of bringing him before a court in execution of the order of a court; or 
(f) for the purpose of preventing the introduction or spread of a disease or suspected 
disease, whether of humans, animals or plants, or for normal purposes of quarantine; or 
(g) for the purpose of preventing the unlawful entry of a person into Papua New Guinea, 
or for the purpose of effecting the expulsion, extradition or other lawful removal of a 
person from Papua New Guinea, or the taking of proceedings for any of those purposes; 
or 
(h) in the case of a person who is, or is reasonably suspected of being of unsound mind, 
or addicted to drugs or alcohol, or a vagrant, for the purposes of— 
(i) 
his care or treatment or the protection of the community, under an order of a 
court; or 
(ii) 
taking prompt legal proceedings to obtain an order of a court of a type referred 
to in Subparagraph (i); 
(i) in the case of a person who has not attained the age of 18 years, for the purpose of his 
education or welfare under the order of a court or with the consent of his guardian. 
 
(Paragraph (h) repealed and replaced and Paragraph (i) added by 
Constitutional Amendment No.11)
```

---

## Page 27

```text
27
(2) 
A person who is arrested or detained— 
(a) shall be informed promptly, in a language that he understands, of the reasons for his 
arrest or detention and of any charge against him; and 
(b) shall be permitted whenever practicable to communicate without delay and in private 
with a member of his family or a personal friend, and with a lawyer of his choice 
(including the Public Solicitor if he is entitled to legal aid); and 
(c) shall be given adequate opportunity to give instructions to a lawyer of his choice in 
the place in which he is detained, 
and shall be informed immediately on his arrest or detention of his rights under this subsection. 
(Subsection (2) amended by Constitutional Amendment No.11) 
(3) 
A person who is arrested or detained— 
(a) for the purpose of being brought before a court in the execution of an order of a 
court; or 
(b) upon reasonable suspicion of his having committed, or being about to commit, an 
offence, 
shall, unless he is released, be brought without delay before a court or a judicial officer and, in a 
case referred to in paragraph (b), shall not be further held in custody in connexion with the 
offence except by order of a court or judicial officer. 
(4) 
The necessity or desirability of interrogating the person concerned or other persons, or 
any administrative requirement or convenience, is not a good ground for failing to comply with 
Subsection (3), but exigencies of travel which in the circumstances are reasonable may, without 
derogating any other protection available to the person concerned, be such a ground. 
(5) 
Where complaint is made to the National Court or a Judge that a person is unlawfully or 
unreasonably detained— 
(a) the National Court or a Judge shall inquire into the complaint and order the person 
concerned to be brought before it or him; and 
(b) unless the Court or Judge is satisfied that the detention is lawful, and in the case of a 
person being detained on remand pending his trial does not constitute an 
unreasonable detention having regard, in particular, to its length, the Court or a 
Judge shall order his release either unconditionally or subject to such conditions as 
the Court or Judge thinks fit. 
 
(See: Bail Act (Chapter 340)) 
 
(6) 
A person arrested or detained for an offence (other than treason or wilful murder as 
defined by an Act of the Parliament) is entitled to bail at all times from arrest or detention to 
acquittal or conviction unless the interests of justice otherwise require. 
(7) 
Where a person to whom Subsection (6) applies is refused bail— 
(a) the court or person refusing bail shall, on request by the person concerned or his 
representative, state in writing the reason for the refusal; and 
(b) the person or his representative may apply to the Supreme Court or the National 
Court in a summary manner for his release.
```

---

## Page 28

```text
28
(8) 
Subject to any other law, nothing in this section applies in respect of any reasonable act 
of the parent or guardian of a child, or a person into whose care a child has been committed, in 
the course of the education, discipline or upbringing of the child. 
(9) 
Subject to any Constitutional Law or Act of the Parliament, nothing in this section 
applies in respect of a person who is in custody under the law of another country— 
(a) while in transit through the country; or 
(b) as permitted by or under an Act of the Parliament made for the purposes of Section 
206 (visiting forces). 
43. Freedom from forced labour. 
(1) 
No person shall be required to perform forced labour. 
(2) 
In Subsection (1), “forced labour” does not include— 
(a) labour required by the sentence or order of a court; or 
(b) labour required of a person while in lawful custody, being labour that, although not 
required by the sentence or order of a court, is necessary for the hygiene of, or for the 
maintenance of, the place in which he is in custody; or 
(c) in the case of a person in custody for the purpose of his care, treatment, rehabilitation 
or welfare, labour reasonably required for that purpose; or 
(d) labour required of a member of a disciplined force in pursuance of his duties as such 
a member; or 
(e) subject to the approval of any local government body for the area in which he is 
required to work, labour reasonably required as part of reasonable and normal communal 
or other civic duties; or 
(f) labour of a reasonable amount and kind (including in the case of compulsory military 
service, labour required as an alternative to such service in the case of a person who has 
conscientious objections to military service) that is required in the national interest by an 
Organic Law that complies with Section 38 (general qualifications on qualified rights). 
44. Freedom from arbitrary search and entry. 
No person shall be subjected to the search of his person or property or to entry of his premises, 
except to the extent that the exercise of that right is regulated or restricted by a law— 
(a) that makes reasonable provision for a search or entry— 
(i) 
under an order made by a court; or 
(ii) 
under a warrant for a search issued by a court or judicial officer on reasonable 
grounds, supported by oath or affirmation, particularly describing the purpose of the 
search; or 
(iii) that authorizes a public officer or government agent of Papua New Guinea or 
an officer of a body corporate established by law for a public purpose to enter, where 
necessary, on the premises of a person in order to inspect those premises or anything 
in or on them in relation to any rate or tax or in order to carry out work connected 
with any property that is lawfully in or on those premises and belongs to the 
Government or any such body corporate; or 
(iv) that authorizes the inspection of goods, premises, vehicles, ships or aircraft to
```

---

## Page 29

```text
29
ensure compliance with lawful requirements as to the entry of persons or importation 
of goods into Papua New Guinea or departure of persons or exportation of goods 
from Papua New Guinea or as to standards of safe construction, public safety, public 
health, permitted use or similar matters, or to secure compliance with the terms of a 
licence to engage in manufacture or trade; or 
(v) 
for the purpose of inspecting or taking copies of documents relating to— 
(A) the conduct of a business, trade, profession or industry in accordance 
with a law regulating the conduct of that business, trade, profession or industry; 
or 
(B) the affairs of a company in accordance with a law relating to companies; 
or 
(vi) for the purpose of inspecting goods or inspecting or taking copies of 
documents, in connexion with the collection, or the enforcement of payment of taxes 
or under a law prohibiting or restricting the importation of goods into Papua New 
Guinea or the exportation of goods from Papua New Guinea; or 
(b) that complies with Section 38 (general qualifications on qualified rights). 
 
(See: Search Act (Chapter 341)) 
45. Freedom of conscience, thought and religion. 
(1) 
Every person has the right to freedom of conscience, thought and religion and the 
practice of his religion and beliefs, including freedom to manifest and propagate his religion and 
beliefs in such a way as not to interfere with the freedom of others, except to the extent that the 
exercise of that right is regulated or restricted by a law that complies with Section 38 (general 
qualifications on qualified rights). 
(2) 
No person shall be compelled to receive religious instruction or to take part in a 
religious ceremony or observance, but this does not apply to the giving of religious instruction to 
a child with the consent of his parent or guardian or to the inclusion in a course of study of 
secular instruction concerning any religion or belief. 
(3) 
No person is entitled to intervene unsolicited into the religious affairs of a person of a 
different belief, or to attempt to force his or any religion (or irreligion) on another, by harassment 
or otherwise. 
(4) 
No person may be compelled to take an oath that is contrary to his religion or belief, or 
to take an oath in a manner or form that is contrary to his religion or belief. 
(5) 
A reference in this section to religion includes a reference to the traditional religious 
beliefs and customs of the peoples of Papua New Guinea. 
 
 
46. Freedom of expression. 
(1) 
Every person has the right to freedom of expression and publication, except to the
```

---

## Page 30

```text
30
extent that the exercise of that right is regulated or restricted by a law— 
(a) that imposes reasonable restrictions on public office-holders; or 
(b) that imposes restrictions on non-citizens; or 
(c) that complies with Section 38 (general qualifications on qualified rights). 
(2) 
In Subsection (1), “freedom of expression and publication” includes— 
(a) freedom to hold opinions, to receive ideas and information and to communicate ideas 
and information, whether to the public generally or to a person or class of persons; and 
(b) freedom of the press and other mass communications media 
(3) 
Notwithstanding anything in this section, an Act of the Parliament may make reasonable 
provision for securing reasonable access to mass communications media for interested persons 
and associations— 
(a) for the communication of ideas and information; and 
(b) to allow rebuttal of false or misleading statements concerning their acts, ideas or 
beliefs, 
and generally for enabling and encouraging freedom of expression. 
47. Freedom of assembly and association. 
Every person has the right peacefully to assemble and associate and to form or belong to, or not 
to belong to, political parties, industrial organizations or other associations, except to the extent 
that the exercise of that right is regulated or restricted by a law— 
(a) that makes reasonable provision in respect of the registration of all or any 
associations; or 
(b) that imposes reasonable restrictions on public office-holders; or 
(c) that imposes restrictions on non-citizens; or 
(d) that complies with Section 38 (general qualifications on qualified rights). 
48. Freedom of employment. 
(1) 
Every person has the right to freedom of choice of employment in any calling for which 
he has the qualifications (if any) lawfully required, except to the extent that that freedom is 
regulated or restricted voluntarily or by a law that complies with Section 38 (general 
qualifications on qualified rights), or a law that imposes restrictions on non-citizens. 
(2) 
Subsection (1) does not prohibit reasonable action or provision for the encouragement 
of persons to join industrial organizations or for requiring membership of an industrial 
organization for any purpose. 
49. Right to privacy. 
Every person has the right to reasonable privacy in respect of his private and family life, his 
communications with other persons and his personal papers and effects, except to the extent that 
the exercise of that right is regulated or restricted by a law that complies with Section 38 
(general qualifications on qualified rights). 
Special Rights of Citizens. 
50. Right to vote and stand for public office.
```

---

## Page 31

```text
31
(1) 
Subject to the express limitations imposed by this Constitution, every citizen who is of 
full capacity and has reached voting age, other than a person who— 
(a) is under sentence of death or imprisonment for a period of more than nine months; or 
(b) has been convicted, within the period of three years next preceding the first day of 
the polling period for the election concerned, of an offence relating to elections that is 
prescribed by an Organic Law or an Act of the Parliament for the purposes of this 
paragraph, 
has the right, and shall be given a reasonable opportunity— 
(c) to take part in the conduct of public affairs, either directly or through freely chosen 
representatives; and 
(d) to vote for, and to be elected to, elective public office at genuine, periodic, free 
elections; and 
(e) to hold public office and to exercise public functions. 
(2) 
The exercise of those rights may be regulated by a law that is reasonably justifiable for 
the purpose in a democratic society that has a proper regard for the rights and dignity of 
mankind. 
 
(See: Organic Law on National and Local Government Elections) 
 
51. Right to freedom of information. 
(1) 
Every citizen has the right of reasonable access to official documents, subject only to 
the need for such secrecy as is reasonably justifiable in a democratic society in respect of— 
(a) matters relating to national security, defence or international relations of Papua New 
Guinea (including Papua New Guinea‘s relations with the Government of any other 
country or with any international organization); or 
(b) records of meetings and decisions of the National Executive Council and of such 
executive bodies and elected governmental authorities as are prescribed by Organic Law 
or Act of the Parliament; or 
(c) trade secrets, and privileged or confidential commercial or financial information 
obtained from a person or body; or 
(d) parliamentary papers the subject of parliamentary privilege; or 
(e) reports, official registers and memoranda prepared by governmental authorities or 
authorities established by government, prior to completion; or 
(f) papers relating to lawful official activities for investigation and prosecution of crime; 
or 
(g) the prevention, investigation and prosecution of crime; or 
(h) the maintenance of personal privacy and security of the person; or 
(i) matters contained in or related to reports prepared by, on behalf of or for the use of a 
governmental authority responsible for the regulation or supervision of financial 
institutions; or 
(j) geological or geophysical information and data concerning wells and ore bodies. 
(2) 
A law that complies with Section 38 (general qualifications on qualified rights) may
```

---

## Page 32

```text
32
regulate or restrict the right guaranteed by this section. 
(3) 
Provision shall be made by law to establish procedures by which citizens may obtain 
ready access to official information. 
(4) 
This section does not authorize— 
(a) withholding information or limiting the availability of records to the public except in 
accordance with its provisions; or 
(b) withholding information from the Parliament. 
52. Right to freedom of movement. 
(1) 
Subject to Subsection (3), no citizen may be deprived of the right to move freely 
throughout the country, to reside in any part of the country and to enter and leave the country, 
except in consequence of a law that provides for deprivation of personal liberty in accordance 
with Section 42 (liberty of the person). 
(2) 
No citizen shall be expelled or deported from the country except by virtue of an order of 
a court made under a law in respect of the extradition of offenders, or alleged offenders, against 
the law of some other place. 
(3) 
A law that complies with Section 38 (general qualifications on qualified rights) may 
regulate or restrict the exercise of the right referred to in Subsection (1), and in particular may 
regulate or restrict the freedom of movement of persons convicted of offences and of members of 
a disciplined force. 
53. Protection from unjust deprivation of property. 
(1) 
Subject to Section 54 (special provision in relation to certain lands) and except as 
permitted by this section, possession may not be compulsorily taken of any property, and no 
interest in or right over property may be compulsorily acquired, except in accordance with an 
Organic Law or an Act of the Parliament, and unless— 
(a) the property is required for— 
(i) 
a public purpose; or 
(ii) a reason that is reasonably justified in a democratic society that has a proper  
regard for the rights and dignity of mankind, that is so declared and so described, for 
the purposes of this section, in an Organic Law or an Act of the Parliament; and 
(b) the necessity for the taking of possession or acquisition for the attainment of that 
purpose or for that reason is such as to afford reasonable justification for the causing of 
any resultant hardship to any person affected. 
(2) 
Subject to this section, just compensation must be made on just terms by the 
expropriating authority, giving full weight to the National Goals and Directive Principles and 
having due regard to the national interest and to the expression of that interest by the Parliament, 
as well as to the person affected. 
(3) 
For the purposes of Subsection (2), compensation shall not be deemed not to be just and 
on just terms solely by reason of a fair provision for deferred payment, payment by instalments 
or compensation otherwise than in cash. 
(4) 
In this section, a reference to the taking of possession of property, or the acquisition of
```

---

## Page 33

```text
33
an interest in or right over property, includes a reference to— 
(a) the forfeiture; or 
(b) the extinction or determination (otherwise than by way of a reasonable provision for 
the limitation of actions or a reasonable law in the nature of prescription or adverse 
possession), 
of any right or interest in property. 
(5) 
Nothing in the preceding provisions of this section prevents— 
(a) the taking of possession of property, or the acquisition of an interest in or right over 
property, that is authorized by any other provision of this Constitution; or 
(b) any taking of possession or acquisition— 
(i) 
in consequence of an offence or attempted offence against, or a breach or 
attempted breach of, or other failure to comply with a law; or 
(ii) 
in satisfaction of a debt or civil obligation; or 
(iii) subject to Subsection (6), where the property is or may be required as evidence 
in proceedings or possible proceedings before a court or tribunal, 
in accordance with a law that is reasonably justifiable in a democratic society that has a 
proper regard for the rights and dignity of mankind; or 
(c) any taking of possession or acquisition that was an incident of the grant or 
acceptance of, or of any interest in or right over, that property or any other property by 
the holder or any of his predecessors in title; or 
(d) any taking of possession or acquisition that is in accordance with custom; or 
(e) any taking of possession or acquisition of ownerless or abandoned property (other 
than customary land); or 
(f) any restriction on the use of or on dealing with property or any interest in or right 
over any property that is reasonably necessary for the preservation of the environment or 
of the national cultural inheritance. 
(6) 
Subsection (5)(b)(iii) does not authorize the retention of any property after the end of 
the period for which its retention is reasonably required for the purpose referred to in that 
paragraph. 
(7) 
Nothing in the preceding provisions of this section applies to or in relation to the 
property of any person who is not a citizen and the power to compulsorily take possession of, or 
to acquire an interest in, or right over, the property of any such person shall be as provided for by 
an Act of the Parliament. 
(See: Lands Acquisition (Development Purposes) Act (Chapter 192)) 
 
 
54. Special provision in relation to certain lands. 
Nothing in Section 37 (protection of the law) or 53 (protection from unjust deprivation of 
property) invalidates a law that is reasonably justifiable in a democratic society that has a proper 
regard for human rights and that provides—
```

---

## Page 34

```text
34
(a) for the recognition of the claimed title of Papua New Guinea to land where— 
(i) 
there is a genuine dispute as to whether the land was acquired validly or at all 
from the customary owners before Independence Day; and 
(ii) 
if the land were acquired compulsorily the acquisition would comply with 
Section 53(1) (protection from unjust deprivation of property); or 
(b) for the settlement by extra-judicial means of disputes as to the ownership of 
customary land that appear not to be capable of being reasonably settled in practice by 
judicial means; or 
(c) for the prohibition or regulation of the holding of certain interests in, or in relation to, 
some or all land by non-citizens. 
55. Equality of citizens. 
(1) 
Subject to this Constitution, all citizens have the same rights, privileges, obligations and 
duties irrespective of race, tribe, place of origin, political opinion, colour, creed, religion or sex. 
(2) 
Subsection (1) does not prevent the making of laws for the special benefit, welfare, 
protection or advancement of females, children and young persons, members of underprivileged 
or less advanced groups or residents of less advanced areas. 
(3) 
Subsection (1) does not affect the operation of a pre-Independence law. 
56. Other rights and privileges of citizens. 
(1) 
Only citizens may— 
(a) vote in elections for, or hold, elective public offices; or 
(b) acquire freehold land. 
 
(See: Land (Ownership of Freeholds) Act (Chapter 359)) 
 
(2) 
An Act of the Parliament may— 
(a) define the offices that are to be regarded as elective public offices; and 
(b) define the forms of ownership that are to be regarded as freehold; and 
(c) define the corporations that are to be regarded as citizens, 
for the purposes of Subsection (1). 
(3) 
An Act of the Parliament may make further provision for rights and privileges to be 
reserved for citizens. 
 
 
 
Subdivision D.—Enforcement. 
57. Enforcement of guaranteed rights and freedoms. 
(1) 
A right or freedom referred to in this Division shall be protected by, and is enforceable
```

---

## Page 35

```text
35
in, the Supreme Court or the National Court or any other court prescribed for the purpose by an 
Act of the Parliament, either on its own initiative or on application by any person who has an 
interest in its protection and enforcement, or in the case of a person who is, in the opinion of the 
court, unable fully and freely to exercise his rights under this section by a person acting on his 
behalf, whether or not by his authority. 
(2) 
For the purposes of this section— 
(a) the Law Officers of Papua New Guinea; and 
(b) any other persons prescribed for the purpose by an Act of the Parliament; and 
(c) any other persons with an interest (whether personal or not) in the maintenance of the 
principles commonly known as the Rule of Law such that, in the opinion of the court 
concerned, they ought to be allowed to appear and be heard on the matter in question, 
have an interest in the protection and enforcement of the rights and freedoms referred to in this 
Division, but this subsection does not limit the persons or classes of persons who have such an 
interest. 
(3) 
A court that has jurisdiction under Subsection (1) may make all such orders and 
declarations as are necessary or appropriate for the purposes of this section, and may make an 
order or declaration in relation to a statute at any time after it is made (whether or not it is in 
force). 
(4) 
Any court, tribunal or authority may, on its own initiative or at the request of a person 
referred to in Subsection (1), adjourn, or otherwise delay a decision in, any proceedings before it 
in order to allow a question concerning the effect or application of this Division to be determined 
in accordance with Subsection (1). 
(5) 
Relief under this section is not limited to cases of actual or imminent infringement of 
the guaranteed rights and freedoms, but may, if the court thinks it proper to do so, be given in 
cases in which there is a reasonable probability of infringement, or in which an action that a 
person reasonably desires to take is inhibited by the likelihood of, or a reasonable fear of, an 
infringement. 
(6) 
The jurisdiction and powers of the courts under this section are in addition to, and not in 
derogation of, their jurisdiction and powers under any other provision of this Constitution. 
58. Compensation. 
(1) 
This section is in addition to, and not in derogation of, Section 57 (enforcement of 
guaranteed rights and freedoms). 
(2) 
A person whose rights or freedoms declared or protected by this Division are infringed 
(including any infringement caused by a derogation of the restrictions specified in Part X.5 
(internment)) on the use of emergency powers in relation to internment is entitled to reasonable 
damages and, if the court thinks it proper, exemplary damages in respect of the infringement. 
(3) 
Subject to Subsections (4) and (5), damages may be a awarded against any person who 
committed, or was responsible for, the infringement. 
(4) 
Where the infringement was committed by a governmental body, damages may be 
awarded either— 
(a) subject to Subsection (5), against a person referred to in Subsection (3); or
```

---

## Page 36

```text
36
(b) against the governmental body to which any such person was responsible, 
or against both, in which last case the court may apportion the damages between them. 
(5) 
Damages shall not be awarded against a person who was responsible to a governmental 
body in respect of the action giving rise to the infringement if— 
(a) the action was an action made unlawful only by Section 41(1) (proscribed acts); and 
(b) the action taken was genuinely believed by that person to be required by law, 
but the burden of proof of the belief referred to in paragraph (b) is on the party alleging it. 
Division 4.—Principles of Natural Justice. 
59. Principles of natural justice. 
(1) 
Subject to this Constitution and to any statute, the principles of natural justice are the 
rules of the underlying law known by that name developed for control of judicial and 
administrative proceedings. 
(2) 
The minimum requirement of natural justice is the duty to act fairly and, in principle, to 
be seen to act fairly. 
60. Development of principles. 
In the development of the rules of the underlying law in accordance with Schedule (adoption, 
etc., of certain laws) particular attention shall be given to the development of a system of 
principles of natural justice and of administrative law specifically designed for Papua New 
Guinea, taking special account of the National Goals and Directive Principles and of the Basic 
Social Obligations, and also of typically Papua New Guinean procedures and forms of 
organization. 
61. Basic rights and freedoms. 
For the avoidance of doubt, it is hereby declared that nothing in the preceding provisions of this 
Division derogates any of the rights and freedoms provided for by Division 3 (basic rights). 
62. Decisions in “deliberate judgement”. 
(1) 
Where a law provides or allows for an act to be done in the “deliberate judgement” of a 
person, body or authority, the principles of natural justice apply only to the extent that the 
exercise of judgement must not be biassed, arbitrary or capricious. 
(2) 
Except— 
(a) to the extent provided for by Subsection (1); and 
(b) in accordance with Section 155(5) (the National Judicial System); and 
(c) as provided by a Constitutional Law or an Act of the Parliament, 
an act to which Subsection (1) applies is, to the extent to which it is done in the deliberate 
judgement of the person concerned, non-justiciable. 
 
Division 5.—Basic Social Obligations.
```

---

## Page 37

```text
37
63. Enforcement of the Basic Social Obligations. 
(1) 
Except to the extent provided in Subsections (3) and (4), the Basic Social Obligations 
are non-justiciable. 
(2) 
Nevertheless, it is the duty of all governmental bodies to encourage compliance with 
them as far as lies within their respective powers. 
(3) 
Where any law, or any power conferred or duty imposed by any law (whether the power 
or duty be of a legislative, judicial, executive, administrative or other kind), can reasonably be 
understood, applied, exercised, complied with or enforced, without failing to give effect to the 
intention of the Parliament or to this Constitution, in such a way as to enforce or encourage 
compliance with the Basic Social Obligations, or at least not to derogate them, it is to be 
understood, applied, exercised, complied with or enforced in that way. 
(4) 
Subsection (1) does not apply in the exercise of the jurisdiction of the Ombudsman 
Commission or other body prescribed for the purposes of Division III.2 (leadership code), which 
shall take the Basic Social Obligations fully into account in all cases as appropriate. 
 
PART IV.—CITIZENSHIP. 
Division 1.—Introductory. 
64. Dual citizenship. 
(1) 
Notwithstanding the succeeding provisions of this Part but subject to Subsection (2), no 
person who has a real foreign citizenship may be or become a citizen, and the provisions of this 
Part shall be read subject to that prohibition. 
(2) 
Subsection (1) does not apply to a person who has not yet reached the age of 19 years, 
provided that, before he reaches that age and in such manner as is prescribed by or under an Act 
of the Parliament, he renounces his other citizenship and makes the Declaration of Loyalty. 
(3) 
A person who has a real foreign citizenship and fails to comply with Subsection (2) 
ceases to be a citizen of Papua New Guinea when he reaches the age of 19 years. 
(4) 
For the purposes of this section, a person who— 
(a) was, immediately before Independence Day, an Australian citizen or an Australian 
Protected Person by virtue of— 
(i) 
birth in the former Territory of Papua; or 
(ii) 
birth in the former Territory of New Guinea and registration under Section 11 
of the Australian Citizenship Act 1948-1975 of Australia; and 
(b) was never granted a right (whether revocable or not) to permanent residence in 
Australia, 
has no real foreign citizenship. 
(See: Citizenship Act (Chapter 12)) 
Division 2.—Acquisition of Citizenship. 
65. Automatic citizenship on Independence Day.
```

---

## Page 38

```text
38
(1) 
A person born in the country before Independence Day who has two grand-parents who 
were born in the country or an adjacent area is a citizen. 
(2) 
A person born outside the country before Independence Day who has two grand-parents 
born in the country is a citizen as from Independence Day if— 
(a) within one year after Independence Day or such longer period as the Minister 
responsible for citizenship matters allows in a particular case, application is made by 
him or on his behalf for registration as a citizen; and 
(b) he renounces any other citizenship and makes the Declaration of Loyalty— 
(i) 
if he has not reached the age of 19 years—in accordance with Section 64(2) 
(dual citizenship); or 
(ii) 
if he has reached the age of 19 years—at or before the time when the 
application is made. 
(3) 
In Subsection (1), “adjacent area” means an area that immediately before Independence 
Day constituted— 
(a) the Solomon Islands; or 
(b) the Province of the Republic of Indonesia known as Irian Jaya; or 
(c) the islands in Torres Straits annexed to the then Colony of Queensland under Letters 
Patent of the United Kingdom of Great Britain and Ireland bearing date the 10th day of 
October in the forty-second year of the reign of Her Majesty Queen Victoria (that is, 
1878), 
not forming on Independence Day part of the area of Papua New Guinea. 
(4) 
Subsections (1) and (2) do not apply to a person who— 
(a) has a right (whether revocable or not) to permanent residence in Australia; or 
(b) is a naturalized Australian citizen; or 
(c) is registered as an Australian citizen under Section 11 of the Australian Citizenship 
Act 1948-1975 of Australia; or 
(d) is a citizen of a country other than Australia, 
unless that person renounces his right to residence in Australia or his status as a citizen of 
Australia or of another country in accordance with Subsection (5). 
(5) 
A person to whom Subsection (4) applies may, within the period of two months after 
Independence Day and in such manner as may be prescribed by or under an Act of the 
Parliament, renounce his right to permanent residence in Australia or his status as an Australian 
citizen or as a citizen of another country and make the Declaration of Loyalty. 
(See: Citizenship Act (Chapter 12)) 
(6) 
Where in his opinion it is just to do so, the Minister responsible for citizenship matters 
may in his deliberate judgement (but subject to Division 4 (Citizenship Advisory Committee)), 
extend the period of two months referred to in Subsection (4), but unless the Minister is satisfied 
that the applicant— 
(a) assumed in error that he was a citizen; or 
(b) did not know that he was not a citizen; or 
(c) had no reasonable opportunity or not enough time to determine his status,
```

---

## Page 39

```text
39
the period may not be extended beyond a further two months. 
66. Citizenship by descent. 
(1) 
A person who— 
(a) is born in the country on or after Independence Day; and 
(b) had one parent who was a citizen or who, if he had survived to Independence Day, 
would have been or would have been entitled to become, such a citizen, 
is a citizen. 
(2) 
A person— 
(a) who is born outside the country on or after Independence Day; and 
(b) who had one parent who was a citizen or who, if he had survived to Independence 
Day, would have been, or would have been entitled to become, such a citizen; and 
(c) whose birth is registered as prescribed by or under an Act of the Parliament made for 
the purposes of this subsection, is a citizen. 
 
(See: Citizenship Act (Chapter 12)) 
 
67. Citizenship by naturalization. 
(1) 
A person who has resided continuously in the country for at least eight years may apply 
to the Minister responsible for citizenship matters to be naturalized as a citizen, and the Minister 
may, if he is satisfied as to the matters referred to in Subsection (2), in his deliberate judgement 
(but subject to Division 4 (Citizenship Advisory Committee)), grant or refuse the application. 
(2) 
To be eligible for naturalization, a person must— 
(a) be of good character; and 
(b) intend to reside permanently in the country; and 
(c) unless prevented by physical or mental disability, speak and understand Pisin or Hiri 
Motu, or a vernacular of the country, sufficiently for normal conversational purposes; 
and 
(d) have a respect for the customs and cultures of the country; and 
(e) be unlikely to be or become a charge on public funds; and 
(f) have a reasonable knowledge and understanding of the rights, privileges, 
responsibilities and duties of citizenship; and 
(g) renounce, in such manner as is prescribed by or under an Act of the Parliament, any 
other citizenship and make the Declaration of Loyalty. 
 
(See: Citizenship Act (Chapter 12)) 
 
(3) 
If an applicant for naturalization so requests, any child of the applicant who is under 
voting age at the time when the applicant is naturalized becomes a citizen by naturalization on 
the naturalization of the applicant. 
68. Special provisions relating to naturalization.
```

---

## Page 40

```text
40
(1) 
A person who is eligible to become a citizen under Section 67(1) (citizenship by 
naturalization) and holds an executive office by virtue of being a member of an elective body 
shall cease to hold that office at the expiration of a period of two months after Independence Day 
unless within that time he makes application under that section to be naturalized and that 
application is granted. 
(2) 
Without limiting the matters that may be taken into account in deciding on the 
application for naturalization, under Section 67 (citizenship by naturalization) the following 
matters shall be taken into account in deciding on an application that is made during the first 
eight years after Independence Day:— 
(a) if the applicant is a person to whom Section 65(4) (automatic citizenship on 
Independence Day) applies, whether he acquired the right of permanent residence in 
Australia or became an Australian citizen otherwise than by reason of a voluntary act 
(other than marriage) on his part; and 
(b) whether the applicant has at any time accepted pay and conditions of employment 
that were not in general applicable— 
(i) 
before Independence Day, to persons who qualify or would, if they had 
survived to that day, have qualified for citizenship under Section 65 (automatic 
citizenship on Independence Day); or 
(ii) 
after Independence Day, to citizens; and 
(c) whether the major part of the investment and business interests of the applicant are 
and have been in the country; and 
(d) whether the applicant is or has been married to a citizen or to a person who, if he had 
survived to Independence Day, would have been, or would have been entitled to 
become, a citizen, and the nature of the family ties of the applicant; and 
(e) the length and nature of the residence of the applicant in the country; and 
(f) any performance by the applicant of services beneficial to Papua New Guinea or its 
people; and 
(g) any sacrifices made by the applicant in the interests of Papua New Guinea or its 
people; and 
(h) the applicant’s knowledge of Pisin or Hiri Motu or of a vernacular of the country; 
and 
(i) whether or not the application of the applicant includes the children (if any) under 
voting age of the applicant; and 
(j) any references given as to the good character and suitability for citizenship of the 
applicant; and 
(k) the place of birth and the parentage of the applicant. 
(3) 
Notwithstanding anything in a Constitutional Law, a benefit, right or privilege, directly 
or indirectly, conferred upon “Papua New Guineans” or “natives” or “local persons” or “non-
overseas persons” or “citizens” (where that term is to take effect after the making of a law 
relating to citizenship) by any pre-Independence law shall continue to be enjoyed only by 
persons who became citizens of Papua New Guinea under Section 65 (automatic citizenship on 
Independence Day) but only— 
(a) for a period of ten years after Independence Day; or 
(b) until an Act of the Parliament takes away that benefit, right or privilege,
```

---

## Page 41

```text
41
whichever first occurs. 
(4) 
Notwithstanding anything in a Constitutional Law, during the five years after 
Independence Day only persons who become citizens of Papua New Guinea under Section 65 
(automatic citizenship on Independence Day) shall have the rights conferred by Section 53 
(protection from unjust deprivation of property) except that during this period the rights of a 
person who becomes a citizen otherwise than under Section 65 (automatic citizenship on 
Independence Day) in respect of his property shall not be less than those accorded by law to non-
citizens. 
(5) 
Notwithstanding anything in a Constitutional Law, but subject to Subsection (6), an Act 
of the Parliament made in the period of ten years after Independence Day may confer a benefit, 
right or privilege on persons who became citizens of Papua New Guinea under Section 65 
(automatic citizenship on Independence Day). 
(6) 
An Act of the Parliament referred to in Subsection (5)— 
(a) shall not derogate the rights conferred by Sections 32 to 58 (basic rights) except the 
rights conferred by Section 55 (equality of citizens); and 
(b) shall be for the purpose of giving advantage or assistance to persons who become 
citizens of Papua New Guinea under Section 65 (automatic citizenship on Independence 
Day). 
69. Application for naturalization. 
(1) 
Subject to Subsection (2), an application for naturalization under Section 67 (citizenship 
by naturalization) must be made— 
(a) in the case of a person who has resided continuously in the country for eight years or 
more before Independence Day—within two months after Independence Day; and 
(b) in the case of any other person—within two months after the completion by him of 
eight years continuous residence in the country. 
(2) 
Where in his opinion it is just to do so, the Minister responsible for citizenship matters 
may in his deliberate judgement, (but subject to Division 4 (Citizenship Advisory Committee)) 
extend the periods referred to in Subsection (1) where he is satisfied that— 
(a) the person was unaware of the provisions of Subsection (1); or 
(b) there are special circumstances. 
Division 3.—Loss and Regaining of Citizenship. 
70. Automatic loss of citizenship. 
(1) 
A citizen who has reached voting age and is of full capacity who— 
(a) obtains the nationality or citizenship of another country by a voluntary act (other than 
marriage); or 
(b) exercises a right that is exclusive to nationals or citizens of another country, unless 
the Minister responsible for citizenship matters is satisfied that the right was exercised 
inadvertently; or 
(c) takes an oath or makes a declaration or affirmation of allegiance to another country 
or to the Sovereign or Head of State of another country; or 
(d) does, agrees to or adopts any act (other than marriage) by which he becomes a
```

---

## Page 42

```text
42
national or citizen of another country; or 
(e) enters or serves in the armed forces of another country, except with the express 
approval of the Head of State, acting with, and in accordance with, the advice of the 
National Executive Council; or 
(f) except as permitted by an Act of the Parliament, votes in a national, provincial, state 
or local election, or accepts elective office, of another country; or 
(g) subject to Subsection (3), travels under the protection of a passport or purported 
passport of another country in which he is described as a citizen or national of that 
country, 
loses his citizenship. 
(2) 
A person who is found by a court to have obtained citizenship by a false representation, 
fraud or concealment of a material fact on his part loses his citizenship, unless the Minister 
responsible for citizenship matters is satisfied that the offence was of a minor nature and that 
revelation of the true fact would not have affected the grant of naturalization. 
(3) 
Subsection (1)(g) does not apply to— 
(a) a person who is absent from the country on Independence Day, who continues to 
travel under the protection of a passport of another country, but only until— 
(i) 
the expiration of the then-current period of validity of the passport; or 
(ii) 
his return to the country, 
whichever first happens; or 
(b) a person travelling under the protection of the passport of a parent or guardian; or 
(c) a person travelling under the protection of a passport of another country with the 
approval of the Minister responsible for citizenship matters. 
71. Acts done under compulsion of law. 
The preceding provisions of this Division do not apply to any act done under compulsion of law 
of another country. 
72. Renunciation of citizenship. 
(1) 
Subject to Subsections (2) and (3), a citizen who has reached voting age and is of full 
capacity may renounce his citizenship in such manner and on such conditions as are prescribed 
by or under an Act of the Parliament. 
(See: Citizenship Act (Chapter 12)) 
(2) 
A person may not renounce his citizenship unless— 
(a) he already holds some other nationality or citizenship; or 
(b) the renunciation is for the purpose of his obtaining some other nationality or 
citizenship. 
(3) 
During a time of war, citizenship may not be renounced without the prior consent of the 
Minister responsible for citizenship matters. 
73. Regaining citizenship. 
(1) 
Subject to Subsection (2), citizenship once lost can be regained—
```

---

## Page 43

```text
43
(a) in the case of citizenship by virtue of Section 65 (automatic citizenship on 
Independence Day) or 66 (citizenship by descent)—only after five years continuous 
residence in the country after the loss of citizenship, and in the deliberate judgement (but 
subject to Division 4 (Citizenship Advisory Committee)) of the Minister responsible for 
citizenship matters; and 
(b) in the case of citizenship by naturalization—only in accordance with the law relating 
to naturalization, for which purpose any period of residence in the country before the 
loss of citizenship shall be disregarded. 
(2) 
Where a person— 
(a) was a citizen by virtue of Section 65 (automatic citizenship on Independence Day) or 
66 (citizenship by descent); and 
(b) married, before, on or after Independence Day, a person who was a national or 
citizen of another country; and 
(c) became, on or during the marriage, a national or citizen of the country of which his 
spouse was at that time a national or citizen, 
and the marriage has permanently broken up, the reference in Subsection (1)(a) to a period of 
five years shall be read as a reference to a period of three years commencing— 
(d) if the person was, at the time when the marriage broke up, resident in the country—
on the date on which it broke up; or 
(e) if the person was at that time resident outside the country—on his return to reside in 
the country. 
74. Loss and regaining of citizenship by certain children. 
(1) 
Where— 
(a) a parent of a child loses his citizenship; and 
(b) the Minister is satisfied on application on behalf of the child that it is for the welfare 
of the child to do so, 
the Minister responsible for citizenship matters may, by order, deprive the child of his 
citizenship. 
(2) 
A person aggrieved by an order under Subsection (1) may appeal to the National Court. 
(3) 
An Act of the Parliament may make special provision to facilitate the regaining of 
citizenship by persons who lose their citizenship by reason of the loss of citizenship by a parent. 
 
 
Division 4.—Citizenship Advisory Committee. 
75. The Committee. 
(1) 
An Act of the Parliament shall make provision for a Citizenship Advisory Committee, 
all of the members of which must be citizens (other than naturalized citizens). 
(2) 
The Committee shall consist of— 
(a) four permanent members, at least two of whom are members of the Parliament other
```

---

## Page 44

```text
44
than Ministers; and 
(b) one ad hoc member to represent the community in which the person to whom a 
matter before the Committee relates resides. 
76. Functions of the Committee. 
(1) 
Before taking any action under this Part in relation to a person, the Minister responsible 
for citizenship matters shall refer the matter to the Citizenship Advisory Committee and receive 
its advice. 
(Subsection (1) amended by Constitutional Amendment No.5) 
(2) 
If the Minister refuses to accept the advice of the Committee on any matter referred to it 
under Subsection (1), he shall, if so requested by a person affected or by the Committee, give to 
the Parliament, as soon as practicable, a statement on the matter setting out the reasons for his 
refusal, and the Parliament may reverse his decision on such conditions as it thinks proper. 
(3) 
The reversal by the Parliament of a decision to grant or to allow the regaining of 
citizenship, or to grant a certificate under Section 81 (certificate as to citizenship), takes effect, 
subject to any conditions to which it is made subject, as a deprivation of citizenship on the date 
of the reversal. 
(4) 
The reversal by the Parliament of a decision to refuse to grant citizenship to a person, to 
deprive a person of citizenship or to refuse to grant a certificate under Section 81 (certificate as 
to citizenship) takes effect retrospectively to the date of the decision. 
(5) 
The Committee has such powers and such other functions and duties as are conferred or 
imposed by or under an Act of the Parliament. 
(See: Citizenship Act (Chapter 12)) 
Division 5.—General. 
77. Special provisions for certain persons. 
(1) 
A foundling discovered at any time in the country shall, in the absence of proof to the 
contrary, be deemed to be the child of parents at least one of whom was, or if he had survived 
would have been, a citizen. 
(2) 
Where the identity or the citizenship status of a parent of a child born in the country is 
unknown or doubtful, the parent shall be deemed to have been, in the absence of proof to the 
contrary, a person who was, or if he had survived would have been, a citizen. 
(3) 
For the purposes of this Part, a posthumous child of a person has the same status as he 
would have had if he had been born immediately before the date of the death of his father. 
78. Effect of adoption. 
(1) 
Where the citizenship status or entitlement of a person is to be determined by reference 
to a parent or grand-parent and the person, or a parent of the person, was adopted under a law at 
any time in force in the country or any other place, the status or entitlement shall be determined 
by reference to the natural parents or grand-parents, except that the Minister responsible for 
citizenship matters may, in his deliberate judgement (but subject to Division 4 (Citizenship 
Advisory Committee)), allow an adoptive parent or grand-parent to be taken into account where
```

---

## Page 45

```text
45
the result would be to recognize citizenship or the entitlement to citizenship. 
(2) 
In Subsection (1), a reference to adoption includes a reference to an adoption by custom. 
79. Place of birth of certain persons. 
For the purposes of this Part— 
(a) a person born on a registered ship or aircraft shall be deemed to have been born at the 
place where the ship or aircraft was registered; and 
(b) a person born on an unregistered ship or aircraft belonging to the government of a 
country shall be deemed to have been born in that country. 
80. Residence 
Subject to any Act of the Parliament, a requirement in this Part of a period of residence in a place 
is not satisfied by— 
(a) residence in custody under sentence awaiting deportation or removal from the 
country; or 
(b) residence as an unlawful immigrant. 
 
(See: Organic Law on Residence) 
 
81. Certificate as to citizenship. 
(1) 
A person whose status or entitlement in relation to Citizenship of Papua New Guinea is, 
or may be, in doubt may apply to the Minister responsible for citizenship matters for a certificate 
under this section. 
(2) 
If the Minister is satisfied that the applicant is, or is entitled to become, a citizen, he 
may, in his deliberate judgement (but subject to Division 4 (Citizenship Advisory Committee)), 
grant a certificate stating that the person is or may become a citizen by virtue of a provision 
specified in the certificate. 
(3) 
Subject to Section 76 (functions of the Committee), a certificate under this section is 
(unless it is proved that it was obtained by means of a false representation, fraud or concealment 
of a material fact) conclusive evidence that on the material date the person concerned was, is or 
may become a citizen in accordance with the terms of the certificate. 
 
PART V.—THE HEAD OF STATE. 
Division 1.—The Head of State. 
82. Queen and Head of State. 
(1) 
Her Majesty the Queen— 
(a) having been requested by the people of Papua New Guinea, through their Constituent 
Assembly, to become the Queen and Head of State of Papua New Guinea; and 
(b) having graciously consented so to become,” are, however, obviously not part of that 
paragraph, and the correct form of printing is—
```

---

## Page 46

```text
46
 (2) 
Subject to and in accordance with this Constitution, the privileges, powers, functions, 
duties and responsibilities of the Head of State may be had, exercised and performed through a 
Governor-General appointed in accordance with Division 3 (appointment, etc., of Governor-
General) and, except where the contrary intention appears, reference in any law to the Head of 
State shall be read accordingly. 
83. Queen’s successors. 
The provisions of this Constitution referring to the Queen extend to Her Majesty’s heirs and 
successors in the sovereignty of the United Kingdom of Great Britain and Northern Ireland. 
84. Precedence. 
The Head of State takes precedence in rank over all other persons in Papua New Guinea, and the 
Governor-General takes precedence in rank immediately after the Head of State. 
85. Royal Style and Titles. 
The Style and Titles of the Head of State are as determined by Act of the Parliament, and until 
such an Act is made are— 
Elizabeth II, Queen of Papua New Guinea and Her other Realms and Territories, Head 
of the Commonwealth. 
Division 2.—Functions, etc., of the Head of State. 
86. Functions, etc. 
(1) 
The privileges, powers, functions, duties and responsibilities of the Head of State are as 
prescribed by or under Constitutional Laws and Acts of the Parliament. 
(2) 
Except as provided by Section 96(2) (terms and conditions of employment), in the 
exercise and performance of his privileges, powers, functions, duties and responsibilities the 
Head of State shall act only with, and in accordance with, the advice of the National Executive 
Council, or of some other body or authority prescribed by a Constitutional Law or an Act of the 
Parliament for a particular purpose as the body or authority in accordance with whose advice the 
Head of State is obliged, in a particular case, to act. 
(3) 
Any instrument made by or in the name of the Head of State shall recite that it is made 
with, and in accordance with, the advice of the National Executive Council or of any other body 
or authority in accordance with whose advice the Head of State is obliged, in the particular case, 
to act, but failure to comply with this subsection does not affect the validity of an instrument. 
(4) 
The question, what (if any) advice was given to the Head of State, or by whom, is non-
justiciable. 
Division 3.—Appointment, etc., of Governor-General. 
87. Qualifications for appointment. 
(1) 
The Governor-General must be a citizen who— 
(a) is qualified to be a member of the Parliament (except for the reason that he occupies 
the office of Governor-General); and 
(b) is a mature person of good standing who enjoys the general respect of the
```

---

## Page 47

```text
47
community. 
(2) 
The question, whether for the purposes of Subsection (1) a person is a person to whom 
Subsection (1)(b) applies, is non-justiciable. 
(3) 
The Governor-General must not hold any office or position or engage in any calling 
other than that of, or an office or position associated with, his office as Governor-General, except 
with the consent of the Head of State, acting with, and in accordance with, the joint advice of the 
National Executive Council and the Ombudsman Commission. 
(4) 
A request for the consent of the Head of State under Subsection (3) shall not be made 
unless agreement on the matter in relation to which the consent is sought has been reached 
between the National Executive Council and the Ombudsman Commission. 
(5) 
No person is eligible for appointment as Governor-General more than once unless the 
Parliament, by two-thirds absolute majority vote, approves appointment for a second term, but no 
person is eligible for appointment for a third term. 
88. Appointment to office. 
(1) 
Except in the case of the first Governor-General appointed before Independence Day the 
Governor-General shall be appointed by the Head of State, acting with, and in accordance with, 
the advice of the National Executive Council given in accordance with a decision of the 
Parliament. 
(See: Organic Law on the Nomination of Governor – General) 
(2) 
A decision of the Parliament to nominate a person for appointment as Governor-General 
shall be made by a simple majority vote, in an exhaustive secret ballot conducted in accordance 
with an Organic Law. 
(3) 
Subject to Subsection (5), the Speaker shall, within the period of three months before 
the completion of the normal term of office of the Governor-General, call a meeting of the 
Parliament to nominate the next Governor-General. 
(4) 
Subject to Subsection (5), in the event of a casual vacancy in the office of Governor-
General, the Speaker shall, as soon as practicable, call a meeting of the Parliament to nominate 
the next Governor-General. 
(5) 
If— 
(a) at a time when a meeting of the Parliament should otherwise be called under 
Subsection (3) or (4) a general election to the Parliament has been ordered; or 
(b) between the time when a meeting of the Parliament should otherwise be called under 
Subsection (3) and the date of the completion of the normal term of office of the 
outgoing Governor-General a general election to the Parliament is due to be held in 
accordance with this Constitution, 
the Speaker shall not call a meeting of the Parliament in accordance with Subsection (3) or (4), 
as the case may be, and a nomination shall be made at the first meeting of the new Parliament as 
its first item of business after any formal business and the election of a Speaker. 
89. Assumption of office.
```

---

## Page 48

```text
48
Notwithstanding Section 90 (Declaration of Loyalty, etc.) for the purposes of this Constitution a 
person appointed as Governor-General takes office— 
(a) subject to paragraph (b), at the end of his predecessor’s term of office; or 
(b) if he is appointed to fill a casual vacancy—on the date of his appointment. 
90. Declaration of Loyalty, etc. 
(1) 
Before entering upon the duties of his office, a Governor-General shall take the Oath of 
Allegiance and make the Declaration of Loyalty and the Declaration of Office before the Chief 
Justice and in the presence of the Parliament, but during a period of declared national emergency 
they may be taken and made in such manner as is directed by the National Executive Council. 
(2) 
If the Governor-General has not complied with Subsection (1) before taking office— 
(a) he is suspended from office until such time as he does so; and 
(b) if he does not do so at the first reasonably available opportunity, he may be dismissed 
from office by the Head of State, acting with, and in accordance with, the advice of the 
National Executive Council given in accordance with a decision of the Parliament, and 
in that event is not eligible for re-appointment for a period of six years. 
91. Normal term of office. 
Unless he earlier dies, resigns, ceases to be qualified for office in accordance with Section 87 
(qualifications for appointment), is dismissed under Section 90 (Declaration of Loyalty, etc.), or 
93(1) (dismissal and removal from office), or is removed from office under Section 93(2) 
(dismissal and removal from office), the Governor-General holds office for a term of six years 
from the date of his assumption of office in accordance with Section 89 (assumption of office), 
plus any period that is required, in accordance with Section 88(5) (appointment to office), for the 
appointment of the next Governor-General. 
92. Resignation. 
(1) 
The Governor-General may resign from office by notice in writing to the Head of State. 
(2) 
The resignation takes effect on its acceptance by the Head of State, acting with, and in 
accordance with, the advice of the National Executive Council. 
93. Dismissal and removal from office. 
(1) 
The Governor-General may be dismissed from office by the Head of State, acting with, 
and in accordance with, the advice of the National Executive Council given in accordance with 
either— 
(a) a decision of the National Executive Council; or 
(b) a decision made by an absolute majority of the Parliament. 
(2) 
The Governor-General may be removed from office by the Head of State, acting with, 
and in accordance with, the advice of the National Executive Council given in accordance with a 
decision of the Parliament, if the Speaker advises the Parliament that two medical practitioners 
appointed for the purpose by the National authority responsible for the registration or licensing 
of medical practitioners have jointly reported to the Speaker that, in their professional opinions, 
the Governor-General is unfit, by reason of physical or mental incapacity, to carry out the duties 
of his office.
```

---

## Page 49

```text
49
94. Suspension from office. 
(1) 
The Governor-General may be suspended from office— 
(a) by the National Executive Council, if he refuses or fails to act in accordance with the 
advice of the National Executive Council or of any other body or authority in accordance 
with whose advice he is obliged, in the particular case, to act, or acts, or purports to act 
contrary to, or without, any such advice; or 
(b) in accordance with an Act of the Parliament pending an investigation for the 
purposes of Section 93(2) (dismissal and removal from office), 
and pending any resultant action by the Parliament. 
(2) 
If the Governor-General is suspended from office by the National Executive Council 
under Subsection (1)(a), the Prime Minister shall immediately inform the Speaker of the 
suspension and of the reasons for it. 
(3) 
If the Governor-General is suspended from office under Subsection (1)(a)— 
(a) the Speaker shall, as soon as practicable, call a meeting of the Parliament at which 
the matter of the suspension and of the possible dismissal of the Governor-General shall 
be the first item of business after any formal business and, if necessary, the appointment 
of a Speaker; and 
(b) the suspension may be lifted at any time by decision of the Parliament; and 
(c) unless before the end of the meeting a recommendation is made in accordance with 
Section 93(1) (dismissal and removal from office) that the Governor-General be 
dismissed from office, the suspension ceases at the end of the meeting. 
(4) 
If the Governor-General is suspended from office under this section, the Prime Minister 
shall, as soon as practicable, inform the Head of State of the suspension and of the reasons for it. 
(5) 
A period of suspension under this section shall be taken into account in calculating for 
the purposes of this Division, the length of the period of service in office of the Governor-
General. 
95. Acting Governor-General. 
(1) 
In this section, a reference to the Speaker or to the Chief Justice shall be read as a 
reference to the substantive holder of that office. 
(2) 
If— 
(a) there is a vacancy in the office of Governor-General; or 
(b) the Governor-General is suspended from office; or 
(c) the Governor-General is— 
(i) 
on leave of absence; or 
(ii) 
absent from the country; or 
(iii) out of speedy and effective communication; or 
(iv) otherwise unable to perform, or is not readily available to perform, the duties of 
his office, 
the Speaker is, subject to Subsection (3), the Acting Governor-General.
```

---

## Page 50

```text
50
(3) 
If at any time to which Subsection (2) applies— 
(a) there is a vacancy in the office of Speaker; or 
(b) the Speaker is suspended from office; or 
(c) the Speaker is— 
(i) 
on leave of absence; or 
(ii) 
absent from the country; or 
(iii) out of speedy and effective communication; or 
(iv) otherwise unable to perform, or is not readily available to perform, the duties of 
his office, 
the Chief Justice (if he is a citizen) is the Acting Governor-General. 
(4) 
During any period when he is the Acting Governor-General, the Speaker or the Chief 
Justice shall not exercise or perform any of the other powers, functions, duties and 
responsibilities of the office of Speaker or Chief Justice, as the case may be, except that the 
Chief Justice may complete any proceedings actually commenced before him unless other 
suitable arrangements can be made. 
(5) 
When neither the Speaker nor the Chief Justice is available (or, in the case of the Chief 
Justice, qualified) to be the Acting Governor-General, the powers, functions, duties and 
responsibilities of the Governor-General shall be exercised and performed by a Minister 
appointed by the Head of State on the advice of the National Executive Council for the purpose. 
(6) 
The question, whether the occasion for the exercise or performance of a power, 
function, duty or responsibility by an Acting Governor-General or a Minister under this section 
has arisen or has ceased, is non-justiciable. 
96. Terms and conditions of employment. 
(1) 
Subject to this Constitution, the terms and conditions of employment of the Governor-
General are as determined by or under an Organic Law. 
(See: Organic Law on the terms and conditions of employment of the 
Governor-General) 
(2) 
Except with the consent of the Governor-General the terms and conditions of 
employment of the Governor-General shall not be changed to his detriment during his term of 
office, and an Organic Law that so changes them shall recite the terms of the consent. 
Division 4.—General. 
97. Conveyance of decisions, etc. 
Where any act is done, decision is made or advice is given by the Parliament or the National 
Executive Council under this Part, the Prime Minister shall immediately convey it to the Head of 
State. 
98. Acts, etc., of the Head of State. 
Unless the contrary intention appears, any act by the Head of State takes effect when it is 
formally advised to the Prime Minister or the National Executive Council.
```

---

## Page 51

```text
51
 
PART VI.—THE NATIONAL GOVERNMENT. 
Division 1.—General Principles. 
99. Structure of Government. 
(1) 
Subject to and in accordance with this Constitution, the power, authority and 
jurisdiction of the People shall be exercised by the National Government. 
(2) 
The National Government consists of three principal arms, namely:— 
(a) the National Parliament, which is an elective legislature with, subject to the 
Constitutional Laws, unlimited powers of law-making; and 
(b) the National Executive; and 
(c) the National Judicial System, consisting of a Supreme Court of Justice and a National 
Court of Justice, of unlimited jurisdiction, and other courts. 
(3) 
In principle, the respective powers and functions of the three arms shall be kept separate 
from each other. 
(4) 
Subsection (2) is descriptive only and is non-justiciable. 
Division 2.—The National Parliament. 
Subdivision A.—The Legislative Power. 
100. Exercise of the legislative power. 
(1) 
Subject to this Constitution, the legislative power of the People is vested in the National 
Parliament. 
(2) 
Subsection (1) does not prevent a law from conferring on an authority other than the 
Parliament legislative powers or functions (including, if the law so provides, a further power or 
further powers of delegation and subdelegation). 
(3) 
Nothing in any Constitutional Law enables or may enable the Parliament to transfer 
permanently, or divest itself of, legislative power. 
Subdivision B.—Composition of the National Parliament. 
101. Membership. 
(1) 
Subject to this section, the Parliament is a single-chamber legislature, consisting of— 
(a) a number of members elected from single-member open electorates; and 
(b) a number of members elected from single-member provincial electorates; and 
(c) not more than three nominated members, appointed and holding office in accordance 
with Section 102 (nominated members). 
(2) 
An Organic Law shall make provision for the number of open and provincial 
electorates. 
(See: Organic Law on National and Local Level Government Elections) 
(3) 
No member may represent two or more electorates at the same time.
```

---

## Page 52

```text
52
(4) 
The precise number of open electorates and of provincial electorates and their 
boundaries shall be determined from time to time in accordance with Section 125 (electorates). 
(5) 
An alteration to the number of electorates or to the boundaries of an electorate takes 
effect for the purposes of the next general election and of succeeding elections. 
102. Nominated members. 
The Parliament may, from time to time, by a two-thirds absolute majority vote, appoint a person 
(other than a member) to be a nominated member of the Parliament. 
103. Qualifications for and disqualifications from membership. 
(1) 
A member of the Parliament must be not less than 25 years of age. 
(2) 
A candidate for election to the parliament must have been born in the electorate for 
which he intends to nominate or have resided in the electorate for a continuous period of two 
years immediately preceding his nomination or for a period of five years at any time and must 
pay a nomination fee of K1,000.00. 
(Subsection (2) amended by Constitutional Amendment No.15) 
(3) 
A person is not qualified to be, or to remain, a member of the Parliament if— 
(a) he is not entitled to vote in elections to the Parliament; or 
(b) he is of unsound mind within the meaning of any law relating to the protection of the 
persons and property of persons of unsound mind; or 
(c) subject to Subsections (4) to (7), he is under sentence of death or imprisonment for a 
period of more than nine months; or 
(d) he is adjudged insolvent under any law; or 
(e) he has been convicted under any law of an indictable offence committed after the 
coming into operation of the Constitutional Amendment No 24—Electoral Reforms; or 
(f) he is otherwise disqualified under this Constitution. 
(4) 
Where a person is under sentence of death or imprisonment for a period exceeding nine 
months, the operation of Subsection (3)(d) is suspended until— 
(a) the end of any statutory period allowed for appeals against the conviction or 
sentence; or 
(b) if an appeal is lodged within the period referred to in paragraph (a), the appeal is 
determined. 
(5) 
The references in Subsection (4), to appeals and to the statutory period allowed for 
appeals shall, where there is provision for a series of appeals, be read as references to each 
appeal and to the statutory period allowed for each appeal. 
(6) 
If a free pardon is granted, a conviction is quashed or a sentence is changed to a 
sentence of imprisonment for nine months or less, or some other form of penalty (other than 
death) is substituted, the disqualification ceases, and if at the time of the pardon, quashing, 
change of sentence or substitution of penalty the writ for the by-election has not been issued the 
member is restored to his seat. 
(7) 
In this section— 
“appeal” includes any form of judicial appeal or judicial review;
```

---

## Page 53

```text
53
“statutory period allowed for appeals” means a definite period allowed by law for 
appeals, whether or not it is capable of extension, but does not include an extension of 
such a definite period granted or that may be granted unless it is granted within that 
definite period. 
104. Normal term of office. 
(1) 
An elected member of the Parliament takes office on the day immediately following the 
day fixed for the return of the writ for the election in his electorate. 
(2) 
The seat of a member of the Parliament becomes vacant— 
(a) if he is appointed as Governor-General; or 
(b) upon the expiry of the day fixed for the return of the writs, for the general election 
after he last became a member of the Parliament; or 
(c) if he resigns his seat by notice in writing to the Speaker, or in the case of the Speaker 
to the Clerk of the Parliament; or 
(d) if he is absent, without leave of the Parliament, during the whole of three consecutive 
meetings of the Parliament unless Parliament decides to waive this rule upon satisfactory 
reasons being given; or 
(e) if, except as authorized by or under an Organic Law or an Act of the Parliament, he 
directly or indirectly takes or agrees to take any payment in respect of his services in the 
Parliament; or 
(f) if he becomes disqualified under Section 103 (qualifications for and disqualifications 
from membership); or 
(g) on his death; or 
(h) if he is dismissed from office under Division III.2 (leadership code). 
(3) 
For the purposes of Subsection (2)(d), a meeting of the Parliament commences when the 
Parliament first sits following a general election, prorogation of the Parliament or an 
adjournment of the Parliament otherwise than for a period of less than 12 days and ends when 
next the Parliament is prorogued or adjourned otherwise than for a period of less than 12 days. 
105. General elections. 
(1) 
A general election to the Parliament shall be held— 
(a) within the period of three months before the fifth anniversary of the day fixed for the 
return of the writs for the previous general election; or 
(b) if, during the last 12 months before the fifth anniversary of the day fixed for the 
return of the writs for the previous general election— 
(i) 
a vote of no confidence in the Prime Minister or the Ministry is passed in 
accordance with Section 145 (motions of no confidence); or 
(ii) 
the Government is defeated on the vote on a question that the Prime Minister 
has declared to the Parliament to be a question of confidence; or 
(c) if the Parliament, by an absolute majority vote, so decides. 
(2) 
The Head of State, acting with, and in accordance with, the advice of the Electoral 
Commission, shall fix the first and last days of the period during which polling shall take place 
and the date by which the writs for a general election shall be returned.
```

---

## Page 54

```text
54
(3) 
In advising the Head of State under Subsection (2), and in conducting the election, the 
Electoral Commission shall do its best to ensure that— 
(a) in a case to which Subsection (1)(a) applies—the date for the return of the writs is 
fixed as nearly as may reasonably be to the fifth anniversary of the date fixed for the 
return of the writs for the previous general election; and 
(b) in a case to which Subsection (1)(b) or (c) applies—the date for the return of the 
writs is fixed as soon as may reasonably be after the date of the relevant decision of the 
Parliament. 
106. By-elections. 
If the office of an elected member of the Parliament becomes vacant otherwise than by virtue of 
Section 104(2)(b) (normal term of office), an election shall be held to fill the vacancy unless the 
vacancy occurs— 
(a) within the period of 12 months before the fifth anniversary of the date fixed for the 
return of the writs for the previous general election; or 
 
(Paragraph (a) amended by Constitutional Amendment No.15) 
 
(b) after the writ has been issued for (1) (general elections)” in Paragraph (b) should 
read “the election”, and something like “in which case” should appear before “the first-
mentioned writ” in Paragraph (b). 
an election under Section 105(1) (general elections) and before the day fixed for the return of 
that writ, writs for a general election are issued, the first-mentioned writ shall be deemed to have 
been revoked. 
Subdivision C.—The Speaker and the Deputy Speaker. 
107. Offices of Speaker and Deputy Speaker. 
(1) 
There shall be offices of Speaker and Deputy Speaker of the National Parliament. 
(2) 
The Speaker and the Deputy Speaker must be members of the Parliament, and shall be 
elected by the Parliament by secret ballot in accordance with the Standing Orders of the 
Parliament. 
(3) 
The Speaker and the Deputy Speaker hold office, and their offices become vacant, in 
accordance with the Constitutional Laws and the Standing Orders of the Parliament. 
(4) 
No Minister or Parliamentary Leader of a registered political party may be the Speaker 
or Deputy Speaker, and if a Speaker or Deputy Speaker becomes a Minister or Parliamentary 
Leader of a registered political party he vacates his office as Speaker or Deputy Speaker, as the 
case may be. 
108. Functions of the Speaker and Deputy Speaker. 
(1) 
The Speaker is responsible, subject to and in accordance with the Constitutional Laws, 
the Acts of the Parliament and the Standing Orders of the Parliament, for upholding the dignity 
of the Parliament, maintaining order in it, regulating its proceedings and administering its affairs, 
and for controlling the precincts of the Parliament as defined by or under an Act of the
```

---

## Page 55

```text
55
Parliament. 
(See: Parliamentary Powers and Privileges Act (Chapter 24)) 
(2) 
In the event of a vacancy in the office of the Speaker or his absence from the country or 
from the Parliament, and otherwise as determined by or under a Constitutional Law, an Act of 
the Parliament or the Standing Orders of the Parliament, the Deputy Speaker has, subject to 
Section 95 (Acting Governor-General), all the rights, privileges, powers, functions, duties and 
responsibilities of the Speaker. 
(3) 
A Constitutional Law, an Act of the Parliament or the Standing Orders of the Parliament 
may provide for other powers, functions, duties and responsibilities of the Speaker and the 
Deputy Speaker. 
Subdivision D.—Powers, Privileges and Procedures. 
109. General power of law-making. 
(1) 
Subject to this Constitution, the Parliament may make laws, having effect within and 
outside the country, for the peace, order and good government of Papua New Guinea and the 
welfare of the People. 
(2) 
In particular, Acts of the Parliament, not inconsistent with the Constitutional Laws, may 
provide for all matters that are necessary or convenient to be prescribed for carrying out and 
giving effect to this Constitution. 
(3) 
No law made by the Parliament is open to challenge in any court on the ground that— 
(a) it is not for the peace, order or good government of Papua New Guinea or the welfare 
of the People; or 
(b) it purports to have extra-territorial effect. 
(4) 
Each law made by the Parliament shall receive such fair, large and liberal construction 
and interpretation as will best ensure the attainment of the object of the law according to its true 
intent, meaning and spirit, and there is no presumption against extra-territoriality. 
110. Certification as to making of laws. 
(1) 
Subject to Section 137(3) (Acts of Indemnity) and to any Act of the Parliament made for 
the purposes of Subsection (3), the Speaker shall certify under the National Seal, in accordance 
with the Standing Orders of the Parliament, that a law has been made by the Parliament and, 
subject to Subsection (2), the law comes into operation on the date of the certificate. 
(2) 
Nothing in Subsection (1) prevents a law— 
(a) being expressed to come, or to be deemed to have come, into force on a date 
specified by, or fixed in accordance with, law; or 
(b) being retrospective or retroactive. 
(3) 
An Act of the Parliament or the Standing Orders of the Parliament may make provision 
under which a law made by the Parliament may, at the direction of the Head of State, acting 
with, and in accordance with, the advice of the National Executive Council, be recommitted to 
the Parliament for the consideration of amendments proposed by the Head of State, acting with, 
and in accordance with, the advice of the National Executive Council.
```

---

## Page 56

```text
56
111. Right to introduce bills, etc. 
(1) 
Subject to Section 210 (executive initiative) and to an Organic Law made for the 
purposes of Subdivision VI.2.H (Protection of Elections from Outside or Hidden Influence and 
Strengthening of Political Parties), any member of the Parliament is entitled to introduce into the 
Parliament, in accordance with, and subject to any reasonable restrictions contained in, the 
Standing Orders of the Parliament, a petition, question, bill, resolution or motion. 
 
(2) 
The petition, question, bill, resolution or motion shall be dealt with as provided by the 
Standing Orders of the Parliament. 
(3) 
The Standing Orders of the Parliament may make provision for priority to be given to 
Government business at certain times or in certain circumstances. 
112. Presiding in the Parliament. 
(1) 
Subject to Subdivision C (the Speaker and the Deputy Speaker) and to Subsection (2), 
the Standing Orders of the Parliament shall make provision in respect of the chairmanship of the 
Parliament and of Committees of the Whole. 
(2) 
No Minister may preside in the Parliament or in a Committee of the Whole. 
113. Quorum. 
(1) 
The quorum for a sitting of the Parliament is one-third of the number of seats in the 
Parliament at the time. 
(2) 
The Standing Orders of the Parliament shall make provision for the action to be taken in 
the event of a lack of or loss of a quorum at any time. 
114. Voting in the Parliament. 
(1) 
Subject to Subsection (5) and except as otherwise provided by a Constitutional Law or 
the Standing Orders of the Parliament, all questions before a meeting of the Parliament shall be 
decided in accordance with the majority of votes of the members present and voting. 
(2) 
Subject to Subsection (5), the member presiding does not have a deliberative vote 
except— 
(a) on a motion of no confidence in the Prime Minister, the Ministry or a Minister, in 
accordance with an Organic Law referred to in Section 145 (motions of no confidence); 
or 
(b) on any question which requires an affirmative vote greater than a simple majority. 
(3) 
Subject to Subsection (5), except in a case where he has voted under Subsection (2), in 
the event of an equality of votes on a question, the member presiding has a casting vote, but if he 
fails to use it the motion shall be deemed to be withdrawn. 
(4) 
The Standing Orders of the Parliament shall make provision for the manner in which a 
vote is to be taken and recorded. 
(5) 
An Organic Law made for the purposes of Subdivision VI.2.H (Protection of Elections 
from Outside or Hidden Influence and Strengthening of Political Parties) may restrict the voting
```

---

## Page 57

```text
57
rights of a member of the Parliament in certain circumstances. 
115. Parliamentary privileges, etc. 
(1) 
The powers (other than legislative powers), privileges and immunities of the Parliament 
and of its members and committees are as prescribed by or under this section and by any other 
provision of this Constitution. 
(2) 
There shall be freedom of speech, debate and proceeding in the Parliament, and the 
exercise of those freedoms shall not be questioned in any court or in any proceedings whatever 
(otherwise than in proceedings in the Parliament or before a committee of the Parliament). 
(3) 
No member of the Parliament is subject to the jurisdiction of any court in respect of the 
exercise of his powers or the performance of his functions, duties or responsibilities as such, but 
this subsection does not affect the operation of Division III.2 (leadership code). 
(4) 
No member of the Parliament is liable to civil or criminal proceedings, arrest, 
imprisonment, fine, damages or compensation by reason of any matter or thing that he has 
brought by petition, question, bill, resolution, motion or otherwise, or has said before or 
submitted to the Parliament or a committee of the Parliament. 
(5) 
No member of the Parliament or other person is liable to civil or criminal proceedings, 
arrest, imprisonment, fine, damages or compensation by reason of— 
(a) an act done under the authority of the Parliament or under an order of the Parliament 
or a committee of the Parliament; or 
(b) words spoken or used, or a document or writing made or produced, under an order or 
summons made or issued under the authority of the Parliament or a committee of the 
Parliament. 
(6) 
Members of the Parliament are free from arrest for civil debt during meetings of the 
Parliament and during the period commencing three days before, and ending three days after, a 
meeting when they are travelling from their respective electorates to attend the meeting or are 
returning to their electorates from the meeting. 
(7) 
No process issued by any court in the exercise of its civil jurisdiction shall be served or 
executed through the Speaker, an officer of the Parliament or a member of the Parliamentary 
Service, or within the precincts of the Parliament (as defined by or under an Act of the 
Parliament) while it is sitting. 
(See: Parliamentary Powers and Privileges Act (Chapter 24)) 
(8) 
The powers conferred by Section 109 (general powers of law-making) extend to the 
making of laws— 
(a) declaring further powers (other than legislative powers), privileges and immunities 
of the Parliament, and of its members and committees; and 
(b) providing for the manner in which powers, privileges and immunities provided for by 
or under this section may be exercised or upheld. 
(9) 
The powers and privileges conferred by or under this section do not and shall not 
include the power to impose or provide for the imposition of a fine, imprisonment, forfeiture of 
property or other penalty of a criminal nature, but this subsection does not prevent the creation of 
offences for the purposes of this section that are triable within the National Judicial System.
```

---

## Page 58

```text
58
116. Disallowance of subordinate laws. 
(1) 
All subordinate legislative enactments made under an Act of the Parliament— 
(a) shall be tabled in the Parliament as soon as practicable, and in any event within seven 
sitting days of the Parliament, after being made; and 
(b) are subject to disallowance in whole or in part by decision of the Parliament, 
in accordance with Section Sch.1.18 (disallowance, etc.) and the Standing Orders of the 
Parliament. 
(2) 
Subject to Section Sch.1.18 (disallowance, etc.) an Act of the Parliament may make 
further provision as to the disallowance of a subordinate legislative enactment or part of a 
subordinate legislative enactment under this section, and as to the effect of such a disallowance 
on or in respect of rights and liabilities under or affected by the disallowed enactment or part. 
(3) 
Failure to comply with Subsection (1) does not invalidate a subordinate legislative 
enactment. 
117. Treaties, etc. 
(1) 
In this section, unless the contrary intention appears— 
“treaty” means an agreement between States that— 
(a) 
is governed by international law; and 
(b) 
creates a relationship binding at international law on Papua New Guinea, 
whether embodied in a single instrument or in two or more related instruments and 
whatever may be its designation, but does not include a visiting forces agreement 
entered into in accordance with Section 206 (visiting forces); 
“treaty document” means— 
(a) 
the text of a treaty that it is proposed to accept or to ratify; or 
(b) 
a statement of the effect of such a treaty; or 
(c) 
a copy of the document by which it is intended that Papua New Guinea will 
express its consent to be bound by such a treaty. 
(2) 
Subject to Subsection (3), the consent of Papua New Guinea to be bound as a party to a 
treaty may be given only— 
(a) by the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council; or 
(b) by a Minister authorized either generally or specifically for the purpose by the Head 
of State, acting with, and in accordance with, the advice of the National Executive 
Council; or 
(c) otherwise in accordance with international law, usage and practice, 
and in accordance with this section. 
(3) 
Subject to Subsection (5), the consent of Papua New Guinea to be bound as a party to a 
treaty shall not be given— 
(a) unless a treaty document relating to the treaty has been presented to the Parliament 
for at least ten sitting days; or
```

---

## Page 59

```text
59
(b) if within ten sitting days of the Parliament after the day on which the treaty document 
was presented to the Parliament the Parliament, by an absolute majority vote, 
disapproves the giving of the consent. 
(4) 
The fact that the Parliament has disapproved the giving of the consent of Papua New 
Guinea to be bound as a party to a treaty does not prevent the re-presentation to the Parliament of 
a treaty document relating to the treaty, and in that event Subsection (3) once again applies. 
(5) 
Subsection (3) does not apply if— 
(a) the Parliament has, by an absolute majority vote, waived the requirements of that 
subsection; or 
(b) both the Speaker (acting on behalf of the Parliament) and the Prime Minister are 
satisfied that the giving of the consent of Papua New Guinea to be bound as a party to 
the treaty is too urgent a matter to allow of compliance with that subsection, or that 
compliance would not be in the national interest. 
(6) 
A certificate of the Speaker as to any matter arising under this section is, before all 
courts and all persons acting judicially, conclusive evidence of the facts certified to. 
(7) 
Notwithstanding the consent of Papua New Guinea to be bound as a party to a treaty, no 
treaty forms part of the municipal law of Papua New Guinea unless, and then only to the extent 
that, it is given the status of municipal law by or under a Constitutional Law or an Act of the 
Parliament. 
(8) 
Legislative approval or ratification of a treaty does not, without more, give it the status 
of municipal law for the purposes of Subsection (7). 
Subdivision E.—The Committee System. 
118. Permanent Parliamentary Committees. 
(1) 
In order to ensure full and active participation by backbenchers in the work of the 
Parliament and of government, there shall be the following Permanent Parliamentary 
Committees which, in principle, should cover all major fields of the activities of the National 
Government:— 
(a) a Public Accounts Committee, established in accordance with Subdivision VIII.1.C 
(the Public Accounts Committee); and 
(b) such other committees as are determined by the Parliament from time to time. 
(2) 
The Parliament shall, subject to this Constitution, make provision by Organic Law, by 
Act of the Parliament, Standing Order or otherwise, for the establishment, membership, 
jurisdiction, functions, powers and procedures of the Permanent Parliamentary Committees, and 
in particular for empowering such a Committee to call for persons, papers and records. 
(See: Public Finance (Management) Act 1994;  Public Works Committee 
Act (Chapter 28);  Permanent Parliamentary Committees Act 1994) 
(3) 
No Minister may be a member of a Permanent Parliamentary Committee. 
(4) 
In principle, membership of the Permanent Parliamentary Committees should be spread 
as widely as practicable among the backbenchers. 
119. Chairmen and Deputy Chairmen.
```

---

## Page 60

```text
60
(1) 
There shall be a Chairman and a Deputy Chairman of each Permanent Parliamentary 
Committee. 
(2) 
In principle, either the Chairman or the Deputy Chairman of each Permanent 
Parliamentary Committee should be a member of the Parliament who is recognized by the 
Parliament as being generally committed to support the Government in the Parliament, and the 
other should be a member of the principal party or group, or coalition of parties or groups, that is 
recognized by the Parliament as being not so committed. 
(3) 
Subject to any Act of the Parliament and to the Standing Orders of the Parliament, in the 
event of the absence or non-availability to act of the Chairman, the Deputy Chairman has all the 
rights, privileges, powers, functions, duties and responsibilities of the Chairman. 
(4) 
An Organic Law made for the purposes of Subdivision VI.2.H (Protection of Elections 
from Outside or Hidden Influence and the Strengthening of Political Parties) may provide that in 
certain circumstances a member of the Parliament is not eligible to be appointed to or hold the 
office of Chairman or Deputy-Chairman of a Permanent Parliamentary Committee. 
120. Roles of Chairmen and Deputy Chairmen of Permanent Parliamentary 
Committees. 
(1) 
The Chairman and Deputy Chairman of each Permanent Parliamentary Committee shall 
be granted full access to each Minister having responsibilities relevant to the jurisdiction and 
functions of his Committee and, by arrangement with the Minister, to the head of the Minister‘s 
department, and are entitled to be briefed and consulted on major policy issues. 
(2) 
In relation to any information given to or obtained by them under Subsection (1), the 
Chairman and the Deputy Chairman are under the same obligation, whether by law or by 
convention, as to confidentiality as is the Minister but this principle does not prevent the 
Chairman or Deputy Chairman from briefing the members of his Permanent Parliamentary 
Committee on major policy issues. 
(3) 
In relation to any information given to him under Subsection (2), a member of a 
Permanent Parliamentary Committee is under the same obligation, whether by law or 
convention, as to confidentiality as is the Minister. 
 
 
121. Sessional Committees, Select Committees, etc. 
Nothing in this Subdivision prevents the Parliament from establishing Sessional or Select 
Committees or other committees for any purpose, or prevents the Parliament from sitting as a 
Committee of the Whole. 
122. Arrangement of Parliamentary business in relation to Committees. 
The business of the Parliament shall be so arranged as to allow reasonable time for committees 
of the Parliament to perform their functions adequately, and the Standing Orders of the 
Parliament shall make provision to ensure that such time is allowed either within or outside the 
sitting hours of the Parliament.
```

---

## Page 61

```text
61
123. Membership of Parliamentary Committees. 
Each committee of the Parliament shall consist only of members of the Parliament, but nothing 
in this section prevents the establishment, by statute or otherwise, of commissions or committees 
of any other kind. 
 
Subdivision F.—Calling, etc., of the Parliament. 
124. Calling, etc. 
(1) 
The Parliament shall be called to meet not more than seven days after the day fixed for 
the return of the writs for a general election, and shall meet not less frequently than three times in 
each period of 12 months, and, in principle, for not less than nine weeks in each such period. 
(Subsection (1) Amended by Constitutional Amendment No.15) 
(2) 
An Organic Law shall make provision for the calling of meetings of the Parliament. 
(See: Organic Law on the Calling of Meetings of the Parliament) 
(3) 
Subject to Subsections (1) and (2), an Act of the Parliament or the Standing Orders of 
the Parliament may make provision in respect of the sittings of the Parliament. 
Subdivision G.—Electorates and Elections. 
125. Electorates. 
(1) 
The number of open electorates and of provincial electorates and their boundaries shall 
be determined by the Parliament in accordance with recommendations from a Boundaries 
Commission from time to time, at intervals determined by or under an Organic Law, being 
intervals of not more than 10 years. 
(2) 
In recommending open electorates and open electorate boundaries, the Boundaries 
Commission shall, taking into account any considerations laid down by an Organic Law, 
endeavour to ensure that all open electorates contain approximately the same population, within 
limits prescribed by an Organic Law. 
(3) 
The Parliament may accept or reject, but may not amend, any recommendation of the 
Boundaries Commission under Subsection (1). 
(4) 
The Boundaries Commission is not subject to direction or control by any person or 
authority. 
(5) 
An Organic Law shall make further provision for and in respect of the appointment, 
constitution and procedures of the Boundaries Commission, and for safeguarding its 
independence, and in relation to the procedures for formulating and considering its 
recommendations. 
(6) 
An Organic Law relating to provinces or to Provincial Governments and Local-level 
Governments may confer or impose on the Boundaries Commission powers, functions, duties or 
responsibilities in relation to the boundaries of provinces and of provincial electorates. 
126. Elections.
```

---

## Page 62

```text
62
(1) 
Elections to the Parliament shall be conducted, in accordance with an Organic Law, by 
an Electoral Commission 
(See: Organic Law on National and Local Level Government Elections) 
(2) 
General elections shall be held in accordance with Sections 105 (general elections) and 
106 (by-elections), as required. 
(3) 
The members of the Parliament (other than the nominated members) shall be elected 
under a system of universal, adult, citizen suffrage in accordance with Section 50 (right to vote 
and stand for public office) and the other Constitutional Laws, and the voting age is 18 years. 
(4) 
A citizen’s right to vote in an election to the Parliament is as provided by Section 50 
(right to vote and stand for public office). 
(5) 
No non-citizen may vote in an election for the Parliament. 
(6) 
The Electoral Commission is not subject to direction or control by any person or 
authority. 
(7) 
An Organic Law shall make provision for and in respect of— 
(a) the appointment, constitution and procedures of the Electoral Commission, and for 
safeguarding its independence; and 
(b) the electoral system; and 
(c) safeguarding the integrity of elections; and 
(d) appeals to the National Court in electoral matters. 
 
(See: Organic Law on National and Local Level Government Elections) 
 
(8) An Organic Law relating to provinces or provincial government may confer or impose 
on the Electoral Commission powers, functions, duties or responsibilities in relation 
to provincial elections. 
 
(Subsection (8) added by Constitutional Amendment No.2) 
 
 
 
 
Subdivision H.—Protection of Elections from Outside or Hidden Influence and 
Strengthening of Political Parties. 
 
127. Purposes of Subdivision H. 
The purposes of this Subdivision are— 
(a) to protect elections and to prevent candidates from being, or appearing to be or to 
have been, improperly influenced by outside (especially foreign) or hidden influences; 
and 
(b) to permit the funding of registered political parties; and
```

---

## Page 63

```text
63
(c) to restrict a member of the Parliament in certain circumstances from resigning or 
withdrawing from or failing to support a political party of which he is a member; and 
(d) to provide that in certain circumstances a member of the Parliament who— 
(i) 
resigns or withdraws from the political party of which he is a member; or 
(ii) 
fails to support the political party of which he is a member; or 
(iii) is a member of a political party whose registration is cancelled, 
is guilty of misconduct in office; and 
(e) to restrict in certain circumstances the voting rights of a member of the Parliament, 
and an Organic Law may make provision, in addition to the provisions expressly referred to in 
this Subdivision, for achieving those purposes. 
128. “Registered political party”. 
In this Subdivision, “registered political party” means a political party or organization registered 
under an Organic Law made for the purpose of Section 129(1)(a) (integrity of political parties). 
(See: Organic Law on the Integrity of Political Parties and Candidates) 
 
129. Integrity of political parties. 
(1) 
An Organic Law shall make provision— 
(a) requiring any political party or organization having political aims and desiring to 
nominate a candidate for election to the Parliament, or to publicly support such a 
candidate as representing its views, to register with an appropriate body established by 
an Organic Law such reasonable particulars as are prescribed by Organic Law; and 
(b) requiring any such party or organization to disclose to the Ombudsman Commission 
or some other authority prescribed by the law in such manner, at such times and with 
such details as are prescribed in or under the law— 
(i) 
its assets and income, and their sources; and 
(ii) 
its expenditure on or connected with an election or the support of a candidate; 
and 
(c) prohibiting non-citizens from membership of, and from contributing to the funds of, 
any such party or organization; and 
(d) defining the corporations and organizations that are to be regarded as non-citizens for 
the purposes of a provision made for the purposes of paragraph (c); and 
(e) limiting the amount of contributions that such a party or organization may receive 
from any source or sources; and 
(f) requiring persons who have made, or may have made, contributions to any such party 
or organization to give to the Ombudsman Commission, or some other authority, details 
of any such contribution; and 
(g) authorizing the funding of registered political parties from the National Budget and 
establishing a body to manage and distribute the funds in accordance with established 
procedures; and 
(h) authorizing the payment in certain circumstances of a percentage of electoral 
expenses incurred by a female candidate in an election.
```

---

## Page 64

```text
64
(2) 
Where another authority is prescribed by the law under Subsection (1)(b), that 
authority— 
(a) shall be composed of a person or persons who are declared under paragraph (i) of the 
definition of “constitutional office-holder” in Section 221 (definitions) to be a 
constitutional office-holder; and 
(b) is not subject to direction or control by any person or authority. 
(3) 
An Organic Law made for the purposes of Subsection (1) may provide that the value of 
any assistance given otherwise than in cash shall be taken into account as expenditure or 
contributions for any purpose of that subsection or of that law. 
(See: Organic Law on the Integrity of Political Parties and Candidates) 
130. Integrity of candidates. 
(1) 
An Organic Law shall make provision— 
(a) requiring a candidate or former candidate for election to the Parliament to disclose to 
the Ombudsman Commission or some other authority prescribed by the law, in such 
manner, at such times and with such details as are prescribed by or under the law— 
(i) 
any assistance (financial or other) received by him in respect of his 
candidature, and its source; and 
(ii) 
the amount or value of his electoral expenses; and 
(b) prohibiting a candidate or former candidate for election to the Parliament from 
accepting from a non-citizen assistance (financial or other) in respect of his candidature; 
and 
(c) defining the corporations and organizations that are to be regarded as non-citizens for 
the purposes of a provision made for the purposes of paragraph (b); and 
(d) regulating or restricting the amount or kind of such assistance that may be received 
from any source other than a registered political party; and 
(e) prohibiting a candidate for election to the Parliament from holding himself out as 
representing any party or organization other than a registered political party that has 
publicly adopted him as its candidate. 
(2) 
Where another authority is prescribed by the law under Subsection (1)(b), that 
authority— 
(a) shall be composed of a person or persons who are declared under paragraph (i) of the 
definition of “constitutional office-holder” in Section 221 (definitions) to be a 
constitutional office-holder; and 
(b) is not subject to direction or control by any person or authority. 
(3) 
An Organic Law made for the purposes of Subsection (1) may make provision for 
further defining what are to be regarded as assistance and electoral expenses for any purpose of 
that subsection or of that law, and in particular may provide that— 
(a) the value of hospitality (including meals, accommodation and transport) of a kind 
and to a degree recognized by custom in the country shall not be taken into account as 
assistance; and 
(b) the personal expenses of a candidate shall not be taken into account as electoral 
expenses.
```

---

## Page 65

```text
65
(4) 
In this section— 
“electoral expenses”, in relation to a candidate, means expenses incurred (whether 
before, during or after an election to the Parliament, including expenses incurred before 
the issue of the writ for election) by him or on his behalf on account of or in respect of 
the election; 
“personal expenses”, in relation to a candidate, means any reasonable costs incurred by 
him personally for travel and for living away from his home for the purposes of the 
election. 
130A. Provisions relating to political parties. 
An Organic Law made for the purposes of this Subdivision may— 
(a) restrict a member of the Parliament from resigning or withdrawing from a political 
party of which he is a member; and 
(b) restrict a member of the Parliament from failing to support, in certain circumstances, 
a political party of which he is a member; and 
(c) provide that, in certain circumstances, a member of Parliament who— 
(i) 
resigns or withdraws from the political party of which he is a member; or 
(ii) 
fails to support the political party of which he is a member; or 
(iii) is a member of a political party whose registration is cancelled, 
is guilty of misconduct in office; and 
(d) permit a member of the Parliament who at the time of his election to the Parliament 
was not a member of a registered political party to join a registered political party; and 
(e) authorize the Head of State to invite a registered political party to form the 
Government in certain circumstances; and 
(e) restrict a member of the Parliament in certain circumstances, from exercising his 
voting rights in the Parliament. 
(See: Organic Law on the Integrity of Political Parties and Candidates) 
 
 
 
 
 
Subdivision I.—General. 
 
131. The Parliamentary Salaries Tribunal. [Repealed] 
132. The Parliamentary Service. 
(1) 
An Act of the Parliament shall make provision for and in respect of a Parliamentary 
Service, separate from the other State Services. 
(See: Parliamentary Services Act (Chapter 26)) 
(2) 
Within the Service, there shall be an office of Clerk of the National Parliament who 
shall, subject to Subsection (3), be the head of the Service.
```

---

## Page 66

```text
66
(3) The Service shall be subject to the direction and control of the Speaker and shall 
perform its functions impartially. 
133. Standing Orders. 
The Parliament may make Standing Orders and other rules and orders in respect of the order and 
conduct of its business and proceedings and the business and proceedings of its committees, and 
of such other matters as by law are required or permitted to be prescribed or provided for by the 
Standing Orders of the Parliament. 
134. Proceedings non-justiciable. 
Except as is specifically provided by a Constitutional Law, the question, whether the procedures 
prescribed for the Parliament or its committees have been complied with, is non-justiciable, and 
a certificate by the Speaker under Section 110 (certification as to making of laws) is conclusive 
as to the matters required to be set out in it. 
135. Questions as to membership, etc. 
The National Court has jurisdiction to determine any question as to— 
(a) the qualifications of a person to be or to remain a member of the Parliament; or 
(b) the validity of an election to the Parliament. 
136. Validation of Acts of the Parliament. 
Where a person who has purported to sit or vote as a member of the Parliament at a meeting of 
the Parliament or of a committee of the Parliament— 
(a) was not duly qualified to be elected or appointed, or to continue, as a member of the 
Parliament; or 
(b) had vacated his office as a member of the Parliament, 
all things done or purporting to have been done by the Parliament or by the committee, as the 
case may be, shall be deemed to have been as validly done as if that person had, when so sitting 
or voting, been duly qualified to be elected or appointed or to continue as a member of the 
Parliament, or had not vacated his office, as the case may be. 
Division 3.—Special Instances of the Legislative Power. 
137. Acts of Indemnity. 
(1) 
If— 
(a) a provision of a Constitutional Law has been contravened or not complied with; and 
(b) the Parliament is satisfied that— 
(i) 
the contravention or non-compliance was made in good faith and in exceptional 
circumstances for the purpose, or with the intention, of upholding this Constitution or 
protecting Papua New Guinea, or of dealing with an for the purposes of Part X. 
emergency for which no provision or no adequate provision appeared to exist; and 
(ii) 
no blameworthiness attaches to some person or some persons concerned in the 
contravention or non-compliance,
```

---

## Page 67

```text
67
the Parliament may make a special law (to be known as an “Act of Indemnity”) in relation to that 
person or those persons. 
(2) 
An Act of Indemnity shall— 
(a) specify the contravention or non-compliance; and 
(b) certify as to the Parliament‘s satisfaction concerning the matters specified in 
Subsection (1)(b)(i) and (ii); and 
(c) identify or provide for the identification of the person or persons to whom it relates; 
and 
(d) provide for the making of full compensation to any person suffering injury as a result 
of the contravention or non-compliance; and 
(e) be made in accordance with the procedures laid down by this Constitution for the 
making of Organic Laws; and 
(f) be passed by an absolute majority vote of the Parliament. 
(3) 
Before the Speaker certifies under Section 110 (certification as to making of laws) as to 
the Act, he shall refer the question, whether the Act complies with this section, for the opinion of 
the Supreme Court in accordance with Section 19 (special references to the Supreme Court), and 
until the Court advises that the Act does so comply he shall not so certify it. 
(4) 
An Act of Indemnity— 
(a) relieves, and shall be expressed to relieve, the person or persons concerned from all 
liability for, and from all legal consequences of, the contravention or non-compliance; 
and 
(b) if a person concerned has been convicted of an offence in respect of or arising out of 
the contravention or non-compliance, takes effect as a free pardon, 
but in respect only of acts done before the Parliament was formally advised of the intention to 
propose the Act. 
(5) 
An Act of Indemnity does not take effect as a Constitutional Law. 
(6) 
An Act of Indemnity shall not be amended or extended in any way, and its repeal does 
not affect the operation of Subsection (4). 
 
 
Division 4.—The National Executive. 
Subdivision A.—The National Executive and the Executive Power. 
138. Vesting of the executive power. 
Subject to this Constitution, the executive power of the People is vested in the Head of State, to 
be exercised in accordance with Division V.2 (functions, etc., of the Head of State). 
139. The National Executive. 
The National Executive consists of— 
(a) the Head of State acting in accordance with Division V.2 (functions, etc., of the Head
```

---

## Page 68

```text
68
of State); and 
(b) the National Executive Council. 
140. Conferring of powers, etc., outside the National Executive. 
Except where the contrary intention appears, nothing in this Constitution prevents an Organic 
Law or a statute from conferring or imposing powers, functions, duties or responsibilities on a 
person or authority outside the National Executive. 
Subdivision B.—The Ministry. 
141. Nature of the Ministry: collective responsibility. 
The Ministry is a Parliamentary Executive, and therefore— 
(a) no person who is not a member of the Parliament is eligible to be appointed to be a 
Minister, and, except as is expressly provided in this Constitution to the contrary, a 
Minister who ceases to be a member of the Parliament ceases to hold office as a 
Minister; and 
(b) it is collectively answerable to the People, through the Parliament, for the proper 
carrying out of the executive government of Papua New Guinea and for all things done 
by or under the authority of the National Executive; and 
(c) it is liable to be dismissed from office, either collectively or individually, in 
accordance with this Subdivision. 
142. The Prime Minister. 
(1) 
An office of Prime Minister is hereby established. 
(2) 
The Prime Minister shall be appointed, at the first meeting of the Parliament after a 
general election and otherwise from time to time as the occasion for the appointment of a Prime 
Minister arises, by the Head of State, acting in accordance with a decision of the Parliament. 
(3) 
If the Parliament is in session when a Prime Minister is to be appointed, the question of 
the appointment shall be the first matter for consideration, after any formal business and any 
nomination of a Governor-General or appointment of a Speaker, on the next sitting day. 
(4) 
If the Parliament is not in session when a Prime Minister is to be appointed, the Speaker 
shall immediately call a meeting of the Parliament, and the question of the appointment shall be 
the first matter for consideration, after any formal business and any nomination of a Governor-
General or appointment of a Speaker, on the next sitting day. 
(5) 
The Prime Minister— 
(a) shall be dismissed from office by the Head of State if the Parliament passes, in 
accordance with Section 145 (motions of no confidence), a motion of no confidence in 
him or the Ministry, except where the motion is moved within the last 12 months before 
the fifth anniversary of the date fixed for the return of the writs at the previous general 
election; and 
(b) may be dismissed from office in accordance with Division III.2 (leadership code); 
and 
(c) may be removed from office by the Head of State, acting in accordance with a 
decision of the Parliament, if the Speaker advises the Parliament that two medical
```

---

## Page 69

```text
69
practitioners appointed by the National Authority responsible for the registration or 
licensing of medical practitioners have jointly reported in accordance with an Act of the 
Parliament that, in their professional opinions, the Prime Minister is unfit, by reason of 
physical or mental incapacity, to carry out the duties of his office. 
(6) 
The Prime Minister may be suspended from office— 
(a) by the tribunal appointed under an Organic Law made for the purposes of Section 28 
(further provisions), pending an investigation into a question of misconduct in office 
within the meaning of Division III.2 (leadership code), and any resultant action; or 
 
(See: Organic Law on the Duties and Responsibilities of Leadership) 
 
(b) in accordance with an Act of the Parliament, pending an investigation for the 
purposes of Subsection (5)(c), and any resultant action by the Parliament. 
 
(See: Prime Minister Act (Chapter 27)) 
 
(7) 
An Organic Law made for the purposes of Subdivision VI.2.H (Protection of Elections 
from Outside or Hidden Influence and Strengthening of Political Parties) may provide that in 
certain circumstances a member of the Parliament is not eligible to be appointed to or hold the 
office of Prime Minister. 
143. Acting Prime Minister. 
(1) 
Subject to Subsection (2) an Act of the Parliament shall make provision for and in 
respect of the appointment of a Minister to be Acting Prime Minister to exercise and perform the 
powers, functions, duties and responsibilities of the Prime Minister when— 
(a) there is a vacancy in the office of Prime Minister; or 
(b) the Prime Minister is suspended from office; or 
(c) the Prime Minister is— 
(i) 
absent from the country; or 
(ii) 
out of speedy and effective communication; or 
(iii) otherwise unable or not readily available to perform the duties of his office. 
(See: Prime Minister Act (Chapter 27)) 
(2) 
Where a Prime Minister is dismissed under Section 142(5)(a) (the Prime Minister) the 
person nominated under Section 145(2)(a) (motions of no confidence)— 
(a) becomes the Acting Prime Minister until he is appointed a Prime Minister in 
accordance with Section 142(2) (the Prime Minister); and 
(b) may exercise and perform all the powers, functions, duties and responsibilities of a 
Prime Minister. 
(3) 
The question whether the occasion for the appointment of an Acting Prime Minister or 
for the exercise or performance of a power, function, duty or responsibility by an Acting Prime 
Minister, under this section has arisen or has ceased, is non-justiciable.
```

---

## Page 70

```text
70
144. Other Ministers. 
(1) 
There shall be such number of Ministers (other than the Prime Minister), not being less 
than six or more than one quarter of the number of members of the Parliament from time to time, 
as is determined by or under an Organic Law. 
(See: Organic Law on the Number of Ministers) 
(2) 
The Ministers, other than the Prime Minister, shall be appointed by the Head of State, 
acting with, and in accordance with, the advice of the Prime Minister. 
(3) 
A Minister, other than the Prime Minister, may be suspended from office in accordance 
with an Organic Law made for the purposes of Section 28(2) (further provisions). 
(See: Organic Law on the Duties and Responsibilities of Leadership) 
(4) 
A Minister other than the Prime Minister— 
(a) shall be dismissed from office by the Head of State if the Parliament passes, in 
accordance with Section 145 (motions of no confidence), a motion of no confidence in 
him; and 
(b) may be dismissed from office— 
(i) 
by the Head of State, acting with, and in accordance with, the advice of the 
Prime Minister; or 
(ii) 
in accordance with Division III.2 (leadership code). 
(5) 
An Organic Law made for the purposes of Subdivision VI.2.H (Protection of Elections 
from Outside or Hidden Influence and Strengthening of Political Parties) may provide that in 
certain circumstances a member of the Parliament is not eligible to be appointed to or hold the 
office of Minister. 
145. Motions of no confidence. 
(1) 
For the purposes of Sections 142 (the Prime Minister) and 144 (other Ministers), a 
motion of no confidence is a motion— 
(a) that is expressed to be a motion of no confidence in the Prime Minister, the Ministry 
or a Minister, as the case may be; and 
(b) of which not less than one week’s notice, signed by a number of members of the 
Parliament being not less than one-tenth of the total number of seats in the Parliament, 
has been given in accordance with the Standing Orders of the Parliament. 
(2) 
A motion of no confidence in the Prime Minister or the Ministry— 
(a) moved during the first four years of the life (1). 
Parliament shall not be allowed unless it nominates the next Prime Minister; and 
(b) moved within 12 months before the fifth anniversary of the date fixed for the return 
of the writs at the previous general election shall not be allowed if it nominates the next 
Prime Minister. 
(3) 
A motion of no confidence in the Prime Minister or the Ministry moved in accordance 
with Subsection (2)(a) may not be amended in respect of the name of the person nominated as 
the next Prime Minister except by substituting the name of some other person.
```

---

## Page 71

```text
71
(4) 
A motion of no confidence in the Prime Minister or in the Ministry may not be moved 
during the period of eighteen months commencing on the date of the appointment of the Prime 
Minister. 
(Subsection (4) amended by Constitutional Amendment No.14) 
 
146. Resignation. 
(1) 
The Prime Minister may resign from office by notice in writing to the Head of State. 
(2) 
A Minister other than the Prime Minister may resign from office by notice in writing to 
the Prime Minister. 
147. Normal term of office. 
(1) 
Unless he earlier— 
(a) dies; or 
(b) subject to Subsection (2), resigns; or 
(c) subject to Subsection (3), ceases to be qualified to be a Minister; or 
(d) is dismissed or removed from office, 
a Minister (including the Prime Minister) holds office until the next appointment of a Prime 
Minister. 
(2) 
Notwithstanding Subsection (1)(b)— 
(a) a Prime Minister who resigns; and 
(b) a Ministry that resigns collectively, 
shall continue in office until the appointment of the next Prime Minister. 
(3) 
Notwithstanding Subsection (1)(c), a Minister who— 
(a) ceases, by reason of a general election, to be a member of the Parliament; but 
(b) remains otherwise qualified to be a member of the Parliament, 
shall continue in office until the next appointment of a Prime Minister. 
 
 
148. Functions, etc., of Ministers. 
(1) 
Ministers (including the Prime Minister) have such titles, portfolios and responsibilities 
as are determined from time to time by the Prime Minister. 
(2) 
Except as provided by a Constitutional Law or an Act of the Parliament, all 
departments, sections, branches and functions of government must be the political responsibility 
of a Minister, and the Prime Minister is politically responsible for any of them that are not 
specifically allocated under this section. 
(3) 
Subsection (2) does not confer on a Minister any power of direction or control. 
Subdivision C.—The National Executive Council.
```

---

## Page 72

```text
72
149. The National Executive Council. 
(1) 
A National Executive Council is hereby established. 
(2) 
The Council shall consist of all the Ministers (including the Prime Minister when he is 
present as Chairman). 
(3) 
The functions of the Council are— 
(a) to be responsible, in accordance with this Constitution, for the executive government 
of Papua New Guinea; and 
(b) such other functions as are allocated to it by this Constitution or any other law. 
(4) 
Except where the contrary intention appears, nothing in this Constitution prevents the 
powers, functions, duties or responsibilities of the Council from being exercised, as determined 
by it, through a Minister. 
(5) 
Subject to any Organic Law or Act of the Parliament, the procedures of the Council are 
as determined by it. 
150. The Secretary to the National Executive Council. 
(1) 
An office of Secretary to the National Executive Council is hereby established. 
(2) 
Subject to any Act of the Parliament, the functions and responsibilities of the Secretary 
of the Council shall be as determined by the Council. 
 
Subdivision D.—The Power of Mercy. 
151. Grant of pardon, etc. 
(1) 
Subject to this Subdivision, the Head of State, acting with, and in accordance with, the 
advice of the National Executive Council, may grant to a person convicted of an offence or held 
in penal detention under a law of Papua New Guinea— 
(a) a pardon, either free or conditional; or 
(b) a remission or commutation of sentence; or 
(c) a respite of the execution of sentence; or 
(d) a less severe form of punishment for that imposed by any sentence, 
and may remit or refund, in whole or in part, any fine, penalty or forfeiture paid or payable to a 
governmental body. 
(2) 
Where an offence has been committed, the Head of State, acting with, and in accordance 
with, the advice of the National Executive Council, may grant a pardon, either free or 
conditional, to an accomplice who gives evidence that leads to the conviction of a principal 
offender. 
(3) 
Except in a case referred to in Subsection (2) or as otherwise permitted by or under an 
Act of the Parliament, the exercise of the power conferred by Subsection (1) shall not be held 
out, offered or promised in advance of conviction. 
(4) 
Nothing in this section prevents the establishment by law of systems of probation, 
parole or release on licence, or any similar systems.
```

---

## Page 73

```text
73
(See: Probation Act (Chapter 381); Parole Act 1992) 
 
152. Advisory Committee on the Power of Mercy. 
(1) 
An Organic Law shall make provision for and in respect of an Advisory Committee on 
the Power of Mercy, and for and in respect of its appointment, constitution, powers and 
procedures. 
(See: Organic Law on the Advisory Committee on the Power of Mercy) 
(2) 
Before giving any advice to the Head of State under Section 151(1) (grant of pardon, 
etc.), the National Executive Council shall consider a report from the Advisory Committee. 
Subdivision E.—General. 
153. Validity of executive acts. 
(1) 
Subsections (2), (3) and (4) are subject to any Constitutional Law or Act of the 
Parliament. 
(2) 
The question, whether the procedures prescribed for the National Executive Council 
have been or are being complied with, is non-justiciable. 
(3) 
The question, whether any, and if so what report has been given to the National 
Executive Council by the Advisory Committee on the Power of Mercy, is non-justiciable. 
(4) 
No act of a Minister is open to challenge on the ground that he was not empowered to 
perform the act, if some other Minister, or any Minister, was so empowered. 
(5) 
This section does not limit the jurisdiction or powers of the Ombudsman Commission, 
or of an authority or tribunal established under Division III.2 (leadership code). 
 
 
 
 
Division 5.—The Administration of Justice. 
Subdivision A.—General Structure and Principles of the National Justice 
Administration. 
154. The National Justice Administration. 
The National Justice Administration consists of— 
(a) the National Judicial System; and 
(b) the Minister responsible for the National Justice Administration; and 
(c) the Law Officers of Papua New Guinea. 
155. The National Judicial System. 
(1) 
The National Judicial System consists of—
```

---

## Page 74

```text
74
(a) the Supreme Court; and 
(b) the National Court; and 
(c) such other courts as are established under Section 172 (establishment of other 
courts). 
(2) 
The Supreme Court— 
(a) is the final court of appeal; and 
(b) has an inherent power to review all judicial acts of the National Court; and 
(c) has such other jurisdiction and powers as are conferred on it by this Constitution or 
any other law.(See Supreme Court Act (Chapter 37)) 
(3) 
The National Court— 
(a) has an inherent power to review any exercise of judicial authority; and 
(b) has such other jurisdiction and powers as are conferred on it by this Constitution or 
any law, 
except where— 
(c) jurisdiction is conferred upon the Supreme Court to the exclusion of the National 
Court; or 
(d) the Supreme Court assumes jurisdiction under Subsection (4); or 
(e) the power of review is removed or restricted by a Constitutional Law or an Act of the 
Parliament. (See: National Court Act (Chapter 38)) 
(4) 
Both the Supreme Court and the National Court have an inherent power to make, in 
such circumstances as seem to them proper, orders in the nature of prerogative writs and such 
other orders as are necessary to do justice in the circumstances of a particular case. 
(5) 
In a case referred to in Subsection (3)(e), the National Court has nevertheless an 
inherent power of review where, in its opinion, there are over-riding considerations of public 
policy in the special circumstances of a particular case. 
(6) 
Subject to any right of appeal or power of review of a decision, it is the duty of all 
persons (including the Law Officers of Papua New Guinea and other public officers in their 
respective official capacities), and of all bodies and institutions, to comply with and, so far as is 
within their respective lawful powers, to put into effect all decisions of the National Judicial 
System. 
156. The Law Officers. 
(1) 
The Law Officers of Papua New Guinea are— 
(a) the principal legal adviser to the National Executive; and 
(b) the Public Prosecutor; and 
(c) the Public Solicitor. 
(2) 
An Act of the Parliament shall make provision for and in respect of the office referred to 
in Subsection (1)(a). (See: Attorney General Act 1989) 
157. Independence of the National Judicial System. 
Except to the extent that this Constitution specifically provides otherwise, neither the Minister 
responsible for the National Justice Administration nor any other person or authority (other than
```

---

## Page 75

```text
75
the Parliament through legislation) outside the National Judicial System has any power to give 
directions to any court, or to a member of any court, within that System in respect of the exercise 
of judicial powers or functions. 
Subdivision B.—The Judicial Power. 
158. Exercise of the judicial power. 
(1) 
Subject to this Constitution, the judicial authority of the People is vested in the National 
Judicial System. 
(2) 
In interpreting the law the courts shall give paramount consideration to the dispensation 
of justice. 
159. Tribunals, etc., outside the National Judicial System. 
(1) 
Subject to Subsection (3), nothing in this Constitution prevents an Organic Law or a 
statute from conferring judicial authority on a person or body outside the National Judicial 
System, or the establishment by or in accordance with law, or by consent of the parties, of 
arbitral or conciliatory tribunals, whether ad hoc or other, outside the National Judicial System. 
(2) 
Nothing in, or done in accordance with, Subsection (1) affects the operation of Section 
155(4) or (5) (the National Judicial System). 
(3) 
No person or body outside the National Judicial System, has, or may be given, power to 
impose a sentence of death or imprisonment, or to impose any other penalty as for a criminal 
offence, but nothing in this subsection prevents— 
(a) the imposition, in accordance with law, of disciplinary detention or any other 
disciplinary punishment (other than death) by a disciplinary authority of a disciplined 
force on persons subject to the disciplinary law of the force; or 
(b) the imposition, in accordance with law, of disciplinary punishments (other than death 
or detention) on members of other State or provincial services; or 
(c) the imposition of reasonable penalties (other than death or detention) by an 
association on its members for breaches of its rules. 
(4) 
In Subsection (3)(a), “disciplined force” has the same meaning as in Section 207 
(definition of “disciplined force”). 
Subdivision C.—The Supreme Court of Justice. 
160. Establishment of the Supreme Court. 
(1) 
A Supreme Court of Justice is hereby established. 
(2) 
The Supreme Court is a superior court of record and accordingly, subject to any Act of 
the Parliament, has the power to punish the offence against itself commonly known as contempt 
of court. 
161. Composition of the Supreme Court. 
(1) 
The Supreme Court shall consist of the Chief Justice, the Deputy Chief Justice and the 
other Judges of the National Court (excluding the acting Judges). 
(2) 
Subject to Section 162(2) (jurisdiction of the Supreme Court) and for the purposes of
```

---

## Page 76

```text
76
any hearing, the Supreme Court shall consist of at least three Judges. 
(3) 
In a hearing that consists of at least three Judges, the Chief Justice, the Deputy Chief 
Justice or the most senior Judge available shall preside over the Court. 
162. Jurisdiction of the Supreme Court. 
(1) 
The jurisdiction of the Supreme Court is as set out in— 
(a) Subdivision II.2.C (constitutional interpretation); and 
(b) Subdivision III.3.D (enforcement); and 
(c) Section 155 (the National Judicial System), 
and otherwise as provided by this Constitution or any other law. 
(2) 
In such cases as are provided for by or under an Act of the Parliament or the Rules of 
Court of the Supreme Court, the jurisdiction of the Supreme Court may be exercised by a single 
Judge of that Court, or by a number of Judges sitting together. 
(See: Supreme Court Act (Chapter 37)) 
(3) 
The jurisdiction of the Supreme Court may be exercised by a Judge or Judges of that 
Court notwithstanding that it is being exercised at the same time by another such Judge or 
Judges. 
(4) 
The jurisdiction of the Supreme Court may be exercised either in court or in chambers, 
as provided by or under an Act of the Parliament or the Rules of Court of the Supreme Court. 
Subdivision D.—The National Court of Justice. 
163. Establishment of the National Court. 
(1) 
A National Court of Justice is hereby established. 
(2) 
The National Court is a superior court of record and accordingly, subject to any Act of 
the Parliament, has the power to punish the offence against itself commonly known as contempt 
of court. 
164. Composition of the National Court. 
The National Court shall consist of— 
(a) the Chief Justice; and 
(b) the Deputy Chief Justice; and 
(c) subject to Section 165(2) (Acting Judges) not less than four or more than six other 
Judges, or such greater number as is determined by or under an Act of the 
Parliament. 
(See: National Court (Number of Judges) Act (Chapter 40)) 
165. Acting Judges. 
(1) 
A person who is qualified under Section 168 (qualifications) for appointment may be 
appointed to be an acting Judge of the National Court— 
(a) to fill temporarily a vacancy; or 
(b) in the case of the absence from duty for any reason of a Judge of that Court; or
```

---

## Page 77

```text
77
(c) to meet a temporary unexpected workload or other exigency of the business of the 
Court. 
(2) 
An appointment under Subsection (1)(c) may be made without reference to the 
numerical limit imposed by Section 164 (composition of the National Court). 
166. Jurisdiction of the National Court. 
(1) 
Subject to this Constitution, the National Court is a court of unlimited jurisdiction. 
(2) 
In particular, the National Court has the jurisdiction set out in— 
(a) Section 22 (enforcement of the Constitution); and 
(b) Subdivision III.3.D (enforcement); and 
(c) Section 155 (the National Judicial System), 
and otherwise as provided by this Constitution or any other law. 
(3) 
Subject to any Act of the Parliament and to the Rules of Court of the National Court, the 
jurisdiction of the National Court may be exercised by a single Judge of that Court, or by a 
number of Judges sitting together. 
(4) 
The jurisdiction of the National Court may be exercised by a Judge or Judges of that 
Court notwithstanding that it is being exercised at the same time by another Judge or other 
Judges. 
(5) 
The jurisdiction of the National Court may be exercised either in court or in chambers, 
as provided by or under an Act of the Parliament or the Rules of Court of the National Court. 
167. Assistant Judges. 
Subject to this section, an Act of the Parliament may make provision for and in respect of the 
appointment of Assistant Judges of the National Court, and for and in respect of their 
qualifications, privileges, powers, functions, duties and responsibilities, and of their terms and 
conditions of employment. 
 
 
Subdivision E.—Appointment, etc., of Judges. 
168. Qualifications. 
The qualifications for appointment as a Judge are as determined by or under an Act of the 
Parliament. (See: National Court Act (Chapter 38)) 
169. Appointment, etc., of the Chief Justice. 
(1) 
An office of Chief Justice of Papua New Guinea is hereby established. 
(2) 
The Chief Justice shall be appointed by the Head of State, acting with, and in 
accordance with, the advice of the National Executive Council given after consultation with the 
Minister responsible for the National Justice Administration. 
(3) 
In addition to his other powers, functions, duties and responsibilities, the Chief Justice,
```

---

## Page 78

```text
78
after consultation with the other Judges, is responsible for the organization of the affairs and the 
administration of the business of the Supreme Court and the National Court (other than, except to 
the extent allowed by or under an Act of the Parliament, matters relating to the National Public 
Service). (See: National Judicial Staff Service Act 1987) 
(4) 
Where— 
(a) there is a vacancy in the office of Chief Justice; or 
(b) the Chief Justice is absent from the country or is absent from duty; or 
(c) the Chief Justice is unable or unavailable to act; or 
(d) the Chief Justice so directs, 
the powers, functions, duties and responsibilities (other than as acting Governor-General) of the 
Chief Justice may be exercised and performed by the next most senior Judge who is available. 
(5) 
The question, whether the occasion for the exercise or performance of the powers, 
functions, duties and responsibilities of the Chief Justice by another Judge under this section has 
arisen or has ceased, is non-justiciable. 
170. Appointment of other Judges. 
(1) 
An office of Deputy Chief Justice of Papua New Guinea is hereby established. 
(2) 
The Deputy Chief Justice and the other Judges of the National Court (other than the 
Chief Justice) and acting Judges shall be appointed by the Judicial and Legal Services 
Commission. 
(3) 
No appointment of an acting Judge shall continue for a period of more than 12 months, 
but one extension for a period of not more than 12 months may be granted by the Judicial and 
Legal Services Commission. 
(4) 
The question, whether the occasion for the appointment of an acting Judge has arisen or 
has ceased, is non-justiciable. 
171. Seniority of Judges. 
(1) 
Subject to Subsection (2), the Chief Justice is the most senior Judge, the Deputy Chief 
Justice is the second senior Judge and the other Judges (other than acting Judges) have seniority 
according to the dates of their respective appointments, unless otherwise stated in an instrument 
of appointment. 
(2) 
Unless otherwise stated in an instrument of appointment, acting Judges— 
(a) rank in seniority after the other Judges; and 
(b) have seniority as between themselves according to the dates of their respective 
appointments or last appointments, as the case requires 
Subdivision F.—Inferior Courts, the Magisterial Service, etc. 
172. Establishment of other courts. 
(1) 
Subject to this Constitution, Acts of the Parliament may establish, or provide for the 
establishment of, courts within the National Judicial System in addition to the Supreme Court 
and the National Court, and may define, or provide for the definition of, their respective powers, 
functions and jurisdictions and their relationship with other components of the National Judicial
```

---

## Page 79

```text
79
System. (See: District Courts Act (Chapter 40); Village Courts Act 1989; 
Local Courts Act (Chapter 41); Juvenile Courts Act 1991) 
(2) 
Courts established under Subsection (1) may include courts intended to deal with 
matters primarily by reference to custom or in accordance with customary procedures, or both. 
(See: Village Courts Act 1989) 
(3) 
Full-time members of courts established under Subsection (1) (other than courts referred 
to in Subsection (2)) shall be appointed by the Judicial and Legal Services Commission, and may 
be removed from office in accordance with an Act of the Parliament, but only for incapacity or 
misbehaviour (including, if applicable, misconduct in office). 
(4) 
Acts of the Parliament may make provision for or in respect of the appointment and 
removal from office of members of courts referred to in Subsection (2). 
173. Establishment of the Magisterial Service. 
(1) 
A service to be known as the Magisterial Service is hereby established. 
(2) 
The Magisterial Service consists of— 
(a) the Chief Magistrate; and 
(b) subject to Section 174 (magistrates, etc., outside the Magisterial Service), all other 
members of courts established under Section 172 (establishment of other courts); and 
(c) such other persons employed in connexion with the National Judicial System as are 
prescribed by or under Acts of the Parliament. 
(3) 
The Chief Magistrate is responsible to the Judicial and Legal Services Commission for 
the efficient functioning and operation of the Magisterial Service. 
(4) 
Subject to the Constitutional Laws, an Act of the Parliament shall make provision for 
and in respect of the Magisterial Service. (See: Magisterial Service Act (Chapter 43)) 
174. Magistrates, etc., outside the Magisterial Service. 
(1) 
Unless and except to the extent that an Act of the Parliament makes provision to the 
contrary, members of village courts are not, as such, members of the Magisterial Service. 
(2) 
An Act of the Parliament may provide for part-time members of courts established 
under Section 172 (establishment of other courts), who need not be members of the Magisterial 
Service. 
175. The Chief Magistrate. 
(1) 
An office of Chief Magistrate is hereby established. 
(2) 
The Chief Magistrate shall be appointed by the Judicial and Legal Services 
Commission. 
(3) 
Unless and except to the extent that an Act of the Parliament makes provision to the 
contrary, the Chief Magistrate is ex officio a member of all courts (other than village courts) 
established under Section 172 (establishment of other courts), and, if provision is made for 
grades of powers, functions or jurisdiction within any such courts, has all the powers, functions 
and jurisdiction of the highest grades.
```

---

## Page 80

```text
80
(4) 
In the performance of his functions under Section 173(3) (establishment of the 
Magisterial Service), the Chief Magistrate shall carry out any directions or instructions of the 
Judicial and Legal Services Commission. 
Subdivision G.—The Public Prosecutor and the Public Solicitor. 
176. Establishment of offices. 
(1) 
Offices of Public Prosecutor and Public Solicitor are hereby established. 
(2) 
The Public Prosecutor and the Public Solicitor shall be appointed by the Judicial and 
Legal Services Commission. 
(3) 
Subject to this Constitution— 
(a) in the performance of his functions under this Constitution the Public Prosecutor is 
not subject to direction or control by any person or authority; but 
(b) nothing in paragraph (a) prevents the Head of State, acting with, and in accordance 
with, the advice of the National Executive Council, giving a direction to the Public 
Prosecutor on any matter that might prejudice the security, defence or international 
relations of Papua New Guinea (including Papua New Guinea‘s relations with the 
Government of any other country or with any international organization). 
(4) 
The Prime Minister shall table in the National Parliament any direction to the Public 
Prosecutor at the next sitting of the Parliament after the direction is given unless, after 
consultation with the Leader of the Opposition, he considers that tabling of the direction is likely 
to prejudice the security, defence or international relations of Papua New Guinea. 
(5) 
Subject to Section 177(2) (functions of the Public Prosecutor and the Public Solicitor), 
in the performance of his functions under this Constitution the Public Solicitor is not subject to 
direction or control by any person or authority. 
177. Functions of the Public Prosecutor and the Public Solicitor. 
(1) 
The functions of the Public Prosecutor are— 
(a) in accordance with an Act of the Parliament and the Rules of Court of the Supreme 
Court and the National Court, to control the exercise and performance of the prosecution 
function (including appeals and the refusal to initiate and the discontinuance of 
prosecutions) before the Supreme Court and the National Court, and before other Courts 
as provided by or under Acts of the Parliament; and 
(b) to bring or to decline to bring proceedings under Division III.2 (leadership code) for 
misconduct in office. (See: Public Prosecutor (Office & Finance) Act 
(Chapter 338)) 
(2) 
The functions of the Public Solicitor are to provide legal aid, advice and assistance for 
persons in need of help by him, and in particular— 
(a) to provide legal assistance to a person in need of help by him who has been charged 
with an offence punishable by imprisonment for more than two years; and 
(b) notwithstanding the provisions of Section 176(5) (establishment of offices) he shall 
provide legal aid, advice and assistance to any person when directed to do so by the 
Supreme Court or the National Court; and 
(c) in his discretion in any matter, whether of a criminal or civil nature provided that
```

---

## Page 81

```text
81
such assistance shall be— 
(i) 
limited to advice and preparation of documents in any proceedings in respect of 
which an Act of the Parliament prohibits legal representation of any party to the 
proceedings; and 
(ii) 
granted in accordance with an order of priorities relative to the resources of the 
Public Solicitor laid down by an Act of the Parliament. 
(3) 
A person aggrieved by a refusal of the Public Solicitor to provide legal aid may apply to 
the Supreme Court or the National Court for a direction under Subsection (2)(b). 
(4) 
For the purposes of this section the need of a person is to be interpreted in relation to 
each particular case and, without limiting the generality of this expression, account shall be taken 
of the means of the person to meet the probable cost of obtaining alternative legal assistance, the 
availability of such assistance and the hardship which might result to the person if compelled to 
obtain legal assistance other than by the Public Solicitor. 
(5) 
An Act of Parliament may make provision for the Public Solicitor to make a reasonable 
charge for services provided by him to persons in need of his help whom he considers are able to 
make a contribution towards the cost of these services. 
(See: Public Solicitor (Charges) Act (Chapter 337)) 
(6) 
An Act of the Parliament may confer, or may provide for the conferring of, additional 
functions, not inconsistent with the performance of the functions conferred by Subsections (1) 
and (2), on the Public Prosecutor or the Public Solicitor. 
Subdivision H.—Removal from Office of Senior Judicial and Legal Office-holders. 
178. Grounds of removal. 
A Judge, the Public Prosecutor, the Public Solicitor or the Chief Magistrate may, during his term 
of office, be removed from office only— 
(a) for inability (whether arising from physical or mental infirmity or otherwise) to 
perform the functions and duties of his office; or 
(b) for misbehaviour; or 
(c) in accordance with Division III.2 (leadership code), for misconduct in office. 
179. Removal from office of Chief Justice. 
(1) 
If the National Executive Council is satisfied that the question of the removal from 
office of the Chief Justice should be investigated, the Head of State, acting with, and in 
accordance with, the advice of the National Executive Council, may— 
(a) appoint a tribunal under Section 181 (constitution, etc., of tribunals); and 
(b) refer the matter, together with a statement of the reasons for its opinion, to the 
tribunal for investigation and report to it. 
(2) 
If the tribunal reports that there are good grounds for removing the Chief Justice from 
office, the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council, may, by notice in writing to the Chief Justice, remove him from office. 
(3) 
The Prime Minister shall send a copy of the notice, together with a copy of the report of 
the tribunal, to the Speaker for presentation to the Parliament, and shall also forward copies to
```

---

## Page 82

```text
82
the Judicial and Legal Services Commission. 
180. Removal from office of other Judges, etc. 
(1) 
If the Judicial and Legal Services Commission is satisfied that the question of the 
removal from office of a Judge (other than the Chief Justice), the Public Prosecutor, the Public 
Solicitor or the Chief Magistrate should be investigated, it may— 
(a) appoint a tribunal under Section 181 (constitution, etc., of tribunals); and 
(b) refer the matter, together with a statement of the reasons for its opinion, to the 
tribunal for investigation and report to it. 
(2) 
If the tribunal reports that there are good grounds for removing the Judge, Public 
Prosecutor, Public Solicitor or Chief Magistrate from office, the Judicial and Legal Services 
Commission, may, by notice in writing to the Judge, Public Prosecutor, Public Solicitor or Chief 
Magistrate, as the case may be, remove him from office. 
(3) 
The Commission shall send a copy of the notice, together with a copy of the report of 
the tribunal, to the Speaker for presentation to the Parliament. 
181. Constitution, etc., of tribunals. 
(1) 
A tribunal for the purposes of Section 179 (removal from office of Chief Justice) or 180 
(removal from office of other Judges, etc.) shall consist of a Chairman and two other members, 
each of whom must be— 
(a) a Judge or former Judge of the Supreme Court or of the National Court; or 
(b) a former Judge or acting Judge of the pre-Independence Supreme Court; or 
(c) a Judge or former Judge of a court of unlimited jurisdiction of a country with a legal 
system similar to that of Papua New Guinea, or of a court to which an appeal from such 
a court lies. 
(2) 
The tribunal shall make due inquiry into any matter referred to it without regard to legal 
formalities or the rules of evidence, and shall inform itself in such manner as it thinks proper, 
subject to compliance with the principles of natural justice. 
182. Suspension. 
(1) 
Where a question has been referred to a tribunal under this Subdivision— 
(a) the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council, in the case of the Chief Justice; or 
(b) the Judicial and Legal Services Commission, in any other case, 
may suspend the person concerned from office pending the report of the tribunal, and may 
remove the suspension at any time. 
(2) 
Unless otherwise determined by the Head of State, acting with, and in accordance with, 
the advice of the National Executive Council, or by the Judicial and Legal Services Commission, 
as the case may be, the suspension shall be on full pay. 
(3) 
Where at the time of the suspension, a suspended Judge or Chief Magistrate was dealing 
with any judicial proceedings, he may continue and complete those proceedings, unless the 
Judicial and Legal Services Commission in the case of the Chief Justice, or the Chief Justice in
```

---

## Page 83

```text
83
any other case, otherwise orders. 
Subdivision I.—The Judicial and Legal Services Commission. 
183. Establishment of the Commission. 
(1) 
A Judicial and Legal Services Commission is hereby established. 
(2) 
Subject to Subsection (3), the Commission consists of— 
(a) the Minister responsible for the National Justice Administration, or a person 
nominated by him, who is the Chairman; and 
(b) the Chief Justice; and 
(c) the Deputy Chief Justice; and 
(d) the Chief Ombudsman; and 
(e) a member of the Parliament appointed by the Parliament. 
(3) 
When the Commission is considering a matter relating to the appointment or removal 
from office of a member of the Magisterial Service, or any other matter relating to the 
Magisterial Service prescribed for the purposes of this subsection by or under an Act of the 
Parliament, the Chief Magistrate is (except in a matter involving himself) an additional member 
of the Commission. 
(4) 
The Commission is not subject to direction or control by any person or authority. 
(5) 
An Organic Law may make further provision in respect of the constitution, powers, 
functions, duties and responsibilities of the Commission, and for guaranteeing its independence. 
(See: Organic Law on the Judicial and Legal Services Commission) 
Subdivision J.—Miscellaneous. 
184. Rules of court. 
(1) 
The Judges of the Supreme Court or of the National Court may make rules of court, not 
inconsistent with a Constitutional Law or an Act of the Parliament, with respect to the practice 
and procedure in and in relation to the Supreme Court or the National Court, as the case may be. 
(2) 
Without limiting the generality of Subsection (1), the rules may make provision for and 
in respect of— 
(a) the practice and procedures in the offices of the Supreme Court and the National 
Court; and 
(b) the service and execution of process and judgements of the Supreme Court and the 
National Court; and 
(c) the service and execution within the country of process and judgements of foreign 
courts; and 
(d) the issue by the Supreme Court or the National Court of letters of request for the 
service in a foreign country of process of the Supreme Court or the National Court, as 
the case may be, or for the examination of witnesses in a foreign country; and 
(e) the costs of and relating to proceedings in the Supreme Court or the National Court; 
and 
(f) the methods of pleading; and
```

---

## Page 84

```text
84
(g) the attendance of witnesses and the taking of evidence; and 
(h) the means by which particular facts may be proved, and the manner in which 
evidence of particular facts may be given, in any proceedings or in any application in 
connexion with, or at any stage of, any proceedings. 
(3) 
The rules of court may require or permit legal argument to be submitted in writing. 
(4) 
If an Act of the Parliament comes into force that is inconsistent with a rule of court, the 
rule ceases to have effect to the extent of the inconsistency. 
(5) 
All rules of court shall be forwarded by the Chief Justice to the Speaker, for 
presentation to the Parliament, as soon as practicable after being made, and may be disallowed 
by the Parliament. 
185. Lack of procedural provision. 
If in the circumstances of a particular case before a court no provision, or no adequate provision, 
is made in respect of a matter of practice or procedure, the court shall give ad hoc directions to 
remedy the lack or inadequacy. 
186. Juries and assessors. 
Nothing in this Division prevents the establishment, by or under an Act of the Parliament, of a 
system of juries or assessors.  
(See: National Court Assessors (T.N.G) Act (Chapter 42)) 
187. Reports by Judges. 
(1) 
The Judges shall, at least once in each period of 12 months, at such times as are fixed by 
or under an Act of the Parliament or, subject to any such Act, by the Head of State, acting with, 
and in accordance with, the advice of the National Executive Council, give to the Head of State, 
for presentation to the Parliament, a report on the work of the National Judicial System, with 
such recommendations as to improvement as they think proper. 
(2) 
Nothing in Subsection (1) prevents the Judges from making, on their own initiative or at 
the request of the Parliament or of the National Executive, other reports on any aspect of the 
work of the National Judicial System. 
 
PART VIA.—PROVINCIAL GOVERNMENTS AND LOCAL-LEVEL GOVERNMENTS. 
187A. 
Provincial Governments and Local-level Governments system. 
There shall be a system of Provincial Governments and Local-level Governments for Papua New 
Guinea in accordance with this Part. 
187B. 
Grant of Provincial Government and Local-level Government. 
An Organic Law shall provide for, or make provision in respect of, the form and the manner of 
establishment of the Provincial Governments and the Local-level Governments. 
(See: Organic Law on Provincial Governments and Local-level 
Governments)
```

---

## Page 85

```text
85
187C. 
Constitution, functions, etc., of Provincial Governments and Local-level 
Governments. 
(1) 
Subject to this Part, an Organic Law shall make provision in respect of the constitution, 
powers and functions of a Provincial Government or a Local-level Government. 
(2) 
For each Provincial Government and Local-level Government, there shall be 
established— 
(a) a mainly elective (elected directly or indirectly), legislature with such powers as are 
conferred by law; and 
(b) an executive; and 
(c) an office of head of the executive. 
(3) 
An Organic Law shall provide for the minimum number of members for the Provincial 
Assemblies and Local-level Governments and the maximum number of members that may be 
appointed as nominated members of Provincial Assemblies and Local-level Governments. 
(4) 
An Organic Law shall make provision for and in respect of— 
(a) grants by the National Government to Provincial Governments and Local-level 
Governments; and 
(b) subject to Subsection (4A), the imposition, collection and distribution of taxation by 
Provincial Governments and Local-level Governments, 
and may make other financial provisions for Provincial Governments and Local-level 
Governments, to an extent reasonably adequate for the performance of their functions. 
(4A) 
Where an Organic Law provides for the imposition, collection and distribution by 
Provincial Governments and Local-level Governments of sales and service tax, it may also 
provide that the National Government has concurrent power to impose, collect and distribute 
sales and service tax. 
(4B) 
An Act or Acts of the Parliament— 
(a) passed during the period between 19 July 1995 and the date of certification of 
Constitutional Amendment No 27—Sales and Services Tax; and 
(b) providing for the National Government to impose, collect and distribute a sales and 
services tax (by whatever name known), 
are validated, to the extent that the provisions of the Act or Acts were in contravention of this 
Constitution, in accordance with Schedule 6. 
(5) 
An Organic Law shall make provision for the devolution and delegation to each 
Provincial Government and Local-level Government of substantial powers of decision-making 
and substantial administrative powers in respect of matters of direct concern to the province and 
to the local-level government area. 
(6) 
An Organic Law shall make provision in respect of the legislative powers of Provincial 
Governments and Local-level Governments. 
(7) 
A question of the adequacy of provision made under Subsection (3), (4), (5) or (6) is 
non-justiciable. 
(8) 
Elections to a Local-level Government shall be conducted, in accordance with an
```

---

## Page 86

```text
86
Organic Law, by the Electoral Commission.  
See: Organic Law on Provincial Governments and Local-Level 
Governments ) 
187D. 
Inconsistency and justiciability of provincial laws and local-level laws. 
(1) 
Subject to any Constitutional Law, the application by its own force of an Act of the 
Parliament is not affected by a provincial law or a local-level law. 
(2) 
Nothing in this Part authorises the making of a provincial law or a local-level law, or 
authorises any other action, that is inconsistent with— 
(a) this Constitution (and in particular with Division 3 (Basic Rights)); or 
(b) an Organic Law, 
and all questions as to such consistency are justiciable. 
(3) 
In order to avoid fruitless controversy and litigation, an Organic Law may provide that a 
question as to the effect of Subsection (1) is non-justiciable either absolutely or to the extent or 
in the cases prescribed by the Organic Law, except in proceedings between the National 
Government and a Provincial Government or a Local-level Government, or between  
governments. 
 (See: Organic Law on Provincial Governments and Local-Level 
Governments) 
187E. 
Suspension of Provincial Governments and Local-level Governments. 
(1) 
Where a Provincial Government or a Local-level Government undermines or attempts 
to undermine the authority of the National Parliament or the national unity, the National 
Executive Council may provisionally suspend the Provincial Government or the Local-level 
Government concerned subject to confirmation by an absolute majority vote of the Parliament. 
(Subsection(1) repealed and replaced by Constitutional Amendment No.7) 
(2) 
An Organic Law may make provision for and in respect of the procedures to be 
followed in the exercise of the powers under Subsection (1). 
(Subsection (2) repealed and replaced by Constitutional Amendment No.7) 
(See: Organic Law on Provincial Governments and Local-level 
Governments) 
(3) 
An Organic Law may make provision for further defining any matter referred to in 
Subsection (1). 
(4) 
The National Executive Council may suspend a Provincial Government or a Local-level 
Government that cannot carry out its functions effectively because of a war or a national 
emergency declared under Part X (emergency powers) affecting the province, local-level 
government area or the whole of the country. 
(5) 
While a Provincial Government or a Local-level Government is suspended, its powers 
and functions are vested in and shall be exercised by or on behalf of the National Executive 
Council, in accordance with an Organic Law.
```

---

## Page 87

```text
87
(See: Organic Law on Provincial Governments and Local-level 
Government) 
(6) 
Where a Provincial Government or a Local-level Government is suspended— 
(a) in the case of a suspension under Subsection (4), the Minister responsible for 
provincial government and local-level government matters, shall, as soon as practicable 
and in any event not later than the first meeting of the Parliament after the suspension, 
table in the Parliament a report on the suspension, the reasons for it and the 
circumstances of it; and 
(b) at each meeting of the Parliament during the suspension, the Minister responsible for 
provincial government and local-level government matters shall report to the Parliament 
on the measures taken to re-establish the Provincial Government or the Local-level 
Government, as the case may be. 
187F. 
Re-establishment of Provincial Governments and Local-level 
Governments. 
(1) Subject to Subsections (2) and (3), if a Provincial Government or a Local-level 
Government is suspended, arrangements shall be made to re-establish it within nine 
months from the effective date of suspension 
(Subsection (1) amended by Constitutional Amendment No.7) 
(2) 
Subject to Subsections (3) and (4), where— 
(a) a Provincial Government or a Local-level Government is suspended under Section 
187E(4) (suspension of Provincial Governments and Local-level Governments) as a 
result of a declaration of a national emergency under Section 228 (declaration of 
national emergency); and 
(b) the declaration is extended under Section 239(3) (Parliamentary control), 
the period of nine months referred to in Subsection (1) runs from the end of the meeting (or if 
there are more such extensions than one the last meeting) of the Parliament at which the 
declaration is so extended. 
(3) 
A period of nine months referred to in the preceding provisions of this section may be 
extended by periods, each not exceeding six months, by the Parliament by a simple majority 
vote. 
(4) 
Subject to Subsection (3), where a Provincial Government or a Local-level Government 
is suspended under Section 187E(4) (suspension of Provincial Governments and Local-level 
governments) the period of suspension, unless earlier terminated, ends at the end of nine months 
after the end of the war or national  for the purposes of Part X. 
emergency concerned. 
187G. 
Gradations of Provincial Governments and Local-level Governments. 
Nothing in any law is inconsistent with this Part so far as it provides for the full status, powers or 
functions of Provincial Governments and Local-level Governments to be acquired by a 
Provincial Government and a Local-level Government in stages, or provides for a gradation of 
Provincial Governments and Local-level Governments or provides for Interim Provincial 
Governments.
```

---

## Page 88

```text
88
187H. 
National Economic and Fiscal Commission. 
(1) An Organic Law shall make provision for and in respect of a National Economic and 
Fiscal Commission. 
(See: Organic Law on Provincial and Local-Level Governments) 
(2) 
The Commission, in addition to any other functions prescribed by an Organic Law, 
shall— 
(a) assess and monitor the economic and fiscal policies of the National Government, 
Provincial Governments and Local-level Governments; and 
(b) advise and recommend to the National Executive Council, appropriate policies; and 
(c) make recommendations to the National Executive Council and to the National 
Parliament on the financial arrangements and allocation of grants— 
(i) 
by the National Government to Provincial Governments and Local-level 
Governments; and 
(ii) 
between Provincial Governments and Local-level Governments. 
(See: Organic Law on Provincial and Local-Level Governments) 
187I.  
Local and village governments. 
(1) 
Until an Organic Law makes provision for government at the local level, and such 
provision is implemented in accordance with the Organic Law the Local Government Act 
(Chapter 57), as in force from time to time, continues to apply in respect of such government in 
the province. 
 (2) 
An Organic Law shall make provision for the respective powers of the National 
Government and of Provincial Governments concerning Local-level Governments. 
187J. 
Reports on Provincial Governments and Local-level Governments. 
The Minister responsible for provincial government and local-level government matters shall, at 
least once in each period of 12 months, at such times as are fixed— 
(a) by or under an Act of the Parliament; or 
(b) subject to any such Act, by the Head of State, acting with, and in accordance with, 
the advice of the National Executive Council, 
present to the Head of State, for presentation to the Parliament, a report on the working of the 
system of Provincial Governments and Local-level Governments. 
(See: Organic Law on Provincial Governments and Local-Level 
Governments) 
 
PART VII.—THE STATE SERVICES. 
Division 1.—Introductory. 
188. Establishment of the State Services.
```

---

## Page 89

```text
89
(1) 
The following State Services are hereby established:— 
(a) the National Public Service; and 
(b) the Police Force; and 
(c) the Papua New Guinea Defence Force; and 
(d) the Parliamentary Service. 
(2) 
Acts of the Parliament may make provision for or in respect of other State Services. 
189. Civilian control. 
All of the State Services other than the Defence Force shall be civilian services, and all of the 
State Services shall be subject at all times to ultimate civilian control. 
 
Division 2.—The Public Services Commission. 
 
190. Establishment of the Commission. 
(1) 
A Public Services Commission is hereby established. 
(2) 
The Commission shall consist of three members who shall be appointed for a term of 
five years by the Head of State, acting with, and in accordance with, the advice of a Public 
Services Commission Appointments Committee consisting of— 
(a) the Prime Minister, who shall be Chairman; and 
(b) the Chief Justice; and 
(c) the Leader of the Opposition; and 
(d) the Chairman of the appropriate Permanent Parliamentary Committee, or, if the 
Chairman is not a member of the Parliament who is recognized by the Parliament as 
being generally committed to support the Government in the Parliament, the Deputy 
Chairman of that Committee; and 
(e) the Chief Ombudsman. 
(2A) 
The Head of State, acting with, and in accordance with, the advice of the Public 
Services Commission Appointments Committee, shall appoint one of the members of the Public 
Services Commission to be Chairman of the Public Services Commission. 
(3) 
All of the members of the Commission must be citizens who have gained substantial 
experience in the National Public Service. 
(4) 
Subject to this Constitution, an Act of the Parliament shall make provision for and in 
respect of acting appointments and conditions of employment of the Chairman and members of 
the Commission, and for and in respect of its constitution, powers and procedures. 
(Section 190 repealed and replaced by Constitutional Amendment No.8) 
(See: Public Services (Management )Act 1995) 
191. Functions of the Commission. 
(1) 
The Public Services Commission shall be responsible, in accordance with an Act of the 
Parliament, for— 
(a) the review of personnel matters connected with the National Public Service; and
```

---

## Page 90

```text
90
(b) the continuous review of the State Services (other than the Papua New Guinea 
Defence Force), and the services of other governmental bodies, and to advise, either on 
its own initiative or on request, the National Executive Council and any authority 
responsible for any or those services, on organizational matters. 
(2) 
The Public Services Commission has such other functions as may be prescribed by or 
under a Constitutional Law or an Act of the Parliament. 
(3) 
In carrying out its function under Subsection (1)(b), the Public Services Commission— 
(a) shall take into account the government policy on a particular matter when advising 
the National Executive Council and the other authorities responsible for those services; 
and 
(b) shall not have any power to direct or control a State Service or the services of other 
governmental bodies. 
(4) 
The Public Services Commission shall, in respect of each year, prepare and forward to 
the Speaker for presentation to the Parliament, a report on the advice it has given during the year 
to the National Executive Council or other authorities in accordance with Subsection (1)(b) 
indicating in particular the nature of the advice given and whether or not that advice was 
accepted. 
(Section 191 repealed and replaced by Constitutional Amendment No.9) 
192. Independence of the Commission. 
The Public Services Commission is not subject to direction or control when carrying out its 
function under Section 191(1)(a) (functions of the Commission). 
(Section 192 repealed and replaced by Constitutional Amendment No.8) 
 
 
193. Appointments to certain offices. 
(1) 
This section applies to and in respect of the following offices and positions:— 
(a) all offices in the National Public Service the occupants of which are directly 
responsible to the National Executive Council or to a Minister; and 
(b) the offices of the members of the Boundaries Commission; and 
(c) the office the occupant of which is responsible for the administration of the 
Government broadcasting service, or, if that responsibility rests with a board or 
commission, the chairman or president of the board or commission; and 
(d) the offices of the persons (including members of boards or commissions) responsible 
for the administration of any of the State Services; and 
(e) the office of Commissioner of Police; and 
(f) the office of Commander of the Defence Force; and 
(g) the office of Secretary to the National Executive Council; and 
(h) such other offices and positions as are prescribed by an Act of the Parliament for the 
purpose,
```

---

## Page 91

```text
91
other than the offices of the members of the Public Services Commission. 
(1A) 
All substantive appointments to offices to which Subsection (1)(a), (g) and (h) apply 
shall be made by the Head of State, acting with, and in accordance with, the advice of the 
National Executive Council from a list of persons recommended by the Public Services 
Commission following procedures prescribed by or under an Act of the Parliament. 
(1B) 
All temporary appointments to offices to which Subsection (1)(a), (g) or (h) apply shall 
be made by the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council in accordance with a recommendation by the Public Services Commission 
following procedures prescribed by or under an Act of the Parliament. 
(1C) 
The revocation of appointment of persons appointed under Subsection (1A) or (1B) 
shall be made by the Head of State, acting with, and in accordance with, the advice of the 
National Executive Council given in accordance with a recommendation by the Public Services 
Commission following procedures prescribed by or under an Act of the Parliament. 
(1D) 
The suspension from office of persons appointed under Subsection (1A) or (1B) shall be 
made by the Head of State, acting with, and in accordance with, a recommendation by the Public 
Services Commission following procedures prescribed by or under an Act of the Parliament. 
(2) 
All appointments (whether temporary or substantive) to offices to which Subsection 
(1)(b), (c), and (e) apply shall be made by the Head of State, acting with, and in accordance with, 
the advice of the National Executive Council given after consultation with the Public Services 
Commission and any appropriate Permanent Parliamentary Committee, and a report concerning 
each of them shall be given to the Parliament by the responsible Minister as soon as possible 
after it has been made. 
(3) 
All appointments (whether temporary or substantive) to which Subsection (1)(d) and (f) 
apply and such other offices and positions as are prescribed by an Act of the Parliament for the 
purpose of this subsection, shall be made by the Head of State, acting with, and in accordance 
with, the advice of the National Executive Council given after consultation with the Public 
Services Commission. 
(4) 
An Act of the Parliament may make provision for and in respect of a temporary 
appointment to an office to which this section applies until such time as it is practicable to make 
an appropriate substantive appointment in accordance with Subsection (2). 
194. “Personnel matters”. 
In this Division, “personnel matters” means decisions and other service matters concerning an 
individual whether in relation to his appointment, promotion, demotion, transfer, suspension, 
disciplining or cessation or termination of employment (except cessation or termination at the 
end of his normal period of employment as determined in accordance with law), or otherwise. 
 
Division 3.—The State Services Generally. 
195. Organization, etc., of the State Services. 
Subject to this Part, Acts of the Parliament may make provision for or in respect of the State 
Services, and in particular for and in respect of—
```

---

## Page 92

```text
92
(a) the structures and organizations of the State Services; and 
(b) the employment of persons in the State Services; and 
(c) the terms and conditions of appointment to, and of employment in, the State 
Services. 
Division 4.—Special Provisions in Relation to the Police Force. 
196. Control of the Police Force. 
(1) 
The Police Force is subject to the control of the National Executive Council through a 
Minister. 
(2) 
The Minister has no power of command within the Police Force, except to the extent 
provided for by a Constitutional Law or an Act of the Parliament. 
197. Functions of the Police Force. 
(1) 
The primary functions of the Police Force are, in accordance with the Constitutional 
Laws and Acts of the Parliament— 
(a) to preserve peace and good order in the country; and 
(b) to maintain and, as necessary, enforce the law in an impartial and objective manner. 
(2) 
Insofar as it is a function of the Police Force to lay, prosecute or withdraw charges in 
respect of offences, the members of the Police Force are not subject to direction or control by 
any person outside the Force. 
(3) 
It is a further function of the Police Force to assist in the fulfilment by Papua New 
Guinea of its international obligations by taking part in an international peace-keeping or relief 
operation. 
(4) 
The Police Force, or a part of the Police Force, in respect of its function under 
Subsection (3)— 
(a) may be ordered on or committed to an international peace-keeping or relief operation 
only by the Head of State, acting with, and in accordance with, the advice of the 
National Executive Council, given after the approval of the Parliament; and 
(b) shall operate in another country in accordance with an Act of the Parliament which 
makes provision for its presence in that other country and in particular for or in respect 
of— 
(i) 
the assertion of the exclusive jurisdiction of courts and tribunals of Papua New 
Guinea, and of Police Force authorities, over members of the Police Force in that 
other country; and 
(ii) 
the manner of its operations in that other country. 
198. Commissioner of Police. 
There shall be, within the Police Force, an office of Commissioner of Police, who shall be 
responsible for the superintendence, efficient organization and control of the Force in accordance 
with an Act of the Parliament. (See: Police Force Act 1996) 
199. Other forces.
```

---

## Page 93

```text
93
There shall be only one Police Force in Papua New Guinea, but this section does not prevent— 
(a) the creation of reserve or special forces, or other similar forces (by whatever name 
known); or 
(b) the creation of special bodies, or the authorization of persons other than members of 
the Police Force, for the administration or enforcement of particular laws; or 
(c) the conferring of police powers on persons who are not members of the Police Force, 
by or under an Act of the Parliament. (See: Police Force Act 1996) 
 
Division 5.—Special Provisions in Relation to the Defence Force. 
200. Raising unauthorized forces. 
(1) 
It is strictly forbidden to establish, organize, equip, train or take part in or associate with 
a military or para-military force, or to organize or take part in military or para-military training, 
except such as is provided for by this Constitution, or to plan, prepare for or assist in the raising 
or training of such a force or in such training. 
(2) 
Subsection (1) does not prevent— 
(a) the establishment of a reserve, auxiliary or special force (by whatever name known) 
as part of the Defence Force; or 
(b) the establishment of civilian components of the Defence Force, or the establishment 
or recognition of non-combatant units or organizations within, attached to or associated 
with the Defence Force, 
in accordance with an Act of the Parliament. (See: Defence Force Act (Chapter 74)) 
(3) 
An Act of the Parliament may provide that Subsection (1) does not apply to the armed 
forces of any other country specified in or under the Act, or to the civilian components of, or to 
the non-combatant units or organizations whether attached to or associated with such forces. 
201. Control of the Defence Force. 
(1) 
There shall be no office of Commander-in-Chief of the Defence Force, whether 
honorary or otherwise. 
(2) 
The Defence Force is subject to the superintendence and control of the National 
Executive Council, through the Minister responsible for the Defence Force. 
(3) 
No serving member of the Defence Force may be the Minister responsible for the 
Defence Force. 
(4) 
The Minister responsible for the Defence Force shall not use any military rank or title, 
and, except to the extent provided for by Constitutional Law or an Act of the Parliament, has no 
power of command within the Defence Force. 
(5) 
There shall be— 
(a) within the Defence Force, an office of Commander of the Defence Force, who shall 
be the principal military adviser to the Minister responsible for the Defence Force on 
matters relating to the Defence Force; and 
(b) within the National Public Service, an officer of the Service, who shall be the
```

---

## Page 94

```text
94
principal civilian adviser to the Minister on matters relating to the Defence Force, 
and each of whom shall have such other powers, functions, duties and responsibilities as are 
prescribed by or under an Act of the Parliament. (See: Defence Force Act (Chapter 74)) 
202. Functions of the Defence Force. 
The functions of the Defence Force are— 
(a) to defend Papua New Guinea and its territory; and 
(b) to assist in the fulfilment by Papua New Guinea of its international obligations; and 
(c) to provide assistance to civilian authorities— 
(i) 
in a civil disaster; or 
(ii) 
in the restoration of public order and security on being called out in accordance 
with Section 204 (call-out in aid to the civil power); or 
(iii) in accordance with an Act of the Parliament during a period of declared 
national emergency under Part X. (emergency powers); and 
(d) to perform, as directed, functions and services of a civil nature so as to participate to 
the maximum in the task of national development and improvement, 
either within the country or outside it, in accordance with this Constitution and Acts of the 
Parliament. (See: Defence Force Act (Chapter 74)) 
203. Application of general law. 
Since it is necessary that the Defence Force and the members of the Defence Force have no 
special position under the law except to such extent as is required by the nature of the Force as a 
disciplined force and its peculiar functions, duties and responsibilities, it is hereby declared that, 
except as is specifically provided by a Constitutional Law or an Act of the Parliament, the 
Defence Force and the members of the Defence Force are subject to all laws in the same way as 
other bodies and persons. 
204. Call-out in aid to the civil power. 
(1) 
The Defence Force or a part of the Defence Force may be called out to perform 
functions under Section 202(c)(ii) (functions of the Defence Force) only by the Head of State, 
acting with, and in accordance with, the advice of the National Executive Council. 
(2) 
When called out in accordance with Subsection (1), the Defence Force or a part of the 
Defence Force— 
(a) does not have, and shall not be given, any power or protection that would not be 
possessed by the Police Force or the members of the Police Force in similar 
circumstances; and 
(b) shall support the Police Force for so long and so far as is necessary to enable the 
Police Force to restore public order and security; and 
(c) in so doing shall act only on, and to the extent specified in, a request by the 
appropriate civilian authority in accordance with an Act of the Parliament; and 
(d) 
shall cease to act in support of the Police Force when directed to do so by the Head of 
State, acting with, and in accordance with, the advice of the National Executive Council.
```

---

## Page 95

```text
95
(See: Defence Force Act (Chapter 74)) 
205. Active service. 
(1) 
Except for the purposes of defence against attack, the Defence Force or a part of the 
Defence Force— 
(a) may be ordered on active service only by the Head of State, acting with, and in 
accordance with, the advice of the National Executive Council; and 
(b) may be sent out of the country only by the authority of and on conditions imposed by 
the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council. 
(2) 
The Defence Force or a part of the Defence Force may not be ordered on, or committed 
to— 
(a) active service; or 
(b) an international peace-keeping or relief operation, 
outside the country without the prior approval of the Parliament. 
(3) 
If practicable before, and in any event as soon as practicable after, action is taken under 
Subsection (1) or the Defence Force becomes engaged in war or warlike operations, or in 
defence against attack, the Parliament shall be advised of the action taken, or likely to be taken, 
and of the reasons for it, and shall be given an opportunity to debate the matter. 
(4) 
Subsection (1)(b) does not prevent— 
(a) the Defence Force or a part of the Defence Force being sent out of the country for 
normal administrative or training purposes; or 
(b) any action that is required or permitted by an Act of the Parliament for the purposes 
of enforcing a law. 
206. Visiting forces. 
(1) 
An Act of the Parliament may make provision for or in respect of— 
(a) the presence in the country, by arrangement with the National Executive, of forces of 
another country; and 
(b) the presence in another country of the Defence Force or a part of the Defence Force, 
and in particular for or in respect of— 
(c) the concession to courts or tribunals, and to service authorities, of the other country 
of jurisdiction over members of its forces (other than citizens of Papua New Guinea) in 
relation to some or all civil and criminal matters; or 
(d) the assertion of the exclusive jurisdiction of courts and tribunals of Papua New 
Guinea, and of Defence Force authorities, over members of the Defence Force in another 
country. 
(2) 
Except in relation to its own members or to civilian components of, or civilians 
accompanying, the force, a visiting force of another country shall not be used in the country in 
any role in which the Defence Force may not be used, and accordingly any law that restricts the 
role, powers or functions of the Defence Force or of members of the Defence Force applies 
equally to visiting forces and members of visiting forces.
```

---

## Page 96

```text
96
(3) 
A law made for the purposes of Subsection (1) may apply, in whole or in part, to 
civilian components of, or civilians accompanying, the Defence Force or a part of the Defence 
Force, or to civilian components of, or civilians accompanying a visiting force. 
(See: Defence (Visiting Forces) Act (Chapter 77); Defence Force (Presence 
Abroad) Act (Chapter 372) 
 
Division 6.—Special Provisions relating to Disciplined Forces. 
207. Definition of “disciplined force”. 
(1) 
The following are, for the purposes of this Division, disciplined forces:— 
(a) the Police Force; and 
(b) the Defence Force; and 
(c) any other force or service that— 
(i) 
is established by or under a statute; and 
(ii) 
is declared by an Organic Law to be a disciplined force for the purpose of this 
Division. 
(2) For the purposes of any Organic Law made for the purposes of this Division, a person 
acting, as required or authorized by law, under the direction of a member of a 
disciplined force, for the purpose of assisting in the performance of the functions or 
duties of the member or of the force, shall be deemed to be a member of that force. 
 (See: Orgainc Law on Relief of Members of Disciplined Forces from the 
Responsibility for consequences of carrying out a Lawful Order) 
208. Protection of members of disciplined forces. 
(1) 
Because of the special nature of disciplined forces and of their operations, it is a primary 
duty of their members to obey lawful orders, and accordingly an Organic Law shall make special 
provision for relieving a member of such a force from responsibility for the consequences of— 
(a) carrying out a lawful order; or 
(b) carrying out an order which he honestly, and on reasonable grounds believed to be a 
lawful order, in which case the onus of establishing his belief and the reasonable 
grounds on which it was based, shall be upon him. 
(3) Without derogating any other right to compensation from an authority responsible for 
the disciplined force concerned, an Organic Law made for the purposes of 
Subsection (1) shall make provision for any liability to make compensation that 
would otherwise lie on a member of a disciplined force to lie on the authority 
responsible for the force. 
 See: Organic Law on Relief of Members of Disciplined Forces from the 
Responsibility for consequences of carrying out a Lawful Order) 
 
Part VIIA.—REGULATORY STATUTORY AUTHORITIES.
```

---

## Page 97

```text
97
208A. 
Establishment of Regulatory Statutory Authorities. 
(1) 
The following are Regulatory Statutory Authorities for the purposes of this Part:— 
(a) a body corporate established by an Act of Parliament to perform specific statutory 
functions; and 
(b) a body corporate incorporated by authority of an Act of Parliament, 
and declared by an Act of Parliament to be a body to which this Part applies. 
See: Regulatory Statutory Authorities Regulation Act 2004 
(2) 
An Act of the Parliament may make provision for or in respect of other Regulatory 
Statutory Authorities to which this Part applies. 
208B. 
Appointments to certain Offices of Regulatory Statutory Authorities. 
(1) 
This section applies to and in respect of the following offices and positions:— 
(a) all offices of chief executive officers of Regulatory Statutory Authorities; and 
(b) all offices of non ex officio members of Boards of Regulatory Statutory Authorities; 
and 
(c) such other offices and positions as are prescribed by an Act of Parliament for the 
purpose. 
(2) 
All appointments (whether temporary or substantive) to offices to which Subsection 
(1)(a) applies shall be made by the Head of State, acting with, and in accordance with, the advice 
of the National Executive Council, given after considering recommendations from the relevant 
Minister, acting on the advice of the relevant Board in accordance with the recommendation 
from the Public Services Commission, following procedures prescribed by an Act of Parliament. 
(3) 
All temporary appointments (whether temporary or substantive) to offices to which 
Subsection (1)(a) applies shall be made by the National Executive Council given after 
considering recommendations from the relevant Minister, acting on the advice of the relevant 
Board in accordance with the recommendation from the Public Services Commission, following 
procedures prescribed by an Act of Parliament. 
(4) 
The revocation of appointments of persons appointed under Subsection (1)(a) shall be 
made by the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council given after considering recommendations from the relevant Minister, acting 
on the advice of the relevant Board in accordance with the recommendation from the Public 
Services Commission, following procedures prescribed by an Act of Parliament. 
(5) 
The suspension from office of persons appointed under Subsection (1)(a) shall be made 
by the Head of State, acting with, and in accordance with, the advice of the National Executive 
Council given after considering recommendations from the relevant Minister, acting on the 
advice of the relevant Board in accordance with the recommendation of the Public Services 
Commission following procedures prescribed by an Act of Parliament. 
(6) 
All appointments (whether temporary or substantive) to offices to which Subsection 
(1)(b) applies shall be made by the Head of State, acting with, and in accordance with, the advice 
of the National Executive Council given after considering recommendations from the relevant 
Minister following procedures prescribed by an Act of Parliament.
```

---

## Page 98

```text
98
 
PART VIII.—SUPERVISION AND CONTROL. 
Division 1.—Public Finances. 
Subdivision A.—The Parliament and Finance. 
209. Parliamentary responsibility. 
(1) 
Notwithstanding anything in this Constitution, the raising and expenditure of finance by 
the National Government, including the imposition of taxation and the raising of loans, is subject 
to authorization and control by the Parliament, and shall be regulated by an Act of the 
Parliament. 
(2) 
For each fiscal year, there shall be a National Budget comprising— 
(a) estimates of finance proposed to be raised and estimates of proposed expenditure by 
the National Government in respect of the fiscal year; and 
(b) separate appropriations for the service of that year in respect of— 
(i) 
the services of the Parliament; and 
(ii) 
general public services; and 
(iii) the services of the Judiciary; and 
(d) such other supplementary Budgets and appropriations as are necessary. 
(Subsection (2) repealed and replaced by Constitutional Amendment 
No.10) 
(2A) 
For the purposes of this Subdivision— 
(a) “the services of the Parliament” include the salaries and allowances (financial and 
otherwise) of the Members of Parliament, the maintenance of the precincts of the 
Parliament, and the Parliamentary Service established under the Parliamentary Service 
Act (Chapter 26); and 
(b) “the services of the Judiciary” include— 
(i) 
the salaries and allowances (financial and otherwise) of Judges of the Supreme 
and National Courts; and 
(ii) 
the maintenance of the Supreme and National courts; and 
(iii) the National Judicial Staff Service established under the National Judicial Staff 
Service Act 1987; and 
(iii) the salaries and allowances (financial and otherwise) of all persons appointed 
under the Supreme Court Act (Chapter 37), the National Court Act (Chapter 
38) and the Sheriff Act (Chapter 55). 
(Subsection (2A) inserted by Constitutional Amendment No.10) 
(2B) 
For the purposes of subsection (2)(b)(i) and (iii), the Speaker of the Parliament and the 
Chief Justice respectively shall, before 30 September each year, submit to the Prime Minister 
estimates of expenditure for the services of the Parliament and the services of the Judiciary 
respectively in the following fiscal year. 
(Subsection (2B) inserted by Constitutional Amendment No.10)
```

---

## Page 99

```text
99
(3) 
Before any Budget or appropriation is prepared for submission to the Parliament, the 
National Executive Council shall consult with any appropriate Permanent Parliamentary 
Committee, but this subsection does not confer any right or impose any duty of consultation after 
the initial stages of the preparation of the Budget or appropriation. 
210. Executive initiative. 
(1) 
The Parliament shall not provide for the imposition of taxation, the raising of loans or 
the expenditure of public moneys of Papua New Guinea except on the recommendation of the 
Head of State, acting with, and in accordance with, the advice of the National Executive Council. 
 
(2) 
Subject to subsections (3) and (4), Parliament may reduce, but shall not increase or re-
allocate, the amount or incidence of, or change the purpose of, any proposed taxation, loan or 
expenditure. (Subsection (2) repealed and replaced by Constitutional 
Amendment No.10) 
(3) 
Where, in the opinion of the Parliament, the proposed expenditure for the services of the 
Parliament or the services of the Judiciary is below the estimate submitted by the Speaker or 
Chief Justice respectively and is insufficient adequately to meet the requirements of that service, 
the Parliament may increase the expenditure to an amount not exceeding the original estimates 
submitted by the Speaker or the Chief Justice, as the case may be, under Section 209(2B). 
Subsection (3) added by Constitutional Amendment No.10) 
(4) 
For the purposes of subsection (3), the Parliament may re-allocate, or reduce and re-
allocate, the amount of expenditure appropriated for any purpose. 
 
 
211. Accounting, etc., for public moneys. 
(1) 
All moneys of or under the control of the National Government for public expenditure 
and the Parliament and the Judiciary for their respective services, shall be dealt with and properly 
accounted for in accordance with law. 
Subsection (1) Amended by Constitutional Amendment No.10) 
(2) 
No moneys of or under the control of the National Government for public expenditure 
or the Parliament and the Judiciary for their respective services, shall be expended except as 
provided by this Constitution or by or under an Act of the Parliament. 
Subsection (2) Amended by Constitutional Amendment No.10) 
212. Revenue and expenditure without prior approval. 
(1) 
If at the beginning of a fiscal year the Parliament has not made provision for public 
expenditure by the National Executive or expenditure by the Parliament or the Judiciary for their 
respective services for that year, the National Executive, the Parliament or the Judiciary, as the 
case maybe, may, without authorization other than this section but in accordance with an Act of 
the Parliament, expend amounts appropriated out of the Consolidated Revenue Fund for the
```

---

## Page 100

```text
100
purpose not exceeding in total one-third of its respective budgetted expenditure during the 
immediately preceding fiscal year. Subsection (1) repealed and replaced by 
Constitutional Amendment No.10) (See: Public Finance (Management) Act 
1995) 
(2) 
The authority conferred by Subsection (1) lapses when the Parliament has made 
provision for the public expenditure for the fiscal year in question, and any amounts expended by 
virtue of that subsection are a charge against the expenditure so provided for and shall be 
properly brought to account accordingly. 
Subdivision B.—The Auditor-General. 
213. Establishment of the office of Auditor-General. 
(1) 
An office of Auditor-General is hereby established. 
(2) 
The Auditor-General shall be appointed by the Head of State, acting with, and in 
accordance with, the advice of the National Executive Council given after receiving reports from 
the Public Services Commission and the Public Accounts Committee. 
(3) 
In the performance of his functions under this Constitution, the Auditor-General is not 
subject to the control or direction of any person or authority. 
214. Functions of the Auditor-General. 
(1) 
The primary functions of the Auditor-General are to inspect and audit, and to report at 
least once in every fiscal year (as provided by an Act of the Parliament) to the Parliament on the 
public accounts of Papua New Guinea, and on the control of and on transactions with or 
concerning the public moneys and property of Papua New Guinea, and such other functions as 
are prescribed by or under a Constitutional Law. (See: Audit Act 1989) 
(2) 
Unless other provision is made by law in respect of the inspection and audit of them, 
Subsection (1) extends to the accounts, finances and property of— 
(a) all arms, departments, agencies and instrumentalities of the National Government; 
and 
(b) all bodies set up by an Act of the Parliament, or by executive or administrative act of 
the National Executive, for governmental or official purposes. 
(3) 
Notwithstanding that other provision for inspection or audit is made as provided for by 
Subsection (2), the Auditor-General may, if he thinks it proper to do so, inspect and audit, and 
report to the Parliament on, any accounts, finances or property of an institution referred to in that 
subsection, insofar as they relate to, or consist of or are derived from, public moneys or property 
of Papua New Guinea. 
(4) 
An Act of the Parliament may expand, and may provide in more detail for, the functions 
of the Auditor-General under Subsections (1), (2) and (3), and may confer on the Auditor-
General additional functions and duties not inconsistent with the performance of the functions 
and duties conferred and imposed by those subsections. (See: Audit Act 1989) 
Subdivision C.—The Public Accounts Committee. 
215. Establishment of the Committee.
```

---

## Page 101

```text
101
There shall be a Public Accounts Committee, which is a Permanent Parliamentary Committee for 
the purposes of Subdivision VI.2.E (the Committee system). 
216. Functions of the Committee. 
(1) 
The primary function of the Public Accounts Committee is, in accordance with an Act 
of the Parliament, to examine and report to the Parliament on the public accounts of Papua New 
Guinea and on the control of and on transactions with or concerning, the public moneys and 
property of Papua New Guinea. (See: Public Finance (Management) Act1995) 
(2) 
Subsection (1) extends to any accounts, finances and property that are subject to 
inspection and audit by the Auditor-General under Section 214(2) (functions of the Auditor-
General), and to reports by the Auditor-General under that subsection or Section 214(3) 
(functions of the Auditor-General). 
(3) 
An Act of the Parliament may expand, and may provide in more detail for, the functions 
of the Committee under Subsections (1) and (2), and may confer on the Committee additional 
functions and duties not inconsistent with the performance of the functions and duties conferred 
and imposed by those subsections. 
 
Division 1A.—Salaries and Remuneration Commission. 
216A. 
The Salaries and Remuneration Commission. 
(1) 
A Salaries and Remuneration Commission is hereby established. 
(2) 
The Commission shall consist of— 
(a) the Speaker of the Parliament as the Chairman when attending, or in his absence, his 
nominee who shall be the Deputy Speaker; and 
(b) the Prime Minister or, in his absence, his nominee who shall be a Minister; and 
(c) the Leader of the Opposition or, in his absence, his nominee who shall be a member 
of Parliament in the Opposition; and 
(d) the Chief Justice or, in his absence, his nominee who shall be nominated after 
consultation with the Judges to represent the Judges; and 
(e) the head of the Department of Personnel Management or in his absence, his nominee 
who shall be an officer of that department; and 
(f) the head of the Department of Labour and Employment or, in his absence, his 
nominee who shall be an officer of that department. 
(3) 
The Commission is responsible for recommending to the Parliament from time to time, 
at intervals determined by it— 
(a) the salaries, allowances and benefits, financial and otherwise (including pensions and 
retirement benefits if they are not provided for by law other than this provision), for all 
or any members of the Parliament; and 
(b) the salaries, allowances and benefits, financial and otherwise (including pensions or 
retirement benefits), for all or any members of Provincial Assemblies and members of 
Local-level Governments; and 
(c) the salaries, allowances and benefits, financial and otherwise (including pensions or 
retirement benefits if they are not provided for by law other than this provision) for all
```

---

## Page 102

```text
102
the Judges; and 
(d) the salaries, allowances and benefits, financial or otherwise (including pensions or 
retirement benefits if they are not provided for by law other than this provision) for all 
Constitutional Office-holders; and 
(e) the salaries, allowances and benefits, financial and otherwise (including pensions or 
retirement benefits if they are not provided for by law other than this provision) for all 
Departmental Heads and the Heads of all bodies set up by statute for governmental or 
official purposes; and 
(f) the salaries, allowances and benefits, financial and otherwise (including pensions or 
retirement benefits if they are not provided for by law other than this provision) for the 
Heads of all bodies (including companies incorporated under any law) in which the 
National Government has a financial interest and which are declared by the Head of 
State, acting with, and in accordance with, the advice of the National Parliament to be 
bodies to which this provision applies; and 
(g) that the Parliament considers, and approves or rescinds, any decision made by the 
Salaries and Conditions Monitoring Committee which the Commission, after 
consideration, is of the opinion should be referred to the Parliament. 
(4) 
The Parliament shall determine the salaries, allowances and benefits, financial and 
otherwise of the members of the Parliament, Provincial Assemblies, the Judges and other 
Constitutional Office-holders in accordance with recommendations of the Commission made 
under subsection (3). 
(5) 
Parliament may accept or reject, but may not amend, any recommendations of the 
Commission. 
(5A) 
Effect may be given to the provisions of a recommendation by the Commission under 
Subsection (3)(a) to (f) inclusive pending the acceptance or rejection of the recommendation by 
the Parliament and where effect is so given and the Parliament subsequently— 
(a) accepts the recommendation—the provisions of the recommendation are deemed to 
have had effect from the date on which they were so effected; and 
(b) rejects the recommendation—the provisions of the recommendation— 
(i) 
cease to have effect from the date on which they are rejected by the Parliament; 
(ii) 
are deemed to have been valid from the date on which they were effected until 
the date on which they are rejected by the Parliament. 
(6) 
An Act of the Parliament shall make further provision in respect of— 
(a) the salaries and remuneration for the holders of the different offices or levels of 
offices held by— 
(i) 
members of the Parliament; and 
(ii) 
members of Provincial Assemblies; and 
(iii) the Judges; and 
(iv) other Constitutional Office-holders; and 
(b) the powers and procedures of the Commission and generally in respect of it. 
(See: Salaries & Remuneration Commission Act 1998) 
(7) 
The provisions of this section apply notwithstanding any law that prescribes a code of
```

---

## Page 103

```text
103
conduct for leaders or imposes a duty, restraint or obligation on leaders acquiring a benefit or 
gain. 
Division 2.—The Ombudsman Commission. 
217. The Ombudsman Commission. 
(1) 
There shall be an Ombudsman Commission, consisting of a Chief Ombudsman and two 
Ombudsmen. 
(2) 
The members of the Commission shall be appointed by the Head of State, acting with, 
and in accordance with, the advice of an Ombudsman Appointments Committee consisting of— 
(a) the Prime Minister, who shall be Chairman; and 
(b) the Chief Justice; and 
(c) the Leader of the Opposition; and 
(d) the Chairman of the appropriate Permanent Parliamentary Committee, or, if the 
Chairman is not a member of the Parliament who is recognized by the Parliament as 
being generally committed to support the Government in the Parliament, the Deputy 
Chairman of that Committee; and 
(e) the Chairman of the Public Services Commission. 
(3) 
The salary and other conditions of employment of the Chief Ombudsman shall not be 
less than or inferior to the salary and other conditions of employment of a Judge other than the 
Chief Justice and the Deputy Chief Justice without taking into account any conditions of 
employment personal to that Judge. 
(4) 
The salary and other conditions of employment of the Ombudsmen shall be not less than 
or inferior to the salary and other conditions of employment of the Public Prosecutor, without 
taking into account any conditions of employment personal to any particular Public Prosecutor. 
(5) 
In the performance of its functions under Section 219 (functions of the Commission) the 
Commission is not subject to direction or control by any person or authority. 
(6) 
The proceedings of the Commission are not subject to review in any way, except by the 
supreme Court or the National Court on the ground that it has exceeded its jurisdiction. 
(7) 
An Organic Law shall make further provision in respect of the appointment, powers, 
procedures and immunity of the Commission. 
(See: Organic Law on the Ombudsman Commission) 
(8) 
In this section “conduct” includes— 
(a) any action or inaction relating to a matter of administration; and 
(b) any alleged action or inaction relating to a matter of administration. 
218. Purposes of the Commission. 
The purposes of the establishment of the Ombudsman Commission are— 
(a) to ensure that all governmental bodies are responsive to the needs and aspirations of 
the People; and 
(b) to help in the improvement of the work of governmental bodies and the elimination 
of unfairness and discrimination by them; and
```

---

## Page 104

```text
104
(c) to help in the elimination of unfair or otherwise defective legislation and practices 
affecting or administered by governmental bodies; and 
(d) to supervise the enforcement of Division III.2 (leadership code). 
219. Functions of the Commission. 
(1) 
Subject to this section and to any Organic Law made for the purposes of Subsection (7), 
the functions of the Ombudsman Commission are— 
(a) to investigate, on its own initiative or on complaint by a person affected, any conduct 
on the part of— 
(i) 
any State Service or provincial service, or a member of any such service; or 
(ii) 
any other governmental body, or an officer or employee of a governmental 
body; or 
(iii) any local government body or an officer or employee of any such body; or 
(iv) any other body set up by statute— 
(A) that is wholly or mainly supported out of public moneys of Papua New 
Guinea; or 
(B) all of, or the majority of, the members of the controlling authority of 
which are appointed by the National Executive, 
or an officer or employee of any such body; and 
(v) 
any member of the personal staff of the Governor-General, a Minister or the 
Leader or Deputy Leader of the Opposition; or 
(vi) any other body or person prescribed for the purpose by an Act of the 
Parliament, 
specified by or under an Organic Law in the exercise of a power or function vested in 
it or him by law in cases where the conduct is or may be wrong, taking into account, 
amongst other things, the National Goals and Directive Principles, the Basic Rights 
and the Basic Social Obligations, and 
(b) to investigate any defects in any law or administrative practice appearing from any 
such investigation; and 
(c) to investigate, either on its own initiative or on complaint by a person affected, any 
case of an alleged or suspected discriminatory practice within the meaning of a law 
prohibiting such practices; and 
(d) any functions conferred on it under Division III.2 (leadership code); and 
(c) any other functions conferred upon it by or under an Organic Law. 
(Subsection (1) amended by Constitutional Amendment No.3)  
(See: Organic Law on Ombudsman Commission) 
(2) 
Subject to Subsections (3), (4) and (5), and without otherwise limiting the generality of 
the expression, for the purposes of Subsection (1)(a) conduct is wrong if it is— 
(a) contrary to law; or 
(b) unreasonable, unjust, oppressive or improperly discriminatory, whether or not it is in 
accordance with law or practice; or 
(c) based wholly or partly on improper motives, irrelevant grounds or irrelevant
```

---

## Page 105

```text
105
considerations; or 
(d) based wholly or partly on a mistake of law or of fact; or 
(e) conduct for which reasons should be given but were not, 
whether or not the act was supposed to be done in the exercise of deliberate judgement within the 
meaning of Section 62 (decisions in “deliberate judgement”). 
(3) 
The Commission shall not inquire into the justifiability of a policy of the National 
Government or a Minister or a provincial government or a member of a provincial executive, 
except insofar as the policy may be contrary to law or to the National Goals and Directive 
Principles, the Basic Rights or the Basic Social Obligations, or of any Act of the Parliament. 
(Subsection (3) amended by Constitutional Amendment No.3) 
(4) 
The Commission shall not inquire into the exercise of a rule-making power by a local 
government body. 
(5) 
The Commission shall not inquire into a decision by a court, except insofar as the 
decision may show an apparent defect in law or administrative practice to which Subsection 
(1)(b) would apply. 
(6) 
Except as provided by or under Division III.2 (leadership code), the Commission’s 
powers of enforcement are limited to publicity for its proceedings, reports and recommendations, 
to the making of reports and recommendations to the Parliament and other appropriate 
authorities as provided by an Organic Law, and to the giving of advice. 
(7) 
An Organic Law shall make provision in respect of the powers and procedures of the 
Commission, and in particular— 
(a) shall, subject to paragraph (b), make provision for the Commission to have access to 
all available relevant information; and 
(b) may impose reasonable restrictions on the availability of information; and 
(c) shall make provision to ensure the secrecy or confidentiality of secret or confidential 
information made available to the Commission or to a member of the Commission or of 
its staff; and 
(d) may limit or restrict to a reasonable extent and in a reasonable manner the 
jurisdiction of the Commission in relation to any matters or class of matters, and in 
particular in relation to national security; and 
(d) shall make provision for and in respect of publicity for the proceedings, reports and 
recommendations of the Commission. 
(See: Organic Law on Ombudsman Commission) 
 
(8) 
In this section, “conduct” includes— 
(a) any action or inaction relating to a matter of administration; and 
(b) any alleged action or inaction relating to a matter of administration. 
220. Reports by the Commission. 
(1) 
The Ombudsman Commission shall, at least once in each period of 12 months, at 
such time as is fixed by or under an Act of the Parliament or, subject to any such Act, by the 
Head of State, acting with, and in accordance with, the advice of the National Executive Council,
```

---

## Page 106

```text
106
give to the Head of State, for presentation to the Parliament, a report on the functions and 
workings of the Commission, with such recommendations as to improvement as the Commission 
thinks proper. (See: Organic Law on Ombudsman Commission) 
(2) 
Nothing in Subsection (1) prevents the Commission from making, on its own initiative 
or at the request of the Parliament or of the National Executive, other reports on any aspect of the 
functions and workings of the Commission. 
 
PART IX.—CONSTITUTIONAL OFFICE-HOLDERS AND CONSTITUTIONAL 
INSTITUTIONS. 
221. Definitions. 
In this Part— 
“constitutional institution” means any office or institution established or provided for by 
this Constitution, other than an office of Head of State or of a Minister, or the National 
Executive Council; 
“constitutional office-holder” means— 
(a) 
a Judge; or 
(b) 
the Public Prosecutor or the Public Solicitor; or 
(c) 
the Chief Magistrate; or 
(d) 
a member of the Ombudsman Commission; or 
(e) 
a member of the Electoral Commission; or 
(f) 
the Clerk of the Parliament; or 
(g) 
a member of the Public Services Commission; or 
(h) 
the Auditor-General; or 
(i) 
the holder of any other office declared by an Organic Law or an Act of the 
Parliament to be a constitutional office for the purposes of this Part. 
222. Other provisions relating to constitutional office-holders and constitutional 
institutions. 
This Part shall be read subject to any other provisions of this Constitution relating to particular 
constitutional office-holders or particular constitutional institutions. 
223. General provision for constitutional office-holders. 
(1) 
Subject to this Constitution, Organic Laws shall make provision for and in respect of the 
qualifications, appointment and terms and conditions of employment of constitutional office-
holders. (See: Organic Law on Certain Constitutional office –Holders; 
Organic Law on the Terms and Conditions of Employment of Judges) 
(2) 
In particular, Organic Laws shall make provision guaranteeing the rights and 
independence of constitutional office-holders by, amongst other things— 
(a) specifying the grounds on which, and the procedures by which, they may be 
dismissed or removed from office, but only by, or in accordance with the
```

---

## Page 107

```text
107
recommendation of, an independent and impartial tribunal; and 
(b) providing that at the end of their periods of office they are entitled, unless they have 
been dismissed from office, to suitable further employment by a governmental body, 
or to adequate and suitable pensions or other retirement benefits, or both, subject to 
such reasonable requirements and conditions (if any) as are laid down by an Organic 
Law. 
(See: Organic Law on the Guarantee of the rights and independence of 
Constitutional Office-Holders; Constitutional Office Holders Retirement 
Benefits Act 1986) 
(3) 
A constitutional office-holder may not be suspended, dismissed or removed from office 
during his term of office except in accordance with a Constitutional Law. 
(4) 
The total emoluments of a constitutional office-holder shall not be reduced while he is 
in office, except— 
(a) as part of a general reduction applicable equally or proportionately to all 
constitutional office-holders or, if he is a member of a State Service, to members of that 
service; or 
(b) as a result of taxation that does not discriminate against him as a constitutional 
office-holder, or against constitutional office-holders generally. 
(5) 
The office of a constitutional office-holder may not be abolished while there is a 
substantive holder of the office but this subsection does not apply to the abolition of any 
additional constitutional office created by an Act of the Parliament. 
(6) 
Nothing in this section prevents the making by or under an Organic Law or an Act of 
the Parliament of reasonable provision for the appointment of a person to act temporarily in the 
office of a constitutional office-holder. See: Organic Law on Certain Constitutional 
office –Holders 
224. Special provision for constitutional institutions. 
(1) 
Subject to this Constitution, Organic Laws and Acts of the Parliament shall provide, or 
shall make provision for, the powers and procedures of constitutional institutions, and generally 
for facilitating the performance of their functions, duties and responsibilities. 
(2) 
Subject to this Constitution, if no provision is made under Subsection (1) a 
constitutional institution— 
(a) may provide, to the extent of the deficiency, for its own procedures; and 
(b) has all reasonable powers that are necessary or convenient for the exercise and 
performance of its powers, functions, duties and responsibilities. 
225. Provision of facilities, etc. 
Without limiting the generality of any other provision of this Constitution, it is the duty of the 
National Government and of all other governmental bodies, and of all public office-holders and 
institutions, to ensure, as far as is within their respective legal powers, that all arrangements are 
made, staff and facilities provided and steps taken to enable and facilitate, as far as may 
reasonably be, the proper and convenient performance of the functions of all constitutional 
institutions and of the offices of all constitutional office-holders.
```

---

## Page 108

```text
108
 
PART X.—EMERGENCY POWERS. 
Division 1.—Introductory. 
226. Definitions. 
In this Part, unless the contrary intention appears— 
“declaration of a national emergency” means a declaration under Section 228 
(declaration of national emergency); 
“emergency” includes, without limiting the generality of the expression— 
(a) 
imminent danger of war between Papua New Guinea and another country, or of 
warlike operations threatening national security; and 
(b) 
an earthquake, volcanic eruption, storm, tempest, flood, fire or outbreak of 
pestilence or infectious disease, or any other natural calamity whether similar to any 
such occurrence or not on such an extensive scale as to be likely to endanger the 
public safety or to deprive the community or any substantial proportion of the 
community of supplies or services essential to life; and 
(c) 
action taken, or immediately threatened, by any person that is of such a nature, 
and on so extensive a scale, as to be likely to endanger the public safety or to deprive 
the community or any substantial portion of the community of supplies or services 
essential to life; 
“Emergency Act” means an Act of the Parliament made for the purposes of this Part and 
in accordance with Section 230 (Emergency Acts); 
“Emergency Committee” means an Emergency Committee appointed under Section 240 
(Emergency Committees), and includes a Temporary Emergency Committee appointed 
and in office under Section 241 (Temporary Emergency Committees); 
“emergency law” means— 
(a) 
an Emergency Act; or 
(b) 
an Emergency Regulation; 
“emergency order” means an order made under an emergency law, as provided for by 
Section 232 (emergency orders); 
“Emergency Regulation” means a law that is made in accordance with Section 231 
(Emergency Regulations); 
“internment” means detention that is authorized by or under a law the validity of which 
depends solely on this Part, but does not include the detention of a member of the armed 
forces of another country as a prisoner of war; 
“period of declared national emergency” means any period during which— 
(a) 
Papua New Guinea is at war with another country by virtue of a declaration 
under Section 227 (declaration of war); or 
(b) 
a declaration of a national emergency is in force under Section 228 
(declaration of national emergency). 
Division 2.—Periods of Declared National Emergency.
```

---

## Page 109

```text
109
227. Declaration of war. 
The Head of State, acting with, and in accordance with, the advice of the National Executive 
Council, may publicly declare that Papua New Guinea is at war with another country. 
228. Declaration of national emergency. 
(1) 
If the National Executive Council is of the opinion that an emergency exists or is about 
to come into being such that it is necessary that the powers conferred by the succeeding 
provisions of this Part be available, the Head of State, acting with, and in accordance with, the 
advice of the National Executive Council, may publicly declare the existence of a national 
emergency in relation to the whole or part of the country. 
(2) 
Unless it is impracticable to do so, a declaration under Subsection (1) shall be made in 
relation to a part of the country only after prior consultation with the Emergency Committee. 
229. Termination of periods of declared national emergency. 
A declaration of war or of a national emergency may be revoked at any time— 
(a) by the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council; or 
(b) by decision of the Parliament. 
Division 3.—Emergency Measures. 
230. Emergency Acts. 
(1) 
Before or during a period of declared national emergency, the Parliament may make 
Acts of the Parliament (to be known as “Emergency Acts”) to make provision for dealing with 
the emergency, and with matters arising out of it. 
(2) 
An Emergency Act shall be expressed to be an Emergency Act. 
(3) 
Except to the extent necessary to bring it into effective operation at the time when it 
otherwise comes into operation, an Emergency Act made before the commencement of a period 
of declared national emergency shall not come into operation until the commencement of the 
period. 
231. Emergency Regulations. 
(1) 
Subject to this Part, at any time before the end of the period of 24 hours after the 
Parliament first meets after commencement of a period of declared national emergency the Head 
of State, acting with, and in accordance with, the advice of the National Executive Council, may 
make laws (to be known as “Emergency Regulations”) to make provision for dealing with the 
emergency concerned, and with matters arising out of it if, and to the extent that, the nature of 
the emergency or its requirements necessitate the making of the provision before the Parliament 
can reasonably consider the matter. 
(2) 
An Emergency Regulation shall be immediately forwarded to— 
(a) the Speaker for presentation to the Parliament; and 
(b) an Emergency Committee in accordance with Section 242(1)(a) (functions etc., of 
Emergency Committees) or where no Emergency Committee has been established, to the
```

---

## Page 110

```text
110
Temporary Emergency Committee established under Section 241 (Temporary 
Emergency Committees). 
(3) 
Unless earlier extended by decision of the Parliament, an Emergency Regulation expires 
at the end of the period of 28 days after the making of the declaration of the emergency, or at the 
end of the period of 14 days after the Parliament first meets after the commencement of the 
period of declared national emergency, whichever first happens. 
232. Emergency orders. 
(1) 
An emergency law may make provision for the giving of orders, not inconsistent with 
the emergency law, by persons authorized to do so by or under the law. 
(2) 
No emergency law shall purport to confer powers to make orders that could not be made 
in the form of an emergency law. 
(3) 
An order shall, if practicable, be in writing and be notified to the appropriate authority 
appointed by law. 
(4) 
As far as practicable, details of, or copies of, all orders given in accordance with this 
section shall immediately be forwarded to— 
(a) the Speaker for presentation to the Parliament; and 
(b) the Emergency Committee in accordance with Section 242(1)(a) (functions, etc., of 
Emergency Committees) or where no Emergency Committee has been established, to the 
Temporary Emergency Committee established under Section 241 (Temporary 
Emergency Committees). 
233. Content, operations, etc., of emergency laws. 
(1) 
Subject to this Part, an emergency law may make provision for the peace, order and 
good government of the country to the extent reasonably required for achieving its purpose. 
(2) 
Notwithstanding the provisions of Sections 12 and 13 but subject to Subsections (3) and 
(4), an emergency law may alter, wholly or partly, and absolutely or subject to conditions, any 
provision of Division III.3 (basic rights), any Organic Law made for the purposes of any such 
provision or any other law (other than a Constitutional Law) to the extent reasonably necessary 
to deal with the emergency concerned, and with matters arising out of it, but only so far as is 
reasonably justifiable in a democratic society having a proper regard for the rights and dignity of 
mankind. 
(3) 
An emergency law— 
(a) may not alter— 
(i) 
Section 35 (right to life); or 
(ii) 
Section 36 (freedom from inhuman treatment); or 
(iii) Section 45 (freedom of conscience, thought and religion); or 
(iv) Section 50 (right to vote and stand for public office); or 
(v) 
Section 55 (equality of citizens); or 
(vi) Section 56 (other rights and privileges of citizens); and 
(b) may provide for internment only in accordance with Division 5 (internment); and
```

---

## Page 111

```text
111
(c) may alter Section 37 (protection of the law) or Section 42 (liberty of the person) only 
to the extent allowed by paragraph (b). 
(4) 
In addition, an Emergency Regulation may not alter— 
(a) Section 46 (freedom of expression); or 
(b) Section 47 (freedom of assembly and association); or 
(c) Section 49 (right to privacy); or 
(d) Section 51 (right to freedom of information), 
and may not provide for a sentence of imprisonment for a period exceeding nine months. 
(5) 
In the case of an inconsistency between a valid emergency law and any other law, the 
law made later prevails. 
234. Release from custody on expiry, etc., of Emergency Regulations. 
Subject to any Act of the Parliament made for the purpose of dealing with the effect of the expiry 
or revocation of a particular Emergency Regulation, any person held in custody under or for the 
purposes of an Emergency Regulation shall be released from custody on its expiry or repeal, 
unless he is also held in custody under some other law. 
235. Custody of members of Parliament under Emergency Regulations or in 
internment. 
If a member of the Parliament is held in custody under an Emergency Regulation, or is an 
internee, he shall, at all times when the Parliament is in session or when a committee (of which 
he is a member) of the Parliament is meeting, be released, on such conditions (if any) as are 
prescribed by an Act of the Parliament, into the custody of the Parliament in order to allow him 
to attend to his parliamentary duties, unless he is also held in custody under some other law. 
(See: Emergency (Custody of Members of Parliament) Act (Chapter338)) 
236. Revocation, etc., of emergency laws, etc. 
(1) 
An Emergency Act may be altered— 
(a) by an Act of the Parliament; or 
(b) in an urgent case, where to do so would not be contrary to the positive intention 
expressed by a resolution of the Parliament dealing with the particular emergency, by an 
Emergency Regulation. 
(2) 
An Emergency Regulation may be altered at any time— 
(a) by the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council; or 
(b) by an Emergency Act; or 
(c) by decision of the Parliament. 
(3) 
An emergency order may be disallowed at any time by decision of the Parliament. 
237. Automatic termination of emergency laws, etc. 
(1) 
Subject to Section 238 (extension of Emergency Acts) an emergency law, unless it has 
expired under Section 231(3) (Emergency Regulations) or unless earlier repealed shall be
```

---

## Page 112

```text
112
deemed to be repealed immediately after the end of the day on which the period of declared 
national emergency ends. 
(2) 
Where an Emergency Regulation which has amended or repealed any law in force 
immediately before the regulation took effect, is deemed to be repealed under Subsection (1), the 
repeal of that regulation shall revive the previous law from the date of that repeal as if the 
repealed regulation had not been made. 
238. Extension of Emergency Acts. 
(1) 
Subject to Subsection (2), to the extent that its extension is necessary to deal with the 
results or aftermath of the period of declared national emergency and is reasonably justifiable in 
a democratic society thathas a proper regard for the rights and dignity of mankind, the operation 
of an Emergency Act may be extended from time to time, after the end of the period of declared 
national emergency, by decision of the Parliament by an absolute majority vote, for a period or 
periods each not exceeding two months. 
(2) 
After the end of the period of declared national emergency, internment may be 
continued only in accordance with Section 244(6) (laws providing for internment). 
Division 4.—Parliamentary Supervision and Control. 
239. Parliamentary control. 
(1) 
Unless the Parliament is in session at the commencement of a period of declared 
national emergency, it shall be called to meet as soon as practicable, and in any event not more 
than 15 days, after the commencement of the period and thereafter during the period at intervals 
each not exceeding two months. 
(2) 
At each meeting of the Parliament during a period of declared national emergency the 
Prime Minister shall present to the Parliament a statement setting out— 
(a) the reasons for the declaration of war or of the national emergency, or for the 
continuance of the period; and 
(b) the reasons for any new Emergency Regulations; and 
(c) a report on the operation of the emergency laws. 
(3) 
Unless earlier revoked, a declaration of a national emergency expires at the end of the 
period of 21 days after its making, but may be extended from time to time by decision of the 
Parliament by an absolute majority vote, for a period or periods each not exceeding two months. 
240. Emergency Committees. 
(1) 
An Act of the Parliament shall provide for and in respect of the appointment of 
committees of the Parliament (to be known as “Emergency Committees”) in respect of a period 
or periods of declared national emergency. (See: Emergency Committees Act 
(Chapter 33A)) 
(2) 
No Minister may be a member of a Committee. 
(3) 
A Committee shall be available to meet at all times during the period in respect of 
which it was appointed. 
(4) 
Subject to the availability of members to meet in accordance with Subsection (3), a
```

---

## Page 113

```text
113
Committee should, in principle, be broadly representative of the various parts of the country and 
of parties and groups in the Parliament. 
241. Temporary Emergency Committees. 
(1) 
An Act of the Parliament or the Standing Orders of the Parliament shall make provision 
for and in respect of the appointment of a Temporary Emergency Committee to hold office if a 
period of declared national emergency commences at a time when the Parliament is not in 
session and an Emergency Committee has not been established in accordance with Section 240 
(Emergency Committees) in respect of the period. (See: Emergency Committees Act 
(Chapter 33A)) 
(2) 
A Temporary Emergency Committee ceases to hold office (except for the purpose of 
making a report in accordance with Section 242(2) (functions, etc., of Emergency Committees) as 
to events occurring during its term of office)— 
(a) at the time of the establishment of an Emergency Committee in accordance with 
Section 240 (Emergency Committees) in respect of the period of declared national 
emergency; or 
(b) at the end of the first meeting of the Parliament after its establishment, 
whichever first occurs. 
242. Functions, etc., of Emergency Committees. 
(1) 
The Prime Minister shall ensure that— 
(a) copies of all emergency laws and, so far as is practicable, of all emergency orders, 
are forwarded immediately to the Emergency Committee; and 
(b) subject to any Emergency Act, the Committee is fully provided with information 
concerning, and is fully consulted concerning, developments in the situation and in 
particular concerning proposed emergency laws and the operation of existing emergency 
laws. 
(2) 
At each meeting of the Parliament during a period of declared national emergency the 
Emergency Committee shall present to the Parliament a statement as to— 
(a) whether or not the period of declared national emergency should continue; and 
(b) the justification for and the operation of the emergency laws; and 
(c) whether or not any emergency law should be altered, 
and such other related matters as it thinks fit. 
(3) 
As soon as practicable after receipt by him of a request to do so from the Emergency 
Committee, and in any event not more than 15 days afterwards, the Speaker shall call a meeting 
of the Parliament to consider— 
(a) any statements by the Committee under Subsection (2) and by the Prime Minister 
under Section 239(2) (Parliamentary control); and 
(b) whether or not the period of declared national emergency should be allowed to 
continue; and 
(c) whether or not an emergency law should be altered, 
and such other matters as the Parliament thinks fit.
```

---

## Page 114

```text
114
243. Priority of emergency business in Parliament. 
During a period of declared national emergency, and while any emergency law is in force, first 
priority shall, subject to any express provision of this Constitution to the contrary, be given to 
any question, notice, motion or other Parliamentary process relating to the emergency or to an 
emergency law. 
Division 5.—Internment. 
244. Laws providing for internment. 
(1) 
The internment of persons may be permitted only by an Act of the Parliament. 
(2) 
An Act referred to in Subsection (1)— 
(a) must be made by an absolute majority vote; and 
(b) takes effect on a date fixed by an absolute majority vote of the Parliament made after 
the commencement of a period of declared national emergency and, after at least four 
days‘ notice of the relevant motion has been given; and 
(c) subject to Subsection (6), authorizes internment only during a period of declared 
national emergency. 
(3) 
Subject to Subsection (4), at least four days’ notice of the intention to introduce to the 
Parliament a proposed law to permit internment must be given, and the proposed law must be 
circulated, in accordance with the Standing Orders of the Parliament, to all members of the 
Parliament at least four days before the proposed law is made. 
(4) 
During a time of war, the periods of four days prescribed in Subsection (3) are reduced 
to 24 hours. 
(5) 
In his certificate given under Section 110 (certification as to making of laws) the 
Speaker must certify that the requirements of Subsection (2)(a) and (b), and of Subsection (3) or 
(4), as the case may be, have been complied with. 
(6) 
Internment may continue after the end of the period of declared national emergency 
only to the extent that is reasonably required for the orderly and peaceful repatriation, 
resettlement or re-establishment of internees. 
245. Internment. 
(1) 
The following provisions apply to and in relation to an internee:— 
(a) an internee and his next-of-kin or other close relative in the country shall, as soon as 
practicable and in any case not more than seven days after the commencement of his 
internment, be furnished with a statement in writing in a language that he understands 
specifying in detail the grounds upon which he is interned; and 
(b) subject to Section 244(6) (laws providing for internment), an internee (other than an 
alien enemy) shall be released from detention at the end of the period of two months 
after his internment unless an independent and impartial tribunal established under 
paragraph (e) has reviewed his case and found that sufficient cause has been shown for 
his internment; and 
(c) subject to Section 244(6) (laws providing for internment) an internee (other than an 
alien enemy) shall be released from detention at the end of the period of six months after
```

---

## Page 115

```text
115
his internment; and 
(d) an internee (other than an alien enemy) is entitled to have his case reviewed by an 
independent and impartial tribunal established under paragraph (e) as soon as practicable 
after he has been interned, and in any case not more than one month after the 
commencement of his internment, and afterwards at intervals not exceeding two months; 
and 
(e) an Organic Law shall provide for the establishment of the independent and impartial 
tribunal referred to in this section and that the Chairman of the tribunal shall be a person 
qualified to be a Judge of the National Court; and 
(f) the Organic Law referred to in paragraph (e) shall provide that as far as practicable 
where the case of an internee is being reviewed on a second or subsequent occasion, a 
majority of the members (including the Chairman) of any tribunal referred to in that 
paragraph which conducts that review shall be different from the members of any such 
tribunal which previously reviewed the case of that detainee; and 
(g) subject to Subsection (5), where a tribunal established under paragraph (e) finds that 
a citizen has been interned wrongly or without sufficient reason— 
(i) 
the Head of State, acting with, and in accordance with, the advice of the 
National Executive Council shall order that he be released; and 
(ii) 
he is entitled to compensation, in accordance with law, for the internment and 
any consequences of it; and 
(h) subject to Subsection (5), where a tribunal established in accordance with paragraph 
(e) finds that there are no longer sufficient grounds for the internment of a citizen, the 
Minister responsible for national security shall order that he be released immediately; 
and 
(i) a person released from internment in accordance with paragraphs (c), (g) or (h) shall 
not again be interned substantially on the same facts unless a change in circumstances 
relating to the grounds of the original internment gives these facts a new significance; 
and 
(j) internees shall be kept separated, as far as practicable, from other persons in custody, 
and shall receive treatment not less favourable than that afforded to persons in custody 
awaiting trial for offences; and 
(k) the names and places of residence of internees shall be published in the National 
Gazette and in any newspaper which has a national circulation, within 14 days of the 
internment, and at monthly intervals afterwards; and 
(l) the Minister responsible for national security shall present to the Parliament at each 
meeting of the Parliament during the period of declared national emergency, but in any 
event, at intervals not exceeding six months, reports concerning all internees, their 
treatment, the review of their cases and action taken in regard to them. 
(2) 
An internee shall be given adequate facilities to prepare and make representations to the 
review tribunal referred to in Subsection (1)(e) either personally or through a lawyer, and in 
particular shall be allowed full access to a lawyer (and if necessary to legal aid) and the services 
of a competent interpreter if required. 
(3) 
An internee shall— 
(a) be permitted to appear in person before the review tribunal; and
```

---

## Page 116

```text
116
(b) be permitted to be represented by a lawyer and a friend before the review tribunal. 
(4) 
The tribunal shall forward copies of its findings and recommendations to the internee 
and to his next-of-kin or other close relative in the country when they are furnished to the 
Minister responsible for national security. 
(5) 
Where in his opinion it is necessary to do so in the interests of national security or 
public order, the Head of State, acting with, and in accordance with, the advice of the National 
Executive Council may refuse to make an order in accordance with, the need for a consequential 
amendment to Subsection (5) was apparently overlooked. 
Subsection (1)(g) or (h) for the release of an internee, but in that event, except in time of war— 
(a) he shall promptly present to the Parliament a report stating that he has refused to 
release the internee and setting out the reasons for his refusal; and 
(b) the Parliament may order that the internee be released. 
(6) 
Where an order is made in accordance with Subsection (5)— 
(a) the internee shall be released in accordance with the order; and 
(b) Subsection (1)(i) applies as though the order were an order under Subsection(1)(g) or 
(h), as appropriate. 
(7) 
An Organic Law, an Act of the Parliament or an emergency law may make further 
provision, not inconsistent with this section, in respect of the treatment, security and discipline of 
internees. 
(8) 
The provisions of the Geneva Convention Relative to the Protection of Civilian Persons 
in Time of War of August 14 1949, and any other international convention relating to interned 
persons, shall be complied with in relation to persons protected by them, and in addition such of 
those provisions that are of general application and can appropriately be applied to interned 
citizens shall be complied with in relation to such internees. 
Division 6.—Miscellaneous. 
246. Extension of tenure of Parliament and Governor-General. 
During a period of declared national emergency the Parliament may, by an absolute majority 
vote, extend its term of office, or the term of office of the Governor-General, or both, for a term 
not exceeding the length of the period and such time afterwards as is necessary to allow a general 
election to be arranged and held, or for a Governor-General to be appointed, as the case requires. 
 
PART XI.—MISCELLANEOUS. 
247. Legal capacity of the Independent State of Papua New Guinea. 
(1) 
Papua New Guinea has power to acquire, hold and dispose of property of any kind, and 
to make contracts, in accordance with an Act of the Parliament. (See: Lands (Acquisition 
Development Purposes) Act (Chapter 192); Public Finance (Management) 
Act 1995) 
(2) 
Papua New Guinea may sue and be sued, in accordance with an Act of the Parliament. 
248. Vesting of rights and liabilities of former Government.
```

---

## Page 117

```text
117
All property that was, immediately before Independence Day, vested in the body corporate at 
that time known as “The Government of Papua New Guinea” is, on that day, vested in Papua 
New Guinea, and all rights and liabilities (actual or contingent) of that body immediately before 
that day are, on that day, rights and liabilities of Papua New Guinea. 
249. Declarations by certain office-holders. 
Subject to any Organic Law, every person who is subject to Division III.2 (leadership code) 
before entering upon the duties of or exercising any of the powers of his office, shall make— 
(a) unless he has made it on a previous occasion or is exempt from making it under— 
(i) 
Section 251(1) (taking certain oaths, etc., by non-citizens); or 
(ii) 
Section 272 (oaths, affirmation, etc.), 
the Declaration of Loyalty; and 
(b) in the case of— 
(i) 
a judicial officer—the Judicial Declaration; or 
(ii) 
an office-holder other than a judicial officer—the Declaration of Office. 
250. Making of Declaration of Loyalty, etc. 
(1) 
Subject to any provision of a Constitutional Law making special provision for the 
purpose, the Oath of Allegiance, the Declaration of Loyalty, the Judicial Declaration or the 
Declaration of Office (or any other oath, affirmation or declaration that is required or permitted 
to be taken or made by or for the purposes of a Constitutional Law) may be taken or made before 
any person appointed for the purpose by or under an Act of the Parliament, or in the absence of 
any such Act, before a person appointed for the purpose by the Head of State, acting with, and in 
accordance with, the advice of the National Executive Council. 
(2) 
Notwithstanding the provisions of Subsection (1), an oath, affirmation or declaration 
referred to in that subsection is binding and effectual no matter before whom it is taken or made. 
251. Taking certain oaths, etc., by non-citizens. 
(1) 
If— 
(a) it is desirable that a non-citizen be appointed to an office under or a statue was 
intended. 
a statute; and 
(b) it is a requirement that in order to be qualified for appointment, or to enter upon the 
duties or exercise the powers of the office, a person must take the Oath of Allegiance or 
make the Declaration of Loyalty, or take or make some oath, affirmation or declaration; 
and 
(c) the National Executive Council is satisfied that, by reason of the law of some other 
country, to take the Oath of Allegiance or make the Declaration of Loyalty, or to take or 
make the other oath, affirmation or declaration, in the prescribed manner or form would 
or might adversely affect the nationality or citizenship status of the person concerned, 
the Head of State, acting with, and in accordance with, the advice of the National Executive 
Council, may, by order, substitute some oath, affirmation or declaration or, if thought necessary, 
exempt the person from the requirement.
```

---

## Page 118

```text
118
(2) 
Notwithstanding Subsection (1), the non-citizen is subject to all laws as if he had made 
the Declaration of Loyalty, or had taken or made the other oath, affirmation or declaration, as the 
case may be. 
(3) 
Nothing in Subsection (1) applies to or in respect of the Judicial Declaration. 
252. The National Gazette. 
There shall be an official journal of the National Government, which shall be known as the 
National Gazette or by such other name as is given by or under an Act of the Parliament. 
253. Slavery, etc. 
Slavery, and the slave trade in all their forms, and all similar institutions and practices, are 
strictly prohibited. 
254. Filling of offices, etc. 
In principle— 
(a) no constitutional office shall be left unfilled on a substantive basis for longer than is 
necessary for it to be filled by an appropriate appointee; and 
(b) no person shall hold more than one public office at the same time except where one 
such office is so much associated with, or related to, another, or where the holding of 
one such office is so relevant to the holding of another, as to make it desirable that the 
offices be held jointly; and 
(c) public offices of similar importance or standing, and in particular offices in any 
statutory board or committee, should be filled by persons from the various areas of the 
country. 
255. Consultation. 
In principle, where a law provides for consultation between persons or bodies, or persons and 
bodies, the consultation must be meaningful and allow for a genuine interchange and 
consideration of views. 
256. Reports by public office-holders, etc. 
Subject to this Constitution, an Act of the Parliament may make provision for and in respect of 
annual and other reports by a constitutional office-holder or any other public office-holder, or by 
a constitutional institution or any other statutory body. 
257. Proof of acts of the Constituent Assembly. 
(1) 
All courts, Judges and persons acting judicially shall take judicial notice of all acts and 
proceedings of the Constituent Assembly. 
(2) 
An act of, or the proceedings of, the Constituent Assembly may be proved for any 
purpose by the production of— 
(a) a certificate under the hand, or purporting to be under the hand, of the Speaker of the 
pre-Independence House of Assembly; or 
(b) a document under the hand, or purporting to be under the hand, of the Clerk or other 
proper officer of the pre-Independence House of Assembly and purporting to be the
```

---

## Page 119

```text
119
minutes or other official record of the proceedings of the Constituent Assembly. 
258. Constitutional Regulations. 
(1) 
The Head of State, acting with, and in accordance with, the advice of the National 
Executive Council, may make regulations, not inconsistent with a Constitutional Law or an Act 
of the Parliament, prescribing all matters that by a Constitutional Law are required or permitted 
to be prescribed or provided for by Constitutional Regulation. 
 (See: Electoral Regulation 1977) 
(2) 
All Constitutional Regulations shall be tabled in the Parliament as soon as practicable 
after being made, and may be disallowed by the Parliament at any time. 
259. Independent tribunals. 
Unless otherwise provided for by a Constitutional Law, in any case where a Constitutional Law 
requires the appointment of an independent tribunal, the members of that tribunal shall be 
appointed from a list of names approved by the Judicial and Legal Services Commission. 
 
PART XII.—CONSTITUTIONAL REVIEW. 
260. General Constitutional Commission. 
(1) 
An Act of the Parliament shall make provision for and in respect of the establishment, at 
or after the end of the period of three years commencing on Independence Day, of a General 
Constitutional Commission. (See: Constitutional and Law Reform Commission 
Act 2004) 
(2) 
The members of the Commission shall— 
(a) be appointed by the Head of State, acting with, and in accordance with, the advice of 
the National Executive Council given after consultation with any appropriate 
parliamentary committee; and 
(b) be broadly representative of the different areas of the country; and 
(c) give balanced representation of the major parties and groups in Parliament. 
(3) 
Each member of the General Constitutional Commission must be— 
(a) a member of the Parliament; or 
(b) a member of a provincial government or local government body; or 
(c) a member of a State Service; or 
(d) some other citizen with relevant expertise. 
(4) 
The General Constitutional Commission shall inquire into the working of this 
Constitution and the Organic Laws. 
(5) 
As soon as is reasonably practicable after its appointment, the General Constitutional 
Commission shall forward a report of its findings to the Speaker for presentation to the 
Parliament, together with its recommendations (if any) as to amendment of this Constitution, and 
new or amended Organic Laws or other laws or administrative procedures. 
261. Interim Constitutional Commission.
```

---

## Page 120

```text
120
(1) 
An Act of Parliament shall provide that until the Constitutional Commission is 
established there shall be an Interim Constitutional Commission the membership of which is in 
accordance with Section 260(2) and (3) (General Constitutional Commission). 
(2) 
The Interim Constitutional Commission shall consideration was intended proposed 
alteration of this Constitution or of any Organic Law, and report to Parliament before there is an 
opportunity for debate of the proposed legislation. 
262. Subordinate commissions and committees. 
 
(1) 
Acts of the Parliament may make provision for and in respect of— 
(a) a Commission on Provincial Government, the primary function of which shall be to 
investigate the workings of the system of provincial government; and 
(b) other commissions and committees to investigate such other aspects of the working 
of this Constitution as the Parliament thinks desirable. (Subsection (1) repealed 
& replaced by Constitutional Amendment No.1) 
(2) 
The commissions and committees established in accordance with Subsection (1)(b) shall 
report to the General Constitutional Commission on the subject matters of their respective 
investigations, with such recommendations (if any) as they think desirable, in time to allow the 
General Constitutional Commission to report to the Parliament in accordance with Section 260 
(General Constitutional Commission). 
(3) 
The General Constitutional Commission shall ensure that any reports of commissions or 
committees established in accordance with Subsection (1)(b) are forwarded to the Speaker for 
presentation to the Parliament before or at the same time as its report is so forwarded. 
263. Further definition, etc. 
Acts of the Parliament may make provision for further defining the terms of reference of the 
General Constitutional Commission and any other commissions or committees established in 
accordance with Section 262 (subordinate commissions and committees). 
 
PART XIII.— IMMEDIATE AND TRANSITIONAL PROVISIONS. 
264. Effect of Part XIII. 
The provisions of this Part, and of any Provisional Organic Law or Organic Law made for the 
purposes of Section 267 (transitional laws), have effect notwithstanding anything in the 
preceding provisions of this Constitution. 
265. Dissolution of the Constituent Assembly. 
The Constituent Assembly, having performed its duty to frame and adopt, on behalf of the 
People, a Constitution, and its other duties, is dissolved. 
266. Provisional laws. 
(1) 
If before Independence Day the Constituent Assembly has made an instrument 
expressed to be a Provisional Organic Law, the instrument takes effect, on Independence Day, as
```

---

## Page 121

```text
121
if it were an Organic Law made and coming into effect on that day. 
(2) 
If before Independence Day the Constituent Assembly has made an instrument 
expressed to be a Provisional Act of the Parliament made for the purpose of bringing any 
provision of this Constitution into effective operation on Independence Day, the instrument takes 
effect, on Independence Day, as if it were an Act of the Parliament made and coming into effect 
on that day. 
267. Transitional laws. 
(1) 
A Provisional Organic Law or an Organic Law may make whatever provision seems 
necessary or desirable for a smooth transition from pre-Independence arrangements to 
arrangements under this Constitution and, in particular, but without limiting the generality of the 
foregoing, for securing— 
(a) the immediate filling of offices, and the immediately effective operation of 
institutions under this Constitution where there were corresponding pre-Independence 
offices or institutions; and 
(b) the continued effect of acts done or commenced before Independence Day under pre-
Independence laws. 
(2) 
A Provisional Organic Law or an Organic Law made for the purposes of Subsection (1) 
may declare what were the pre-Independence offices and institutions that correspond with offices 
and institutions under this Constitution. (See: Organic Law on Certain 
Constitutional Office Holders; Organic Law on Immediate and 
Transitional Constitutional Provisions) 
 
 
268. First Governor-General. 
If before Independence Day— 
(a) the Constituent Assembly has nominated by a simple majority vote, in an exhaustive 
secret ballot a person to be the first Governor-General; and 
(b) Her Majesty, Elizabeth II, having consented to become Queen and Head of State of 
Papua New Guinea has signified her approval to that person becoming the Governor-
General, 
that person becomes the first Governor-General on Independence Day. 
269. First Parliament, electorates, etc. 
(1) 
Notwithstanding anything in this Constitution, but subject to Subsection (6), the open 
and regional electorates for the pre-Independence House of Assembly established immediately 
before Independence Day are the first open and provincial (as the case may be) electorates for 
the Parliament. 
(2) 
Notwithstanding anything in this Constitution but subject to any Organic Law on 
national electoral matters— 
(a) each member of the pre-Independence House of Assembly in office immediately
```

---

## Page 122

```text
122
before Independence Day (including a member who although he is or may be 
disqualified under Section 37(4)(a) of the Papua New Guinea Act 1949-1975 of 
Australia has been confirmed in his membership by resolution of the House of 
Assembly) is the first member of the Parliament for his electorate and shall continue to 
hold office unless or until— 
(i) 
his seat becomes vacant by virtue of Section 104(2)(a), (b), (c), (d), (e), (g) or 
(h) (normal term of office); or 
(ii) 
he becomes a person who has been convicted of and is under sentence of 
imprisonment, or is subject to be sentenced (other than a person who has been 
released on recognizance to appear and receive judgement when called upon), for an 
offence punishable by imprisonment for one year or longer, as in Section 50(1)(a) 
(right to vote and stand for public office); or 
(iii) he becomes disqualified under Section 103(3)(b) or (d) (qualifications for and 
disqualifications from membership); and 
(b) the pre-Independence Speaker and Chairman of Committees in office immediately 
before Independence Day are the first Speaker and Deputy Speaker, respectively, of the 
Parliament; and 
(c) the electoral rolls in effect immediately before Independence Day are the first 
electoral rolls for the first open and provincial electorates (as the case may be). 
(3) 
The Boundaries Commission shall recommend to the Parliament the number of open 
electorates and their boundaries for determination by the Parliament under Section 125(1) 
(electorates) as soon as possible after Independence Day. 
(4) 
Unless a general election to the Parliament is held earlier under Section 105 (general 
elections) the term of the first Parliament is— 
(a) the balance of the term of the pre-Independence House of Assembly remaining 
unexpended immediately after Independence Day; and 
(b) the period up to the first general election held after Independence Day and the first 
general elections shall be held, as directed by the Head of State, acting with, and in 
accordance with, the advice of the Electoral Commission, in the months May and June 
1977. 
(5) 
If the Parliament has not made a determination under Section 125(1) (electorates) in 
time for the first general elections held after Independence Day— 
(a) the number and boundaries of the open electorates shall remain the same as for the 
previous general elections; and 
(b) the number of provincial electorates shall be as determined by an Organic Law; and 
(c) the boundaries of the provincial electorates shall be as determined by the Head of 
State, acting with, and in accordance with, the advice of the Boundaries Commission, 
but so that the boundaries of the provincial electorates— 
(i) 
enclose all the territory of open electorates within each province; and 
(ii) 
so near as may be, coincide with the boundaries of the provinces as defined in 
the Organic Law on Provincial Boundaries and the boundaries of the National 
Capital District as defined in the Organic Law on the Boundaries of the National 
Capital District.
```

---

## Page 123

```text
123
(6) 
If a provincial electorate consists of two or more provinces, an Organic Law shall make 
adequate provision for— 
(a) the declaration of each province as a provincial electorate; and 
(b) each electorate to be represented by a provincial member, 
as soon as practicable after Independence Day. 
270. First Ministry. 
(1) 
The pre-Independence Chief Minister in office immediately before Independence Day is 
the first Prime Minister. 
(2) 
The other Ministers of the pre-Independence House of Assembly in office immediately 
before Independence Day are the other first Ministers. 
271. First Judges. 
Notwithstanding anything in this Constitution— 
(a) the pre-Independence Chief Justice in office immediately before Independence Day 
is the first Chief Justice of Papua New Guinea; and 
(b) the Senior Puisne Judge in office immediately before Independence Day is the First 
Deputy Chief Justice of Papua New Guinea; and 
(c) each Judge in office immediately before Independence Day is a Judge of the National 
Court; and 
(d) each acting Judge in office immediately before Independence Day is an Acting Judge 
of the National Court, 
on the same terms and conditions that were applicable to him before Independence Day but in no 
case shall his term of office exceed three years from the date of his present appointment. 
272. Oaths, affirmation, etc. 
(1) 
Notwithstanding anything in this Constitution, but subject to Section 250 (making of 
Declaration of Loyalty, etc.) and Section 251 (taking certain oaths, etc., by non-citizens)— 
(a) the first Governor-General shall take the Oath of Allegiance and make the 
Declaration of Loyalty and the Declaration of Office; and 
(b) the first Prime Minister and other Ministers, and the first Speaker and Deputy 
Speaker, shall make the Declaration of Loyalty and the Declaration of Office; and 
(c) the first Chief Justice and other Judges shall make the Judicial Declaration, 
in public on Independence Day, at such place, and in such manner and form, as are directed by 
the Prime Minister. 
(2) 
If it is not practicable for a person referred to in Subsection (1)(a), (b) or (c) to comply 
with the requirements of Subsection (1), he shall take and make the necessary oath or 
declarations, or both, as the case requires, at such time and place, and in such manner and form, 
as are directed by the Head of State, acting with, and in accordance with, the advice of the Prime 
Minister. 
(3) 
Any provision of this Constitution preventing a person referred to in Subsection (1)(a), 
(b) or (c) from entering upon the duties of his office until he has taken the Oath of Allegiance or
```

---

## Page 124

```text
124
made the Declaration of Loyalty, the Declaration of Office or the Judicial Declaration (as the 
case requires) is suspended pending compliance with the preceding provisions of this section. 
273. Treaties applying before Independence. 
The provisions of Section 117 (treaties, etc.) do not prevent the Head of State, acting with, and 
in accordance with, the advice of the National Executive Council, from making a declaration that 
an international commitment, that, immediately before Independence Day, applied to the 
territory at that time known as Papua New Guinea or a component part of that territory may, by 
agreement, be treated as if it were binding on Papua New Guinea for a period not exceeding five 
years after that day. 
274. Composition of certain constitutional institutions. 
Except where expressly provided otherwise in a Constitutional Law, until 16 September 1985, 
where a constitutional institution other than the Supreme Court or the National Court is 
composed of more than one person, the majority of those persons must be citizens, but failure to 
comply with this section does not invalidate any act of the institution. 
275. Chairmanship of tribunal to review internments. 
Until 16 September 1985, in addition to persons who are qualified to be appointed as Judges of 
the National Court, a person who holds office as a magistrate of the highest grade or 
classification is eligible for appointment as Chairman of a tribunal appointed in accordance with 
Section 245(1)(e) (internment). 
 
 
PART XIV.—BOUGAINVILLE GOVERNMENT AND BOUGAINVILLE REFERENDUM. 
Division 1.—Preliminary. 
276. Application of this Part. 
(1) 
This Part applies in and in relation to Bougainville only. 
(2) 
This Part shall apply notwithstanding the provisions of this Constitution and where the 
other provisions of this Constitution are inconsistent with the provisions of this Part, the 
provisions of this Part shall prevail. 
 
277. Non-application of Part VIA. 
After the establishment of the Bougainville Government following elections, in accordance with 
this Part and the Bougainville Constitution, the provisions of Part VIA shall not apply to 
Bougainville. 
278. Interpretation. 
(1) 
In this Part, unless the contrary intention appears— 
“Agreement” means the Bougainville Peace Agreement signed at Arawa on 30 August
```

---

## Page 125

```text
125
2001 and published in National Gazette No. G146 of 16 November 2001; 
“Bougainville” means— 
(a) 
the areas of land within the boundaries of Bougainville Province as described 
in the Schedule to the Organic Law on Provincial Boundaries; and 
(b) 
the areas of sea extending to three nautical miles from the low water mark of 
the areas of land referred to in Paragraph (a); 
“Bougainville Constituent Assembly” means the Bougainville Constituent Assembly 
established in accordance with Section 284 (Bougainville Constituent Assembly); 
“Bougainville Constitution” means the Bougainville Constitution endorsed and gazetted 
in accordance with Section 285 (Endorsement of Bougainville Constitution); 
“Bougainville Constitutional Commission” means the Bougainville Constitutional 
Commission established in accordance with Section 281 (Bougainville Constitutional 
Commission); 
“Bougainville Constitutional Office-holder” means a Bougainville Constitutional Office-
holder appointed under or in pursuance of the provisions of Section 321 (Bougainville 
Constitutional office-holders); 
“Bougainville Correctional Service” means Bougainville Correctional Service for which 
provision is made under Section 310(1)(c) (Bougainville Government Services); 
“Bougainville court” means a court established under Section 306(1) (Establishment of 
courts in Bougainville) 
“Bougainville Executive” means the accountable executive body of the Bougainville 
Government; 
“Bougainville Government” means the autonomous Bougainville Government 
established in accordance with this Part; 
“Bougainville Interim Provincial Government” means the Bougainville Interim 
Provincial Government established under the Organic Law on Provincial Governments 
and Local-level Governments; 
“Bougainville law” means a law made in accordance with the Bougainville Constitution 
and this Part; 
“Bougainville Legislature” means the legislature of the Bougainville Government; 
“Bougainville Police” means the Bougainville Police for which provision is made under 
Section 310(1)(b) (Bougainville Government Services); 
“Bougainville Public Service” means the Bougainville Public Service for which 
provision is made under Section 310(1)(a) (Bougainville Government Services); 
“Bougainville Referendum” mean the Referendum for which provision is made under 
Division 7 (Bougainville Referendum); 
“Bougainville Salaries and Remuneration Commission” means the Bougainville Salaries 
and Remuneration Commission established in accordance with Section 320 
(Bougainville Salaries and Remuneration Commission); 
“dispute resolution procedure” means the dispute resolution procedure for which 
provision is made under Division 6 (Intergovernmental Relations and Review); 
“fiscal self-reliance” means the first year in which the revenue from company tax, 
customs duties and 70% of value added tax collected in Bougainville is equal to the 
value of the recurrent grant on a sustainable basis;
```

---

## Page 126

```text
126
“National law” means a law made by the National Parliament; 
“Referendum” means the Bougainville Referendum; 
“review” means a review under Division 6. 
(2) 
Where this Part or an Organic Law authorized by this Part provides for consultation 
between the National Government and the Bougainville Government, such consultation shall be 
conducted on the following basis:— 
(a) views shall be communicated in a timely manner in writing (or, by prior written 
agreement, by electronic equivalent) to a specified point of contact; 
(b) adequate opportunity shall be given to respond in a similar manner; 
(c) where there are differences, meaningful views shall be exchanged within an adequate 
time-frame, either agreed or specified in a written document (or, by prior written 
agreement, by electronic equivalent) with a view to reaching agreement; 
(d) a clear, written record of the outcome of a consultation shall be prepared and made 
available for all parties. 
(3) 
The Agreement may be used, so far as it is relevant, as an aid to interpretation where 
any question relating to the interpretation or application of any provision of this Part or an 
Organic Law authorized by this Part arises. 
(4) 
The Agreement shall be interpreted liberally, by reference to its intentions and without 
undue reference to technical rules of construction. 
 
 
 
 
Division 2.—Arrangements for the Establishment of Bougainville Government. 
279. Autonomous government for Bougainville. 
(1) 
There shall be a system of autonomous government for Bougainville in accordance with 
this Part. 
(2) 
Elections to the Bougainville Legislature may be held only— 
(a) in accordance with an agreement reached in accordance with Paragraph 8(a) of the 
weapons disposal plan contained in the Agreement; or 
(b) on verification and certification by the Director of the United Nations Observer 
Mission in Bougainville, of substantial compliance with, and generally in accordance 
with Paragraph 8(b) of, the weapons disposal plan according to the Agreement. 
(3) 
An Organic Law shall make provision for such matters pertaining to the system of 
autonomous government as are authorized by this Part. 
280. Bougainville Constitution. 
There shall be a Bougainville Constitution made and endorsed in accordance with this Part, 
which shall make provision for the organization and structures of the government for 
Bougainville under the autonomy arrangements in a manner consistent with this Part and with
```

---

## Page 127

```text
127
the Agreement. 
281. Bougainville Constitutional Commission. 
(1) 
The Bougainville Interim Provincial Government, after consultation in accordance with 
the Agreement, shall establish a Bougainville Constitutional Commission which shall be broadly 
representative of the people of Bougainville. 
(2) 
The Bougainville Constitutional Commission shall— 
(a) consult widely with the people of Bougainville to obtain their views on a 
Bougainville Constitution; and 
(b) prepare a draft Bougainville Constitution. 
(3) 
Where, prior to the coming into operation of this Part, the Bougainville Interim 
Provincial Government has established a body, after consultation in accordance with the 
requirements of the Agreement in relation to the Bougainville Constitutional Commission, with 
functions equivalent to those given to the Bougainville Constitutional Commission by 
Subsection (2)— 
(a) such body may be adopted by the Bougainville Interim Provincial Government as the 
Bougainville Constitutional Commission; and 
(b) any consultation by, and reports, findings and drafts prepared by such body may be 
adopted by the Bougainville Interim Provincial Government as consultation by, and 
reports, findings and drafts of the Bougainville Constitutional Commission. 
282. Structures of Bougainville government to be contained in Bougainville 
Constitution. 
(1) 
The Bougainville Constitution shall make provision for the Bougainville Government 
generally and in particular shall provide, subject to this Part and to any Organic Law authorized 
by this Part— 
(a) that the Bougainville Government shall include a mainly elective (either directly or 
indirectly) legislature, but which may include persons appointed, elected or nominated to 
represent community, youth or other interests; and 
(b) that the Bougainville Government shall include an accountable executive body; and 
(c) for a head of the executive body and for his title, the method of his appointment and 
his powers and functions; and 
(d) for the establishment of an independent and impartial judiciary for Bougainville in 
accordance with this Part; and 
(e) for the powers, functions and procedures of the legislature, executive and judiciary, 
in accordance with the terms of the Agreement; and 
(f) for the establishment of such institutions as are necessary or desirable to enable the 
Bougainville Government to carry out its powers effectively; and 
(g) for the accountability of all institutions established by or under the Bougainville 
Constitution; and 
(h) for Bougainville Constitutional Office-holders and for their powers and functions; 
and 
(i) for the manner in which the Bougainville Constitution will come into operation after 
its endorsement by the Head of State, acting on advice; and
```

---

## Page 128

```text
128
(j) for the naming of Bougainville, the Bougainville Government and institutions of the 
Bougainville Constitution or Bougainville Government; and 
(k) for any other matters required by this Part. 
(2) 
The structures and procedures of the Bougainville Government shall meet 
internationally accepted standards of good governance, as they are applicable and implemented 
in the circumstance of Bougainville and Papua New Guinea as a whole, including democracy, 
the opportunity for participation by Bougainvilleans, transparency, accountability, and respect 
for human rights and the rule of law, including this Constitution. 
283. Consultation with National Executive Council. 
The Bougainville Constitutional Commission shall— 
(a) keep the National Executive Council informed as proposals for the Bougainville 
Constitution are developed; and 
(b) allow the National Executive Council adequate opportunity to make its views known 
as proposals for the Bougainville Constitution are developed. 
284. Bougainville Constituent Assembly. 
(1) 
The Bougainville Interim Provincial Government, after consultation in accordance with 
the Agreement, shall establish a Bougainville Constituent Assembly which shall be broadly 
representative of the people of Bougainville. 
(2) 
The Bougainville Constituent Assembly— 
(a) shall consider and debate the draft Bougainville Constitution; and 
(b) may amend the draft Bougainville Constitution; and 
(c) shall submit the draft Bougainville Constitution to the National Executive Council 
and consult with the National Executive Council on its contents; and 
(d) may adopt the Bougainville Constitution; and 
(e) following adoption by it of the Bougainville Constitution, send a copy of that 
Bougainville Constitution to the Minister responsible for Bougainville matters. 
(3) 
The Bougainville Government and the National Government shall co-operate in 
facilitating the establishment of the Constituent Assembly. 
285. Endorsement of Bougainville Constitution. 
(1) 
The Minister responsible for Bougainville matters shall submit that Bougainville 
Constitution to the National Executive Council at the first practicable opportunity. 
(2) 
The National Executive Council shall consider the Bougainville Constitution within 14 
days of its being submitted under Subsection (1) and, where it meets the requirements of this Part 
and any Organic Law authorized by this Part, shall advise the Head of State to endorse the 
Bougainville Constitution. 
(3) 
The Head of State, acting on advice in accordance with Subsection (2), shall endorse the 
Bougainville Constitution. 
(4) 
After the Bougainville Constitution has been endorsed under Subsection (3), the 
National Executive Council shall cause it to be published promptly in the National Gazette.
```

---

## Page 129

```text
129
(5) 
Following publication in the National Gazette, the Bougainville Constitution shall come 
into operation in accordance with the manner provided in the Bougainville Constitution. 
286. Legal status of Bougainville Constitution. 
(1) 
Subject to this Constitution, the Bougainville Constitution shall be the supreme law as 
regards matters that fall within the jurisdiction of the Bougainville Government in accordance 
with this Part and the Agreement, and Bougainville laws and institutions shall be consistent with 
the Bougainville Constitution. 
(2) 
The Bougainville Constitution shall be enforceable— 
(a) in the Supreme Court; and 
(b) in the Bougainville Court established under Section 306(4)(a) (establishment of 
courts in Bougainville), 
to the extent provided by the Bougainville Constitution. 
287. Amendment of Bougainville Constitution. 
(1) 
The Bougainville Constitution shall provide that the Bougainville Constitution may be 
amended and shall provide for the manner in which it may be amended so as to comply with this 
section. 
(2) 
Where any amendment to the Bougainville Constitution is proposed, the Bougainville 
Executive shall give notification of it to the Minister responsible for Bougainville matters. 
(3) 
The National Government may consult with the Bougainville Government in relation to 
any proposed amendment of the Bougainville Constitution. 
 
 
Division 3.—Division of Functions and Powers between National Government and 
Bougainville Government and transfer of functions and powers to Bougainville 
Government. 
288. Division of functions and powers of government. 
The functions and powers of government relating to Bougainville shall be divided between the 
National Government and the Bougainville Government in accordance with this Part and the 
Agreement. 
289. Functions and powers of the National Government. 
(1) 
Subject to this Part and to the Agreement, the functions and powers of the National 
Government in and in relation to Bougainville are as specified in this section. 
(2) 
The functions and powers of the National Government in and in relation to Bougainville 
are the following:— 
(a) central banking; 
(b) currency; 
(c) customs (imposition, administration and collection);
```

---

## Page 130

```text
130
(d) defence; 
(e) foreign relations (including foreign aid); 
(f) highly migratory and straddling fish stocks; 
(g) industrial relations; 
(h) international civil aviation; 
(i) international shipping; 
(j) international trade; 
(k) legislation specifically required to implement this Constitution; 
(l) legislation required to amend this Constitution; 
(m) 
migration in and out of the country; 
(n) quarantine; 
(o) posts; 
(p) telecommunications; 
(q) such other powers and functions for which, in accordance with this Part and the 
Agreement, the National Government is responsible. 
(3) 
The National Government is responsible in and in relation to Bougainville for the 
operation of the functions and powers of a Constitutional office or State Service to the extent 
necessary— 
(a) where an equivalent Bougainville Constitutional office or Bougainville Government 
Service has not been established or is not fully operational; or 
(b) as otherwise provided for or required by this Part or the Agreement. 
(4) 
The National Government shall have the function and power relating to firearms 
control. 
(5) 
The National Government shall have the function and power relating to foreign 
investment to the extent permitted by Section 290(4) (functions and powers available to the 
Bougainville Government). 
(6) 
The National Government shall have the functions and powers necessary to develop the 
infrastructure relative to its functions and powers under this section. 
(7) 
The— 
(a) Bougainville Government shall not obstruct the National Government in the exercise 
of its functions and powers under this section; and 
(b) exercise by the National Government of its functions and powers under this section 
shall respect the Bougainville laws. 
290. Functions and powers available to the Bougainville Government. 
(1) 
Subject to this Part and the Agreement, the functions and powers available to the 
Bougainville Government in and in relation to Bougainville are as specified in this section. 
(2) 
The functions and powers available to the Bougainville Government in and in relation 
to Bougainville are the following:— 
(a) agriculture; 
(b) arts; 
(c) building regulation;
```

---

## Page 131

```text
131
(d) cemeteries; 
(e) censorship; 
(f) children; 
(g) churches and religion; 
(h) civil registration; 
(i) communications and information services within Bougainville; 
(j) community development; 
(k) corporation law; 
(l) culture; 
(m) 
education; 
(n) energy (including electricity and power generation and distribution); 
(o) environment; 
(p) family law; 
(q) fire service; 
(r) fisheries (other than highly migratory or straddling stocks); 
(s) forestry and agro-forestry; 
(t) gambling, lotteries and games of chance; 
(u) harbours and marine; 
(v) health; 
(w) heritage; 
(x) home affairs, including youth and social welfare; 
(y) housing (but not State-owned housing); 
(z) information technology; 
(za) 
insurance; 
(zb) 
intellectual property; 
(zc) 
labour and employment (other than industrial relations); 
(zd) 
land and natural resources; 
(ze) 
land, sea and air transport; 
(zf) 
language; 
(zg) 
libraries and measures; 
(zh) 
licensing of public entertainment; 
(zi) liquor; 
(zj) livestock; 
(zk) 
local-level government; 
(zl) manufacturing; 
(zm) mining; 
(zn) 
non-banking financial institutions; 
(zo) 
oil and gas; 
(zp) 
parks and reserves; 
(zq) 
physical planning; 
(zr) 
professions; 
(zs) 
public holidays; 
(zt)     public works;
```

---

## Page 132

```text
132
(zu) 
science and technology; 
(zv) 
sports and recreations; 
(zw) statistics (other than National Census); 
(zx) 
symbols of the Bougainville Government; 
(zy) 
time zones; 
(zz) 
tourism; 
(zza) trade, commerce and industry; 
(zzb) waste management; 
(zzc) water and sewerage; 
(zzd) water resources; 
(zze) wild life preservation; 
(zzf) wills and succession; 
(zzg) such other functions and powers for which, in accordance with this Part and the 
Agreement, the Bougainville Government may be responsible. 
(3) 
The Bougainville Government is responsible for— 
(a) administration of justice including dispute resolution; and 
(b) the operation and the functions and powers of Bougainville Constitutional Office-
holders; and 
(c) the operation of and the powers and functions of Bougainville Government Services, 
in accordance with the Agreement and this Part. 
(4) 
Where the function and power relating to foreign investment applications has been 
transferred to the Bougainville Government, it shall be exercised in the following manner:— 
(a) each application for foreign investment relating to Bougainville shall be lodged in 
duplicate, one for the National Government and one for the Bougainville Government; 
(b) each application must satisfy the National Government‘s reasonable foreign 
investment requirements for Papua New Guinea as a whole; 
(c) the Bougainville Government, through the Bougainville Public Service or by an 
authority established by the Bougainville Government for the purpose, shall be 
responsible for considering each application and for determining whether the 
requirements referred to in Paragraph (b) are met; 
(d) where satisfied that an application meets the requirements referred to in Paragraph 
(b), the Bougainville Government through the Bougainville Public Service or by an 
authority established by the Bougainville Government for the purpose may, accept the 
application, or without limit to its discretion, may refuse it or accept it subject to 
conditions; 
(e) the Bougainville Government, through the Bougainville Public Service or by an 
authority established by the Bougainville Government for the purpose of processing 
foreign investment applications, and the National Government, and any authority 
established by the National Government for the purpose of foreign investment 
applications, shall consult and co-operate at all stages of the consideration of an 
application; 
(f) there shall be joint and ongoing review and development of foreign investment 
policy by the two Governments and the authorities referred to in Paragraph (e) to
```

---

## Page 133

```text
133
promote restoration and development in Bougainville; 
(g) a dispute as to whether an application does or does not comply with the requirements 
referred to in Paragraph (b) shall be resolved through the dispute resolution procedure. 
(5) 
The Bougainville Government shall have the functions and powers necessary to develop 
the infrastructure relative to its powers and functions under this section. 
291. Functions and powers of the National Government and of the Bougainville 
Government in relation to criminal law. 
(1) 
The provisions of Sections 295 (process for transfer of functions and powers), 296 
(relationships of National and Bougainville laws) and 298 (National Government assets and 
land) do not apply to this section. 
(2) 
The Bougainville Government shall have power, subject to Subsection (4)— 
(a) to adopt the Criminal Code; and 
(b) to create and set penalties for offences incidental to the exercise of its agreed powers 
and functions; and 
(c) to amend National laws relating to summary offences and other laws relating to 
criminal law as they apply in Bougainville; and 
(d) to make laws relating to criminal law, other than a law equivalent to the Criminal 
Code. 
(3) 
The Criminal Code shall apply in and to Bougainville until adopted under Subsection 
(2)(a). 
(4) 
Where the Bougainville Government has adopted the Criminal Code under Subsection 
(2)(a), it may amend the Criminal Code as adopted— 
(a) with the consent of the National Government; or 
(b) in accordance with the following:— 
(i) 
the principles contained in the Agreement being:— 
(A) changes to the principles of the criminal law shall be evolutionary; 
(B) there shall be no large scale changes to the coverage of subjects by the 
criminal law; 
(ii) 
the procedures contained in the Agreement being:— 
(A) the Bougainville Government will cause to be published in the National 
Gazette amendments to the Criminal Code as adopted proposed by the 
Bougainville Government and such amendments shall not come into operation 
without the agreement of the National Government; 
(B) in the event that the National Government does not accept any 
amendments proposed by the Bougainville Government, it may require further 
consultation with the Bougainville Government and in the event of failure to 
agree, the dispute resolution procedure shall apply. 
292. Subjects not specified in Sections 289, 290 and 291. 
(1) 
Subject to Subsection (2), the function and power in relation to any subject— 
(a) not specified in Section 289 (powers and functions of the National Government),
```

---

## Page 134

```text
134
Section 290 (powers and functions available to the Bougainville Government) and 
Section 291 (functions and powers of the National Government and of the Bougainville 
Government in relation to criminal law); and 
(b) not coming within the category of any subject specified in Section 289 (powers and 
functions of the National Government), Section 290 (powers and functions available to 
the Bougainville Government) and Section 291 (functions and powers of the National 
Government and of the Bougainville Government in relation to criminal law), 
shall be a power and function of the National Government, until otherwise determined in 
accordance with this section. 
(2) 
Where the National Government or the Bougainville Government proposes to legislate 
on a subject to which Subsection (1) applies, it shall notify the other Government of its proposals 
and consult with the other Government with a view to reaching agreement on which Government 
should be responsible for the subject, and where agreement is not reached, it shall not legislate. 
(3) 
Where either the National Parliament or the Bougainville Legislature passes a law on a 
subject to which Subsection (1) applies, the other Government may invoke the dispute resolution 
procedure, and— 
(a) pending final determination of the dispute the law shall not take effect, unless both 
Governments agree that it should take effect; and 
(b) on the determination of the dispute resolution procedure, the law shall or shall not 
take effect in accordance with that determination. 
(4) 
Any dispute between the National Government and the Bougainville Government over 
which Government is responsible for a function or power shall be resolved by applying the 
principles governing the division of powers as specified in the Agreement. 
 
 
293. International obligations, etc., of the State in respect of the powers and 
functions of the Bougainville Government. 
(1) 
In this section, “international obligations” includes treaties and other written 
international agreements to which the State is or becomes a party. 
(2) 
The powers and functions available to the Bougainville Government specified in 
Section 290 (powers and functions available to the Bougainville Government) will not be 
exercised in a manner inconsistent with Papua New Guinea’s international obligations and 
human rights regime— 
(a) in existence on the date of the coming into operation of this Part; and 
(b) entered into after the date of coming into operation of this Part, in accordance with 
this section. 
(3) 
The National Government— 
(a) shall consult with the Bougainville Government on— 
(i) 
any proposed new international obligations likely to affect the exercise by the 
Bougainville Government of the functions and powers available to it under this Part, 
or
```

---

## Page 135

```text
135
(ii) 
any proposed future border agreement (other than one concerning defence or 
national security) affecting the jurisdiction of the Bougainville Government; and 
(b) shall not enter into a border agreement (other than one concerning defence or 
national security) affecting the jurisdiction of the Bougainville Government without the 
agreement of the Bougainville Government. 
(4) 
For the purposes of Section 117(3) (treaties), the consent of Papua New Guinea to be 
bound as a party to a treaty which— 
(a) has a purpose of altering the autonomy arrangements contained in the Agreement; or 
(b) being a border agreement (other than one concerning defence or national security) 
affects the jurisdiction of the Bougainville Government, 
shall not be given unless— 
(c) the National Government and the Bougainville Government have agreed on the 
contents of the treaty; and 
(d) the provisions of Section 117(3)(a) or (b) (treaties) have been complied with. 
(5) 
Any disagreement between the National Government and the Bougainville Government 
as to whether any treaty has a purpose of altering the autonomy arrangement contained in the 
Agreement shall be resolved in accordance with the dispute resolution procedure. 
(6) 
Any differences between the National Government and the Bougainville Government 
arising from generally accepted rules of international law shall be resolved in accordance with 
the dispute resolution procedure. 
(7) 
The Bougainville Government may, through an agreed mechanism, request the 
assistance or concurrence of the National Government— 
(a) to participate in the negotiation of international agreements of particular relevance to 
Bougainville; or 
(b) to negotiate international agreements on its own account. 
294. Functions and powers of the Bougainville Government on establishment and 
within 12 months thereafter. 
(1) 
Prior to the establishment of the Bougainville Government the Bougainville Interim 
Provincial Government may give to the National Government reasonable notice of— 
(a) functions or powers available to the Bougainville Government to be transferred; and 
(b) institutions expected to be established under the Bougainville Constitution, 
within the period of 12 months commencing on the date of the establishment of the Bougainville 
Government. 
(2) 
The Bougainville Government shall, on its establishment, have the same functions and 
powers as the Bougainville Interim Provincial Government, together with such other functions 
and powers transferred under Subsection (1). 
295. Process for transfer of functions and powers. 
Where the Bougainville Government wishes a function or power available to it to be transferred 
to it, it shall— 
(a) take full account of its needs and capacity in relation to the function or power; and
```

---

## Page 136

```text
136
(b) initiate the transfer by giving to the National Government 12 months notice of its 
intention to seek the transfer of the function or power; and 
(c) consult with the National Government concerning the transfer,  
unless both Governments otherwise agree. 
296. Relationship of National and Bougainville laws. 
(1) 
National laws relating to the functions and powers available to the Bougainville 
Government shall continue to apply until replaced by Bougainville laws. 
(2) 
The— 
(a) National Government may legislate on subjects specified in Section 290 (functions 
and powers available to the Bougainville Government) but not so as to be inconsistent 
with Bougainville laws on such subjects; and 
(b) Bougainville Government may legislate on subjects specified in Section 289 
(functions and powers available to the National Government) but not so as to be 
inconsistent with National laws on such subjects. 
297. Manner of implementation of transfer of functions and powers. 
An Organic Law shall make provision for— 
(a) the transfer together of closely linked functions and powers; and 
(b) the manner of overcoming difficulties of capacity or economic circumstances 
preventing the effective exercise of a function or power; and 
(c) the resolution of issues in dispute in the event of failure to overcome difficulties 
referred to in Paragraph (b); and 
(d) the resolution of difficulties in dividing the personnel, assets or funding of an 
institution or service organized on a regional or National basis; and 
(e) the making of arrangements to share access to or use of an institution or service 
organised on a regional or National basis to include cost-sharing; and 
(f) the plans prepared and agreed by the National Government and the Bougainville 
Government for co-operating in implementing the transfer of functions for which the 
Bougainville Government will become responsible. 
298. National Government assets and land. 
(1) 
Subject to Subsection (2), the National Government shall transfer to the Bougainville 
Government, at the same time as the transfer of a function or power, such assets and land as are 
associated with the function or power. 
(2) 
Where the National Government has a continuing responsibility in respect of a function 
or power transferred to the Bougainville Government, it may retain assets and land associated 
with that function or power to the extent necessary to carry out its continuing responsibility. 
299. Transfer or delegation of functions and powers. 
The National Government or the Bougainville Government may, by agreement, transfer or 
delegate any function or power (including a financial function or power) to the other 
Government.
```

---

## Page 137

```text
137
Division 4.—Powers and Functions of the Bougainville Government and Matters 
relative thereto affecting other Provisions of this Constitution. 
Subdivision A.—Preliminary. 
300. Bougainville Constitution and Bougainville laws to form part of the laws of 
Papua New Guinea. 
The Bougainville Constitution and laws made by the Bougainville Legislature in accordance 
with the Bougainville Constitution form part of the laws of Papua New Guinea as specified in 
Section 9 (The Laws). 
301. Special references to the Supreme Court. 
The— 
(a) Bougainville Legislature; and 
(b) Bougainville Executive, 
are authorities entitled to make application to the Supreme Court, in accordance with Section 19 
(Special references to the Supreme Court), for an opinion on any question relating to the 
interpretation or application of any provision of a Constitutional Law including (but without 
limiting the generality of that expression) any question as to the validity of a law or proposed 
law. 
Subdivision B.—Code of Conduct, etc., and Leadership Code. 
302. Code of conduct, etc., and Leadership Code. 
(1) 
The Bougainville Constitution may make provision for a code of conduct or rules of 
conduct, similar to and requiring standards of conduct not less than those required by, the 
Leadership Code for which provision is made in Division III.2 (Leadership Code), to apply to 
and in relation to the holders of public offices— 
(a) established under the Bougainville Constitution; and 
(b) specified in the Bougainville Constitution as offices to which the code of conduct or 
rules of conduct applies or apply. 
(2) 
A person to whom the code of conduct or rules of conduct referred to in Subsection (1) 
applies or apply shall not be subject to Division III.2 (Leadership Code) in respect of— 
(a) the office held by him under the Bougainville Constitution to which the code of 
conduct or rules of conduct referred to in Subsection (1) applies or apply; and 
(b) matters to which the code of conduct or rules of conduct referred to in Subsection (1) 
applies or apply. 
(3) 
The Bougainville Constitution— 
(a) may provide for penalties to be imposed for breaches of the code of conduct or rules 
of conduct referred to in Subsection (1) by persons to whom the code of conduct or rules 
of conduct apply; and 
(b) where the code of conduct or rules of conduct have been breached by a person to 
whom, but for Subsection (2), Division III.2 (Leadership Code) would have applied, 
shall provide for penalties the same as those imposed by or under Division III.2 
(Leadership Code) for an equivalent breach.
```

---

## Page 138

```text
138
(4) 
Until such time as a code of conduct or rules of conduct referred to in Subsection (1) 
have been provided for and applied, the following public offices shall be offices to which 
Division III.2 (Leadership Code) applies:— 
(a) members of the Bougainville Legislature; 
(b) Bougainville Constitutional Office-holders; 
(c) the heads of the Bougainville Government Services. 
Subdivision C.—Rights and Freedoms. 
303. Qualifications on qualified rights. 
(1) 
The Bougainville Constitution may make provision for the regulation or restriction by a 
Bougainville law which complies with the requirement of this section, of a right or freedom 
referred to in Subdivision III.3.C (qualified rights) where the law— 
(a) regulates or restricts the right or freedom to the extent that the regulation or 
restriction is necessary— 
(i) 
taking account of the National Goals and Directive Principles and the Basic 
Social Obligations, for the purpose of giving effect to the public interest in— 
(A) public safety; or 
(B) public order; or 
(C) public welfare; or 
(D) public health (including plant and animal health); or 
(E) 
the protection of children and persons under disability (whether legal or 
practical); or 
(F) 
the development of under-privileged or less advanced groups or areas; or 
(ii) 
in order to protect the exercise of the rights and freedoms of others; or 
(b) makes reasonable provision for cases where the exercise of one such right may 
conflict with the exercise of another, 
to the extent that the law is reasonably justifiable in a democratic society having a proper regard 
for the rights and dignity of mankind. 
(2) 
A Bougainville law referred to in Subsection (1) shall— 
(a) be expressed to be a law regulating or restricting a right or freedom referred to in 
Subdivision III.3.C (qualified rights); and 
(b) specify the right or freedom that it regulates or restricts; and 
(c) specify the purpose for which the regulation or restriction was necessary; and 
(d) be made and certified in the manner provided in the Bougainville Constitution. 
(3) 
The burden of showing that a Bougainville law is a law that complies with the 
requirements of this Section is on the party relying on its validity. 
304. Guaranteed rights and freedoms. 
(1) 
Subject to Subsection (3), the Bougainville Constitution may make provision for 
guarantees in Bougainville of basic and qualified rights in addition to those otherwise guaranteed 
in this Constitution.
```

---

## Page 139

```text
139
(2) Subject to Subsection (3), the Bougainville Constitution may make provision for the 
establishment of procedures, institutions or courts to ensure the enforcement of 
guaranteed rights and freedoms. 
(3) Guarantees provided for under Subsection (1) and procedures established under 
Subsection (2) shall not abrogate the guaranteed rights and freedoms or procedures 
to ensure their enforcement provided for in this Constitution. 
Subdivision D.—Administration of Justice. 
305. Operation of National Judicial System in Bougainville. 
The National Judicial System shall continue to carry out its responsibilities in Bougainville, in 
accordance with this Part. 
306. Establishment of Courts in Bougainville. 
(1) 
The Bougainville Constitution may make provision for the establishment under 
Bougainville law of courts and tribunals in Bougainville in accordance with this Part and the 
Agreement, and may authorize Bougainville laws to make further provisions in respect of such 
courts and tribunals. 
(2) 
Bougainville may operate— 
(a) wholly under courts and tribunals established under Subsection (1); or 
(b) partly under courts and tribunals established under Subsection (1) and partly under 
other courts within the National Judicial System and tribunals established under National 
Laws. 
(3) 
A court established under Subsection (1) (other than a court with a jurisdiction similar 
to that of a Village Court) shall be within the National Judicial System. 
(4) 
The courts which may be established under Subsection (1) may range from— 
(a) a court with jurisdiction equivalent to that of the National Court; or 
(b) a court with jurisdiction similar to that of a Village Court, 
such jurisdiction to be limited to and in relation to Bougainville. 
(5) 
National laws and Bougainville laws shall be enforceable in all courts in the National 
Judicial System. 
(6) 
The name ”National Court“ shall not be used in any form for any court established 
under Subsection (1). 
307. Establishment of tribunals in Bougainville. 
The Bougainville Constitution may make provision for the establishment within Bougainville by 
or in accordance with a Bougainville law, or by consent of the parties concerned, of arbitral or 
conciliatory tribunals, whether ad hoc or other, outside the National Judicial System and such 
tribunals shall be subject to Section 159 (tribunals, etc., outside the National Judicial System). 
308. Jurisdiction of Bougainville Courts. 
(1) 
The Bougainville Constitution may provide that the powers of a Bougainville court with
```

---

## Page 140

```text
140
jurisdiction similar to that of the National Court may include power to— 
(a) make orders in the nature of prerogative writs and such other orders as are necessary 
to do justice in the circumstances of a particular case; and 
(b) exercise jurisdiction under the Criminal Code; and 
(c) subject to Subsection (2), review the exercise of judicial authority by Bougainville 
courts and by Bougainville tribunals; and 
(d) determine questions of interpretation of the Bougainville Constitution; and 
(e) protect and enforce human rights. 
(2) 
The Bougainville Constitution shall provide that, where a person has a right of appeal 
from a Bougainville court to a Bougainville court established under Section 306(4)(a) 
(Establishment of courts in Bougainville), he has an alternative (but not an additional) right of 
appeal to the National Court. 
(3) 
A resident of Bougainville may commence an action for the enforcement of human 
rights in the National Court or in a Bougainville Court or institution with competent jurisdiction. 
(4) 
The National Court shall have the power— 
(a) to review the exercise of judicial authority by Bougainville courts (other than a 
Bougainville court established under Section 306(4)(a) (Establishment of courts in 
Bougainville)) and by Bougainville tribunals; and 
(b) equal to the power of a Bougainville court established under Section 306(4)(a) 
(Establishment of courts in Bougainville), to hear appeals from Bougainville courts, but 
such power shall be exercised only as an alternative appeal and not as an appeal 
additional to that which by law may be made to the Bougainville court established under 
Section 306(4)(a) (Establishment of courts in Bougainville). 
(5) 
The Supreme Court shall be the final court of appeal for Bougainville including appeals 
on determinations made under Subsection (1)(d). 
(6) 
An Organic Law may make further provision for the relationship between Bougainville 
courts and other courts in the National Judicial System and for the manner in which the 
responsibilities of other courts in Bougainville in the National Judicial System shall be 
transferred to Bougainville courts of equivalent jurisdiction. 
309. Appointment of Judges, etc. 
(1) 
The Bougainville Constitution may make provision for an independent appointments 
body to appoint Judges to a Bougainville court established under Section 306(4)(a) 
(Establishment of courts in Bougainville). 
(2) 
The appointments body referred to in Subsection (1) shall include two members of the 
Judicial and Legal Services Commission, appointed by that Commission. 
(3) 
The Bougainville Constitution shall otherwise provide for the appointment, terms and 
conditions of employment, seniority and removal from office of judges of a Bougainville court. 
(4) 
A— 
(a) Judge of the National Court may hold an appointment as a Bougainville Judge 
concurrently with his tenure of appointment as a Judge of the National Court; and 
(b) Bougainville Judge may hold an appointment as a Judge of the National Court
```

---

## Page 141

```text
141
concurrently with his tenure of appointment as a Bougainville Judge. 
Subdivision E.—Bougainville Government Services. 
310. Bougainville Government Services. 
(1) 
The Bougainville Constitution may make provision for Bougainville Government 
Services being— 
(a) a Bougainville Public Service; and 
(b) Bougainville Police; and 
(c) a Bougainville Correctional Service; and 
(d) such other Bougainville Government Services as may be necessary, 
in accordance with this Part, and may provide for Bougainville laws to make further provision in 
respect of Bougainville Government Services. 
(2) 
The Bougainville Constitution shall make provision for a head of a Bougainville 
Government Service to be responsible to the Bougainville Executive, and for the manner in 
which he is to be so responsible. 
(3) 
Members of a Bougainville Government Service shall take an Oath of Allegiance or 
make an Affirmation of Allegiance in accordance with Section 7 (Oath of Allegiance), Section 
250 (Making of Declaration of Loyalty, etc.,) and Section 251 (taking certain oaths, etc., by non-
citizens). 
(4) 
Any official marking on the uniforms, vehicles, premises and stationery of Bougainville 
Police and Bougainville Correctional Service shall include the National Emblem or Name. 
(5) 
An Organic Law may make provision for co-operative and transitional arrangements 
between National State Services and Bougainville Government Services. 
Subdivision F.—Bougainville Public Service. 
311. Bougainville Public Service. 
(1) 
The Bougainville Constitution may make provision for a Bougainville Public Service 
under Bougainville law to be responsible for the administration of the powers and functions of 
the Bougainville Government. 
(2) 
Where the Bougainville Constitution makes provision for a Bougainville Public Service, 
it shall provide for— 
(a) Bougainville laws for and in respect of— 
(i) 
standards for management and control of the Bougainville Public Service; and 
(ii) 
work value and standard for pay for the Bougainville Public Service; and 
(iii) classification and grade structures in the Bougainville Public Service, 
compatible with those of the National Public Service; and 
(b) an independent body (which may be the Public Services Commission) which will be 
responsible for reviewing decisions on personnel matters connected with the 
Bougainville Public Service. 
(3) 
For the purposes of Subsection (2)(b), personnel matters means decisions and other
```

---

## Page 142

```text
142
service matters concerning an individual whether in relation to his appointment, promotion, 
demotion, transfer, suspension, disciplining or cessation or termination of employment (except 
cessation or termination at the end of his normal period of employment as determined in 
accordance with law) or otherwise. 
(4) 
An Organic Law shall make provision for— 
(a) the Bougainville Government to consult with the National Government before 
making laws relating to the Bougainville Public Service; and 
(b) arrangements for implementation of the Bougainville Public Service; and 
(c) transitional arrangements between the National Public Service and Bougainville 
Public Service. 
312. National Public Service in Bougainville. 
The National Public Service shall continue to operate in Bougainville— 
(a) to carry out the functions and powers of the National Government as specified in 
Section 289 (powers and functions of the National Government); and 
(b) to carry out the functions and powers available to the Bougainville Government as 
specified in Section 290 (powers and functions available to the Bougainville 
Government) until such time as the Bougainville Public Service has been established and 
the function or power has been transferred to the Bougainville Government. 
Subdivision G.—Bougainville Police. 
313. Bougainville Police. 
(1) 
The Bougainville Constitution may make provision under Bougainville law for the 
Bougainville Police which will be responsible in Bougainville for preserving peace and good 
order and for maintaining and as necessary enforcing National laws and Bougainville laws in an 
impartial and objective manner, with full regard for human rights. 
(2) 
Where the Bougainville Constitution makes provision for the Bougainville Police, it 
shall provide for— 
(a) Bougainville laws for and in respect of— 
(i) 
the structures and organization of the Bougainville Police; and 
(ii) 
the terms and conditions of service of the Bougainville Police; and 
(iii) the core training and personnel development arrangements of the Bougainville 
Police, consistent with those of the Police Force established by Section 188(1)(b) 
(Establishment of the State Services); and 
(b) an independent body, which shall include the Commissioner of Police or his 
representative and one other representative of the National Government appointed by the 
National Government, to be responsible for the appointment and removal for just cause 
of the head of the Bougainville Police; and 
(c) the head of the Bougainville Police to have a title other than Commissioner and to 
hold a rank below that of the Commissioner of Police. 
(3) 
Insofar as it is a function of the Bougainville Police to lay, prosecute or withdraw 
charges in respect of offences, the members of the Bougainville Police are not subject to 
direction or control by—
```

---

## Page 143

```text
143
(a) any person outside the Bougainville Police; or 
(b) where acting under any agency arrangement with the Police Force established by 
Section 188(1)(b) (Establishment of the State Services), by any person outside that 
Police Force. 
314. Funding of the Bougainville Police. 
(1) 
The National Government shall provide the Bougainville Government with funding by 
way of— 
(a) guaranteed annual conditional grants for the specific purpose of meeting the 
recurrent costs of policing in Bougainville; and 
(b) guaranteed conditional grants for the purpose of restoring and further developing 
civilian peacetime policing in Bougainville. 
(2) 
An Organic Law may make provision for and in respect of all matters relating to the 
grants referred to in Subsection (1). 
315. Police Force etc., in Bougainville. 
(1) 
The Police Force established by Section 188(1)(b) (Establishment of the State Services) 
shall continue to operate and the Act of Parliament under which it operates shall continue to 
apply in Bougainville to enable the Police Force established by Section 188(1)(b) (Establishment 
of the State Services)— 
(a) to carry out its functions in Bougainville; and 
(b) to enforce National laws and Bougainville laws prior to the establishment of the 
Bougainville Police; and 
(c) to fulfill the co-operative arrangements with the Bougainville Police as specified in 
the Agreement. 
(2) 
An Organic Law shall make provision for— 
(a) the transitional arrangements to apply until the Bougainville Police are established 
and operational; and 
(b) co-operative arrangements between the Police Force established under Section 
188(1)(b) (Establishment of the State Services) and the Bougainville Police. 
Subdivision H.—Bougainville Correctional Service. 
316. Bougainville Correctional Service. 
(1) 
The Bougainville Constitution may make provision for the Bougainville Correctional 
Service under Bougainville law which will be responsible for the supervision and administration 
of correctional institutions in Bougainville. 
(2) 
Where the Bougainville Constitution makes provision for the Bougainville Correctional 
Service it shall provide for— 
(a) Bougainville laws for and in respect of— 
(i) 
the structures and organizations of the Bougainville Correctional Service; and 
(ii) 
the terms and conditions of service of the Bougainville Correctional Service; 
and
```

---

## Page 144

```text
144
(iii) the core training and personnel development arrangements of the Bougainville 
Correctional Service, consistent with those of the Correctional Service of the 
National Government; and 
(b) an independent body, which shall include the Commissioner of the Correctional 
Service or his representative and one other representative of the National Government 
appointed by the National Government to be responsible for the appointment and 
removal for just cause of the head of the Bougainville Correctional Service; and 
(c) the head of the Bougainville Correctional Service to have a title other than 
Commissioner and to hold a rank below that of the Commissioner of the Correctional 
Service of the National Government; and 
(d) co-operation with the Correctional Service of the National Government in the 
provision and management of correctional institutions and services. 
317. Funding of the Bougainville Correctional Service. 
An Organic Law shall make provision for and in respect of the funding of the Bougainville 
Correctional Service. 
318. Correctional Service of the National Government in Bougainville. 
(1) 
The Correctional Service of the National Government shall continue to operate and the 
Act of the Parliament under which it operates shall continue to apply in Bougainville in 
accordance with the Agreement until the Bougainville Correctional Service has been established 
and is operational and an appropriate Bougainville law has been made. 
(2) 
An Organic Law shall make provision for— 
(a) the transitional arrangements to apply until the Bougainville Correctional Service are 
established and operational; and 
(b) co-operative arrangements between the National Correctional Service and the 
Bougainville Correctional Service. 
Subdivision I.—Bougainville Salaries and Remuneration Commission. 
319. Bougainville Salaries and Remuneration Commission. 
(1) 
The Bougainville Constitution may establish a Bougainville Salaries and Remuneration 
Commission. 
(2) 
The Bougainville Salaries and Remuneration Commission shall be responsible for 
recommending to the Bougainville Legislature the salaries, allowances and benefits, financial or 
otherwise (including pensions or retirement benefits if they are not otherwise provided for by 
law) of all— 
(a) persons holding elective office under the Bougainville Constitution; and 
(b) Bougainville Constitutional office-holders (including Bougainville Judges); and 
(c) the heads of Bougainville Government Services; and 
(d) such other persons as are specified in the Bougainville Constitution. 
(3) 
In making recommendations under Subsection (2), the Bougainville Salaries and 
Remuneration Commission shall take into account advice from the Salaries and Remuneration 
Commission established by Section 216A (The Salaries and Remuneration Commission) on the
```

---

## Page 145

```text
145
maintenance of relativities of salaries and conditions of employment with those applicable to 
similar offices elsewhere in Papua New Guinea and at the National level. 
(4) 
The Bougainville Legislature— 
(a) shall determine the salaries, allowances and benefits, financial or otherwise 
(including pensions or retirement benefits if they are not otherwise provided for by law) 
of persons referred to in Subsection (2) in accordance with a recommendation of the 
Bougainville Salaries and Remuneration Commission; and 
(b) may accept or reject, but may not amend, any recommendation from the Bougainville 
Salaries and Remuneration Commission. 
320. Salaries and Remuneration Commission. 
(1) 
Subject to Subsection (2), until the establishment of the Bougainville Salaries and 
Remuneration Commission, the Salaries and Remuneration Commission established by Section 
216A (Salaries and Remuneration Commission) shall be responsible for recommending to the 
Bougainville Legislature the salaries, allowances and benefits, financial or otherwise (including 
pensions or retirement benefits if they are not otherwise provided for by law) of all persons 
referred to in Section 319(2) (Bougainville Salaries and Remuneration Commission). 
(2) 
In carrying out its functions under Subsection (1) the Salaries and Remuneration 
Commission shall include two persons nominated by the Bougainville Executive in accordance 
with a Bougainville Law. 
(3) 
The Bougainville Legislature— 
(a) shall determine the salaries, allowances and benefits, financial or otherwise 
(including pensions and retirement benefits if they are not otherwise provided for by 
law) of persons referred to in Section 319(2) (Bougainville Salaries and Remuneration 
Commission) in accordance with a recommendation of the Salaries and Remuneration 
Commission under this section; and 
(b) may accept or reject, but may not amend, any recommendation from the Salaries and 
Remuneration Commission under this Section. 
(4) 
Where the Bougainville Salaries and Remuneration Commission has been established, 
the Salaries and Remuneration Commission established by Section 216A (Salaries and 
Remuneration Commission) shall not be responsible for the salaries, allowances and benefits, 
financial or otherwise (including pensions and retirement benefits if they are not otherwise 
provided for by law) of persons referred to in Section 319(2) (Bougainville Salaries and 
Remuneration Commission). 
Subdivision J.—Powers Relating to Constitutional Office-Holders. 
321. Bougainville Constitutional Office-holders. 
(1) 
The Bougainville Constitution may make provision for Bougainville Constitutional 
Office-holders with powers and functions in Bougainville equivalent to the powers and functions 
of a Constitutional Office-holder, referred to in Section 221 (Definitions). 
(2) 
The Bougainville Constitution may make provision for any other office established 
under the Bougainville Constitution or a Bougainville law to be declared a Bougainville 
Constitutional Office and for the holder of such office to be declared a Bougainville
```

---

## Page 146

```text
146
Constitutional Office-holder. 
(3) 
The Bougainville Constitution shall make provision for and in respect of the 
qualifications, appointment and terms and conditions of employment of Bougainville 
Constitutional Office-holders and shall— 
(a) subject to any express provisions in this Part, provide that any body established by or 
under the Bougainville Constitution to appoint a Bougainville Constitutional Office-
holder shall include two persons appointed by the body responsible for the appointment 
of the equivalent Constitutional office-holder under Section 221 (Definitions) or where 
there is no such equivalent, by the National Executive Council; and 
(b) guarantee the rights and independence of Bougainville Constitutional Office-holders 
similar to the protections of office of Constitutional Office-holders under Section 221 
(Definitions) 
(4) 
A Constitutional Office-holder referred to in Section 221 (Definitions) may enter into 
co-operative or agency arrangements with the equivalent Bougainville Constitutional office-
holder to avoid gaps and duplication and to encourage common standards. 
(5) 
Subject to this Part, a Constitutional Office-holder under Section 221 (Definitions) shall, 
in Bougainville, where an equivalent Bougainville Constitutional office— 
(a) has not been established—carry out his responsibilities in respect of powers and 
functions specified in Section 289 (powers and functions of the National Government) 
and Section 290 (powers and functions available to the Bougainville Government); and 
(b) has been established—carry out his responsibilities in respect of— 
(i) 
the powers and functions specified in Section 289 (powers and functions of the 
National Government); and 
(ii) 
such powers and functions specified in Section 290 (powers and functions 
available to the Bougainville Government) as have not been transferred to the 
Bougainville Government. 
(6) 
The Bougainville Government will meet the costs of the establishment and maintenance 
of Bougainville Constitutional Office-holders. 
Subdivision K.—Emergency Powers. 
322. Bougainville Constitution may provide for emergencies. 
The Bougainville Constitution may make provision for procedures to be followed by the 
Bougainville Government to deal with an emergency as defined in Section 226 (Definitions). 
323. Declaration of national emergency in Bougainville. 
(1) 
Subject to Subsection (2), where circumstances arise in Bougainville which make it 
necessary that the existence of a national emergency be declared under Section 228 (declaration 
of national emergency) in relation to Bougainville or part of Bougainville, the following 
provisions shall apply:— 
(a) the Bougainville Constitution shall make provision for a procedure whereby the 
Bougainville Government may request the National Executive Council to advise the 
Head of State to declare the existence of a national emergency in relation to 
Bougainville or part of Bougainville;
```

---

## Page 147

```text
147
(b) where the National Executive Council agrees to a request under Paragraph (a), it 
shall advise the Head of State to declare the existence of a national emergency in 
relation to Bougainville or part of Bougainville; 
(c) where no request under Paragraph (a) has been received within a period reasonable in 
the circumstances, the National Executive Council through a Minister shall endeavour to 
consult with the Bougainville Government; 
(d) other than where the existence of a national emergency is declared under Paragraph 
(b), the only circumstance in which the National Executive Council may advise the Head 
of State to declare the existence of a national emergency is where no request under 
Paragraph (a) has been received and, due to the urgency of the circumstances, 
consultation under Paragraph (c) has not been possible and is not practicable. 
(2) 
Subsection (1) does not apply where the existence of a state of emergency is to be 
declared in respect of the whole of the country or in respect of Bougainville and substantial areas 
of the country other than Bougainville. 
(3) 
Where a declaration of national emergency under Section 228 (declaration of national 
emergency) is in force in relation to Bougainville, the National Government and the Bougainville 
Government shall co-operate in the management of the emergency in so far as relating to 
Bougainville. 
Division 5.—Fiscal Arrangements. 
324. Basic principles of fiscal arrangements. 
The basic principles of the fiscal arrangements between the National Government and the 
Bougainville Government are as follows:— 
(a) that the Bougainville Government shall have sufficient revenue raising powers to 
enable it to reach fiscal self-reliance, and the National Government shall support the 
Bougainville Government in reaching fiscal self-reliance; 
(b) that Bougainville shall continue to make a contribution, in accordance with this Part 
and the Agreement, to the National Government— 
(i) 
prior to fiscal self-reliance—through the collection and application of company 
tax, value added tax and customs duties in Bougainville remaining with the National 
Government; and 
(ii) 
after fiscal self-reliance, through an agreed revenue-sharing formula which 
may be determined through the review process; 
(c) except as otherwise provided in this Part or the Agreement, the costs involved in 
establishing and maintaining the Bougainville Government additional to those of the 
functions and powers covered by recurrent grants under Section 326(1)(a)(i) (grants) 
shall be shared between the National Government and the Bougainville Government. 
325. Revenue raising, etc., arrangements. 
Subject to the Agreement, an Organic Law shall make provision for— 
(a) the method of sharing, between the National Government and the Bougainville 
Government, of taxes collected in Bougainville and the manner in which such taxes shall 
be dealt with both before and after fiscal self-reliance; and
```

---

## Page 148

```text
148
(b) the Bougainville Government to have power to adjust the rate of— 
(i) 
personal income tax collected from Bougainville; and 
(ii) 
after fiscal self-reliance—company tax collected in Bougainville; and 
(c) the arrangements between the National Government and the Bougainville 
Government relating to the collection of taxes; and 
(d) the Bougainville Government to have power to establish its own tax regime for all 
taxes (excluding customs duties, company tax and value added tax); and 
(e) existing tax incentives in Bougainville to continue and for the Bougainville 
Government to be empowered— 
(i) 
to recommend persons as eligible for tax incentives; and 
(ii) 
to request new tax incentives; and 
(f) the audit, by or on behalf of the National Government and by or on behalf of the 
Bougainville Government of all taxes collected; and 
(g) the manner of sharing revenues from activities in areas of sea and seabed beyond the 
guaranteed three mile limit and within the Exclusive Economic Zone and the continental 
shelf associated with Bougainville. 
326. Grants. 
(1) 
The National Government shall provide grants to the Bougainville Government as 
follows:— 
(a) recurrent unconditional grant; and 
(b) restoration and development grant; and 
(c) conditional grants for specific purposes; and 
(d) a Police grant; and 
(e) an establishment grant. 
(2) 
Subject to the Agreement, an Organic Law shall make provision for— 
(a) the manner of calculation, adjustment (including the effects of progress towards 
fiscal self-reliance), timing, payment and management of such grants; and 
(b) methods of consultation between the National Government and the Bougainville 
Government in relation to such grants. 
(3) 
Grants provided to the Bougainville Government under Subsection (1) shall be subject 
to audit by the Auditor-General. 
327. Foreign aid. 
(1) 
The National Government shall use its best endeavours— 
(a) to obtain foreign aid to support restoration and development in Bougainville; and 
(b) to facilitate the participation of the Bougainville Government in the management of 
aid projects. 
(2) 
The Bougainville Government— 
(a) may seek and obtain foreign aid; and 
(b) shall keep the National Government fully informed as to its efforts under Paragraph 
(a).
```

---

## Page 149

```text
149
(3) 
The National Government shall— 
(a) approve foreign aid obtained by the Bougainville Government, where the aid— 
(i) 
does not reduce the value of aid already available to Papua New Guinea; and 
(ii) 
does not conflict with overriding foreign policy considerations; and 
(b) co-operate with the Bougainville Government by negotiating such international 
agreements as may be required to finalise foreign aid identified by the Bougainville 
Government. 
328. Other financial powers and accountability 
(1) 
The Bougainville Constitution or a Bougainville Law, in addition to other powers 
conferred by this Division— 
(a) may provide for the Bougainville Government after consultation with the National 
Government— 
(i) 
to raise foreign loans, in accordance with required approvals and other 
requirements of the Bank of Papua New Guinea; and 
(ii) 
to raise domestic loans, in accordance with regulation of the banking system by 
the Bank of Papua New Guinea; and 
(b) shall provide for the manner of approval and administration of annual budgets (and 
where appropriate, supplementary budgets) comprising estimates of revenue and 
expenditure and appropriation of the main functions of the Bougainville Government; 
and 
(c) shall provide for the manner of approval of making expenditures; and 
(d) shall provide for the maintenance of proper transparent and accurate accounts, 
compatible with international accounting standards. 
(2) 
The Bougainville Constitution— 
(a) shall make provision for regular audits of the accounts of the Bougainville 
Government in addition to audits carried out by, or on behalf of, the Auditor-General in 
the exercise of his powers and the performance of his functions under this Constitution; 
and 
(b) shall make provision, within the Bougainville Legislature, for a public accounts 
committee which shall receive, consider and make recommendations on reports of audits 
carried out under Paragraph (a); and 
(b) shall make provision whereby, if at the beginning of a financial year the 
Bougainville Legislature has not made provision for expenditure for the services of 
the Bougainville Government for that year, the Bougainville Executive may expend 
amounts up to a limit specified in the Bougainville Constitution. 
329. Follow-up to audit reports. 
Subject to the Agreement, an Organic Law shall make provision in accordance with the 
Agreement for circumstances where any audit carried out by the Auditor-General discloses 
systematic and widespread abuse (or misuse) of funding provided to the Bougainville 
Government by way of recurrent or conditional grant and in particular shall make provision 
for— 
(a) the procedures to be followed by the National Government and by the Bougainville
```

---

## Page 150

```text
150
Government; and 
(b) the withholding by the National Government in certain circumstances of certain 
grants; and 
(c) recourse to the dispute resolution procedure,  
in relation to any such abuse (or misuse). 
Division 6.—Intergovernmental Relations and Review. 
330. Interpretation. 
In this Division unless the contrary intention appears— 
“dispute” means any disagreement between the National Government and the 
Bougainville Government in relation to the autonomy for Bougainville and the 
referendum for Bougainville; 
“dispute resolution procedure” means the dispute resolution procedure set out in Section 
333 (Joint Supervisory Body); 
“intergovernmental relations” means relations between the National Government and the 
Bougainville Government; 
“Joint Supervisory Body” means the Joint Supervisory Body established by Section 332 
(Joint Supervisory Body); 
“review” means review under Section 337 (Reviews). 
331. Principles of intergovernmental relations. 
The general principles of intergovernmental relations between the National Government and the 
Bougainville Government are as follows:— 
(a) that the autonomy arrangements, having been reached through consultation and co-
operation, should be implemented in like manner; 
(b) that there be a procedure to avoid, minimize and resolve disputes; 
(c) that the National Government has no power to withdraw powers from the 
Bougainville Government or to suspend it. 
332. Joint Supervisory Body. 
(1) 
There is established a Joint Supervisory Body consisting of— 
(a) not less than two members appointed by the National Executive Council; and 
(b) not less than two members appointed by the Bougainville Executive. 
(2) 
There shall be an equal number of members appointed under Subsection (1)(a) and (b). 
(3) 
The functions of the Joint Supervisory Body are— 
(a) to oversee implementation of the Agreement and of this Part, in accordance with the 
Agreement; and 
(b) to provide a consultative forum at which consultation between the National 
Government and the Bougainville Government and their agencies can take place. 
(4) 
The Joint Supervisory Body shall have such powers as are necessary to enable it to 
perform its functions under this Part and the Agreement. 
(5) 
The Joint Supervisory Body—
```

---

## Page 151

```text
151
(a) subject to Paragraph (b), shall, at its first meeting, develop its own procedures and fix 
the frequency of its meeting (which shall be at least once in each year); and 
(b) provide that any of its members may put matters on an agenda of a meeting; and 
(c) at its first meeting elect one of the members under Subsection (1)(a) to be the 
Chairman and at its second meeting elect one of the members under Subsection (1)(b) to 
be the Chairman and thereafter elect a Chairman from Subsection (1)(a) and (b) in 
rotation. 
333. Dispute resolution procedure. 
The dispute resolution procedure is as follows:— 
(a) subject to express provisions relating to consultation in this Part and the Agreement, 
the National Government and the Bougainville Government shall try to resolve a dispute 
by consultation— 
(i) 
where appropriate, between the relevant agencies of each Government; or 
(ii) 
where consultation under Subparagraph (1) is not practicable or successful, 
through the Joint Supervisory Body; 
(b) where a dispute cannot be resolved by consultation under Paragraph (a), it shall be 
referred for mediation and arbitration under Section 334 (mediation and arbitration), 
unless otherwise agreed by the National Government and the Bougainville Government; 
(c) where a dispute cannot be resolved under Paragraph (a) or (b), or where the parties 
otherwise agree it may be submitted to the jurisdiction of the courts; 
(d) where a dispute involves a point of law, that point of law may be submitted to the 
jurisdiction of the courts without application of Paragraph (a) or (b). 
 
 
334. Mediation and arbitration. 
(1) 
Where a dispute proceeds to mediation or arbitration, the National Government and the 
Bougainville Government shall agree on the Mediator or Arbitrator. 
(2) 
The Mediator or Arbitrator shall determine procedures to be followed in the initial 
consideration of a dispute referred to him and shall determine whether a dispute is or is not 
suitable for mediation or arbitration. 
(3) 
Where the Mediator or Arbitrator determines that a dispute is not suitable for arbitration 
or mediation, he shall issue to each of the parties to the dispute a certificate to that effect. 
(4) 
Where the mediation or arbitration proceeds, the Mediator or Arbitrator shall determine 
the procedures to be followed. 
335. Dispute resolution in the Courts. 
The Courts shall have jurisdiction in a dispute— 
(a) in accordance with Section 333(d) (dispute resolution procedure), where a dispute 
involves a point of law; and
```

---

## Page 152

```text
152
(b) where the parties so agree; and 
(c) where the mediation or arbitration procedure fails to resolve the dispute and one or 
other party wishes to take the matter to Court; and 
(d) prescribed as a dispute in relation to which the Courts have jurisdiction. 
336. Panel of persons with appropriate expertise. 
(1) 
Subject to Subsection (2), at any stage in the dispute resolution procedure, the parties 
may agree to appoint a panel of persons with expertise appropriate to the matter in dispute. 
(2) 
Where a Mediator or Arbitrator has been appointed in respect of a dispute, his consent 
to the appointment of a panel under Subsection (1) shall be sought. 
337. Reviews. 
(1) 
The National Government and the Bougainville Government— 
(a) shall meet as close as is practicable to the fifth anniversary of the establishment of 
the Bougainville Government and every five years thereafter, jointly to review the 
autonomy arrangements; and 
(b) may agree to additional reviews of the autonomy arrangements at any time; and 
(c) shall present a report of each review under Paragraph (a) or (b) to the National 
Parliament and to the Bougainville Legislature. 
(2) 
A review under Subsection (1) of the autonomy arrangements shall follow and consider 
separate reviews by independent experts of particular aspects, including— 
(a) the financial arrangements—grants, taxes and progress towards fiscal self-reliance; 
and 
(b) the Bougainville Government Services and other aspects of public sector 
administration in Bougainville—including size, efficiency, effectiveness, and related 
matters; and 
(c) technical and legal aspects, including issues arising from judicial interpretation, and 
the distribution of powers and functions; and 
(d) such other areas as the Bougainville Government and the National Government may 
agree. 
(3) 
The terms of reference for a review shall specify that, unless otherwise agreed, they are 
intended to improve, clarify and strengthen the autonomy arrangements consistently with the 
objectives and principles in the Agreement. 
(4) 
The National Government and the Bougainville Government may, by agreement, defer 
the specialist reviews or incorporate the issues with which they deal in the general review. 
(5) 
The reports of the specialist reviews will include drafts or drafting instructions for any 
legislative amendments they recommend. 
(6) 
In the event that either the National Parliament or the Bougainville Legislature passes 
any amendments proposed under Subsection (5) according to its own constitutional procedures 
and the other does not, the Bougainville Government on behalf of the Bougainville Legislature 
and the National Government on behalf of the National Parliament shall follow the dispute 
resolution procedure up to the level of mediation or arbitration.
```

---

## Page 153

```text
153
(7) 
Any point of law arising from the application of Subsection (6) shall be referred to the 
Supreme Court. 
(8) 
A Mediator or Arbitrator may not give directions to the National Parliament or the 
Bougainville Legislature but may order the National Government and the Bougainville 
Government to present a report in the National Parliament and the Bougainville Legislature 
recording the views of both Governments and containing their own recommendations on 
differences between them. 
(9) 
In addition to the reviews under Subsection (1), the National Government and the 
Bougainville Government shall hold annual, wide-ranging consultations on the general operation 
of the autonomy arrangements. 
(10) 
Unless the National Government and the Bougainville Government agree to some other 
method, the consultation under Subsection (9) shall be held through the Joint Supervisory Body. 
Division 7.—Bougainville Referendum. 
338. Referendum to be held. 
(1) 
Subject to this section, a Referendum on the future political status of Bougainville shall 
be held in accordance with this Division. 
(2) 
Subject to Subsection (7), the Referendum shall be held on a date agreed after 
consultation by the Bougainville Government with the National Government, which date shall be 
not earlier than 10 years and, notwithstanding any other provision, not more than 15 years after 
the election of the first Bougainville Government. 
(3) 
The date referred to in Subsection (2) shall be determined after considering whether— 
(a) weapons have been disposed of in accordance with the Agreement; and 
(b) in accordance with Subsection (4), it has been determined that the Bougainville 
Government has been and is being conducted in accordance with internationally 
accepted standards of good governance. 
(4) 
The question whether the Bougainville Government has been and is being conducted in 
accordance with internationally accepted standards of good governance shall be determined in 
accordance with the review and the dispute resolution procedure. 
(5) 
For the purposes of Subsection (4), the internationally accepted standards of good 
governance, as they are applicable and implemented in the circumstances of Bougainville and 
Papua New Guinea as a whole, include democracy, the opportunity for participation by 
Bougainvilleans, transparency, accountability, and respect for human rights and the rule of law, 
including this Constitution. 
(6) 
The National Government and the Bougainville Government shall co-operate in 
ensuring progress towards achieving and maintaining the standards referred to in Subsection (5). 
(7) 
The Referendum shall not be held where the Bougainville Government decides, in 
accordance with the Bougainville Constitution, after consultation with the National Government, 
that the Referendum shall not be held. 
339. The question or questions to be put.
```

---

## Page 154

```text
154
The question or questions to be put at the Referendum— 
(a) shall be agreed to by the National Government and the Bougainville Government; 
and 
(b) shall be formulated to avoid a disputed or unclear result; and 
(c) shall include a choice of separate independence for Bougainville. 
340. Manner of conducting Referendum. 
(1) 
An Organic Law shall make provision for the manner in which the Referendum is to be 
conducted and in particular shall make provision for and in relation to— 
(a) the authorities to be jointly responsible for preparing for and conducting the 
Referendum and for the arrangements whereby they shall exercise joint authority; and 
(b) electorates and polling places; and 
(c) electoral rolls, enrolment, objections to enrolment and appeals relating to enrolment; 
and 
(d) postal voting; and 
(e) polling and scrutiny; and 
(f) interpreters; and 
(g) offences; and 
(h) polling and scrutiny; and 
(i) communicating the results of the Referendum to the National Government and to the 
Bougainville Government; and 
(j) the invitation of international observers to observe the conduct of the Referendum; 
and 
(k) such other matters as may be required effectively to conduct the Referendum. 
(2) 
The Referendum may be held in conjunction with an election. 
341. Referendum to be free and fair. 
The National Government and the Bougainville Government shall co-operate to ensure that the 
Referendum is free and fair. 
342. Referendum results and implementation. 
(1) 
The National Government and the Bougainville Government shall consult over the 
results of the Referendum. 
(2) 
Subject to the consultation referred to in Subsection (1), the Minister responsible for the 
Bougainville Referendum shall table the results of the Referendum in the National Parliament 
and the Speaker of the National Parliament shall furnish to the Bougainville Executive a copy of 
the minutes of the relevant proceedings and of any decision made in the National Parliament 
regarding the Referendum. 
343. Resolution of differences on Referendum. 
Any differences between the National Government and the Bougainville Government in relation 
to the Referendum shall be resolved in accordance with the dispute resolution procedure. 
Division 8.—Immunity from Prosecution.
```

---

## Page 155

```text
155
344. Immunity from prosecution. 
(1) 
The purpose of this section is to assist in the reconciliation process in Bougainville, and 
it is the intention of the Parliament that the provisions of this section be so applied as to assist in 
achieving this purpose. 
(2) 
There shall be immunity from prosecution in accordance with this section in respect of 
certain offences arising from crisis-related activities in relation to the Bougainville conflict. 
(3) 
The Head of State, acting with, and in accordance with, the advice of the National 
Executive Council, may by declaration published in the National Gazette, declare— 
(a) subject to Paragraph (b), the class or classes of offences to which the immunity is to 
apply or not apply; and 
(b) the nature of crisis-related activities which shall qualify the offences for the 
immunity; and 
(c) the period of time to which the immunity shall apply; and 
(d) such other matters as are necessary to ensure that the immunity can be effected. 
(4) 
Where a declaration has been made under Subsection (3), no charge shall be laid and no 
prosecution— 
(a) shall be initiated; or 
(b) if initiated, shall be pursued, 
in respect of an offence— 
(c) included in the offences described pursuant to Subsection (3)(a); and 
(d) of a nature described in Subsection (3)(b); and 
(e) committed during the period specified in Subsection (3)(c). 
(5) 
The provisions of this section— 
(a) may be applied generally in respect of classes of offences and classes of 
circumstances without the need to identify alleged offenders; and 
(b) shall apply to offences whether or not a charge has been laid in respect of them. 
Division 9.—Miscellaneous. 
345. Requirement for amendment of this Part, etc. 
(1) 
The provisions of this section are in addition to and are not in derogation of the 
provision of Section 14 (making of alterations to the Constitution and Organic Laws). 
(2) 
Where the National Government or the Bougainville Government seeks to present or 
have presented in the Parliament an amendment to this Part or to an Organic Law authorized by 
this Part, it shall— 
(a) consult with the other Government concerning the proposed amendments; or 
(b) submit the proposed amendment to a review, before presenting it or having it 
presented in the Parliament. 
(3) 
Where an amendment to this Part or to an Organic Law authorized by this Part is 
proposed to be presented in the Parliament, the Minister responsible for Constitutional Law 
matters in relation to Bougainville shall, as soon as practicable after the proposed amendment is 
published in the National Gazette (or earlier if the Minister has notification of the proposed
```

---

## Page 156

```text
156
amendment) send a copy of the proposed amendment to the Bougainville Government and the 
two Governments shall consult with each other concerning the proposed amendment. 
(4) 
An amendment referred to in Subsection (2) or (3) cannot become law unless— 
(a) it is passed by the National Parliament in accordance with Section 14 (making of 
alterations to the Constitution and Organic Laws); and 
(b) before the second vote in the National Parliament on the amendment in accordance 
with Section 14 (making of alterations to the Constitution and Organic Laws), on a 
motion in the Bougainville Legislature for approval of the amendment as presented to 
the Parliament, there is— 
(i) 
in the case of an amendment to Division 7 or to this Subsection—a two-thirds 
absolute majority vote of members of the Bougainville Legislature in favour of the 
amendment; and 
(ii) 
in the case of an amendment to this Part, other than to Division 7 or to this 
Subsection—a simple majority vote of the members of the Bougainville Legislature 
in favour of the amendment. 
(5) 
The person presiding over the Bougainville legislature on the occasion of a vote taken 
under Subsection (4)(b)(i) or (ii) shall, as soon as practicable after the vote has been taken, send 
to the Speaker of the National Parliament details of the result of the vote. 
346. Prescribed majority of votes required for this Part, etc. 
(1) 
For the purposes of Section 14 (making of alterations to the Constitution and Organic 
Laws), the prescribed majority of votes for this Part is a two-thirds absolute majority vote. 
(2) 
For the purposes of Section 14(5)(b)(i) (making of alterations to the Constitution and 
Organic Laws) the prescribed majority of votes for an Organic Law authorized by this Part is a 
two-thirds absolute majority vote. 
347. Organic Laws. 
Where this Part authorizes an Organic Law to make provision for any matter, the Organic Law 
may make full provision for all aspects of that matter, notwithstanding that all such aspects have 
not been expressly referred to in the provision authorizing the Organic Law. 
348. Transitional provisions. 
An Organic Law may make provision for all matters relating to the transition of Bougainville 
from the system of Government immediately before the coming into operation of this Part to the 
system of Government for which provision is made in this Part. 
349. Constitutional Regulations. 
(1) 
The Head of State, acting with, and in accordance with, the advice of the National 
Executive Council, may make Constitutional Regulations not inconsistent with this Part 
prescribing all matters that by this Part are required or permitted to be prescribed or that are 
necessary or convenient to be prescribed for carrying out and giving effect to this Part. 
(2) 
The Constitutional Regulations under Subsection (1) shall not be made, amended or 
repealed except with the approval of the Bougainville Executive in accordance with the
```

---

## Page 157

```text
157
Bougainville Constitution and the Agreement.
```

---

## Page 158

```text
158
 
SCHEDULES. 
SCHEDULE 1. 
RULES FOR SHORTENING AND INTERPRETATION OF THE CONSTITUTIONAL 
LAWS. 
PART 1.—INTRODUCTORY. 
Sch.1.1. Application of Schedule 1. 
(1) 
The rules contained in this Schedule apply, unless the contrary intention appears, in the 
interpretation of the Constitution and of the Organic Laws. 
(2) 
Unless adopted by law for the purposes, they do not apply to any other law. 
PART 2.—GENERAL 
Sch.1.2. Meaning of certain expressions. 
(1) 
In this Constitution or an Organic Law— 
“absolute majority vote”, in relation to proceedings in the Parliament, means— 
(a) 
if qualified by reference to a certain fraction or percentage, affirmative votes 
equal to not less than that fraction or percentage of the total number of seats in the 
Parliament; or 
(b) 
if not so qualified, affirmative votes equal to more than one half of the total 
number of those seats; 
“act” includes omission or failure to act; 
“Act of the Parliament” means a law (other than a Constitutional Law) made by the 
Parliament, and includes a subordinate legislative enactment made under any such law; 
“alter”, in relation to any provision of this Constitution or any other law, includes repeal 
(with or without re-enactment or the making of other provision), amend, modify, 
suspend (or remove a suspension) or add to the words or effect of the provision; 
“committee”, in relation to the Parliament, includes a subcommittee of a committee of 
the Parliament; 
“Constitutional Law” means this Constitution, a law altering this Constitution or an 
Organic Law; 
“the country” means the area of Papua New Guinea; 
“custom” means the customs and usages of indigenous inhabitants of the country 
existing in relation to the matter in question at the time when and the place in relation to 
which the matter arises, regardless of whether or not the custom or usage has existed 
from time immemorial; 
“the day fixed for the return of the writs for a general election” means— 
(a) 
in the case of a general election where there is no extension of the time for the 
return of any writ or the time for the return of all writs is extended—the day by 
which the writs are to be returned; and 
(b) 
in any other case—the day by which the majority of the writs are to be
```

---

## Page 159

```text
159
returned. 
“the Declaration of Office” means a declaration in the form in Schedule 3; 
“the Deputy Leader of the Opposition” means the member of the Parliament (if any) 
recognized by the Parliament as being the second principal speaker on behalf of those 
members of the Parliament who are not generally committed to support the Government 
in the Parliament; 
“deliberate judgement”, in relation to an act, has the meaning and effect attributed to it 
by Section 62 (decisions in ”deliberate judgement“); 
“Emergency Regulation” means a law that is made in accordance with Section 231 
(Emergency Regulations); 
“fiscal year”, in relation to any activity of the National Government, means the period of 
12 months commencing on 1 July or on such other date as is fixed by an Act of the 
Parliament for the purpose;(See: Fiscal Year Change Act (Chapter 350)) 
“of full capacity”, in relation to a person means that he is not of unsound mind within the 
meaning of any law relating to the custody or protection of the persons or property of 
persons of unsound mind; 
“governmental body” means— 
(a) 
the National Government; or 
(b) 
a provincial government; or 
(c) 
an arm, department, agency or instrumentality of the National Government or a 
provincial government; or 
(d) 
a body set up by statute or administrative act for governmental or official 
purposes; (Paragraph (b) and (c) of definition of “government body” 
amended by Constitutional Amendment No.1) 
“Judge” means a Judge of the Supreme Court or a Judge of the National Court; 
“Judge of the National Court” means the Chief Justice, the Deputy Chief Justice or a 
Judge, and includes an acting Judge; 
“Judge of the Supreme Court” means a Judge of the National Court, other than an acting 
Judge; 
“the Judicial Declaration” means a declaration in the form in Schedule 4; 
“judicial officer” means a Judge or Magistrate of a court within the National Judicial 
System (other than a magistrate or member of a village court) in his capacity as such; 
“law” includes the underlying law; 
“lawyer” means a person who has been admitted to practice as a lawyer under an Act of 
the Parliament; (See: Lawyer’s Act 1986) 
“the Leader of the Opposition” means the member of the Parliament (if any) recognized 
by the Parliament as being the principal speaker on behalf of those members of the 
Parliament who are not generally committed to support the Government in the 
Parliament; 
“local government body” includes a local government council and a local government 
authority established under the pre-Independence law known as the Local Government 
Act 1963 or any other law; 
“medical practitioner” means a person who has been admitted to practice as a medical 
practitioner under an Act of the Parliament; (See: Medical Registration Act
```

---

## Page 160

```text
160
(Chapter 398)) 
“the Minister” in relation to any Constitutional Law, provision, matter or thing, means 
the Minister for the time being administering that Constitutional Law or provision, or the 
Minister for the time being administering the Constitutional Law or provision that 
governs that matter or thing, as the case may be; 
“misconduct in office” means misconduct in office as described in Section 27 
(responsibilities of office) or as prescribed by an Organic Law made for the purposes of 
Section 28 (further provisions) or as prescribed by an Organic Law made for the 
purposes of Subdivision VI.2.H (Protection of Elections from Outside or Hidden 
Influences and Strengthening of Political Parties); 
“the National Gazette” includes any Special National Gazette or National Gazette 
Extraordinary, and any supplement to a National Gazette; 
“Papua New Guinea” means the Independent State of Papua New Guinea; 
“Parliamentary Leader of, a registered political party” or “Parliamentary Leader” means 
the member of the Parliament elected by a registered political party to be its 
Parliamentary Leader; 
“Parliamentary Leader of, a registered political party or ‘Parliamentary Leader’ means 
the member of the Parliament elected by a registered political party to be its 
Parliamentary Leader; 
“personal staff”, in relation to the Governor-General, a Minister, the Leader of the 
Opposition or the Deputy Leader of the Opposition, means the staff supplied to him by 
or under an Act of the Parliament at the public expense, not being members of the 
National Public Service in their capacities as such; (See: Official Personal Staff 
Act (Chapter 383)) 
“pre-Independence law” has the same meaning as in Section Sch.2.6 (adoption of pre-
Independence laws); 
“the pre-Independence Supreme Court” means the pre-Independence court known as the 
Supreme Court of Papua New Guinea, the Supreme Court of the Territory of Papua and 
New Guinea or the Supreme Court of the Territory of Papua-New Guinea; 
“provincial law” means a law made or adopted by a provincial legislature, and includes a 
subordinate legislative enactment made under any such law;(Definition of 
“provincial law” inserted by Constitutional Amendment No.1) 
“public accounts of Papua New Guinea” includes all accounts, books and records of, or 
in the custody, possession or control of, the National Executive or of a public officer, 
relating to public property or public moneys of Papua New Guinea; 
“public moneys of Papua New Guinea” includes moneys held in trust by the National 
Executive or a public officer in his capacity as such, whether or not they are so held for 
particular persons; 
“principles of natural justice” means the principles referred to in Division III.4 
(principles of natural justice), and where those principles have been altered in 
accordance with Section 60 (development of principles), or by an Act of the Parliament, 
includes those principles as so altered; 
“public office-holder” means— 
(a) 
a member of any of the State Services or of a provincial service; or 
(b) 
any other constitutional office-holder; or
```

---

## Page 161

```text
161
(c) the holder of any office or position established by statute for administrative or 
governmental purposes; or 
(d) the holder of any other office or position declared by a statute to be a public office;  
(Paragraph (a) of definition of “Public Office-holder” amended by 
Constitutional Amendment No.1) 
“the public trustee” means the officer (by whatever title known) charged with the duty of 
administering deceased intestate estates; 
“seat”, in relation to the Parliament, includes— 
(a) 
the position of an elected member, whether or not the position is for the time 
being filled; and 
(b) 
where there is for the time being a nominated member appointed in accordance 
with Section 102 (nominated members)—the position of that nominated member; 
“statute” means an Act of the Parliament, an Emergency Regulation or a provincial law, 
and includes a subordinate legislative enactment made under any such law; (amended 
by Constitutional Amendment No.1) 
“subordinate legislative enactment” means a regulation or any other instrument (whether 
of a legislative nature or not) made under a statute; 
“taxation” includes rates, charges and fees and imposts of any kind; 
“time of war” means a period during which a declaration under Section 227 (declaration 
of war) is in force; 
“the underlying law” means— 
(a) 
the underlying law provided for by an Act of the Parliament under Section 
20(1) (underlying law and pre-Independence statutes); and 
(b) 
until such time as there is an Act of the Parliament, the underlying law 
prescribed in Schedule 2 (adoption, etc., of certain laws); 
“village court” means a court referred to in Section 172(2) (establishment of other 
courts). 
(2) 
Unless the contrary intention appears, where an expression is defined for any purpose in 
this Schedule, or otherwise in a Constitutional Law, then for that purpose all grammatical 
variations and cognate and related expressions are to be understood in the same sense. 
(3) 
Unless the contrary intention appears, a reference in a Constitutional Law to an 
institution, office or other thing shall be read as a reference to the appropriate institution, office 
or thing established or provided for this Constitution, or referred to in the Preamble to this 
Constitution. 
Sch.1.3. Form of the Constitutional Laws. 
(1) 
The Preamble to this Constitution (being the provisions that end immediately before the 
heading to Part I.) forms part of this Constitution, but expresses general principles and therefore 
must be read subject to any other provision of this Constitution, though it may be used as an aid 
to interpretation in cases of doubt. 
(2) 
The heading or head-notes to the various sections of a Constitutional Law do not form 
part of the Law, but other headings and notes do form part of the Law.
```

---

## Page 162

```text
162
(3) 
Each provision of a Constitutional Law takes effect as a Constitutional Law. 
(4) 
Where a reference in a provision of a Constitutional Law to another provision of that 
Law, or to a provision of another Constitutional Law, is followed by words in brackets 
describing, or purporting to describe, the effect of the provision so referred to, the description or 
purported description does not, unless the contrary is expressed, affect the meaning or effect of 
the provision so referred to. 
Sch.1.4. Constitutional Laws speak from time to time. 
A Constitutional Law speaks from time to time. 
Sch.1.5. Fair meaning to be given to language used. 
(1) 
Each Constitutional Law is intended to be read as a whole. 
(2) 
All provisions of, and all words, expressions and propositions in, a Constitutional Law 
shall be given their fair and liberal meaning. 
Sch. 1.6. Statements of general principle. 
Where a provision of a Constitutional Law is expressed to state a proposition “in principle”, 
then— 
(a) an act (including a legislative, executive or judicial act) that is inconsistent with the 
proposition is not, by reason of that inconsistency alone, invalid or ineffectual; but 
(b) if the act is reasonably capable of being understood or given effect to in such a way 
as not to be inconsistent with the proposition it shall be so given effect to. 
Sch.1.7. “Non-justiciable”. 
Where a Constitutional Law declares a question to be non-justiciable, the question may not be 
heard or determined by any court or tribunal, but nothing in this section limits the jurisdiction of 
the Ombudsman Commission or of any other tribunal established for the purposes of Division 
III.2 (leadership code). 
Sch.1.8. Gender and number. 
In a Constitutional Law— 
(a) words importing the masculine gender include females; and 
(b) words in the singular include the plural and words in the plural include the singular. 
Sch.1.9. Provision where no time prescribed. 
Where no time is prescribed or allowed within which an act is required or permitted by a 
Constitutional Law to be done, the act shall or may be done, as the case may be, with all 
convenient speed and as often as the occasion arises. 
Sch.1.10. Exercise and performance of powers and duties. 
(1) 
Where a Constitutional Law confers a power or imposes a duty, the power may be 
exercised, or the duty shall be performed, as the case may be, from time to time as occasion 
requires.
```

---

## Page 163

```text
163
(2) 
Where a Constitutional Law confers a power or imposes a duty on the holder of an 
office as such, the power may be exercised, or the duty shall be performed, as the case may be, 
by the holder (whether substantive or other) for the time being of the office. 
(3) 
Where a Constitutional Law confers a power to make any instrument or decision (other 
than a decision of a court), the power includes power exercisable in the same manner and subject 
to the same conditions (if any) to alter the instrument or decision. 
(4) 
Subject to Subsection (5), where a Constitutional Law confers a power to make an 
appointment, the power includes power to remove or suspend a person so appointed, and to 
appoint another person temporarily in the place of a person so removed or suspended or, where 
the appointee is for any reason unable or unavailable to perform his duties, to appoint another 
person temporarily in his place. 
(5) 
The power provided for by Subsection (4) is exercisable only subject to any conditions 
to which the exercise of the original power or appointment was subject. 
Sch.1.11. Determination of appropriate authority 
Where a Constitutional Law refers to “the appropriate Permanent Parliamentary Committee”, the 
Parliament shall determine which Permanent Parliamentary Committee is the appropriate 
committee for the purpose and where the Parliament fails to do so the Speaker may so determine. 
Sch.1.12. Power of majority of more than two persons, and quorums. 
(1) 
Where a Constitutional Law requires or permits an act or thing to be done by more than 
two persons, a majority of them may do it. 
(2) 
Subsection (1) does not affect any requirement of a quorum, and, subject to Subsection 
(3), where no quorum is prescribed for a body the quorum is the full membership of the body. 
(3) 
A power conferred by a Constitutional Law, otherwise than on the body in question, to 
determine the procedures of a body includes power to determine a quorum. 
(4) 
The exception contained in Subsection (3) does not apply to the National Executive 
Council. 
Sch.1.13. Attainment of age. 
For any purpose of a Constitutional Law, a person attains a certain age at the first moment of the 
relevant anniversary of his birth. 
Sch.1.14. References to series. 
(1) 
Where in a Constitutional Law a reference is made to a series by reference to two 
numbers, one at the beginning and one at the end of the series, each of those numbers forms part 
of the series. 
(2) 
The reference in Subsection (1) to numbers include, where the elements of a series are 
identified by letters or in some other manner, references to letters or that other means of 
identification.
```

---

## Page 164

```text
164
 
Sch.1.15. Residence. 
(1) 
Where in a Constitutional Law there is a requirement for any purpose of permanent 
residence or of continuous residence in a place (including the area of Papua New Guinea), an 
Organic Law may provide that— 
(a) periods of temporary absence from that place shall be counted as periods of residence 
in that place; or 
(b) periods of temporary absence from that place shall not be counted as periods of 
residence in that place but otherwise do not affect the continuity of residence. 
(2) 
In Subsection (1), “temporary absence” means, subject to Subsection (3), absence for 
temporary purposes with the intention of returning. 
(3) 
An Organic Law may further provide for the definition of classes of absence that 
constitute or do not constitute temporary absence for the purposes of any provision of a 
Constitutional Law. (See: Organic Law on Residence) 
Sch.1.16. Effect of time limits. 
(1) 
Where in a Constitutional Law a time limit is imposed for the doing of an act (whether 
the provision is mandatory, directory or permissive, and whether it is positive or negative), and 
in a particular case it is not practicable to comply with that limitation, the period shall be deemed 
to be extended by whatever period is necessary to make compliance practicable. 
(2) 
The operation of Subsection (1) is not excluded by a provision that unqualifiedly 
specifies a time limit or a maximum time limit. 
Sch.1.17. Repeal, etc. 
(1) 
The repeal of a Constitutional Law or a part of a Constitutional Law does not— 
(a) revive anything (including a statute or any part of the underlying law) that was not in 
force or existing immediately before the repeal took effect; or 
(b) affect the previous operation of the repealed provisions or anything duly done or 
suffered under them; or 
(c) affect any right, privilege, obligation or liability acquired, accrued or incurred under 
the repealed provisions; or 
(d) affect any penalty, forfeiture or punishment incurred in respect of an offence 
committed against the repealed provisions; or 
(e) affect any investigation, legal proceeding or remedy in respect of any such right, 
privilege, obligation, liability, penalty, forfeiture or punishment, 
and any such investigation, legal proceeding or remedy may be instituted, continued or enforced, 
and the penalty, forfeiture or punishment may be imposed, as if the repealed provisions had 
continued in force. 
(2) 
In particular, the repeal of a Constitutional Law or a part of a Constitutional Law does 
not— 
(a) affect any liability under Division III.2 (leadership code); or
```

---

## Page 165

```text
165
(b) prevent the Ombudsman Commission or any other tribunal established for the 
purpose of that Division from investigating any act, 
to which the repealed provisions were relevant. 
(3) 
Where a Constitutional Law or a part of a Constitutional Law is repealed and re-enacted 
(with or without modification), references in any other law to any of the repealed provisions 
shall, unless the contrary intention appears, be read as a reference to the amended or replacing 
provision. 
(4) 
In this section, “repeal” includes revocation, suspension and expiry. 
Sch.1.18. Disallowance, etc. 
(1) 
Where a Constitutional Law provides that a law may be disallowed, the disallowance 
takes effect in the same way as a repeal of a provision of a Constitutional Law takes effect except 
that, if the disallowed law altered any other law, the disallowance revives the other law as in 
force before the alteration. 
(2) 
For the purpose of Subsection (1), a refusal or failure by the Parliament to confirm, 
approve or extend a law that requires such confirmation, approval or extension has the same 
effect as a disallowance. 
Sch.1.19. Independence. 
Where a Constitutional Law provides that a person or institution is not subject to control or 
direction, or otherwise refers to the independence of a person or institution, that provision does 
not affect— 
(a) control or direction by a court; or 
(b) the regulation, by or under a Constitutional Law or an Act of the Parliament, of the 
exercise or performance of the powers, functions, duties or responsibilities of the person 
or institution; or 
(c) the exercise of jurisdiction under Division III.2 (leadership code), Subdivision 
VIII.1.B (the Auditor-General), or Subdivision VIII.1.C (the Public Accounts 
Committee), 
and does not constitute an appropriation of, or authority to expend, funds. 
Sch.1.20. Regulation of acts, etc. 
A provision of a Constitutional Law that provides for the regulation of an act or thing does not 
extend to prohibition, whether in law or in effect. 
 
PART 3.—SPECIAL PROVISIONS RELATING TO THE OFFICE OF HEAD OF 
STATE. 
Sch.1.21.  which to some extent duplicates this provision. 
“the Head of State”; “the Governor-General”. 
For the avoidance of doubt, it is hereby declared that—
```

---

## Page 166

```text
166
(a) in this Constitution— 
(i) 
a reference to “the Head of State” is a reference to the Queen and Head of State 
of Papua New Guinea for the time being and includes a reference to the person or 
persons exercising sovereignty over the United Kingdom of Great Britain and 
Northern Ireland in the event of the youth or incapacity of the person in that 
sovereignty; and 
(ii) 
a reference to “the Governor-General” does not include a reference to the 
Queen or the person exercising sovereignty over the United Kingdom of Great 
Britain and Northern Ireland; and 
(iii) a reference to “the Head of State” is a reference to the Queen or a person 
exercising sovereignty over the United Kingdom of Great Britain and Northern 
Ireland or, where such a person does not act personally, to the Governor-General as 
the representative of the Queen or that person; and 
(b) the question, whether in performing a function or carrying out a duty as Head of 
State the Governor-General is acting in accordance with the will or opinion of the 
person exercising sovereignty over the United Kingdom of Great Britain and 
Northern Ireland, is non-justiciable and is not subject to the jurisdiction of the 
Ombudsman Commission or any other person or authority. 
 
SCHEDULE 2. 
Sec. 18. 
ADOPTION, ETC., OF CERTAIN LAWS. 
PART 1.—CUSTOM. 
Sch.2.1. Recognition, etc., of custom. 
(1) 
Subject to Subsections (2) and (3), custom is adopted, and shall be applied and 
enforced, as part of the underlying law. 
(2) 
Subsection (1) does not apply in respect of any custom that is, and to the extent that it is, 
inconsistent with a Constitutional Law or a statute, or repugnant to the general principles of 
humanity. 
(3) 
An Act of the Parliament may— 
(a) provide for the proof and pleading of custom for any purpose; and 
(b) regulate the manner in which, or the purposes for which, custom may be recognized, 
applied or enforced; and 
(c) provide for the resolution of conflicts of custom. (See: Customs Recognition 
Act (Chapter 19)) 
 
PART 2.—RECEPTION OF A COMMON LAW, ETC. 
Sch.2.2. Adoption of a common law. 
(1) 
Subject to this Part, the principles and rules that formed, immediately before
```

---

## Page 167

```text
167
Independence Day, the principles and rules of common law and equity in England are adopted, 
and shall be applied and enforced, as part of the underlying law, except if, and to the extent 
that— 
(a) they are inconsistent with a Constitutional Law or a statute; or 
(b) they are inapplicable or inappropriate to the circumstances of the country from time 
to time; or 
(c) in their application to any particular matter they are inconsistent with custom as 
adopted by Part 1. 
(2) 
Subject to Subsection (1)(a), (b) and (c), the principles and rules adopted under 
Subsection (1) include principles and rules relating to the Royal Prerogative, except insofar as 
they provide for— 
(a) a power to declare martial law; or 
(b) a power to grant letters of denization or similar privileges; or 
(c) a power to do any other act, provision for the doing of which is made by a 
Constitutional Law or an Act of the Parliament. 
(3) 
The principles and rules of common law and equity are adopted as provided by 
Subsections (1) and (2) notwithstanding any revision of them by any statute of England that does 
not apply in the country by virtue of Section Sch.2.6 (adoption of pre-Independence laws). 
(4) 
In relation to any particular question before a court, the operation of Subsection (1)(b) 
shall be determined by reference, among other things, to the circumstances of the case, including 
the time and place of any relevant transaction, act or event. 
 
PART 3.—DEVELOPMENT OF AN UNDERLYING LAW FOR PAPUA NEW GUINEA. 
Sch.2.3. Development, etc., of the underlying law. 
(1) 
If in any particular matter before a court there appears to be no rule of law that is 
applicable and appropriate to the circumstances of the country, it is the duty of the National 
Judicial System, and in particular of the Supreme Court and the National Court, to formulate an 
appropriate rule as part of the underlying law having regard— 
(a) in particular, to the National Goals and Directive Principles and the Basic Social 
Obligations; and 
(b) to Division III.3 (basic rights); and 
(c) to analogies to be drawn from relevant statutes and custom; and 
(d) to the legislation of, and to relevant decisions of the courts of, any country that in the 
opinion of the court has a legal system similar to that of Papua New Guinea; and 
(e) to relevant decisions of courts exercising jurisdiction in or in respect of all or any 
part of the country at any time, 
and to the circumstances of the country from time to time. 
(2) 
If in any court other than the Supreme Court a question arises that would involve the 
performance of the duty imposed by Subsection (1), then, unless the question is trivial, vexatious 
or irrelevant— 
(a) in the case of the National Court—the court may; and
```

---

## Page 168

```text
168
(b) in the case of any other court (not being a village court)—the court shall, 
refer the matter for decision to the Supreme Court, and take whatever other action (including the  
adjournment of proceedings) is appropriate. (See: The Underlying Law Act 2000) 
 
Sch.2.4. Judicial development of the underlying law. 
In all cases, it is the duty of the National Judicial System, and especially of the Supreme Court 
and the National Court, to ensure that, with due regard to the need for consistency, the 
underlying law develops as a coherent system in a manner that is appropriate to the 
circumstances of the country from time to time, except insofar as it would not be proper to do so 
by judicial act. (See: The Underlying Law Act 2000) 
Sch.2.5. Reports on the development of the underlying law. 
In their reports under Section 187(1) (reports by Judges), and in any report under Section 187(2) 
(reports by Judges) if in their opinion it is desirable to do so, the Judges shall comment on the 
state, suitability and development of the underlying law, with any recommendations as to 
improvement that they think it proper to make. 
 
PART 4.—ADOPTION OF CERTAIN STATUTES. 
Sch.2.6. Adoption of pre-Independence laws. 
(1) 
In Subsection (2), “pre-Independence law” means— 
(a) a law (including a law that had not yet come into operation) that was repealed by the 
Laws Repeal Act 1975 made by the pre-Independence House of Assembly for Papua 
New Guinea, and includes— 
(i) 
a law that was, and to the extent that it was, continued in force under or by 
virtue of any such law; and 
(ii) 
a purported law that might have been (but had not been declared by a court to 
be) invalid by reason of a failure to comply with any other law in respect of the 
manner of its assent, 
other than such a law that was repealed or superseded, or had expired or was spent, before 
the commencement of the Laws Repeal Act 1975; and 
(b) the laws of Australia specified in Part 1 of Schedule 5 as in force in the country 
immediately before Independence Day; and 
(c) the laws of England specified in Part 2 of Schedule 5 as in force in the country 
immediately before Independence Day; and 
(d) subordinate legislative enactments under any such laws that were in force in the 
country immediately before the repeal, or immediately before Independence Day, as the 
case may be. 
(2) 
Subject to any Constitutional Law, all pre-Independence laws are, by virtue of this 
section, adopted as Acts of the Parliament, or subordinate legislative enactments under such
```

---

## Page 169

```text
169
Acts, as the case may be, and apply to the extent to which they applied, or purported to apply, 
immediately before the repeal referred to in Subsection (1)(a), or immediately before 
Independence Day, as the case may be. 
(3) 
For the avoidance of doubt it is hereby declared that where a pre-Independence law to 
which Subsection (2) applies has not been brought into operation, and does not itself express a 
date on which it is to come into operation, it may be brought into operation— 
(a) in the case of an Act—on a date to be fixed by the Head of State by notice published 
in the National Gazette; and 
(b) in the case of a subordinate legislative enactment—by publication in the National 
Gazette. 
Sch.2.7. Adaptation of adopted law. 
(1) 
A law adopted by Section Sch.2.6 (adoption of pre-Independence laws) takes effect 
subject to such changes as to names, titles, offices, persons and institutions, and to such other 
formal and non-substantive changes, as are necessary to adapt it to the circumstances of the 
country and to the Constitutional Laws. 
(2) 
A Constitutional Regulation may prescribe changes to be made for the purposes of 
Subsection (1) and any such regulation is conclusive as to the changes so prescribed, but no 
omission to prescribe a change affects the generality of that subsection. 
(3) 
A question as to a change to be made for the purposes of Subsection (1) is not a 
question relating to the interpretation or application of any provision of a Constitutional Law 
within the meaning of Section 18 (original interpretative jurisdiction of the Supreme Court), but 
this subsection does not affect the operation of Section 19 (special references to the Supreme 
Court). 
PART 5.—JUDICIAL PRECEDENT. 
Sch.2.8. Effect of Part 5. 
(1) 
Nothing in this Part affects or is intended to affect, except to the extent specifically set 
out in this Part— 
(a) the legal doctrine of judicial precedent (also known as stare decisis); or 
(b) the principles of judicial comity; or 
(c) the rules of private international law (also known as conflict of laws); or 
(d) the legal doctrine known as res judicata, 
or the further development and adoption of those doctrines, principles and rules in accordance 
with Part 3 of this Schedule (development of an underlying law for Papua New Guinea). 
(2) 
Except as provided by or under an Act of the Parliament, this Part does not apply to or 
in respect of village courts. 
Sch.2.9. Subordination of courts. 
(1) 
All decisions of law by the Supreme Court are binding on all other courts, but not on 
itself. 
(2) 
Subject to Section Sch.2.10 (conflict of precedents), all decisions of law by the National
```

---

## Page 170

```text
170
Court are binding on all other courts (other than the Supreme Court), but not on itself (except 
insofar as a decision of the National Court constituted by more Judges than one is of greater 
authority than a decision of the Court constituted by a lesser number). 
(3) 
Subject to this Part, all decisions of law by a court other than the Supreme Court or the 
National Court are binding on all lower courts. 
(4) 
In Subsection (3), “lower court”, in relation to a matter before a court, means a court to 
which proceedings by way of appeal or review (whether by leave or as of right) lie from the first-
mentioned court in relation to the matter. 
Sch.2.10. Conflict of precedents. 
(1) 
Where it appears to a court other than the Supreme Court or the National Court that— 
(a) there are more decisions of law than one that are otherwise binding on it by virtue of 
the preceding provisions of this Part and that, in relation to the matter before it, the 
decisions are conflicting; or 
(b) a decision of law that is otherwise binding on it by virtue of the preceding provisions 
of this Part and that is otherwise applicable to the matter before it— 
(i) 
is not, or is no longer, appropriate to the circumstances of the country or of the 
matter; or 
(ii) 
is inconsistent with any custom that is part of the underlying law and is 
applicable in relation to the matter; or 
(iii) is seriously inconsistent with the trend of the adaptation and development of 
the law in other respects, 
then unless the question is trivial, vexatious or irrelevant the court may, and shall if so requested 
by a party to the matter, state a case to the court that made the decision or decisions or the 
equivalent court, or if there be no such court to the National Court, and take whatever other 
action (including the adjournment of proceedings) is appropriate. 
(2) 
Where a case is stated in accordance with Subsection (1), the court to which it is stated 
may require or permit the Minister responsible for the National Justice Administration to be 
represented by counsel to assist the court. 
Sch.2.11. Prospective over-ruling. 
(1) 
Subject to any decision of law that is binding upon it, in over-ruling a decision of law or 
in making a decision of law that is contrary to previous practice, doctrine or accepted custom, a 
court may, for a special reason, apply its decision of law only to situations occurring after the 
new decision. 
(2) 
In the circumstances described by Subsection (1), a court may apply to a situation a 
decision of law that was over-ruled after the occurrence of the situation, or a practice, doctrine or 
custom that was current or accepted at the time of the occurrence of any relevant transaction, act 
or event. 
(3) 
In a case to which Subsection (1) or (2) applies, a court may make its decision subject to 
such conditions and restrictions as to it seem just. 
Sch.2.12. Outside decisions.
```

---

## Page 171

```text
171
(1) 
For the purposes of this section, except in a matter before the Supreme Court or the 
National Court— 
(a) a decision of law by a Full Court of the pre-Independence Supreme Court, sitting in 
accordance with the pre-Independence law relating to sittings of the Supreme Court, or a 
decision of law on appeal from a decision of that court, has the same binding force as a 
decision of law of the Supreme Court; and 
(b) a decision of law by a pre-Independence Supreme Court sitting otherwise than as a 
Full Court, or a decision of law on appeal from a decision of that court, has the same 
binding force as a decision of law of the National Court, 
subject to any decision of law of the Supreme Court or the National Court, as the case may be, to 
the contrary, but otherwise no decision of law of a court or tribunal that was not established 
within the National Judicial System is binding on a court within it. 
(2) 
Subsection (1) does not prevent recourse to the decisions of law or the opinions of 
courts or tribunals outside the National Judicial System (including courts or tribunals of 
jurisdictions other than Papua New Guinea) for their persuasive value. 
 
PART 6.—THE LAW REFORM COMMISSION. 
Sch.2.13. Establishment of the Commission. 
(1) 
An Act of the Parliament shall make provision for and in respect of a Law Reform 
Commission. 
(2) 
Only citizens may be members of the Commission. 
(See: Constitutional and Law Reform Commission Act 2004)  
Sch.2.14. Special functions of the Commission. 
In addition to its other functions and responsibilities under any law, it is a special responsibility 
of the Law Reform Commission to investigate and report to the Parliament and to the National 
Executive on the development, and on the adaptation to the circumstances of the country, of the 
underlying law, and on the appropriateness of the rules and principles of the underlying law to 
the circumstances of the country from time to time. 
 
SCHEDULE 3. 
Sec.Sch.1.2(1). 
DECLARATION OF OFFICE. 
I…, do promise and declare that I will well and truly serve the Independent State of Papua New 
Guinea and its People in the office of… 
 
 
SCHEDULE 4.
```

---

## Page 172

```text
172
Sec.Sch.1.2(1). 
JUDICIAL DECLARATION. 
I…, do promise and declare that I will well and truly serve the Independent State of Papua New 
Guinea and its People in the office of…, that I will in all things uphold the Constitution and the 
laws of the Independent State of Papua New Guinea, and I will do right to all manner of people 
in accordance therewith, without fear or favour, affection or ill-will. 
 
SCHEDULE 5. 
Sec.Sch.2.6. 
ADOPTED LAWS OF OTHER COUNTRIES. 
PART 1.—AUSTRALIA. 
Continental Shelf (Living Natural Resources) Act 1968—Sections 9 and 14 only. 
Explosives Act 190 -1973. 
Judiciary Act 1903-1969—Section 84 only. 
Marine Insurance Act 1909-1966. 
Navigation Act 1912-1973. 
which dealt with the same subject-matter, although in different ways. 
Patents Act 1903-1973—Section 123 only. 
Petroleum (Submerged Lands) Act 1967-1968—Section 11 only. 
Nationality and Citizenship Act 1948-1967—Section 5(3) only. 
Seamen‘s Compensation Act 1911-1972—Section 4 only (in relation to a ship registered in the 
country under the Merchant Shipping Act 1894, as amended, of England). 
Seamen’s War Pensions and Allowances Act 1940-1974. 
Submarine Cables and Pipelines Protection Act 1963-1973. 
PART 2.—ENGLAND. 
Merchant Shipping Act 1894. 
Merchant Shipping Act 1897. 
Merchant Shipping (Liability of Ship owners and Others) Act 1900. 
Merchant Shipping Act 1906. 
Merchant Shipping Act 1911. 
Maritime Conventions Act 1911. 
Merchant Shipping Act 1921. 
Fees (Increase) Act 1923. 
SCHEDULE 6.
```

---

## Page 173

```text
173
Sch.6.1. Validation of certain matters relating to the Value Added Tax Act 1999. 
(1) 
In Schedule 6.1— 
“the Act” means the Value Added Tax Act 1998; 
“the relevant period” means the period commencing on 1 July 1999 and ending on the 
coming into operation of this section. 
(2) 
The imposition of— 
(a) value added tax; and 
(b) additional value added tax; and 
(c) further additional value added tax, 
under and in accordance with the Act during the relevant period is hereby validated. 
(3) 
The assessment and collection of— 
(a) value added tax; and 
(b) additional value added tax; and 
(c) further additional value added tax, 
under and in accordance with the Act during the relevant period are hereby validated. 
(4) 
The Commissioner General of Internal Revenue and all officers acting under his 
authority are, in respect of all actions taken by them, under and in accordance with the Act 
during the relevant period, indemnified against civil or criminal liability alleged on the grounds 
that the Act was, during the relevant period, declared unconstitutional. 
(5) 
All proceedings, civil or criminal, initiated under and in accordance with the Act during 
the relevant period are not invalid by reason only of the fact that the Act was, during the relevant 
period, declared unconstitutional. 
(6) 
All penalties (financial and otherwise) imposed under and in accordance with the Act 
during the relevant period are not invalid by reason only of the fact that the Act was, during the 
relevant period, declared unconstitutional. 
(7) 
All— 
(a) objections to assessments; and 
(b) objections to decisions; and 
(c) decisions of the— 
(i) 
Commissioner General of Internal Revenue; and 
(ii) 
Review Tribunal; and 
(iii) National Court, 
in relation to objections referred to in Paragraph (a) or (b), under and in accordance with the Act 
during the relevant period are not invalid by reason only of the fact that the Act was, during the 
relevant period, declared unconstitutional. 
(8) 
All— 
(a) exemptions from payment of value added tax; and 
(b) refunds of value added tax; and 
(c) set off of value added tax,
```

---

## Page 174

```text
174
under and in accordance with the Act during the relevant period are not invalid by reason only of 
the fact that the Act was, during the relevant period, declared unconstitutional. 
6.2. Validation of certain matters relating to the Value Added Tax Revenue 
Distribution Act 1998. 
(1) 
In Schedule 6.2— 
“the Act” means the Value Added Tax Revenue Distribution Act 1998; 
“the relevant period” means the period commencing on 1 July 1999 and ending on the 
date of coming into operation of this section. 
(2) 
The establishment and operations of— 
(a) the National VAT Revenue Trust; and 
(b) the Provincial VAT Trust; and 
(c) the National VAT Trust Account; and 
(d) the trust accounts established in each province, 
under and in accordance with the Act during the relevant period are hereby validated. 
(3) 
The— 
(a) payments made into the Trust Accounts referred to in Subsection (2)(c) and (d); and 
(b) payments made out of the Trust Accounts referred to in Subsection (2)(c) and (d); 
and 
(c) the method of calculation of value added tax distribution to the provinces; and 
(d) the order of precedence of distributions from the Trust Accounts referred to in 
Subsection (2)(c) and (d), 
under and in accordance with the Act during the relevant period are hereby validated. 
(4) 
The— 
(a) Commissioner General of Internal Revenue; and 
(b) officers acting under the authority of the Commissioner General of Internal Revenue; 
and 
(c) the trustees of the National VAT Revenue Trust; and 
(d) the trustees of each Provincial VAT Trust, 
are, in respect of all actions taken by them under and in accordance with the Act during the 
relevant period, hereby indemnified against civil or criminal liability alleged on the grounds that 
the Act was, during the relevant period, declared unconstitutional. 
__________
```

---

## Page 175

```text
175
 
INDEPENDENT STATE OF PAPUA NEW GUINEA. 
CHAPTER No. 1. 
Constitution. 
APPENDIX. 
CONSTITUTIONAL AMENDMENTS. 
Amendment No. 1—Provincial Government. 
Amendment No. 2—Provincial Government Elections. 
Amendment No. 3—Provincial Government (Consequential amendments). 
Amendment No. 4—Leadership Code. 
Amendment No. 5—Citizenship. 
Amendment No. 6—Benefits and Pensions. 
Amendment No. 7—Suspension and Re-establishment of Provincial Governments. 
Constitutional Amendment No 8—Public Services Commission 
Constitutional Amendment No. 9—Salaries and Remuneration Commission 
Constitutional Amendment No. 10—The Parliament and Finance 
Constitutional Amendment No. 11—Liberty of the Person 
Constitutional Amendment No. 12—Leadership Code 
Constitutional Amendment No. 13—Protection of the Law 
Constitutional Amendment No. 14—Motions of No Confidence 
Constitutional Amendment No. 15—Elections 
Constitutional Amendment No. 16—Provincial Governments and Local-level 
Governments 
Constitutional Amendment No. 17—Further Provisions relating to Provincial Governments 
and Local-level Governments 
Constitutional Amendment No. 18—Commencement of Constitutional Amendments Nos. 
16 and 17 
Constitutional Amendment No. 19—Elections 
Constitutional Amendment No. 20—Commencement of Constitutional Amendments Nos. 
16 and 17—Further Amendment 
Constitutional Amendment No. 21—Salaries and Remuneration Commission 
Constitutional Amendment No. 22—Integrity of Political Parties and Candidates
```

---

## Page 176

```text
176
Constitutional Amendment No. 23—Peace-Building in Bougainville—Autonomous 
Bougainville Government and Bougainville Referendum 
Constitutional Amendment No. 24—Electoral Reforms 
Constitutional Amendment No. 25—The State Services 
Constitutional Amendment No. 26—Organic Laws 
Constitutional Amendment No. 27—Sales and Services Tax 
Constitutional Amendment No. 28—Police Force 
Constitutional Amendment No. 29—Regulatory Statutory Authorities
```

---
