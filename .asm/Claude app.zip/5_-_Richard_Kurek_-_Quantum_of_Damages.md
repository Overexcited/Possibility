# QUANTUM OF DAMAGES — FULL PER-APPLICANT ANALYSIS
## Richard Ian Kurek & Ors v. Independent State of Papua New Guinea & Ors
### National Court of Justice — Human Rights Track
**Prepared by Claimant for Public Solicitor's Office**
**Companion to: the Affidavit, the Legal Brief, the Breach and Defense Arsenal, and the Quick Reference Card**

---

> **NOTE TO COUNSEL:** This document maps every documented harm, applicant by applicant, to a specific damages consequence, a constitutional/statutory basis, and a causal connection to the proven unlawful confinement. It is a claimant-prepared research aid only. Every figure is a working estimate requiring formal actuarial, accounting, and legal verification. Reasonable damages for breaches established in the Arsenal are not discretionary once proven — Constitution s.58(2) provides the affected person "is entitled" to them (Master Brief F3) — so the figures below quantify an existing entitlement, not a request the Court may decline. Where limitation concerns are flagged, tolling/extension is sought as the primary submission, with the underlying conduct retained in all cases as evidence of pattern, severity, and continuity supporting general and exemplary damages even where a specific head may not independently survive a limitation challenge.

---

## PART 1 — METHODOLOGY

### 1.0 Comparable Benchmark and the Duration/Severity Argument

A newspaper-reported National Court judgment (Waigani, 2025, Makail J) awarded a combined total of K9,679,674 — K9,526,674 special damages and K153,000 general damages — against the State and police, arising from a two-day raid and looting of the plaintiffs' properties and businesses. Interest was awarded on the total sum under the Judicial Proceedings (Interest on Debts and Damages) Act 2015, ss.4(1) and 6(1), running from date of writ of summons to date of final settlement, applied in that matter at **2%** — confirmed correct against the certified Act text (No. 15 of 2015): ss.4(2) and 6(2) both cap State interest at 2% yearly, and a judgment exceeding that is a nullity (ss.4(4), 6(6)). This is the rate used throughout this document. The *Kumasi v Air Niugini* report of an 8% award under this Act could not be reconciled with the certified text and should not be relied on.

This judgment is offered here as a real, current, comparable benchmark — not as binding precedent on quantum — and as confirmation that the interest mechanism used throughout this document is the one the National Court actually applies against the State, including under this specific Act. The 2015 Act (No. 15 of 2015) repealed the predecessor Act (Chapter 52, which had capped State interest at 8% — the rate *Pinzger* and *Sausau* were interpreting) and reduced the cap to 2%, applying retrospectively to State court orders from 1 January 2014 (s.2). The pre-2015 8% cases are legal history, not the current rate.

**Counsel is invited to consider whether the sustained, decade-long, multi-agency nature of the conduct in the present matter — as opposed to a single, however severe, two-day event — supports an argument for materially higher quantum**, given the continuing and in part permanent nature of the harm described throughout this document and the Affidavit. A single violent event, however serious, concludes; the conduct here has been continuous, repeated, and renewed across more than a decade, with the State having had — and declined — many hundreds of individual opportunities to correct course.

### 1.1 How This Document Is Structured

Each of the five applicants is addressed in turn (Parts 3–7). For each applicant, harms are organised by category, with each entry showing: the underlying facts, the breach count(s) it derives from (cross-referenced to the Arsenal document), the applicable head of damage, a causal-connection assessment against the single test set out in Part 2, a limitation assessment, and a working quantum estimate or methodology where one can be responsibly offered.

### 1.2 Limitation Framework

Three limitation postures are used consistently:

| Posture | Meaning | Applied Where |
|---|---|---|
| **(A) Clear / no limitation issue** | Conduct within the standard limitation period, or part of a continuing breach with the most recent instance current. | Most PNGICSA conduct (2021–2025); PNGCIR conduct from 2018 onward; all currently-ongoing harms. |
| **(B) Non-accrual/continuing-duty primary, tolling as fallback** | Conduct is framed first under the continuing-duty/no-accrual argument (Master Brief Part G Ground 1; Arsenal Defense 1C): a continuing failure to discharge a continuing duty has no accrual date until the duty is performed, so the claim does not depend on tolling to survive. Where an item is better characterised as a discrete, completed act rather than a continuing default, tolling is argued as the fallback (via the Frauds and Limitations Act analysis at Arsenal Count 87, the April 2021 acknowledgment resetting the clock, and Underlying Law Act s.7(4) equitable tolling for State-caused delay). If both fail, the conduct is retained as evidence of pattern, severity and continuity rather than abandoned. | The 2016–2018 pre-application barrier period; some 2018–2019 PNGCIR conduct. |
| **(C) Pattern evidence only, not independently pleaded** | Conduct involving no Respondent, or no causal connection at all to the proven confinement (true independent third-party acts that would have occurred, or whose connection cannot be drawn, regardless of confinement). | The pre-arrival visa delay (PNG High Commission, not a Respondent); the business registration/IPA agent fraud (private entity, not a Respondent) — see Part 4.3. |

---

## PART 2 — THE CAUSATION FRAMEWORK: A SINGLE COUNTERFACTUAL TEST

### 2.1 The Test

Two foundational facts are independently and directly proven by the conduct already established in the Master Legal Brief and Breach and Defense Arsenal:

1. **Unlawful confinement is proven.** PNGCIR's refusal to register the children's births made it legally and practically impossible for the family to obtain passports and cross an international border (Affidavit Part B; Arsenal Counts 11–17). PNGICSA's conduct compounds and prolongs this by withholding a validated debt and manufacturing an active enforcement crisis (Affidavit Part C; Arsenal Counts 1–19).
2. **The counterfactual is established and reasonable, not speculative.** Before any of the harm in this case occurred, the family had a concrete, agreed, documented plan to return to Australia within nine to twelve months of Richard's arrival (Affidavit paras 3–5). This was not an aspiration formed after the fact to support a damages claim — it predates the harm entirely. The counterfactual world in which the family was not unlawfully confined is therefore not a matter of speculation about what might have happened; it is the original, intended, and entirely ordinary course of events that the Respondents' own conduct interrupted.

From these two proven facts, a single test applies to every claimed harm in this document:

> **But for the unlawful confinement, would this harm have occurred?**

If the answer is no — if the harm would not have occurred, or would have been substantially less likely or less severe, in the counterfactual world where the family returned to Australia as planned — then the harm is a compensable downstream consequence of the Respondents' own proven unlawful conduct. This is the ordinary first-step causation test applied throughout common law negligence and already invoked elsewhere in this matter (Wrongs Act s.1, Arsenal Counts 78–80); nothing in this document asks the Court to apply a novel or expanded principle.

### 2.2 Strength of Connection — A Spectrum, Not a Cliff Edge

Not every harm sits at the same distance from the confinement. Applying the single test above produces a spectrum of connection strength, not a binary in/out determination. This document records, for each harm, where on that spectrum it sits, so that counsel can calibrate confidence and anticipate the State's likely response at each point — while preserving every harm on the spectrum as part of the same unified claim, rather than discarding the harder cases.

| Connection strength | Description | Example |
|---|---|---|
| **Immediate/mechanical** | The harm is the direct, single-step result of a Respondent's own act. No third party, no intervening event. | Lost Australian wages; the bond debt; inability to travel; the visa overstay crisis itself. |
| **Single-step environmental** | The harm required one additional factual step — exposure to a known, ongoing feature of the specific environment the family was confined to in poverty — but no independent human actor intervened. | Scabies (poverty → no medication); nutritional deprivation; lost early education. |
| **Intervening-actor environmental** | The harm materialised through the act or omission of a specific third party (an assailant, a landlord, a treating clinician) — but that third party's act was only able to cause harm to this family, in this way, because the family's confinement and poverty (both independently proven, Respondent-caused) removed their capacity to avoid, mitigate, or escape the risk. | The knife assault; Brighton's arm; James's facial scarring; Serah's business destruction. |

The third category is not weaker in principle than the first two — the "but for" test is satisfied identically in all three — but it is the category most likely to be tested by the State, because it requires the Court to accept that the family's *inability to avoid or mitigate* a third party's act is itself the compensable consequence of confinement, rather than treating the third party's act as a free-standing, unconnected event. This document takes the position, consistent with Affidavit paras 62–63 (*"the nature of the environment to which a person is confined determines the nature and extent of the harm they will foreseeably suffer... these harms are not random misfortunes that happened to coincide with our period of confinement"*), that this connection is sound and should be pleaded with full confidence — while flagging it clearly so counsel can prepare the strongest presentation of it.

### 2.3 What Falls Outside the Test Entirely

Some events in the family's history do not satisfy the test at all — not because the connection is merely weaker, but because no genuine link to the proven confinement can honestly be drawn. The pre-arrival visa delay and the IPA agent business registration fraud are treated this way (Part 4.3): both occurred through entities that are not Respondents, and neither is shown to be a consequence of the confinement itself (the confinement had not yet begun). These remain valuable as pattern evidence — they corroborate that the family encountered the same institutional dysfunction from the very first point of contact with PNG processes, which rebuts any suggestion that the case overstates a pattern that only later conduct displays — but they are not pleaded as quantified heads of damage.

---

## PART 3 — RICHARD IAN KUREK (First Applicant)

### 3.1 Constitutional and Statutory Rights Engaged

| Provision | Breach Counts | Limitation | Note |
|---|---|---|---|
| Consequential harm via children's s.52 breach (Arsenal Prong 6) | PNGICSA Count 18; PNGCIR (derivative) | (A) | Not an independent s.42 claim — s.42 is not relied upon anywhere in this case (see Additional Arguments). Richard's captivity is pleaded as a direct, foreseeable consequence of the children's established s.52 breach. Anchors the administrative captivity framing for Richard specifically |
| s.37 (protection of the law) | PNGICSA Count 1; PNGCIR Count 3 | (A) | Both agencies, continuing |
| s.41 (proscribed acts) | PNGICSA Counts 2–7; PNGCIR Counts 4–10 | (A) | Largest single cluster — supports exemplary damages independently |
| s.48 (freedom of employment) | PNGICSA Count 19; PNGCIR Count 26 | (A) | Anchor for economic loss claim — Prong 1 of six-prong framework |
| s.53 (protection from unjust deprivation of property) | PNGICSA Counts 8–9 | (A) | Bond debt — s.53(7) excludes non-citizens' property from this provision directly; primary basis is ICSA Act ss.4,5,35,36 and PFMA s.61 (Arsenal Count 29), with s.53 pleaded as a further alternative (full rebuttal at Arsenal Defense 1H) |
| s.59 (natural justice) | PNGICSA Counts 10–14; PNGCIR Counts 18–22 | (A) | Supports Layer 2/3 submissions, not separately quantified |
| ICCPR Art.12(4) via Underlying Law Act s.9 | Legal route, not a breach count | (A) | Prong 3 of six-prong framework |
| Wrongs Act s.1 — negligence, misfeasance, unjust enrichment | PNGICSA Counts 78–80; PNGCIR Count 61 | (A) | Prong 2 of six-prong framework; also anchors special damages |
| Wrongs Act s.1A — named officer personal liability | PNGICSA Counts 81–83; PNGCIR Count 60 | (A) | Sapaka, Metro, Jack, Dilu personally |

### 3.2 Economic Loss — Immediate/Mechanical

#### 3.2.1 Why the National Minimum Wage, Casual Rate, Is the Correct Baseline

The wage baseline used below is deliberately the National Minimum Wage (NMW) plus the statutory 25% casual loading, rather than an average or projected wage for a specific career. This is a deliberate legal strategy, not a simplification, and the reasoning should be put to the Court explicitly:

1. **It is a legislated floor, not an estimate.** The NMW is set annually by the Fair Work Commission under the Fair Work Act 2009 (Cth) and is the lowest amount any employer in the national workplace relations system may lawfully pay an adult employee not covered by a more specific award or agreement. It is not a market average, a survey figure, or an opinion — it is a legal minimum. The State has no basis to argue the figure should be lower, because no lower figure is lawful in Australia.
2. **It corresponds to real, immediately obtainable work.** Richard is a qualified IT specialist, but the claim does not depend on him obtaining IT work — it rests on the far more conservative floor of unskilled or semi-skilled casual work he could obtain immediately upon return: kitchen hand, general/casual labourer through a recruitment or labour-hire agency, and similar entry-level roles requiring no local referees, licences, or extended qualification checks. These roles are typically covered by the Hospitality Industry (General) Award 2020 (kitchen attendant classifications) or, for unclassified general casual labour placed by an agency, default to the National Minimum Wage itself. Both sit at or near the NMW floor — award classifications for this kind of entry-level work are frequently priced only marginally above it, and in some cases at it. Using the bare NMW is therefore not an inflated assumption; if anything it is a conservative one, understating what Richard would likely actually have earned.
3. **Casual loading is the correct classification, not full-time.** Recruitment-agency and hospitality casual work is, by its nature, casual employment. The Fair Work Ombudsman confirms casual employees paid at the National Minimum Wage receive a mandatory 25% loading in lieu of leave entitlements. This is applied throughout the calculation below.
4. **Standard full-time hours are used as the measure of capacity, not actual rostered hours.** Following the approach in Lewis v The State (1980) PNGLR 219 — loss assessed at what the claimant would have earned — the calculation below uses a standard 38-hour week (the National Employment Standards full-time week) as the measure of Richard's lost earning capacity, since he was and remains willing and able to work full-time hours and was prevented from doing so by the Respondents' conduct, not by any choice of his own.
5. Richard's evidence (Affidavit para 79) discloses a specific, higher-paying employment opportunity in Australia, arranged through a family member, that was lost as a direct consequence of the Respondents' conduct. No documentary record of that opportunity exists. It is not quantified as a separate head of loss here. The NMW-based figure below is, on the claimant's own unchallenged evidence, less than what was specifically and actually foregone.
6. **The annual figure applies a realistic attendance rate, not a theoretical 100%.** The calculation uses 50 of 52 weeks per year, reflecting the National Employment Standards' 10-day (2-week) statutory personal/carer's leave entitlement, available for an employee's own illness or to care for an immediate family member. This is a population-level legislative standard, not a claim about Richard's own health, and applies independently of the fitness evidence at §3.2.5 — even a fully able, willing worker does not achieve literal 100% attendance across a decade.

#### 3.2.2 Historical National Minimum Wage — Year by Year

The NMW is reviewed and (where increased) takes effect from the first full pay period on or after 1 July each year, following the Fair Work Commission's Annual Wage Review. The table below sets out the base and casual (base × 1.25) hourly rate for each relevant financial year. **Confidence level is stated for each figure** — this is not a uniform table, and counsel should treat the two tiers differently before filing:

- **Tier 1 (directly verified this session from Fair Work Ombudsman primary sources):** FY2024–25, FY2025–26, FY2026–27.
- **Tier 2 (compiled from a secondary wage-history source, internally consistent with Tier 1 figures and with the claimant's general recollection, but not independently primary-sourced in this session):** FY2016–17 through FY2023–24. Counsel or an instructed actuary should confirm each of these directly against the Fair Work Commission's National Minimum Wage Orders for the relevant year before the figures are relied upon in a filed document.

| Financial Year | NMW Base (AUD/hr) | Casual Rate incl. 25% loading (AUD/hr) | Confidence |
|---|---|---|---|
| 2016–17 | $17.70 | $22.13 | Tier 2 — verify |
| 2017–18 | $18.29 | $22.86 | Tier 2 — verify |
| 2018–19 | $18.93 | $23.66 | Tier 2 — verify |
| 2019–20 | $19.49 | $24.36 | Tier 2 — verify |
| 2020–21 | $19.84 | $24.80 | Tier 2 — verify |
| 2021–22 | $20.33 | $25.41 | Tier 2 — verify |
| 2022–23 | $21.38 | $26.73 | Tier 2 — verify |
| 2023–24 | $23.23 | $29.04 | Tier 2 — verify |
| 2024–25 | $24.10 | $30.13 | **Tier 1 — Fair Work Ombudsman, confirmed** |
| 2025–26 | $24.95 | $31.19 | **Tier 1 — Fair Work Ombudsman, confirmed directly (FWO states $31.19 casual rate verbatim)** |
| 2026–27 (from 1 July 2026) | $26.44 | $33.05 | **Tier 1 — Fair Work Ombudsman, confirmed** |

*Sources (Tier 1): fairwork.gov.au "Minimum wages" and "Minimum wages increase from 1 July 2026" pages, and the Fair Work Ombudsman's 1 July 2025 media release confirming the $24.95/$31.19 rates. The methodology (base × 1.25 = casual rate) is independently cross-verified: applying it to the confirmed FY2025–26 base of $24.95 produces $31.1875, which matches the Fair Work Ombudsman's own published casual figure of $31.19 to the cent (rounding), confirming the calculation method used throughout this table is the one Fair Work itself applies.*

#### 3.2.3 Worked Calculation — Past Loss, Financial Year by Financial Year

Annual loss per FY = casual hourly rate × 38 hours × 50 weeks (52 weeks less a 2-week NES personal/carer's leave allowance — see §3.2.1, point 6).

| Financial Year | Casual Rate | Annual Loss (AUD) |
|---|---|---|
| 2016–17 | $22.13 | $42,047 |
| 2017–18 | $22.86 | $43,436 |
| 2018–19 | $23.66 | $44,962 |
| 2019–20 | $24.36 | $46,291 |
| 2020–21 | $24.80 | $47,120 |
| 2021–22 | $25.41 | $48,279 |
| 2022–23 | $26.73 | $50,788 |
| 2023–24 | $29.04 | $55,176 |
| 2024–25 | $30.13 | $57,247 |
| 2025–26 | $31.19 | $59,262 |
| **Subtotal, 10 completed financial years** | | **≈ AUD $494,608** |
| 2026–27 (partial, 1 July 2026 to date of judgment) | $33.05 | Pro-rated by counsel to actual judgment date once known, at 50/52 |

**This AUD $494,608 figure (plus the partial current-year component) is the refined principal for Richard's past economic loss, calculated period-by-period at the applicable legal minimum for each year, rather than one flat current-day rate applied across the whole period.** This is both more accurate (it does not overstate early years at today's rate, nor understate them at a stale old rate) and more defensible, since every single year's figure is independently anchored to that year's own legislated minimum.

This figure is converted to Kina using the Bank of Papua New Guinea's own official published rate (see 3.2.4 for the source, and the worked conversion immediately below). As with the wage table at 3.2.2, this conversion is presented as a dated, sourced current snapshot, not a final figure — the applicable date for taking the rate (filing, judgment, or payment) remains open pending counsel's confirmation of National Court practice, and the Kina figure below will need to be re-run at whatever date is ultimately used. Note also that PGK has historically traded weaker than AUD, meaning a later conversion is more likely to increase this component in Kina terms than decrease it — the figures below should therefore be read as a floor, not a ceiling.

**Conversion snapshot, as at 2 July 2026** (Bank of Papua New Guinea official rate, K1 = AUD $0.3304, i.e. 1 AUD = K3.0266 — source: bankpng.gov.pg, Monthly Nominal Foreign Exchange Rates): AUD $494,608 × 3.0266 = **K1,496,998**.

#### 3.2.4 Currency and Conversion — Flag for Counsel

The above is calculated in Australian dollars, since the underlying loss is of Australian wages. This document does not convert the figure to PNG Kina, because doing so responsibly requires two separate determinations, only one of which is settled:

**Source of the rate — settled.** The applicable exchange rate should be the Bank of Papua New Guinea's official published rate, not an Australian source. This is the rate the PNG Government itself relies upon for its own official purposes, and using the Respondent's own reference rate removes any basis for the State to dispute the conversion methodology — it cannot credibly argue against a rate it relies on itself. Counsel to confirm this is the specific rate PNG Government agencies use for equivalent purposes (e.g., Treasury or customs valuation), but this is not expected to be contentious.

**Date the rate is taken — still open.** Whether the BPNG rate should be taken as at date of filing, date of judgment, or date of actual payment remains a procedural choice for counsel, since each produces a different final Kina figure given ordinary currency fluctuation, and PNG National Court practice on this point should be confirmed before a Kina figure is filed. If the payment-deadline relief sought at Master Brief F6.1 is granted, "date of actual payment" stops being an indefinite date and becomes a specific, bounded one (the ordered deadline, or shortly after) — which materially changes the practicality of using it as the conversion date, rather than the filing or judgment date, for the final figure.

#### 3.2.5 Interest and Future Loss

**Weekly-tranche interest.** Each year's loss (§3.2.3) accrued progressively across that financial year as wages, rather than as a single lump sum on one date. Treating a full year's figure as interest-bearing from one fixed date would either overstate the claim (running from the year's start) or understate it (running from the year's end). The weekly-tranche method instead treats each year's total as accruing evenly across it — consistent with how wages are actually paid — which for interest purposes is closely approximated by running the full year's figure from that year's midpoint (1 January). Full reasoning at Master Legal Brief F3.2.

Applying JPIDDA 2015 ss.4(2)/6(2) at the certified **2% per annum** rate (Arsenal Count 94), **simple** interest — consistent with National Court Rules O.4 r.10(2)'s general default — from each year's midpoint to 2 July 2026 produces the table below. Whether JPIDDA 2015 prescribes simple or compound interest remains open on the text sighted; if compound, the figures below are a conservative floor, not a ceiling. Note: ss.4(4)/6(6) make a judgment exceeding 2% against the State a nullity — this is a hard ceiling, not a starting point to argue up from.

| Financial Year | Annual Loss (AUD) | Accrual Midpoint | Years to 2 Jul 2026 | Interest @ 2% (AUD) |
|---|---|---|---|---|
| 2016–17 | $42,047 | 1 Jan 2017 | 9.5 | $7,989 |
| 2017–18 | $43,436 | 1 Jan 2018 | 8.5 | $7,384 |
| 2018–19 | $44,962 | 1 Jan 2019 | 7.5 | $6,744 |
| 2019–20 | $46,291 | 1 Jan 2020 | 6.5 | $6,018 |
| 2020–21 | $47,120 | 1 Jan 2021 | 5.5 | $5,183 |
| 2021–22 | $48,279 | 1 Jan 2022 | 4.5 | $4,345 |
| 2022–23 | $50,788 | 1 Jan 2023 | 3.5 | $3,555 |
| 2023–24 | $55,176 | 1 Jan 2024 | 2.5 | $2,759 |
| 2024–25 | $57,247 | 1 Jan 2025 | 1.5 | $1,717 |
| 2025–26 | $59,262 | 1 Jan 2026 | 0.5 | $593 |
| **Total interest** | | | | **≈ AUD $46,287** |

**Principal plus interest: ≈ AUD $540,895 (≈ K1,637,073 at the 2 July 2026 BPNG rate used at §3.2.4).** This is a worked calculation to confirm methodology and order of magnitude — not a final figure. Counsel or an instructed actuary should confirm whether JPIDDA 2015 prescribes simple or compound interest, and recompute to the actual date of filing or judgment. If compound interest is confirmed to apply, the figure would be modestly higher than shown here.

**Continuing loss, 2026–27 to judgment.** As above, pro-rated at the FY2026–27 casual rate ($33.05/hr) once the judgment date is known. To be finalised nearer trial.

**Future loss of earning capacity.** Richard is currently 44 (date of birth 10 April 1982, corroborated by identity documents already in evidence). The ten-year absence from the Australian labour market is established at §3.2.1–3.2.3 above. But for the Respondents' conduct he would have remained continuously employed across that decade, insulated from age as a hiring barrier because no hiring decision would ever have been made — that barrier attaches to entering the labour market, not to continuing within it. His actual position is a cold-start job search at 44 with a ten-year gap, which measurably narrows prospects relative to a continuously-employed candidate of the same age. This is not a physical limitation — Richard has no injury or health condition and remains as capable of the same work as at any younger age — the barrier is evidentiary: an age and an employment gap that, combined, are difficult to overcome on paper, and that do not diminish with further time. Full reasoning at Master Legal Brief F3.4. **Counsel should consider whether to press a specific future-loss claim on this basis and on what quantum** — no figure or multiplier is proposed here. Beyond the calculable heads above, the lost decade carries further financial consequences that resist precise quantification — foregone superannuation accrual, investment and savings opportunities, and the general compounding effect of lost time on long-term financial security. These are not separately claimed or quantified; they illustrate that the true scope of harm exceeds what the wage-and-interest figures alone capture.

But for the unlawful confinement, Richard would have been in Australia, free to work under s.48, earning at least the National Minimum Wage, casual rate, from approximately 2016 onward. This is the clearest possible application of the test in Part 2.1, and it is now anchored to a year-by-year, officially-sourced calculation rather than a single approximated figure.

### 3.3 The Bond Debt — Immediate/Mechanical

The bond's resolution depends on which of two relief paths succeeds, and the two are mutually exclusive as to the principal — the same K1,000 cannot be both offset against the visa fee and repaid in full. Interest for the wrongful-withholding period is payable under either path, since the loss of use of the funds during that period is a distinct harm from how the principal is eventually applied.

| Item | Path A — Mandamus succeeds (offset against K255 fee; Master Brief F1) | Path B — Mandamus fails or is not granted |
|---|---|---|
| Principal disposition | K255.00 satisfies the fee; K745.00 refunded | K1,000.00 refunded in full |
| Interest from 9 March 2020 (maturity) | JPIDDA 2015 ss.4(2)/6(2); ~K126 total to 2 July 2026 at the certified 2% simple rate used at §3.2.5 (rising; Arsenal Count 94), on the full K1,000 | Same |
| Additional compensation for the extended unlawful withholding | Not applicable — resolved via offset | Available in principle; connects to, and should not duplicate, the community-loan-interest item at §3.4; counsel to assess separate quantum if pressed |
| Limitation posture | (A) — April 2021 acknowledgment (Sapaka's validation email) resets any limitation clock; additionally tolled under Underlying Law Act s.7(4) | Same |

Pleaded in the alternative: Path A as primary, matching the Mandamus already sought at Master Brief F1; Path B as the fallback if that relief is refused.

### 3.4 Special Damages — Out-of-Pocket — Immediate/Mechanical

| Item | Breach Count Basis | Limitation | Estimate (K) |
|---|---|---|---|
| Two Port Moresby return trips (2022, 2023) | PNGICSA Count 79 | (A) | 2,000–4,000 |
| Communication costs across ~6 years of correspondence with both agencies | PNGICSA Count 79; PNGCIR Count 61 | (A) | 1,500–3,000 |
| Suit pants and shoes purchased under duress to enter PNGICSA premises (Oct 2023) | PNGICSA Count 79 | (A) | 200–400 |
| Interest/fees on informal high-interest community loans taken during acute crisis periods | PNGICSA Counts 78–79; PNGCIR Count 61 | (A) | TBC — claimant to itemise if records exist |

Each of these costs would not have been incurred but for the confinement and the State agencies' own conduct that necessitated incurring them.

### 3.5 Non-Economic / General Damages

| Harm | Connection Strength | Basis | Note |
|---|---|---|---|
| Administrative captivity itself (consequential, via children's s.52 breach) | Immediate/mechanical | PNGICSA Count 18 | Anchors general damages |
| Bereavement — father's death 10 April 2022, unable to attend funeral | Immediate/mechanical | PNGCIR Counts 11–15 | The inability to travel is the direct mechanical consequence of certificate refusal |
| Decade-long isolation from Australian family | Immediate/mechanical | Same | Ongoing |
| Knife assault, and resulting anxiety/depression/hypervigilance | Intervening-actor environmental | PNGCIR Counts 1–10 | But for the confinement, the family would not have remained in this specific high-crime area, in poverty, with no capacity to relocate within or beyond PNG. The assailant's identity is unrelated to the Respondents, but the family's continued exposure to that risk is the proven, foreseeable product of confinement (Affidavit paras 62–65). |
| Cumulative psychological harm / dehumanisation (Affidavit para 85) | Immediate/mechanical, evidenced throughout by the intervening-actor events above | All counts cumulatively | The confinement itself satisfies the test directly; the specific incidents demonstrate its severity |

**Working estimate, Richard's general/non-economic damages: K150,000–K300,000**, informed by the comparable National Court judgment (Waigani 2025, Makail J) and the duration/severity of sustained decade-long multi-agency conduct.

---

## PART 4 — SERAH SHARON AKUT (Second Applicant)

### 4.1 Constitutional and Statutory Rights Engaged

| Provision | Breach Counts | Limitation | Note |
|---|---|---|---|
| s.52 (freedom of movement — citizen) | PNGCIR Count 15 | (A) | Direct s.52 claim as a PNG citizen — sufficient on its own, no derivative reasoning required |
| s.41 (proscribed acts) | Derivative of institutional counts | (A) | As a directly affected family member |
| Lukautim Pikinini Act ss.5, 7, 8 | PNGICSA Counts 84–86 | (A) | As mother and primary advocate in many direct dealings with both agencies |

### 4.2 Freedom of Movement — Immediate/Mechanical

PNGCIR's failure to register the children's births made it impossible for Serah, a PNG citizen, to travel internationally with her family — but for that confinement, she would have relocated to Australia with Richard as originally planned. No derivative reasoning required.

**Limitation posture: (A).** Continuing breach, ~2016–present (~10 years, ongoing).

**Working estimate: K50,000–K100,000.**

### 4.3 Business Loss

Serah's IT business was a deliberately planned, integral component of the family's strategy for sustaining themselves and funding their relocation to Australia (Affidavit paras 5, 11). Applying the test in Part 2.1 to each stage:

1. **Pre-arrival visa delay** (lost original office space) — occurred before confinement began and involves a non-Respondent (the High Commission). **Falls outside the test entirely (Part 2.3) — pattern evidence only**, relevant to corroborating the broader institutional dysfunction the family encountered, not pleaded as a quantified head.
2. **IPA agent fraud / two-year registration delay** (lost second-tier office space) — non-Respondent private entity. **Falls outside the test entirely — pattern evidence only.**
3. **Landlord's unlawful eviction and year-long withholding of equipment (2022)** — but for the confinement-caused poverty already in place by this point (Part A1 of the Affidavit; the bond withheld since 2021, the years of registration costs already absorbed), the family would have had the financial resilience to pursue the landlord to full resolution, relocate the business promptly, or absorb the loss without lasting consequence. The Public Solicitor's own file was closed not because the landlord's conduct was lawful, but because the family lacked the capacity to pursue it further (Affidavit para 13) — itself a poverty-caused outcome. **Intervening-actor environmental connection** — satisfies the test.
4. **Ongoing deterioration of equipment in storage** — a continuing consequence of (3), same connection.

**Working estimate: K15,000–K35,000** for items 3–4, covering the diminished value of the equipment and the lost capacity to operate the business at sustainable scale during the relevant period. Requires Serah's input on original equipment costs. Items 1–2 remain pattern evidence only and are not included in this figure.

### 4.4 Special Damages

| Item | Note | Limitation |
|---|---|---|
| Informal loan interest arranged by Serah | Cross-reference Richard's 3.4 — counsel to allocate to avoid double-counting; arguably better pleaded as Serah's claim given she arranged the loans | (A) |
| November 2022 Port Moresby trip by public transport | Cross-reference Richard's 3.4 — confirm allocation, made by Serah alone | (A) |

---

## PART 5 — JAMES ALEXANDER KUREK (Third Applicant)

### 5.1 Constitutional and Statutory Rights Engaged

| Provision | Breach Counts | Limitation | Note |
|---|---|---|---|
| s.52 (freedom of movement) | PNGCIR Count 11 | (A) | Longest duration of any applicant — birth 9 March 2016, ~10 years ongoing |
| s.53 (property — birth certificate as legal identity document) | PNGCIR Count 16 | (A) | |
| s.35/s.36 (life / inhuman treatment, derivative) | PNGCIR Count 1, 2 | (A) | |
| Lukautim Pikinini Act ss.5, 7 | PNGICSA Counts 84–85 | (A) | Best interests, right to live with parents |

### 5.2 Freedom of Movement / De Facto Statelessness — Immediate/Mechanical

**Duration: 9 March 2016 – present, ongoing (~10 years)** — the single longest-duration breach in the case. James has spent his entire childhood to date without legal identity documentation, directly traceable to PNGCIR's unlawful conduct.

**Working estimate: K60,000–K100,000** — upper end of the children's general damages range given duration.

### 5.3 Specific Physical and Psychological Harm

| Harm | Connection Strength | Note |
|---|---|---|
| Witnessed father's knife assault | Intervening-actor environmental | But for the confinement and resulting poverty, the family would not have remained in this environment, exposed to this risk |
| Scabies infection | Single-step environmental | Flows from poverty/inadequate access to medication and hygiene — no human actor intervenes |
| Lip laceration during blackout; permanent facial scar | Mixed — fall itself is single-step environmental (absence of electricity, itself confinement-caused); permanence of the scar is intervening-actor environmental (standard of treatment available) | Both satisfy the test; recorded separately for precision |
| Lost kindergarten/pre-school years | Single-step environmental | Flows from poverty |
| Mild dyslexia — no access to assessment/support resources available in Australia | Single-step environmental, as to lost access to support | No claim that confinement caused the condition itself |

**Working estimate, James's non-economic damages: K45,000–K75,000.**

---

## PART 6 — ZACH LIAM KUREK (Fourth Applicant)

### 6.1 Constitutional and Statutory Rights Engaged

| Provision | Breach Counts | Limitation | Note |
|---|---|---|---|
| s.52 (freedom of movement) | PNGCIR Count 12 | (A) | Birth 12 June 2021, ~5 years ongoing |
| s.53 (property) | PNGCIR Count 16 | (A) | |
| s.36 (inhuman treatment, derivative) | PNGCIR Count 2 | (A) | |
| Lukautim Pikinini Act ss.5, 7 | PNGICSA Counts 84–85 | (A) | |

### 6.2 Freedom of Movement — Immediate/Mechanical

**Duration: 12 June 2021 – present (~5 years, ongoing).**

**Working estimate: K40,000–K70,000.**

### 6.3 Specific Physical Harm

| Harm | Connection Strength | Note |
|---|---|---|
| Scabies infection, particularly severe, permanent scarring | Single-step environmental | Among the most severely affected of the three children — flows directly from poverty-caused inability to access medication for approximately two and a half years |
| Nutritional deprivation | Single-step environmental | Flows from poverty |
| Lost kindergarten/pre-school years | Single-step environmental | Not yet of school age; flows from poverty and confinement |

**Note for counsel:** Zach's individually distinct evidentiary record is narrower than his brothers' — he is not currently documented as having suffered a discrete physical injury beyond the scabies common to all three children. This should not be read as reflecting a lesser harm; his claim rests more heavily on the single-step environmental heads than on an intervening-actor incident.

**Working estimate, Zach's non-economic damages: K30,000–K50,000.**

---

## PART 7 — BRIGHTON REECE KUREK (Fifth Applicant)

### 7.1 Constitutional and Statutory Rights Engaged

| Provision | Breach Counts | Limitation | Note |
|---|---|---|---|
| s.52 (freedom of movement) | PNGCIR Count 13 | (A) | Birth 12 June 2021, ~5 years ongoing |
| s.53 (property) | PNGCIR Count 16 | (A) | |
| s.36 (inhuman treatment, derivative) | PNGCIR Count 2 | (A) | |
| Lukautim Pikinini Act ss.5, 7 | PNGICSA Counts 84–85 | (A) | |

### 7.2 Freedom of Movement — Immediate/Mechanical

**Duration: 12 June 2021 – present (~5 years, ongoing).**

**Working estimate: K40,000–K70,000.**

### 7.3 Specific Physical Harm — Strongest Objectively-Evidenced Outcome in the Case

| Harm | Connection Strength | Note |
|---|---|---|
| Right arm fracture, no reduction attempted before casting; permanent deformity confirmed by x-ray (approx. 17° angulation, claimant's non-expert estimate); failed manipulation procedure | Intervening-actor environmental | But for the confinement and resulting poverty, the family would have had access to, at minimum, an Australian standard of orthopaedic care, the ability to seek a second opinion, or the ability to return to Australia for treatment. The Affidavit (para 74) establishes this directly: the standard of care available "would not have been acceptable in Australia." This is not a clinical negligence claim against the treating hospital; it is a damages consequence of the proven confinement, evidenced by the outcome. |
| Scabies infection, particularly severe, permanent scarring | Single-step environmental | As for Zach |

**This is the strongest objectively-evidenced individual physical outcome in the case** — not because any Respondent is alleged to have caused the fracture or the clinical decision directly, but because the x-rays provide independent, permanent, visual confirmation of exactly the category of harm the Affidavit identifies as foreseeable in this environment. That evidentiary strength goes to quantum, not to an expansion of who is liable or on what theory.

**Working estimate, Brighton's non-economic damages: K50,000–K85,000** — upper end of the children's individual range given the objective, permanent, and well-evidenced nature of the outcome.

---

## PART 8 — CONSOLIDATED SUMMARY TABLE

| Applicant | Economic Loss | Bond/Debt | Special Damages | General/Non-Economic | Subtotal (K, working range) |
|---|---|---|---|---|---|
| Richard | AUD $494,608+ ≈ **K1,496,998** at 2 Jul 2026 BPNG rate (10 completed FYs at 50/52 weeks, principal only — see Part 3.2; excludes interest, partial FY2026-27, and future loss) | K1,126 (K1,000 principal + ~K126 interest at the certified 2% rate, Path B — see §3.3) | K4,000–8,000 | K150,000–300,000 | **K1,652,124–K1,806,124** (at 2 Jul 2026 rate; will shift with the date ultimately used) |
| Serah | — | — | (allocation to be confirmed with Richard's, see 4.4) | 50,000–100,000 + 15,000–35,000 (business) | **65,000–135,000** |
| James | — | — | — | 45,000–75,000 (physical/psych) + 60,000–100,000 (movement) | **105,000–175,000** |
| Zach | — | — | — | 30,000–50,000 (physical) + 40,000–70,000 (movement) | **70,000–120,000** |
| Brighton | — | — | — | 50,000–85,000 (physical) + 40,000–70,000 (movement) | **90,000–155,000** |
| **Family total (excl. exemplary, excl. final actuarial interest run)** | | | | | **K1,982,124–K2,391,124** (K485,126–K894,126 Kina-denominated components, all applicants, plus Richard's AUD $494,608+ economic loss converted at the 2 Jul 2026 BPNG rate of K1,496,998), before weekly-tranche interest (≈ K140,092 at the certified 2% rate — see §3.2.5), before the partial FY2026-27 component, and before any future loss the Court elects to award |

**Exemplary damages** (CBASA s.12(1); Premdas) are pleaded separately; the threshold is established at Master Legal Brief F4, with K100,000–K200,000 proposed here as a working range.

**Adding exemplary damages (K100,000–K200,000) to the K1,982,124–K2,391,124 family total above gives K2,082,124–K2,591,124, using the 2 July 2026 BPNG rate.** This is before weekly-tranche interest (≈ K140,092 at the certified 2% rate — see §3.2.5), before the partial FY2026-27 period, and before any future-loss sum the Court may elect to award — each of which adds further, not less. Counsel should treat this range as a conservative floor for this claim, not a ceiling, and should re-run the AUD-to-Kina conversion at whatever date is ultimately confirmed for National Court practice, noting that PGK's historical weakness against AUD makes a later rate more likely to increase this figure than reduce it.**

---

## PART 9 — ITEMS FLAGGED FOR COUNSEL'S SPECIFIC ATTENTION

1. **The single counterfactual test (Part 2)** underpins every harm in this document. Counsel should confirm the test and its application — particularly to the "intervening-actor environmental" category (Richard's assault, James's facial scar, Brighton's arm, Serah's business loss) — is sound as a matter of PNG tort and constitutional principle before finalising pleadings. The test itself is conventional (ordinary "but for" causation); what counsel should specifically test is whether the chain to each intervening-actor item is short and direct enough to survive scrutiny, or whether some should be pleaded with more caution than others.
2. **Double-counting risk** between Richard's and Serah's special damages (informal loans, Port Moresby travel) — needs a single clear allocation before pleading.
3. **The weekly-tranche interest methodology (§3.2.5; Master Brief F3.2)** is now drafted at the certified **2% rate**, confirmed directly against the primary text of the 2015 Act (No. 15 of 2015) — ss.4(2) and 6(2) both cap State interest at 2%, applying retrospectively to State orders from 1 January 2014 (s.2). Do not plead a higher rate: ss.4(4)/6(6) make an excessive judgment against the State a nullity. Counsel should confirm whether the Act prescribes simple or compound interest, then recompute to the actual filing/judgment date. **The future loss head (§3.2.5; Master Brief F3.4)** rests on the continuous-employment-counterfactual argument, with no figure or multiplier proposed — flagged directly to counsel for a decision on whether and how to press it. The Coady and Koko Kopele citations in F3.4 are for the precedent that this head of loss is claimable and assessed on this basis, not for specific holding language. **The 50/52-week attendance rate (§3.2.1 point 6; §3.2.3)** is a considered adjustment, not a cited PNG rate — counsel should confirm it is the right approach before filing, in preference to either the unadjusted 52/52 figure or a larger, uncited discount.
4. **Expert evidence** — Brighton's x-rays may benefit from a short independent expert opinion (even a desk review) confirming the angulation and its permanence, strengthening the quantum evidence without requiring any clinical negligence framing.
5. **The duration/severity argument** (Part 1.0 above) — that a decade of continuous multi-agency bad faith is qualitatively more serious than a single severe event — should be an explicit submission on quantum, not left implicit.
6. **Pattern-only evidence (Part 2.3)** — the pre-arrival visa delay and the IPA agent fraud — remains valuable even though unquantified, as it rebuts any State suggestion that the family's difficulties only began once the named Respondents became involved; the same pattern of institutional dysfunction was present from the family's very first contact with PNG processes.
